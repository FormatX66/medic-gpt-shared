// Medic Bridge — background service worker.
// Toolbar icon click = same as the on-page "Send to Medic" button.
chrome.action.onClicked.addListener(async (tab) => {
  try {
    await chrome.tabs.sendMessage(tab.id, { type: 'SEND_TO_MEDIC' });
  } catch (e) {
    chrome.runtime.openOptionsPage();
  }
});

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg && msg.type === 'OPEN_OPTIONS') { chrome.runtime.openOptionsPage(); return; }
  if (msg && msg.type === 'MEDIC_DROP') {
    // The service worker performs the cross-origin POST (it may use host
    // permissions; content scripts are bound by the page's same-origin
    // policy). Endpoint/token come from storage — never from the message —
    // so a page cannot steer the request to an arbitrary URL.
    (async () => {
      try {
        const stored = await chrome.storage.sync.get(['endpoint', 'token']);
        const endpoint = (stored.endpoint || 'http://localhost:8471').replace(/\/+$/, '');
        const token = stored.token || '';
        const res = await fetch(endpoint + '/drop', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'X-Medic-Token': token },
          body: JSON.stringify(msg.conv)
        });
        const j = await res.json().catch(() => ({}));
        sendResponse(res.ok ? { ok: true } : { ok: false, error: j.error || ('HTTP ' + res.status) });
      } catch (e) {
        sendResponse({ ok: false, error: (e && e.message) || String(e) });
      }
    })();
    return true; // async response
  }
});

// ---- Bilateral replies: poll the relay, show Medic's replies ---------------
const REPLY_ALARM = 'medic-reply-poll';

async function pollReplies() {
  try {
    const stored = await chrome.storage.sync.get(['endpoint', 'token']);
    const endpoint = (stored.endpoint || 'http://localhost:8471').replace(/\/+$/, '');
    const token = stored.token || '';
    const res = await fetch(endpoint + '/replies', { headers: { 'X-Medic-Token': token } });
    if (!res.ok) return;
    const j = await res.json().catch(() => ({}));
    for (const r of (j.replies || [])) {
      if (!r || !r.id) continue;
      await chrome.notifications.create('medic-reply-' + r.id, {
        type: 'basic',
        title: 'Medic',
        message: String(r.message || '(empty reply)').slice(0, 200)
      });
      await fetch(endpoint + '/reply/ack', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-Medic-Token': token },
        body: JSON.stringify({ id: r.id })
      }).catch(() => {});
    }
  } catch (e) { /* relay offline: try again next cycle */ }
}

chrome.alarms.onAlarm.addListener((a) => { if (a.name === REPLY_ALARM) pollReplies(); });
chrome.runtime.onStartup.addListener(() => {
  chrome.alarms.create(REPLY_ALARM, { periodInMinutes: 1 });
  pollReplies();
});
chrome.runtime.onInstalled.addListener(() => {
  chrome.alarms.create(REPLY_ALARM, { periodInMinutes: 1 });
  pollReplies();
});
