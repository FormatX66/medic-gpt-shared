// Connection details are pre-filled — normally nothing to change here.
const DEFAULT_ENDPOINT = 'https://webhook.site/30c5428b-b348-4ec2-bc13-de2bf464d570';
const DEFAULT_TOKEN = 'n5jIU3yh7KAZhK4FpUmIX2YWvhjN4rm3';

document.addEventListener('DOMContentLoaded', () => {
  chrome.storage.sync.get(['endpoint', 'token'], (r) => {
    document.getElementById('endpoint').value = r.endpoint || DEFAULT_ENDPOINT;
    document.getElementById('token').value = r.token || DEFAULT_TOKEN;
  });
  document.getElementById('save').addEventListener('click', () => {
    const endpoint = document.getElementById('endpoint').value.trim().replace(/\/+$/, '');
    const token = document.getElementById('token').value.trim();
    if (!endpoint) { document.getElementById('status').textContent = 'Please enter your relay URL first.'; return; }
    chrome.storage.sync.set({ endpoint, token }, () => {
      document.getElementById('status').textContent = 'Saved ✓ — you can close this page.';
    });
  });
});
