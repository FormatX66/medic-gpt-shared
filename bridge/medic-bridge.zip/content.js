// Medic Bridge — works on ChatGPT, Claude, Gemini, Grok, Copilot, Perplexity,
// Mistral, Meta AI, Poe and other AI chat sites.
// Extracts the visible conversation and POSTs it to the Medic relay.
// Only ever runs when the user clicks "Send to Medic" — never automatically.

const DEFAULT_ENDPOINT = 'https://webhook.site/30c5428b-b348-4ec2-bc13-de2bf464d570';
const DEFAULT_TOKEN = 'n5jIU3yh7KAZhK4FpUmIX2YWvhjN4rm3';

const SITE_NAMES = {
  'chatgpt.com': 'ChatGPT', 'chat.openai.com': 'ChatGPT',
  'claude.ai': 'Claude',
  'gemini.google.com': 'Gemini',
  'grok.com': 'Grok',
  'copilot.microsoft.com': 'Copilot',
  'perplexity.ai': 'Perplexity', 'www.perplexity.ai': 'Perplexity',
  'chat.mistral.ai': 'Mistral',
  'meta.ai': 'Meta AI', 'www.meta.ai': 'Meta AI',
  'poe.com': 'Poe'
};

function siteName() {
  const h = location.hostname.toLowerCase();
  return SITE_NAMES[h] || h.replace(/^www\./, '');
}

function cleanTitle() {
  const t = (document.title || '').trim();
  const site = siteName();
  const cleaned = t.replace(new RegExp('\\s*[–—-]\\s*' + site.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '\\s*$', 'i'), '').trim();
  return cleaned || (site + ' conversation');
}

// Precise extractor (ChatGPT's stable DOM) — tried first.
function extractPrecise() {
  const out = [];
  document.querySelectorAll('article[data-message-author-role]').forEach((a) => {
    const role = a.getAttribute('data-message-author-role') === 'user' ? 'user' : 'assistant';
    const inner = a.querySelector('[data-message-id]') || a;
    const text = (inner.innerText || '').trim();
    if (text) out.push({ role, text });
  });
  return out;
}

function inferRole(el) {
  const parts = [
    el.getAttribute('data-message-author-role') || '',
    (el.dataset && (el.dataset.testid || el.dataset.role)) || '',
    typeof el.className === 'string' ? el.className : '',
    el.getAttribute('aria-label') || ''
  ].join(' ').toLowerCase();
  if (/\buser\b|\bhuman\b/.test(parts)) return 'user';
  if (/\bassistant\b|\bmodel\b/.test(parts)) return 'assistant';
  return 'unknown';
}

// Generic extractor for every other model: find message-like blocks,
// keep the outermost, drop duplicates.
const CANDIDATE_SELECTORS = [
  '[data-message-author-role]',
  '[data-testid*="user-message"]',
  '[data-testid*="assistant-message"]',
  '[data-testid*="ai-message"]',
  '[data-testid*="conversation-turn"]',
  '[data-message-id]',
  'div[data-turn]',
  'article'
];

function extractGeneric() {
  const els = Array.from(document.querySelectorAll(CANDIDATE_SELECTORS.join(',')));
  const outer = els.filter((el) => !els.some((o) => o !== el && o.contains(el)));
  const seen = new Set();
  const out = [];
  for (const el of outer) {
    const text = (el.innerText || '').trim();
    if (text.length < 2 || seen.has(text)) continue;
    seen.add(text);
    out.push({ role: inferRole(el), text });
  }
  return out;
}

function extractConversation() {
  let turns = extractPrecise();
  if (turns.length === 0) turns = extractGeneric();
  return {
    site: siteName(),
    title: cleanTitle(),
    url: location.href,
    exported_at: new Date().toISOString(),
    turns
  };
}

function toMarkdown(conv) {
  let md = `# ${conv.title}\n\nModel: ${conv.site}\nSource: ${conv.url}\nExported: ${conv.exported_at}\n\n---\n\n`;
  for (const t of conv.turns) {
    const who = t.role === 'user' ? 'You' : t.role === 'assistant' ? conv.site : 'Message';
    md += `## ${who}\n\n${t.text}\n\n`;
  }
  return md;
}

function flash(msg, ok) {
  const b = document.getElementById('medic-bridge-btn');
  if (!b) return;
  const orig = b.dataset.label || 'Send to Medic';
  b.dataset.label = orig;
  b.textContent = msg;
  b.style.background = ok ? '#16a34a' : '#dc2626';
  setTimeout(() => { b.textContent = orig; b.style.background = '#10a37f'; }, 3000);
}

async function sendToMedic() {
  flash('Sending…', true);
  try {
    const conv = extractConversation();
    if (conv.turns.length === 0) { flash('No conversation found', false); return; }
    conv.markdown = toMarkdown(conv);
    // Network goes through the background service worker (Chrome treats
    // content-script fetches as page-origin CORS requests; the service
    // worker may use host permissions instead).
    const res = await chrome.runtime.sendMessage({ type: 'MEDIC_DROP', conv });
    if (res && res.ok) flash('Sent to Medic ✓', true);
    else flash('Failed: ' + ((res && res.error) || 'relay unreachable'), false);
  } catch (e) {
    flash('Failed: ' + (e && e.message ? e.message : e), false);
  }
}

function injectButton() {
  if (document.getElementById('medic-bridge-btn')) return;
  if (!document.body) return;
  const b = document.createElement('button');
  b.id = 'medic-bridge-btn';
  b.textContent = 'Send to Medic';
  b.title = 'Send this AI conversation to Medic';
  b.style.cssText = 'position:fixed;right:20px;bottom:96px;z-index:999999;padding:10px 18px;border-radius:999px;border:none;background:#10a37f;color:#fff;font-weight:600;font-size:14px;cursor:pointer;box-shadow:0 4px 14px rgba(0,0,0,.25);font-family:system-ui,sans-serif;';
  b.addEventListener('click', sendToMedic);
  document.body.appendChild(b);
}

injectButton();
new MutationObserver(injectButton).observe(document.documentElement, { childList: true, subtree: true });

chrome.runtime.onMessage.addListener((msg) => {
  if (msg && msg.type === 'SEND_TO_MEDIC') sendToMedic();
});
