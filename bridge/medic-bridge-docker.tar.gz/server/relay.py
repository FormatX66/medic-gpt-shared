#!/usr/bin/env python3
"""Medic Bridge relay — receives AI conversation drops from the browser extension.

POST /drop        JSON body {site, title, url, exported_at, turns, markdown},
                  header X-Medic-Token. Saves to inbox/ as .json + .md.
GET  /drops       Auth required. Lists saved drops (metadata).
GET  /drop?id=X  Auth required. Returns one saved drop as JSON.
GET  /health      Liveness check.
POST /reply       Auth required. Store a Medic reply {message, to_drop?}.
GET  /replies     Auth required. List unacknowledged replies for the extension.
POST /reply/ack   Auth required. Acknowledge (remove) a reply by {id}.

Bilateral replies: Medic cannot reach this relay directly, so a background
thread polls the cloud bus (derived from FORWARD_URL) for {"type":
"medic-reply"} messages and imports them into replies/. The browser
extension polls GET /replies and shows them as notifications.

Environment:
  HOST, PORT             Bind address/port (defaults: 127.0.0.1, 8471).
  MEDIC_BRIDGE_TOKEN     Required bearer token (header X-Medic-Token).
  FORWARD_URL            Optional: every accepted drop is also POSTed here
                         (e.g. the cloud relay Medic polls).
  FORWARD_TOKEN          Optional token header value for the forward request.

Stdlib only. In Docker, run with HOST=0.0.0.0 and an inbox volume.
"""
import json
import os
import re
import shutil
import subprocess
import sys
import threading
import time
import urllib.parse
import urllib.request
import uuid
from datetime import datetime
from http.server import BaseHTTPRequestHandler, HTTPServer

BASE = os.path.dirname(os.path.abspath(__file__))
INBOX = os.path.join(BASE, "inbox")
REPLIES = os.path.join(BASE, "replies")
IMPORTED = os.path.join(REPLIES, ".imported")
TOKEN = os.environ.get("MEDIC_BRIDGE_TOKEN", "")
FORWARD_URL = os.environ.get("FORWARD_URL", "")
FORWARD_TOKEN = os.environ.get("FORWARD_TOKEN", "")
REPLY_POLL_URL = os.environ.get("REPLY_POLL_URL", "")
REPLY_POLL_SECONDS = int(os.environ.get("REPLY_POLL_SECONDS", "60"))
os.makedirs(INBOX, exist_ok=True)
os.makedirs(REPLIES, exist_ok=True)


def forward_drop(payload):
    """Best-effort forward of an accepted drop (runs in a thread)."""
    if not FORWARD_URL:
        return
    try:
        req = urllib.request.Request(
            FORWARD_URL,
            data=json.dumps(payload).encode(),
            headers={"Content-Type": "application/json",
                     "X-Medic-Token": FORWARD_TOKEN},
        )
        with urllib.request.urlopen(req, timeout=15):
            pass
    except Exception:
        pass  # never fail the local save because forwarding failed


def load_drop(base):
    path = os.path.join(INBOX, base + ".json")
    if not os.path.exists(path) or ".." in base or "/" in base:
        return None
    with open(path) as f:
        return json.load(f)


# ---- Bilateral replies: Medic -> bus -> relay -> extension -----------------
# Medic cannot reach this relay directly (it lives on the user's machine), so
# replies travel the reverse path over the same cloud bus the drops use:
# Medic POSTs {"type":"medic-reply",...} to the webhook.site bin, this relay
# polls the bin and imports new replies, and the browser extension polls
# GET /replies and surfaces them as notifications.

def _imported_uuids():
    if not os.path.exists(IMPORTED):
        return set()
    with open(IMPORTED) as f:
        return {line.strip() for line in f if line.strip()}


def _mark_imported(uid):
    with open(IMPORTED, "a") as f:
        f.write(uid + "\n")


def _bus_poll_url():
    if REPLY_POLL_URL:
        return REPLY_POLL_URL
    m = re.match(r"https://webhook\.site/([0-9a-fA-F-]{36})", FORWARD_URL or "")
    if m:
        return f"https://webhook.site/token/{m.group(1)}/requests?sorting=newest"
    return ""


def save_reply(reply):
    rid = str(reply.get("id") or uuid.uuid4().hex[:12])
    path = os.path.join(REPLIES, rid + ".json")
    if os.path.exists(path):
        return None
    doc = dict(reply)
    doc["id"] = rid
    doc.setdefault("created_at", datetime.now().isoformat(timespec="seconds"))
    with open(path, "w") as f:
        json.dump(doc, f, ensure_ascii=False, indent=2)
    return rid


def list_replies():
    out = []
    for fn in sorted(os.listdir(REPLIES)):
        if not fn.endswith(".json"):
            continue
        try:
            with open(os.path.join(REPLIES, fn)) as f:
                out.append(json.load(f))
        except Exception:
            continue
    return out


def ack_reply(rid):
    if not rid or ".." in str(rid) or "/" in str(rid):
        return False
    path = os.path.join(REPLIES, str(rid) + ".json")
    if os.path.exists(path):
        os.remove(path)
        return True
    return False


def bus_fetch_json(url):
    # webhook.site's bot protection drops connections from Python's TLS
    # fingerprint but allows curl's, so prefer curl and fall back to urllib.
    if shutil.which("curl"):
        try:
            out = subprocess.run(
                ["curl", "-s", "--max-time", "25", "-A", "medic-bridge/1.0", url],
                capture_output=True, text=True, timeout=30)
            if out.returncode == 0 and out.stdout.strip():
                return json.loads(out.stdout)
        except Exception:
            pass
    req = urllib.request.Request(url, headers={"User-Agent": "medic-bridge/1.0"})
    with urllib.request.urlopen(req, timeout=25) as resp:
        return json.load(resp)


def poll_bus_once():
    url = _bus_poll_url()
    if not url:
        return 0
    try:
        data = bus_fetch_json(url)
    except Exception as e:
        print(f"[reply-poll] bus unreachable: {e}", flush=True)
        return 0
    imported = _imported_uuids()
    n = 0
    for r in data.get("data", []):
        uid = r.get("uuid")
        if not uid or uid in imported:
            continue
        try:
            body = json.loads(r.get("content") or "{}")
        except Exception:
            body = {}
        _mark_imported(uid)
        imported.add(uid)
        if isinstance(body, dict) and body.get("type") == "medic-reply":
            if save_reply({"message": body.get("message", ""),
                           "to_drop": body.get("to_drop"),
                           "source": "bus", "bus_uuid": uid}):
                n += 1
                print(f"[reply-poll] imported reply {uid[:8]}", flush=True)
    return n


def poll_bus_loop():
    while True:
        try:
            poll_bus_once()
        except Exception as e:
            print(f"[reply-poll] error: {e}", flush=True)
        time.sleep(REPLY_POLL_SECONDS)


class Handler(BaseHTTPRequestHandler):
    CORS_HEADERS = {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type, X-Medic-Token",
    }

    def _send(self, code, obj):
        body = json.dumps(obj).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        for k, v in self.CORS_HEADERS.items():
            if k != "Access-Control-Allow-Headers":
                self.send_header(k, v)
        self.end_headers()
        self.wfile.write(body)

    def do_OPTIONS(self):
        # CORS preflight (e.g. browser extension content-script fetch with
        # Content-Type: application/json + X-Medic-Token header).
        self.send_response(204)
        for k, v in self.CORS_HEADERS.items():
            self.send_header(k, v)
        self.send_header("Content-Length", "0")
        self.end_headers()

    def _authed(self):
        return bool(TOKEN) and self.headers.get("X-Medic-Token") == TOKEN

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        if parsed.path == "/health":
            return self._send(200, {"ok": True})
        if parsed.path == "/drops":
            if not self._authed():
                return self._send(401, {"ok": False})
            drops = []
            for f in sorted(os.listdir(INBOX)):
                if not f.endswith(".json"):
                    continue
                try:
                    d = load_drop(f[:-5])
                    drops.append({"id": f[:-5],
                                  "title": d.get("title"),
                                  "site": d.get("site"),
                                  "turns": len(d.get("turns", [])),
                                  "exported_at": d.get("exported_at")})
                except Exception:
                    continue
            return self._send(200, {"ok": True, "drops": drops})
        if parsed.path == "/drop":
            if not self._authed():
                return self._send(401, {"ok": False})
            q = urllib.parse.parse_qs(parsed.query)
            d = load_drop((q.get("id") or [""])[0])
            if d is None:
                return self._send(404, {"ok": False})
            return self._send(200, {"ok": True, "drop": d})
        if parsed.path == "/replies":
            if not self._authed():
                return self._send(401, {"ok": False})
            return self._send(200, {"ok": True, "replies": list_replies()})
        return self._send(404, {"ok": False})

    def do_POST(self):
        path = urllib.parse.urlparse(self.path).path
        if path == "/reply/ack":
            if not self._authed():
                return self._send(401, {"ok": False})
            length = int(self.headers.get("Content-Length", 0) or 0)
            try:
                data = json.loads(self.rfile.read(length) or b"{}")
            except Exception:
                return self._send(400, {"ok": False})
            return self._send(200, {"ok": ack_reply(data.get("id"))})
        if path == "/reply":
            if not self._authed():
                return self._send(401, {"ok": False})
            length = int(self.headers.get("Content-Length", 0) or 0)
            try:
                data = json.loads(self.rfile.read(length) or b"{}")
            except Exception:
                return self._send(400, {"ok": False, "error": "bad json"})
            if not isinstance(data, dict) or not data.get("message"):
                return self._send(400, {"ok": False, "error": "message required"})
            rid = save_reply({"message": data["message"],
                              "to_drop": data.get("to_drop"),
                              "source": "local"})
            return self._send(200, {"ok": True, "id": rid})
        if path != "/drop":
            return self._send(404, {"ok": False})
        if not self._authed():
            return self._send(401, {"ok": False, "error": "bad token"})
        length = int(self.headers.get("Content-Length", 0) or 0)
        try:
            data = json.loads(self.rfile.read(length) or b"{}")
        except Exception:
            return self._send(400, {"ok": False, "error": "bad json"})
        ts = datetime.now().strftime("%Y%m%d-%H%M%S")
        slug = re.sub(r"[^a-z0-9]+", "-", (data.get("title") or "chat").lower()).strip("-")[:40] or "chat"
        base = f"{ts}-{slug}"
        with open(os.path.join(INBOX, base + ".json"), "w") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        md = data.get("markdown") or json.dumps(data, ensure_ascii=False, indent=2)
        with open(os.path.join(INBOX, base + ".md"), "w") as f:
            f.write(md)
        threading.Thread(target=forward_drop, args=(data,), daemon=True).start()
        return self._send(200, {"ok": True, "saved": base})

    def log_message(self, *args):
        pass


if __name__ == "__main__":
    host = os.environ.get("HOST", "127.0.0.1")
    port = int(os.environ.get("PORT", "8471"))
    threading.Thread(target=poll_bus_loop, daemon=True).start()
    HTTPServer((host, port), Handler).serve_forever()
