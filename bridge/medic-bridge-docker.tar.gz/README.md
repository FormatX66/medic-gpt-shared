# Medic Bridge — self-hosted relay (Docker)

Receives AI conversation drops from the **Medic Bridge** browser extension
(works with ChatGPT, Claude, Gemini, Grok, Copilot, Perplexity, Mistral, Meta AI, Poe…).

How it fits together:

```
[extension in your browser] --POST--> [this relay in Docker :8471]
        |                                        |
        | saves private copy                     | forwards copy
        v                                        v
   inbox volume                        Medic's cloud relay -> Medic
```

Nothing leaves your machine except the forwarded copy that goes to Medic —
and only when you click **Send to Medic** in the extension. There is no
automatic sending.

## Setup

1. Copy the example env file and set a token (any long random string):

   ```bash
   cp .env.example .env
   # edit .env -> MEDIC_BRIDGE_TOKEN=...
   ```

   `FORWARD_URL` is pre-filled with Medic's cloud relay — leave it so he
   receives your drops.

2. Start it:

   ```bash
   docker compose up -d --build
   ```

3. Check it's alive:

   ```bash
   curl http://localhost:8471/health   # {"ok": true}
   ```

4. In the extension's **Options** page, set the relay URL to
   `http://localhost:8471` and paste the same token from `.env`, then Save.

That's it. Click **Send to Medic** on any AI chat page — the conversation is
saved to the `bridge-inbox` volume and forwarded to Medic.

## Bilateral replies (v1.2.0)

Communication now flows both ways. Medic's replies travel the reverse path
over the same cloud bus:

```
[Medic] --medic-reply--> [cloud bus] --poll--> [this relay] --poll--> [extension -> desktop notification]
```

- The relay polls the bus every 60 seconds for new `medic-reply` messages
  (tune with `REPLY_POLL_SECONDS`; override the poll URL with
  `REPLY_POLL_URL` if you ever change `FORWARD_URL` to a non-webhook.site target).
- The extension (v1.2.0+) polls the relay every minute and shows each reply
  as a desktop notification, then acknowledges it.
- Worst case a reply takes ~2 minutes to appear; usually under a minute.

## Useful commands

```bash
docker compose logs -f medic-bridge          # watch traffic
docker compose exec medic-bridge ls /app/inbox   # list saved drops
docker compose down                          # stop
```

## Files

- `Dockerfile` / `docker-compose.yml` — the relay service
- `server/relay.py` — the relay itself (Python, no pip deps; the image adds curl because webhook.site's bot protection drops Python's TLS fingerprint)
- `extension/` — the Chrome extension source (zip: `medic-bridge.zip`)
- `.env.example` — copy to `.env` and fill in
