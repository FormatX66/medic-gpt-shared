# Data Bridge Plugin v17

Symmetric bidirectional machine-to-machine bridge. Same code runs on both sides.
No LLM, no chat, zero ChatGPT usage.

## Architecture (v17)

```
Medic VM                        GitHub repo              Laptop
─────────                       ───────────              ──────
bridge_plugin.py ──API PUT────> bridge/medic-to-laptop/
  --side medic                   (message files)          bridge_plugin.py
        │                                                 --side laptop
        │  Laptop reads via `git pull` on a local clone      │
        │  (git protocol: no API rate limit, no token)       │
        │                                                    │ POST
        │<───────── webhook.site ────────────────────────────┘
   polls for responses              (laptop→medic only)
```

**Why this design:** webhook.site throttles under bidirectional polling load
(HTTP 429). v17 moves the high-volume direction (medic→laptop commands) to
GitHub repo files — reliable, authenticated, no rate-limit risk at our
message volume. The laptop needs no GitHub token: it `git pull`s the public
repo. Laptop→medic responses use webhook.site POST (much lower volume than
before; laptop queues to disk and retries on failure).

## Message Protocol

```json
{
  "id": "msg-medic-20260921T070000-0001",
  "from": "medic",
  "to": "laptop",
  "type": "mcp.tool.call",
  "payload": { "name": "get_raw_memory_status", "arguments": {} },
  "timestamp": "2026-09-21T07:00:00+00:00",
  "needs_ack": true
}
```

Responses carry `"in_reply_to": "<original id>"` and type `"<orig>.response"`.
A response IS the ack — no separate ack is sent when a response exists.

## Built-in Message Types

| Type | Direction | Purpose |
|------|-----------|---------|
| `ping` | medic→laptop | Health check |
| `event` | ↔ | Fire-and-forget notification |
| `learnings.export` | medic→laptop | Request ChatLearningStore export |
| `learnings.push` | laptop→medic | Push new learnings to Medic |
| `gamegpt.status` | medic→laptop | Report GameGPT system status |
| `dir.list` | medic→laptop | List a directory on the laptop |
| `file.search` | medic→laptop | Search for a file on the laptop |
| `mcp.status` | medic→laptop | Check GameGPT MCP server |
| `mcp.tools.list` | medic→laptop | List GameGPT MCP tools |
| `mcp.tool.call` | medic→laptop | Call a GameGPT MCP tool |

## Running

```bash
# Medic's VM (continuous)
python bridge_plugin.py --side medic --poll-secs 30

# Laptop (continuous) — needs git on PATH
python bridge_plugin.py --side laptop --poll-secs 20

# One-shot send (medic)
python bridge_plugin.py --side medic --send ping '{}'

# Check GitHub auth and exit
python bridge_plugin.py --side medic --check-auth
```

On the laptop, double-click `start-bridge.bat`. It self-updates from the repo,
checks for git, then starts the bridge.

## Reliability features (v17)

- **Medic→laptop:** GitHub Contents API with 5-attempt exponential-backoff
  retry. Raises loudly if all retries fail (message NOT silently lost).
- **Laptop inbox:** `git fetch` + `git reset --hard origin/main` (never merge);
  pull-then-read serialized; malformed files skipped and marked seen.
- **Laptop→medic:** webhook POST with curl hardening (`--data-binary`,
  timeouts, retries); failed POSTs queue to `webhook-queue/` on disk
  (bounded 200 files, FIFO) and flush on next success.
- **Heartbeat:** Medic writes `bridge/medic-to-laptop/_heartbeat.json` every
  ~5 min; laptop warns if it's >10 min stale (Medic may be down).
- **Deduplication:** both sides keep a `seen` set of message IDs.

## GameGPT MCP integration

The laptop side can launch GameGPT's MCP server
(`gtp-games-raw-plugin-stdio.exe`) and call its tools directly:
`get_raw_memory_status`, `list_game_processes`, `attach_game_process`,
`read_game_memory`, `write_game_memory` (guarded), etc.
The MCP client captures stderr and reports early-exit codes — a server
crash no longer looks like a silent hang.
