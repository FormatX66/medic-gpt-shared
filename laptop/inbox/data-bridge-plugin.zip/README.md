# Data Bridge Plugin

Symmetric bidirectional machine-to-machine bridge. Same code runs on both sides.
No LLM, no chat, zero usage burn.

## Architecture

```
Medic VM                          GitHub Repo                    Laptop
─────────                         ───────────                    ──────
bridge_plugin.py                  bridge/                        bridge_plugin.py
  --side medic                      medic-to-laptop/  ──poll──>    --side laptop
                                     laptop-to-medic/  <──poll──
```

Both sides poll their inbox, process structured JSON messages, write responses.
No ChatGPT involved. No tokens spent.

## Message Protocol

```json
{
  "id": "msg-medic-20260920T053000-0001",
  "from": "medic",
  "to": "laptop",
  "type": "profile.execute",
  "payload": { "profile_id": "nms-inventory-slots-full" },
  "timestamp": "2026-09-20T05:30:00+00:00",
  "needs_ack": true
}
```

## Built-in Message Types

| Type | Direction | Purpose |
|------|-----------|---------|
| `ping` | ↔ | Health check |
| `event` | ↔ | Fire-and-forget notification |
| `profile.execute` | medic→laptop | Execute a fast-side GameGPT profile |
| `learnings.export` | medic→laptop | Request ChatLearningStore export |
| `learnings.push` | laptop→medic | Push new learnings to Medic |
| `gamegpt.status` | laptop→medic | Report GameGPT system status |

## Running

```bash
# Medic's VM (continuous)
python bridge_plugin.py --side medic --poll-secs 30

# Laptop (continuous)
python bridge_plugin.py --side laptop --poll-secs 30

# One-shot send
python bridge_plugin.py --side medic --send ping '{}'

# Process inbox once and exit
python bridge_plugin.py --side laptop --once
```

## Wiring GameGPT

The laptop-side handlers (`register_laptop_handlers`) have stubs marked
`not_implemented`. Wire them to:
- `profile.execute` → GameGPT `ApplicationService` + fast-side profiles
- `learnings.export` → `ChatLearningStore` records

The medic-side `learnings.push` handler receives learnings and queues them
for fast-side profile processing.
