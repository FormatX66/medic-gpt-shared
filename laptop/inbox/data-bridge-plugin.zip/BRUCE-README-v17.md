# Data Bridge v17 — Morning Restart Instructions

## What changed
The bridge no longer uses webhook.site for commands. Medic now writes messages
as files in the GitHub repo; your laptop picks them up with `git pull`.
Responses still go back via webhook.site (much lower volume now).
This kills the throttling that broke v16.

## What you need to do (one time)

1. If the bridge window is open, press **Ctrl+C** to stop it.
2. Double-click **`start-bridge.bat`** (in your data-bridge-plugin folder).
3. It will auto-update to v17, check for git, and start.
4. Leave the window open.

That's it. One restart.

## What to expect
- You'll see `GameGPT Data Bridge v17` in the header.
- `git OK` should appear (if not, install Git for Windows).
- `inbox primed (N existing file(s) marked seen)` — normal, it ignores old files.
- The bridge polls every 20 seconds. No action needed from you.

## If something looks wrong
- "git not found on PATH" → install from https://git-scm.com/download/win, restart.
- "Medic heartbeat is X seconds old" → Medic's side isn't running; tell Medic.
- Anything else → copy the window text and send it to Medic.

## Technical notes (for Medic)
- Medic→laptop: GitHub `bridge/medic-to-laptop/*.json` via Contents API.
- Laptop→medic: webhook.site POST (with disk retry queue).
- Laptop needs: Python, git, curl.exe (all standard on Win10/11).
- No tokens, no pasting, no ChatGPT usage.
