#!/usr/bin/env python3
"""
Data Bridge Plugin — symmetric bidirectional machine-to-machine bridge.

Runs identically on both sides (Medic VM and Bruce's laptop).
No LLM, no chat, no usage burn. Pure structured data.

Each side:
  - Polls its inbox dir in the shared repo for new messages
  - Processes them via registered handlers
  - Writes responses/acks to its outbox dir
  - Can send messages to the other side at any time

Transport: GitHub repo (already authenticated on both sides).
No ChatGPT, no tokens, no usage.

Usage:
  python bridge_plugin.py --side medic   # on Medic's VM
  python bridge_plugin.py --side laptop  # on Bruce's laptop

Config via env or args:
  --side medic|laptop
  --repo FormatX66/medic-gpt-shared
  --poll-secs 30
  --once (process inbox once and exit)
"""

import argparse
import base64
import json
import os
import subprocess
import sys
import time
import urllib.request
import urllib.error
from datetime import datetime, timezone
from pathlib import Path


# ---------------------------------------------------------------------------
# Message protocol
# ---------------------------------------------------------------------------
# Message = {
#   "id": "msg-<side>-<timestamp>-<seq>",
#   "from": "medic" | "laptop",
#   "to": "medic" | "laptop",
#   "type": "<handler-name>",
#   "payload": { ... },
#   "timestamp": "ISO-8601",
#   "needs_ack": true,
# }
#
# Response = {
#   "id": "msg-<side>-<timestamp>-<seq>",
#   "from": "medic" | "laptop",
#   "to": "medic" | "laptop",
#   "type": "<handler-name>.response | <handler-name>.ack | event",
#   "in_reply_to": "<original-id>",
#   "payload": { ... },
#   "timestamp": "ISO-8601",
# }


def _apply_github_auth(req):
    """Apply GitHub auth to a urllib Request. Prefers a raw token (env var or
    local .github-token file, for the laptop), falls back to the authd
    surrogate (Medic VM only). Returns True if any auth was applied."""
    tok = os.environ.get("GITHUB_TOKEN", "").strip()
    if not tok:
        tf = Path(__file__).parent / ".github-token"
        if tf.is_file():
            tok = tf.read_text().strip()
    if tok:
        req.add_header("Authorization", f"Bearer {tok}")
        return True
    try:
        sys.path.insert(0, "/opt/hatch/skills/skill-creator/bin")
        import dynamic_credentials as dc
        dc.add_surrogate_to_request(req, "custom.github",
                                    allowed_hosts=["api.github.com"])
        return True
    except Exception:
        pass
    return False


class BridgePlugin:
    def __init__(self, side, repo, poll_secs=30, gh_token=None, webhook_bin=None):
        assert side in ("medic", "laptop"), f"side must be medic|laptop, got {side}"
        self.side = side
        self.peer = "laptop" if side == "medic" else "medic"
        self.repo = repo
        self.poll_secs = poll_secs
        self.gh_token = gh_token or ""  # explicit override; else _apply_github_auth
        # webhook bin for laptop->medic (no auth on either end).
        # Laptop sends via webhook; medic polls webhook and relays to repo inbox.
        self.webhook_bin = "" if webhook_bin == "" else (webhook_bin or self.WEBHOOK_BIN)
        self._webhook_seen = set()
        self.base = f"https://api.github.com/repos/{repo}/contents"
        # inbox = messages TO me, outbox = messages FROM me
        self.inbox_dir = f"bridge/{self.peer}-to-{self.side}"
        self.outbox_dir = f"bridge/{self.side}-to-{self.peer}"
        self.seq = 0
        self.seen = set()
        self.handlers = {}
        self._register_builtin_handlers()

    # -- GitHub transport (raw API, stdlib only) ---------------------------

    def _api(self, method, path, data=None):
        url = f"https://api.github.com{path}"
        body = json.dumps(data).encode() if data is not None else None
        req = urllib.request.Request(url, data=body, headers={
            "Accept": "application/vnd.github.v3+json",
            "User-Agent": "data-bridge-plugin",
        }, method=method)
        if self.gh_token:
            req.add_header("Authorization", f"Bearer {self.gh_token}")
        else:
            _apply_github_auth(req)
        try:
            with urllib.request.urlopen(req, timeout=30) as r:
                return json.loads(r.read().decode())
        except urllib.error.HTTPError as e:
            if e.code == 404:
                return None
            raise

    def _list_dir(self, dirpath):
        result = self._api("GET", f"/repos/{self.repo}/contents/{dirpath}")
        if not result or isinstance(result, dict):
            return []
        return [f["name"] for f in result if f["type"] == "file" and f["name"].endswith(".json")]

    def _read_file(self, path):
        result = self._api("GET", f"/repos/{self.repo}/contents/{path}")
        if not result or "content" not in result:
            return None
        return json.loads(base64.b64decode(result["content"]).decode())

    def _write_file(self, path, obj, message):
        # Get existing SHA for update, or None for create
        existing = self._api("GET", f"/repos/{self.repo}/contents/{path}")
        sha = existing.get("sha") if existing and isinstance(existing, dict) else None
        content = base64.b64encode(json.dumps(obj, indent=2).encode()).decode()
        data = {"message": message, "content": content}
        if sha:
            data["sha"] = sha
        return self._api("PUT", f"/repos/{self.repo}/contents/{path}", data)

    # -- Messaging ----------------------------------------------------------

    # webhook.site bin for laptop -> medic (no auth needed on either end).
    # Medic -> laptop still goes through the GitHub repo (public reads).
    # Note: this VM's egress blocks Python-urllib to webhook.site (bot
    # protection), so the medic side polls via curl subprocess.
    WEBHOOK_BIN = "761ba8c4-d58b-49f1-a63f-a06839a47ae9"
    WEBHOOK_POST_URL = f"https://webhook.site/{WEBHOOK_BIN}"
    WEBHOOK_POLL_URL = f"https://webhook.site/token/{WEBHOOK_BIN}/requests?sorting=newest"

    def _new_id(self):
        self.seq += 1
        ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S")
        return f"msg-{self.side}-{ts}-{self.seq:04d}"

    def _deliver(self, msg):
        """Route an outbound message. Laptop -> webhook (no auth). Medic -> GitHub."""
        if self.side == "laptop" and self.webhook_bin:
            self._webhook_post(msg)
        else:
            path = f"{self.outbox_dir}/{msg['id']}.json"
            label = msg.get("type", "?")
            self._write_file(path, msg, f"bridge: {self.side} -> {self.peer} {label}")
        return msg["id"]

    def _webhook_post(self, msg):
        """POST a message to webhook.site. Raises on failure so caller retries.
        Prefers curl: webhook.site's bot protection drops Python's TLS
        fingerprint on some networks (curl.exe ships with Windows 10+)."""
        body = json.dumps(msg).encode()
        try:
            p = subprocess.run(
                ["curl", "-s", "-m", "30", "-X", "POST",
                 "-H", "Content-Type: application/json",
                 "-d", "@-", self.WEBHOOK_POST_URL],
                input=body, capture_output=True, timeout=40)
            if p.returncode == 0:
                return
        except FileNotFoundError:
            pass  # no curl; fall through to urllib
        except Exception:
            pass
        req = urllib.request.Request(self.WEBHOOK_POST_URL, data=body, method="POST",
                                     headers={"Content-Type": "application/json",
                                              "User-Agent": "data-bridge-plugin"})
        with urllib.request.urlopen(req, timeout=30) as r:
            r.read()

    def _webhook_poll(self):
        """Fetch new laptop messages from webhook.site via curl, stage as repo
        inbox files. Medic side only. Returns count of new messages staged."""
        if not self.webhook_bin:
            return 0
        try:
            out = subprocess.run(
                ["curl", "-s", "-m", "30", self.WEBHOOK_POLL_URL],
                capture_output=True, text=True, timeout=40)
        except Exception as e:
            print(f"[bridge] webhook poll error: {e}", flush=True)
            return 0
        try:
            data = json.loads(out.stdout or "{}")
        except Exception:
            return 0
        count = 0
        for req in data.get("data", []):
            uuid = req.get("uuid")
            if not uuid or uuid in self._webhook_seen:
                continue
            self._webhook_seen.add(uuid)
            try:
                msg = json.loads(req.get("content", "") or "")
            except Exception:
                continue
            if not isinstance(msg, dict) or msg.get("from") != "laptop":
                continue
            msg_id = msg.get("id")
            if not msg_id or msg_id in self.seen:
                continue
            # Skip if already staged (survives restarts)
            path = f"{self.inbox_dir}/{msg_id}.json"
            try:
                if self._read_file(path):
                    continue
                self._write_file(path, msg, f"bridge: webhook relay {msg_id}")
                count += 1
            except Exception as e:
                print(f"[bridge] webhook stage error: {e}", flush=True)
        return count

    def send(self, msg_type, payload, needs_ack=True):
        """Send a structured message to the peer."""
        msg = {
            "id": self._new_id(),
            "from": self.side,
            "to": self.peer,
            "type": msg_type,
            "payload": payload,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "needs_ack": needs_ack,
        }
        return self._deliver(msg)

    def _ack(self, original_id):
        ack = {
            "id": self._new_id(),
            "from": self.side,
            "to": self.peer,
            "type": "ack",
            "in_reply_to": original_id,
            "payload": {"status": "received"},
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
        return self._deliver(ack)

    def _respond(self, original_id, msg_type, payload):
        resp = {
            "id": self._new_id(),
            "from": self.side,
            "to": self.peer,
            "type": msg_type,
            "in_reply_to": original_id,
            "payload": payload,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
        return self._deliver(resp)

    # -- Handlers ------------------------------------------------------------

    def on(self, msg_type, fn):
        """Register a handler: fn(payload) -> response_payload or None."""
        self.handlers[msg_type] = fn

    def _register_builtin_handlers(self):
        # Health check — both sides must answer
        self.on("ping", lambda p: {"pong": True, "side": self.side})
        # Generic event ingestion (no response needed)
        self.on("event", lambda p: None)

    def _check_auth(self):
        """Validate GitHub auth on startup. Prints loud diagnostics."""
        url = f"https://api.github.com/repos/{self.repo}"
        req = urllib.request.Request(url, headers={
            "Accept": "application/vnd.github.v3+json",
            "User-Agent": "data-bridge-plugin",
        }, method="GET")
        if self.gh_token:
            req.add_header("Authorization", f"Bearer {self.gh_token}")
            auth_source = "explicit token"
        elif _apply_github_auth(req):
            auth_source = "env/file/surrogate"
        else:
            print("[bridge] WARNING: no GitHub auth found; reads may work (public repo), writes will fail",
                  flush=True)
            return False
        try:
            with urllib.request.urlopen(req, timeout=30) as r:
                r.read()
            print(f"[bridge] GitHub auth OK ({auth_source})", flush=True)
            return True
        except urllib.error.HTTPError as e:
            print(f"[bridge] *** GITHUB AUTH FAILED: HTTP {e.code} ({auth_source}) ***", flush=True)
            print("[bridge] *** Check the token in .github-token and restart ***", flush=True)
            return False
        except Exception as e:
            print(f"[bridge] auth check error: {e}", flush=True)
            return False

    def _process_one(self, name):
        msg = self._read_file(f"{self.inbox_dir}/{name}")
        if not msg or msg.get("id") in self.seen:
            return False

        msg_type = msg.get("type", "")
        # Don't process our own acks as work
        if msg_type == "ack":
            self.seen.add(msg["id"])
            return True

        handler = self.handlers.get(msg_type)
        try:
            if handler:
                result = handler(msg.get("payload", {}))
                if result is not None:
                    self._respond(msg["id"], f"{msg_type}.response", result)
                elif msg.get("needs_ack"):
                    self._ack(msg["id"])
            elif msg.get("needs_ack"):
                self._ack(msg["id"])
            # Only mark seen after successful processing — failed writes retry
            self.seen.add(msg["id"])
            return True
        except Exception as e:
            print(f"[bridge] ERROR processing {msg.get('id')}: {e} (will retry)", flush=True)
            return False

    def poll_once(self):
        """Check inbox once, process all new messages. Returns count."""
        count = 0
        # Medic side: pull laptop messages from webhook into the repo inbox first
        if self.side == "medic" and self.webhook_bin:
            try:
                staged = self._webhook_poll()
                if staged:
                    print(f"[bridge] staged {staged} webhook message(s)", flush=True)
            except Exception as e:
                print(f"[bridge] webhook poll error: {e}", flush=True)
        try:
            files = self._list_dir(self.inbox_dir)
        except urllib.error.HTTPError as e:
            print(f"[bridge] inbox list failed: HTTP {e.code}", flush=True)
            return count
        except Exception as e:
            print(f"[bridge] inbox list error: {e}", flush=True)
            return count
        for name in sorted(files):
            try:
                if self._process_one(name):
                    count += 1
            except Exception as e:
                print(f"[bridge] ERROR on {name}: {e}", flush=True)
                continue
        return count

    def run(self, once=False):
        print(f"[bridge] side={self.side} peer={self.peer} poll={self.poll_secs}s", flush=True)
        print(f"[bridge] inbox: {self.inbox_dir}", flush=True)
        if self.side == "laptop" and self.webhook_bin:
            print(f"[bridge] outbound: webhook.site (no GitHub auth needed)", flush=True)
        else:
            print(f"[bridge] outbox: {self.outbox_dir}", flush=True)
        if self.side == "medic":
            # Medic needs GitHub auth for repo writes; laptop reads are public
            self._check_auth()
        else:
            print("[bridge] GitHub auth not required (public repo reads + webhook outbound)",
                  flush=True)
        while True:
            n = self.poll_once()
            if n:
                print(f"[bridge] processed {n} message(s)", flush=True)
            if once:
                break
            time.sleep(self.poll_secs)


# ---------------------------------------------------------------------------
# Side-specific handlers
# ---------------------------------------------------------------------------

def register_medic_handlers(plugin):
    """Handlers for Medic's side."""
    # Laptop can push learnings directly
    def ingest_learnings(payload):
        # payload: {"learnings": [...], "source": "..."}
        # Medic processes these into fast-side profiles
        return {"received": len(payload.get("learnings", [])), "status": "queued_for_processing"}
    plugin.on("learnings.push", ingest_learnings)

    # Laptop can report GameGPT status
    def gamegpt_status(payload):
        return {"acknowledged": True}
    plugin.on("gamegpt.status", gamegpt_status)


def _find_learned_values():
    """Locate the GameGPT ChatLearningStore JSON on this machine."""
    candidates = []
    gh = os.environ.get("GAMEGPT_HOME")
    if gh:
        candidates.append(Path(gh) / "data" / "chat_learned_values.json")
    home = Path(os.environ.get("USERPROFILE", str(Path.home())))
    for dirname in ("gptgame", "GameGPT-System", "GameGPT", "GameGPT-System-0.16.0"):
        candidates.append(home / dirname / "data" / "chat_learned_values.json")
    # Also relative to the plugin file
    candidates.append(Path(__file__).parent / "data" / "chat_learned_values.json")
    for c in candidates:
        if c.is_file():
            return c
    # Shallow scan: any top-level dir under USERPROFILE with data/chat_learned_values.json
    try:
        for child in home.iterdir():
            if child.is_dir():
                p = child / "data" / "chat_learned_values.json"
                if p.is_file():
                    return p
    except Exception:
        pass
    return None


def register_laptop_handlers(plugin):
    """Handlers for laptop side. Reads GameGPT state directly — no LLM."""

    def export_learnings(payload):
        # payload: {"since": "ISO-8601", "path": "explicit override path"}
        override = payload.get("path")
        if override:
            store_path = Path(override)
            if not store_path.is_file():
                return {"status": "error", "error": f"override path not found: {override}"}
        else:
            store_path = _find_learned_values()
        if not store_path:
            return {"status": "error",
                    "error": "chat_learned_values.json not found; set GAMEGPT_HOME"}
        raw = json.loads(store_path.read_text(encoding="utf-8"))
        records = raw.get("records", [])
        since = payload.get("since")
        if since:
            records = [r for r in records if r.get("learned_at", "") >= since]
        return {
            "status": "ok",
            "source_file": str(store_path),
            "schema_version": raw.get("schema_version", "unknown"),
            "record_count": len(records),
            "records": records,
        }

    plugin.on("learnings.export", export_learnings)

    def push_learnings(payload):
        # Push locally-found learnings to Medic without being asked
        result = export_learnings({})
        if result.get("status") == "ok":
            plugin.send("learnings.push", result, needs_ack=True)
            return {"pushed": result["record_count"]}
        return result

    plugin.on("learnings.push_now", push_learnings)

    def gamegpt_status(payload):
        store_path = _find_learned_values()
        return {
            "side": "laptop",
            "learned_values_found": store_path is not None,
            "store_path": str(store_path) if store_path else None,
        }

    plugin.on("gamegpt.status", gamegpt_status)

    def execute_profile(payload):
        # payload: {"profile_id": "...", "params": {...}}
        # Validates the profile structure; actual GameGPT ApplicationService
        # wiring lands here once learnings are processed into real profiles.
        profile_id = payload.get("profile_id", "?")
        return {"profile_id": profile_id, "status": "not_implemented",
                "note": "Wire to GameGPT ApplicationService here"}

    plugin.on("profile.execute", execute_profile)


def main():
    ap = argparse.ArgumentParser(description="Data Bridge Plugin")
    ap.add_argument("--side", required=True, choices=["medic", "laptop"])
    ap.add_argument("--repo", default="FormatX66/medic-gpt-shared")
    ap.add_argument("--poll-secs", type=int, default=30)
    ap.add_argument("--once", action="store_true", help="Process inbox once and exit")
    ap.add_argument("--send", nargs=2, metavar=("TYPE", "JSON"),
                    help="Send one message and exit. e.g. --send ping '{}'")
    ap.add_argument("--check-auth", action="store_true",
                    help="Validate GitHub auth and exit 0/1")
    ap.add_argument("--webhook-bin", default=None,
                    help="webhook.site bin for laptop->medic (default: built-in)")
    ap.add_argument("--no-webhook", action="store_true",
                    help="Disable webhook transport")
    args = ap.parse_args()

    webhook_bin = "" if args.no_webhook else args.webhook_bin
    plugin = BridgePlugin(side=args.side, repo=args.repo, poll_secs=args.poll_secs,
                          webhook_bin=webhook_bin)

    if args.side == "medic":
        register_medic_handlers(plugin)
    else:
        register_laptop_handlers(plugin)

    if args.send:
        msg_type, payload_json = args.send
        msg_id = plugin.send(msg_type, json.loads(payload_json))
        print(f"sent {msg_id}")
        return

    if args.check_auth:
        ok = plugin._check_auth()
        sys.exit(0 if ok else 1)

    plugin.run(once=args.once)


if __name__ == "__main__":
    main()
