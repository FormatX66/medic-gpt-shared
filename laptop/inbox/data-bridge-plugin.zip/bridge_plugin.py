#!/usr/bin/env python3
"""
Data Bridge Plugin — symmetric bidirectional machine-to-machine bridge.

Runs identically on both sides (Medic VM and Bruce's laptop).
No LLM, no chat, no usage burn. Pure structured data.

Each side:
  - Polls its inbox dir in the shared repo for new messages
  - Processes them via registered handlers
  - Writes responses/acks to its outbox dir
  - Can send messages to the other side at any time

Transport: GitHub repo (already authenticated on both sides).
No ChatGPT, no tokens, no usage.

Usage:
  python bridge_plugin.py --side medic   # on Medic's VM
  python bridge_plugin.py --side laptop  # on Bruce's laptop

Config via env or args:
  --side medic|laptop
  --repo FormatX66/medic-gpt-shared
  --poll-secs 30
  --once (process inbox once and exit)
"""

import argparse
import base64
import json
import os
import subprocess
import sys
import time
import urllib.request
import urllib.error
from datetime import datetime, timezone
from pathlib import Path


# ---------------------------------------------------------------------------
# Message protocol
# ---------------------------------------------------------------------------
# Message = {
#   "id": "msg-<side>-<timestamp>-<seq>",
#   "from": "medic" | "laptop",
#   "to": "medic" | "laptop",
#   "type": "<handler-name>",
#   "payload": { ... },
#   "timestamp": "ISO-8601",
#   "needs_ack": true,
# }
#
# Response = {
#   "id": "msg-<side>-<timestamp>-<seq>",
#   "from": "medic" | "laptop",
#   "to": "medic" | "laptop",
#   "type": "<handler-name>.response | <handler-name>.ack | event",
#   "in_reply_to": "<original-id>",
#   "payload": { ... },
#   "timestamp": "ISO-8601",
# }


def _apply_github_auth(req):
    """Apply GitHub auth to a urllib Request. Prefers a raw token (env var or
    local .github-token file, for the laptop), falls back to the authd
    surrogate (Medic VM only). Returns True if any auth was applied."""
    tok = os.environ.get("GITHUB_TOKEN", "").strip()
    if not tok:
        tf = Path(__file__).parent / ".github-token"
        if tf.is_file():
            tok = tf.read_text().strip()
    if tok:
        req.add_header("Authorization", f"Bearer {tok}")
        return True
    try:
        sys.path.insert(0, "/opt/hatch/skills/skill-creator/bin")
        import dynamic_credentials as dc
        dc.add_surrogate_to_request(req, "custom.github",
                                    allowed_hosts=["api.github.com"])
        return True
    except Exception:
        pass
    return False


BRIDGE_VERSION = "v17"

class BridgePlugin:
    # v17 transport:
    #   medic -> laptop : GitHub repo files (bridge/medic-to-laptop/*.json).
    #                     Medic writes via authenticated Contents API.
    #                     Laptop reads via `git pull` on a local clone
    #                     (git protocol is not API-rate-limited).
    #   laptop -> medic : webhook.site POST (laptop), Medic polls webhook.
    # No side touches webhook.site except laptop-sends / medic-polls.

    def __init__(self, side, repo, poll_secs=30, gh_token=None, webhook_bin=None,
                 repo_dir=None):
        assert side in ("medic", "laptop"), f"side must be medic|laptop, got {side}"
        self.side = side
        self.peer = "laptop" if side == "medic" else "medic"
        self.repo = repo
        self.poll_secs = poll_secs
        self.gh_token = gh_token or ""
        # webhook bin: laptop sends via webhook; medic polls webhook.
        # Medic never posts to webhook in v17.
        self.webhook_bin = "" if webhook_bin == "" else (webhook_bin or self.WEBHOOK_BIN)
        self._webhook_seen = set()
        self.base = f"https://api.github.com/repos/{repo}/contents"
        # inbox = messages TO me, outbox = messages FROM me
        self.inbox_dir = f"bridge/{self.peer}-to-{self.side}"
        self.outbox_dir = f"bridge/{self.side}-to-{self.peer}"
        self.seq = 0
        self.seen = set()
        self.handlers = {}
        # Laptop: local git clone used to read medic's messages.
        # Defaults to ./bridge-repo next to the script; overridable.
        self.repo_dir = repo_dir
        self._git_warned = False
        self._register_builtin_handlers()

    # -- GitHub transport (raw API, stdlib only) ---------------------------

    def _api(self, method, path, data=None):
        url = f"https://api.github.com{path}"
        body = json.dumps(data).encode() if data is not None else None
        req = urllib.request.Request(url, data=body, headers={
            "Accept": "application/vnd.github.v3+json",
            "User-Agent": "data-bridge-plugin",
        }, method=method)
        if self.gh_token:
            req.add_header("Authorization", f"Bearer {self.gh_token}")
        else:
            _apply_github_auth(req)
        try:
            with urllib.request.urlopen(req, timeout=30) as r:
                return json.loads(r.read().decode())
        except urllib.error.HTTPError as e:
            if e.code == 404:
                return None
            raise

    def _list_dir(self, dirpath):
        result = self._api("GET", f"/repos/{self.repo}/contents/{dirpath}")
        if not result or isinstance(result, dict):
            return []
        return [f["name"] for f in result if f["type"] == "file" and f["name"].endswith(".json")]

    def _read_file(self, path):
        result = self._api("GET", f"/repos/{self.repo}/contents/{path}")
        if not result or "content" not in result:
            return None
        return json.loads(base64.b64decode(result["content"]).decode())

    def _write_file(self, path, obj, message):
        # Get existing SHA for update, or None for create
        existing = self._api("GET", f"/repos/{self.repo}/contents/{path}")
        sha = existing.get("sha") if existing and isinstance(existing, dict) else None
        content = base64.b64encode(json.dumps(obj, indent=2).encode()).decode()
        data = {"message": message, "content": content}
        if sha:
            data["sha"] = sha
        return self._api("PUT", f"/repos/{self.repo}/contents/{path}", data)

    # -- Messaging ----------------------------------------------------------

    # webhook.site bin for BOTH directions (no auth needed on either end).
    # Every message carries "from"/"to"; each side filters for its own inbound.
    # The GitHub repo is the durable record only (medic stages both directions
    # there, best-effort). The laptop never touches the GitHub API, so there
    # is no rate-limit risk on that side.
    # Note: this VM's egress blocks Python-urllib to webhook.site (bot
    # protection), so all webhook traffic goes via curl subprocess
    # (curl.exe ships with Windows 10+).
    WEBHOOK_BIN = "9622e3ae-9348-43f1-9c93-e53d007c18cd"
    WEBHOOK_POST_URL = f"https://webhook.site/{WEBHOOK_BIN}"
    WEBHOOK_POLL_URL = f"https://webhook.site/token/{WEBHOOK_BIN}/requests?sorting=newest"

    def _new_id(self):
        self.seq += 1
        ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S")
        return f"msg-{self.side}-{ts}-{self.seq:04d}"

    def _deliver(self, msg):
        """v17: side-specific transport.
        medic  -> writes message file to GitHub (bridge/medic-to-laptop/).
        laptop -> POSTs message to webhook.site (unchanged)."""
        if self.side == "medic":
            return self._github_send(msg)
        else:
            self._webhook_post(msg)
            return msg["id"]

    def _github_send(self, msg, max_retries=5):
        """Write one message file to the repo with retry. Raises on failure
        so the caller knows the message was NOT delivered."""
        import time
        path = f"{self.outbox_dir}/{msg['id']}.json"
        last_err = None
        for attempt in range(max_retries):
            try:
                self._write_file(path, msg,
                                 f"bridge: {self.side} -> {self.peer} {msg.get('type', '?')}")
                return msg["id"]
            except Exception as e:
                last_err = e
                wait = min(2 ** attempt, 30)
                print(f"[bridge] GitHub write failed (attempt {attempt+1}/{max_retries}): "
                      f"{e}; retrying in {wait}s", flush=True)
                time.sleep(wait)
        raise RuntimeError(f"GitHub write failed after {max_retries} attempts: {last_err}")

    def _webhook_post(self, msg):
        """POST a message to webhook.site. Queues to disk on failure for
        retry (laptop side). Raises on persistent failure.
        Prefers curl: webhook.site's bot protection drops Python's TLS
        fingerprint on some networks (curl.exe ships with Windows 10+)."""
        body = json.dumps(msg).encode()
        # Try curl first (with timeouts and retry per Claude's hardening)
        try:
            p = subprocess.run(
                ["curl", "-s", "-m", "30", "--connect-timeout", "10",
                 "--retry", "2", "--retry-delay", "2",
                 "-X", "POST", "-H", "Content-Type: application/json",
                 "--data-binary", "@-", self.WEBHOOK_POST_URL],
                input=body, capture_output=True, timeout=60,
                stdin=subprocess.PIPE)
            if p.returncode == 0:
                self._flush_webhook_queue()  # try queued messages too
                return
            print(f"[bridge] curl POST rc={p.returncode}: "
                  f"{p.stderr.decode()[:200] if p.stderr else ''}", flush=True)
        except FileNotFoundError:
            pass  # no curl; fall through to urllib
        except Exception as e:
            print(f"[bridge] curl POST error: {e}", flush=True)
        # Fallback: urllib
        try:
            req = urllib.request.Request(
                self.WEBHOOK_POST_URL, data=body, method="POST",
                headers={"Content-Type": "application/json",
                         "User-Agent": "data-bridge-plugin"})
            with urllib.request.urlopen(req, timeout=30) as r:
                r.read()
            self._flush_webhook_queue()
            return
        except Exception as e:
            print(f"[bridge] webhook POST failed, queuing: {e}", flush=True)
        # Queue to disk for retry (bounded: max 200 files, FIFO)
        self._queue_webhook(msg)
        raise RuntimeError("webhook POST failed; queued for retry")

    def _webhook_queue_dir(self):
        d = Path(__file__).resolve().parent / "webhook-queue"
        d.mkdir(exist_ok=True)
        return d

    def _queue_webhook(self, msg):
        """Save a failed webhook message to disk (bounded FIFO)."""
        qd = self._webhook_queue_dir()
        # Enforce bound: delete oldest if over 200
        files = sorted(qd.glob("*.json"))
        while len(files) >= 200:
            try:
                files.pop(0).unlink()
            except Exception:
                break
            files = sorted(qd.glob("*.json"))
        fp = qd / f"{msg.get('id', 'unknown')}.json"
        try:
            fp.write_text(json.dumps(msg), encoding="utf-8")
        except Exception as e:
            print(f"[bridge] queue write failed: {e}", flush=True)

    def _flush_webhook_queue(self):
        """Try to send queued webhook messages (oldest first)."""
        qd = self._webhook_queue_dir()
        if not qd.is_dir():
            return
        for fp in sorted(qd.glob("*.json")):
            try:
                msg = json.loads(fp.read_text(encoding="utf-8"))
                body = json.dumps(msg).encode()
                req = urllib.request.Request(
                    self.WEBHOOK_POST_URL, data=body, method="POST",
                    headers={"Content-Type": "application/json",
                             "User-Agent": "data-bridge-plugin"})
                with urllib.request.urlopen(req, timeout=30) as r:
                    r.read()
                fp.unlink()  # sent OK, remove from queue
            except Exception:
                break  # stop on first failure; try again next time

    def _webhook_poll(self):
        """Fetch new inbound messages from webhook.site via curl.
        Each side keeps only messages addressed to it (msg['to'] == self.side).
        Medic also stages laptop messages to the GitHub repo as the durable
        record (best-effort). Returns the list of fresh message dicts."""
        if not self.webhook_bin:
            return []
        try:
            out = subprocess.run(
                ["curl", "-s", "-m", "30", self.WEBHOOK_POLL_URL],
                capture_output=True, text=True, timeout=40)
        except Exception as e:
            print(f"[bridge] webhook poll error: {e}", flush=True)
            return []
        try:
            data = json.loads(out.stdout or "{}")
        except Exception:
            return []
        fresh = []
        for req in data.get("data", []):
            uuid = req.get("uuid")
            if not uuid or uuid in self._webhook_seen:
                continue
            self._webhook_seen.add(uuid)
            try:
                msg = json.loads(req.get("content", "") or "")
            except Exception:
                continue
            if not isinstance(msg, dict):
                continue
            if msg.get("to") != self.side:
                continue  # addressed to the other side
            msg_id = msg.get("id")
            if not msg_id or msg_id in self.seen:
                continue
            if self.side == "medic":
                # Durable record in the repo (best-effort)
                path = f"{self.inbox_dir}/{msg_id}.json"
                try:
                    if not self._read_file(path):
                        self._write_file(path, msg, f"bridge: webhook relay {msg_id}")
                except Exception as e:
                    print(f"[bridge] record stage warning: {e}", flush=True)
            fresh.append(msg)
        return fresh

    def send(self, msg_type, payload, needs_ack=True):
        """Send a structured message to the peer."""
        msg = {
            "id": self._new_id(),
            "from": self.side,
            "to": self.peer,
            "type": msg_type,
            "payload": payload,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "needs_ack": needs_ack,
        }
        return self._deliver(msg)

    def _ack(self, original_id):
        ack = {
            "id": self._new_id(),
            "from": self.side,
            "to": self.peer,
            "type": "ack",
            "in_reply_to": original_id,
            "payload": {"status": "received"},
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
        return self._deliver(ack)

    def _respond(self, original_id, msg_type, payload):
        resp = {
            "id": self._new_id(),
            "from": self.side,
            "to": self.peer,
            "type": msg_type,
            "in_reply_to": original_id,
            "payload": payload,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
        return self._deliver(resp)

    # -- Handlers ------------------------------------------------------------

    def on(self, msg_type, fn):
        """Register a handler: fn(payload) -> response_payload or None."""
        self.handlers[msg_type] = fn

    def _register_builtin_handlers(self):
        # Health check — both sides must answer
        self.on("ping", lambda p: {"pong": True, "side": self.side})
        # Generic event ingestion (no response needed)
        self.on("event", lambda p: None)

    def _check_auth(self):
        """Validate GitHub auth on startup. Prints loud diagnostics."""
        url = f"https://api.github.com/repos/{self.repo}"
        req = urllib.request.Request(url, headers={
            "Accept": "application/vnd.github.v3+json",
            "User-Agent": "data-bridge-plugin",
        }, method="GET")
        if self.gh_token:
            req.add_header("Authorization", f"Bearer {self.gh_token}")
            auth_source = "explicit token"
        elif _apply_github_auth(req):
            auth_source = "env/file/surrogate"
        else:
            print("[bridge] WARNING: no GitHub auth found; reads may work (public repo), writes will fail",
                  flush=True)
            return False
        try:
            with urllib.request.urlopen(req, timeout=30) as r:
                r.read()
            print(f"[bridge] GitHub auth OK ({auth_source})", flush=True)
            return True
        except urllib.error.HTTPError as e:
            print(f"[bridge] *** GITHUB AUTH FAILED: HTTP {e.code} ({auth_source}) ***", flush=True)
            print("[bridge] *** Check the token in .github-token and restart ***", flush=True)
            return False
        except Exception as e:
            print(f"[bridge] auth check error: {e}", flush=True)
            return False

    def _process_one(self, name):
        msg = self._read_file(f"{self.inbox_dir}/{name}")
        if not msg or msg.get("id") in self.seen:
            return False

        msg_type = msg.get("type", "")
        # Don't process our own acks as work
        if msg_type == "ack":
            self.seen.add(msg["id"])
            return True

        handler = self.handlers.get(msg_type)
        try:
            if handler:
                result = handler(msg.get("payload", {}))
                if result is not None:
                    self._respond(msg["id"], f"{msg_type}.response", result)
                elif msg.get("needs_ack"):
                    self._ack(msg["id"])
            elif msg.get("needs_ack"):
                self._ack(msg["id"])
            # Only mark seen after successful processing — failed writes retry
            self.seen.add(msg["id"])
            return True
        except Exception as e:
            print(f"[bridge] ERROR processing {msg.get('id')}: {e} (will retry)", flush=True)
            return False

    def poll_once(self):
        """v17: side-specific inbound polling.
        medic  -> polls webhook.site for laptop messages (unchanged).
        laptop -> git pull on local clone, then reads new files from
                  bridge/medic-to-laptop/ on disk.
        Returns count processed."""
        count = 0
        if self.side == "medic":
            try:
                fresh = self._webhook_poll()
            except Exception as e:
                print(f"[bridge] webhook poll error: {e}", flush=True)
                fresh = []
        else:
            fresh = self._github_inbox_poll()
        for msg in fresh:
            try:
                if self._process_message(msg):
                    count += 1
            except Exception as e:
                print(f"[bridge] ERROR on {msg.get('id', '?')}: {e}", flush=True)
                continue
        return count

    # -- Laptop inbound: git clone polling ---------------------------------

    def _clone_dir(self):
        """Local clone dir for the laptop side. Defaults to ./bridge-repo."""
        if self.repo_dir:
            return Path(self.repo_dir)
        # Next to this script
        return Path(__file__).resolve().parent / "bridge-repo"

    def _ensure_clone(self):
        """Clone the repo if missing. Returns True if a usable clone exists."""
        clone = self._clone_dir()
        if (clone / ".git").is_dir():
            return True
        print(f"[bridge] cloning {self.repo} to {clone} ...", flush=True)
        try:
            p = subprocess.run(
                ["git", "clone", "--depth", "50",
                 f"https://github.com/{self.repo}.git", str(clone)],
                capture_output=True, text=True, timeout=180)
            if p.returncode == 0 and (clone / ".git").is_dir():
                print("[bridge] clone OK", flush=True)
                return True
            print(f"[bridge] git clone failed: {p.stderr.strip()[:300]}", flush=True)
        except FileNotFoundError:
            print("[bridge] *** git not found on PATH; cannot fetch medic messages ***",
                  flush=True)
        except Exception as e:
            print(f"[bridge] git clone error: {e}", flush=True)
        return False

    def _git_pull(self):
        """Sync the clone. Uses fetch + reset --hard (never merge) so a
        dirty/diverged working tree can't block or corrupt the sync.
        Returns True on success."""
        clone = self._clone_dir()
        try:
            # Fetch first
            p = subprocess.run(
                ["git", "-C", str(clone),
                 "-c", "http.lowSpeedLimit=1000", "-c", "http.lowSpeedTime=15",
                 "fetch", "origin", "--quiet"],
                capture_output=True, text=True, timeout=90,
                stdin=subprocess.DEVNULL)
            if p.returncode != 0:
                print(f"[bridge] git fetch rc={p.returncode}: "
                      f"{p.stderr.strip()[:200]}", flush=True)
                return False
            # Reset --hard to origin/main (laptop never has local changes)
            p = subprocess.run(
                ["git", "-C", str(clone), "reset", "--hard", "--quiet",
                 "origin/main"],
                capture_output=True, text=True, timeout=30,
                stdin=subprocess.DEVNULL)
            if p.returncode != 0:
                # Try master as fallback
                p = subprocess.run(
                    ["git", "-C", str(clone), "reset", "--hard", "--quiet",
                     "origin/master"],
                    capture_output=True, text=True, timeout=30,
                    stdin=subprocess.DEVNULL)
                if p.returncode != 0:
                    print(f"[bridge] git reset rc={p.returncode}: "
                          f"{p.stderr.strip()[:200]}", flush=True)
                    return False
            return True
        except FileNotFoundError:
            if not self._git_warned:
                print("[bridge] *** git not found on PATH ***", flush=True)
                self._git_warned = True
            return False
        except subprocess.TimeoutExpired:
            print("[bridge] git sync timed out (network stall?)", flush=True)
            return False
        except Exception as e:
            print(f"[bridge] git sync error: {e}", flush=True)
            return False

    def _check_heartbeat(self, inbox):
        """Laptop: warn if Medic's heartbeat is stale (>10 min)."""
        hb = inbox / "_heartbeat.json"
        if not hb.is_file():
            return
        try:
            data = json.loads(hb.read_text(encoding="utf-8"))
            ts = data.get("timestamp", "")
            # Parse ISO-8601 (handle trailing Z)
            if ts.endswith("Z"):
                ts = ts[:-1] + "+00:00"
            hb_time = datetime.fromisoformat(ts)
            age = (datetime.now(timezone.utc) - hb_time).total_seconds()
            if age > 600 and not getattr(self, "_hb_warned", False):
                print(f"[bridge] WARNING: Medic heartbeat is {age:.0f}s old "
                      f"(>10 min). Medic may be down.", flush=True)
                self._hb_warned = True
            elif age <= 600 and getattr(self, "_hb_warned", False):
                print("[bridge] Medic heartbeat recovered", flush=True)
                self._hb_warned = False
        except Exception:
            pass

    def _github_inbox_poll(self):
        """Laptop: pull the clone and return new inbound message dicts,
        sorted by filename (chronological). Marks pre-existing files as
        seen on first run so old staged records aren't reprocessed."""
        if not self._ensure_clone():
            return []
        self._git_pull()  # best-effort; read what we have regardless
        inbox = self._clone_dir() / self.inbox_dir
        if not inbox.is_dir():
            return []
        try:
            names = sorted(f.name for f in inbox.iterdir()
                           if f.is_file() and f.name.endswith(".json")
                           and not f.name.startswith("_"))
        except Exception as e:
            print(f"[bridge] inbox scan error: {e}", flush=True)
            return []
        # First successful scan: treat everything already there as seen
        # (durable-record files staged by older versions, not live messages).
        if not getattr(self, "_inbox_primed", False):
            for n in names:
                msg_id = n[:-5]  # strip .json
                self.seen.add(msg_id)
            self._inbox_primed = True
            print(f"[bridge] inbox primed ({len(names)} existing file(s) marked seen)",
                  flush=True)
            self._check_heartbeat(inbox)
            return []
        self._check_heartbeat(inbox)
        fresh = []
        for name in names:
            msg_id = name[:-5]
            if msg_id in self.seen:
                continue
            # Read-then-parse with one retry (file may be mid-checkout)
            msg = None
            for _ in range(2):
                try:
                    raw = (inbox / name).read_text(encoding="utf-8")
                    msg = json.loads(raw)
                    break
                except Exception:
                    import time as _t
                    _t.sleep(0.5)
            if not isinstance(msg, dict):
                print(f"[bridge] skipping unreadable inbox file: {name}", flush=True)
                self.seen.add(msg_id)  # don't spin on it forever
                continue
            if msg.get("to") != self.side:
                self.seen.add(msg_id)
                continue
            if not msg.get("id"):
                msg["id"] = msg_id
            fresh.append(msg)
        return fresh

    def _process_message(self, msg):
        """Process one message dict (already fetched)."""
        msg_id = msg.get("id", "")
        if msg_id in self.seen:
            return False
        msg_type = msg.get("type", "")
        handler = self.handlers.get(msg_type)
        try:
            if handler:
                result = handler(msg.get("payload", {}))
                # A .response with in_reply_to IS the ack; don't send both.
                if result is not None and msg_type not in ("ack", "event"):
                    self._respond(msg_id, f"{msg_type}.response", result)
                elif msg.get("needs_ack"):
                    self._ack(msg_id)
            elif msg.get("needs_ack"):
                self._ack(msg_id)
            # Only mark seen after successful processing
            self.seen.add(msg_id)
            return True
        except Exception:
            raise

    def _process_one(self, name):
        """Legacy repo-file path (kept for manual replays)."""
        if name in self.seen:
            return False
        msg = self._read_file(f"{self.inbox_dir}/{name}")
        if not msg:
            return False
        return self._process_message(msg)

    def run(self, once=False):
        print(f"[bridge] data-bridge {BRIDGE_VERSION} side={self.side} "
              f"peer={self.peer} poll={self.poll_secs}s", flush=True)
        if self.side == "medic":
            print("[bridge] transport: medic->laptop via GitHub repo files; "
                  "laptop->medic via webhook.site poll", flush=True)
            # Medic needs GitHub auth for the transport writes
            self._check_auth()
        else:
            print("[bridge] transport: medic->laptop via git pull of repo clone; "
                  "laptop->medic via webhook.site POST", flush=True)
            self._ensure_clone()
        poll_count = 0
        while True:
            n = self.poll_once()
            if n:
                print(f"[bridge] processed {n} message(s)", flush=True)
            poll_count += 1
            # Medic heartbeat: every ~5 min so laptop can tell
            # "no messages" apart from "Medic is dead"
            if self.side == "medic" and poll_count % 10 == 0:
                self._write_heartbeat()
            if once:
                break
            time.sleep(self.poll_secs)

    def _write_heartbeat(self):
        """Medic: update bridge/medic-to-laptop/_heartbeat.json (best-effort)."""
        try:
            self._write_file(
                f"{self.outbox_dir}/_heartbeat.json",
                {"from": "medic", "type": "heartbeat",
                 "timestamp": datetime.now(timezone.utc).isoformat()},
                "bridge: heartbeat")
        except Exception as e:
            print(f"[bridge] heartbeat write failed: {e}", flush=True)


# ---------------------------------------------------------------------------
# Side-specific handlers
# ---------------------------------------------------------------------------

def register_medic_handlers(plugin):
    """Handlers for Medic's side."""
    # Laptop can push learnings directly
    def ingest_learnings(payload):
        # payload: {"learnings": [...], "source": "..."}
        # Medic processes these into fast-side profiles
        return {"received": len(payload.get("learnings", [])), "status": "queued_for_processing"}
    plugin.on("learnings.push", ingest_learnings)

    # Laptop can report GameGPT status
    def gamegpt_status(payload):
        return {"acknowledged": True}
    plugin.on("gamegpt.status", gamegpt_status)


def _deep_find_learned_values(max_depth=4):
    """Recursive search for chat_learned_values.json under USERPROFILE.
    Skips AppData, hidden dirs, and common noise. Returns Path or None."""
    home = Path(os.environ.get("USERPROFILE", str(Path.home())))
    skip = {"appdata", "application data", ".git", ".vscode", "node_modules",
            "__pycache__", "onedrive"}
    target = "chat_learned_values.json"

    def walk(dirpath, depth):
        if depth > max_depth:
            return None
        try:
            entries = list(dirpath.iterdir())
        except Exception:
            return None
        # Check files first
        for e in entries:
            if e.is_file() and e.name.lower() == target:
                return e
        # Then recurse into dirs
        for e in entries:
            if e.is_dir() and not e.name.startswith("."):
                if e.name.lower() in skip:
                    continue
                # Skip junctions/symlinks to avoid loops
                if e.is_symlink():
                    continue
                found = walk(e, depth + 1)
                if found:
                    return found
        return None

    return walk(home, 0)


def _find_learned_values():
    """Locate the GameGPT ChatLearningStore JSON on this machine."""
    candidates = []
    gh = os.environ.get("GAMEGPT_HOME")
    if gh:
        candidates.append(Path(gh) / "data" / "chat_learned_values.json")
    home = Path(os.environ.get("USERPROFILE", str(Path.home())))
    for dirname in ("gptgame", "GameGPT-System", "GameGPT", "GameGPT-System-0.16.0"):
        candidates.append(home / dirname / "data" / "chat_learned_values.json")
    # Also relative to the plugin file
    candidates.append(Path(__file__).parent / "data" / "chat_learned_values.json")
    for c in candidates:
        if c.is_file():
            return c
    # Shallow scan: any top-level dir under USERPROFILE with data/chat_learned_values.json
    try:
        for child in home.iterdir():
            if child.is_dir():
                p = child / "data" / "chat_learned_values.json"
                if p.is_file():
                    return p
    except Exception:
        pass
    # Deep search as last resort (bounded)
    try:
        return _deep_find_learned_values()
    except Exception:
        pass
    return None


def _list_dir_safe(path, max_entries=50):
    """List a directory's contents (names + type). For remote exploration."""
    try:
        p = Path(path)
        if not p.is_dir():
            return {"error": f"not a directory: {path}"}
        entries = []
        for e in sorted(p.iterdir(), key=lambda x: x.name.lower()):
            if len(entries) >= max_entries:
                entries.append({"name": "...", "truncated": True})
                break
            entries.append({
                "name": e.name,
                "type": "dir" if e.is_dir() else "file",
                "size": e.stat().st_size if e.is_file() else None,
            })
        return {"path": str(p), "entries": entries}
    except Exception as e:
        return {"error": str(e)}


def register_laptop_handlers(plugin):
    """Handlers for laptop side. Reads GameGPT state directly — no LLM."""

    def export_learnings(payload):
        # payload: {"since": "ISO-8601", "path": "explicit override path"}
        override = payload.get("path")
        if override:
            store_path = Path(override)
            if not store_path.is_file():
                return {"status": "error", "error": f"override path not found: {override}"}
        else:
            store_path = _find_learned_values()
        if not store_path:
            return {"status": "error",
                    "error": "chat_learned_values.json not found; set GAMEGPT_HOME"}
        raw = json.loads(store_path.read_text(encoding="utf-8"))
        records = raw.get("records", [])
        since = payload.get("since")
        if since:
            records = [r for r in records if r.get("learned_at", "") >= since]
        return {
            "status": "ok",
            "source_file": str(store_path),
            "schema_version": raw.get("schema_version", "unknown"),
            "record_count": len(records),
            "records": records,
        }

    plugin.on("learnings.export", export_learnings)

    def push_learnings(payload):
        # Push locally-found learnings to Medic without being asked
        result = export_learnings({})
        if result.get("status") == "ok":
            plugin.send("learnings.push", result, needs_ack=True)
            return {"pushed": result["record_count"]}
        return result

    plugin.on("learnings.push_now", push_learnings)

    def gamegpt_status(payload):
        store_path = _find_learned_values()
        home = Path(os.environ.get("USERPROFILE", str(Path.home())))
        # Also report what's in the likely GameGPT folders for debugging
        folders = {}
        for dirname in ("gptgame", "GameGPT-System", "GameGPT", "GameGPT-System-0.16.0"):
            fp = home / dirname
            if fp.is_dir():
                folders[dirname] = _list_dir_safe(str(fp), max_entries=20)
        return {
            "side": "laptop",
            "learned_values_found": store_path is not None,
            "store_path": str(store_path) if store_path else None,
            "candidate_folders": folders,
            "userprofile": str(home),
        }

    plugin.on("gamegpt.status", gamegpt_status)

    def dir_list(payload):
        # payload: {"path": "C:\\Users\\bruce\\gptgame"}
        return _list_dir_safe(payload.get("path", ""))

    plugin.on("dir.list", dir_list)

    def file_search(payload):
        # payload: {"name": "chat_learned_values.json", "root": "%USERPROFILE%", "max_depth": 4}
        name = payload.get("name", "chat_learned_values.json").lower()
        root = payload.get("root", "")
        if "%USERPROFILE%" in root:
            root = root.replace("%USERPROFILE%",
                                os.environ.get("USERPROFILE", str(Path.home())))
        max_depth = int(payload.get("max_depth", 4))
        skip = {"appdata", "application data", ".git", ".vscode", "node_modules",
                "__pycache__", "onedrive", "windows", "program files",
                "program files (x86)", "programdata"}
        found = []

        def walk(dirpath, depth):
            if depth > max_depth or len(found) >= 20:
                return
            try:
                entries = list(dirpath.iterdir())
            except Exception:
                return
            for e in entries:
                if e.is_file() and e.name.lower() == name:
                    found.append(str(e))
                    if len(found) >= 20:
                        return
            for e in entries:
                if e.is_dir() and not e.name.startswith("."):
                    if e.name.lower() in skip or e.is_symlink():
                        continue
                    walk(e, depth + 1)

        try:
            walk(Path(root), 0)
        except Exception as e:
            return {"error": str(e)}
        return {"name": name, "root": root, "found": found, "count": len(found)}

    plugin.on("file.search", file_search)

    def execute_profile(payload):
        # payload: {"profile_id": "...", "params": {...}}
        # Validates the profile structure; actual GameGPT ApplicationService
        # wiring lands here once learnings are processed into real profiles.
        profile_id = payload.get("profile_id", "?")
        return {"profile_id": profile_id, "status": "not_implemented",
                "note": "Wire to GameGPT ApplicationService here"}

    plugin.on("profile.execute", execute_profile)

    # --- MCP integration: talk directly to GameGPT's MCP server ---
    # Lazily initialized; only used when Medic sends mcp.* messages.
    _mcp_client = None

    def _get_mcp():
        nonlocal _mcp_client
        if _mcp_client is None:
            try:
                from mcp_client import GameGPTMCPClient
                # Find GameGPT home and the MCP server executable
                gh = os.environ.get("GAMEGPT_HOME")
                server_cmd = "gtp-games-raw-plugin-stdio"  # fallback: PATH
                if not gh:
                    home = Path(os.environ.get("USERPROFILE", str(Path.home())))
                    for dirname in ("GameGPT",):
                        cand = home / "Documents" / "GitHub" / dirname
                        if cand.is_dir():
                            gh = str(cand)
                            break
                if gh:
                    # Prefer the venv's stdio server executable
                    venv_exe = Path(gh) / ".venv" / "Scripts" / "gtp-games-raw-plugin-stdio.exe"
                    if venv_exe.is_file():
                        server_cmd = str(venv_exe)
                _mcp_client = GameGPTMCPClient(
                    server_command=server_cmd,
                    gamegpt_home=Path(gh) if gh else None)
            except ImportError as e:
                return None, f"mcp_client not available: {e}"
        return _mcp_client, None

    def mcp_status(payload):
        client, err = _get_mcp()
        if err:
            return {"status": "error", "error": err}
        try:
            running = client.is_running()
            if not running:
                client.start()
                running = client.is_running()
            return {"status": "ok", "mcp_running": running}
        except Exception as e:
            return {"status": "error", "error": str(e)}

    plugin.on("mcp.status", mcp_status)

    def mcp_tools_list(payload):
        client, err = _get_mcp()
        if err:
            return {"status": "error", "error": err}
        try:
            if not client.is_running():
                client.start()
            tools = client.list_tools()
            return {"status": "ok", "tools": [
                {"name": t.get("name"), "description": t.get("description", "")[:200]}
                for t in tools
            ], "count": len(tools)}
        except Exception as e:
            return {"status": "error", "error": str(e)}

    plugin.on("mcp.tools.list", mcp_tools_list)

    def mcp_tool_call(payload):
        # payload: {"name": "tool_name", "arguments": {...}}
        client, err = _get_mcp()
        if err:
            return {"status": "error", "error": err}
        name = payload.get("name", "")
        arguments = payload.get("arguments", {})
        if not name:
            return {"status": "error", "error": "tool name required"}
        try:
            if not client.is_running():
                client.start()
            result = client.call_tool(name, arguments)
            return {"status": "ok", "tool": name, "result": result}
        except Exception as e:
            return {"status": "error", "tool": name, "error": str(e)}

    plugin.on("mcp.tool.call", mcp_tool_call)


def main():
    ap = argparse.ArgumentParser(description="Data Bridge Plugin")
    ap.add_argument("--side", required=True, choices=["medic", "laptop"])
    ap.add_argument("--repo", default="FormatX66/medic-gpt-shared")
    ap.add_argument("--poll-secs", type=int, default=30)
    ap.add_argument("--once", action="store_true", help="Process inbox once and exit")
    ap.add_argument("--send", nargs=2, metavar=("TYPE", "JSON"),
                    help="Send one message and exit. e.g. --send ping '{}'")
    ap.add_argument("--check-auth", action="store_true",
                    help="Validate GitHub auth and exit 0/1")
    ap.add_argument("--webhook-bin", default=None,
                    help="webhook.site bin for laptop->medic (default: built-in)")
    ap.add_argument("--no-webhook", action="store_true",
                    help="Disable webhook transport")
    args = ap.parse_args()

    webhook_bin = "" if args.no_webhook else args.webhook_bin
    plugin = BridgePlugin(side=args.side, repo=args.repo, poll_secs=args.poll_secs,
                          webhook_bin=webhook_bin)

    if args.side == "medic":
        register_medic_handlers(plugin)
    else:
        register_laptop_handlers(plugin)

    if args.send:
        msg_type, payload_json = args.send
        msg_id = plugin.send(msg_type, json.loads(payload_json))
        print(f"sent {msg_id}")
        return

    if args.check_auth:
        ok = plugin._check_auth()
        sys.exit(0 if ok else 1)

    plugin.run(once=args.once)


if __name__ == "__main__":
    main()
