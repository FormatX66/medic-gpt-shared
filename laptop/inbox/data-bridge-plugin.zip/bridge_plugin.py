#!/usr/bin/env python3
"""
Data Bridge Plugin — symmetric bidirectional machine-to-machine bridge.

Runs identically on both sides (Medic VM and Bruce's laptop).
No LLM, no chat, no usage burn. Pure structured data.

Each side:
  - Polls its inbox dir in the shared repo for new messages
  - Processes them via registered handlers
  - Writes responses/acks to its outbox dir
  - Can send messages to the other side at any time

Transport: GitHub repo (already authenticated on both sides).
No ChatGPT, no tokens, no usage.

Usage:
  python bridge_plugin.py --side medic   # on Medic's VM
  python bridge_plugin.py --side laptop  # on Bruce's laptop

Config via env or args:
  --side medic|laptop
  --repo FormatX66/medic-gpt-shared
  --poll-secs 30
  --once (process inbox once and exit)
"""

import argparse
import base64
import json
import os
import sys
import time
import urllib.request
import urllib.error
from datetime import datetime, timezone
from pathlib import Path


# ---------------------------------------------------------------------------
# Message protocol
# ---------------------------------------------------------------------------
# Message = {
#   "id": "msg-<side>-<timestamp>-<seq>",
#   "from": "medic" | "laptop",
#   "to": "medic" | "laptop",
#   "type": "<handler-name>",
#   "payload": { ... },
#   "timestamp": "ISO-8601",
#   "needs_ack": true,
# }
#
# Response = {
#   "id": "msg-<side>-<timestamp>-<seq>",
#   "from": "medic" | "laptop",
#   "to": "medic" | "laptop",
#   "type": "<handler-name>.response | <handler-name>.ack | event",
#   "in_reply_to": "<original-id>",
#   "payload": { ... },
#   "timestamp": "ISO-8601",
# }


class BridgePlugin:
    def __init__(self, side, repo, poll_secs=30, gh_token=None):
        assert side in ("medic", "laptop"), f"side must be medic|laptop, got {side}"
        self.side = side
        self.peer = "laptop" if side == "medic" else "medic"
        self.repo = repo
        self.poll_secs = poll_secs
        self.gh_token = gh_token or os.environ.get("GITHUB_TOKEN", "")
        self.base = f"https://api.github.com/repos/{repo}/contents"
        # inbox = messages TO me, outbox = messages FROM me
        self.inbox_dir = f"bridge/{self.peer}-to-{self.side}"
        self.outbox_dir = f"bridge/{self.side}-to-{self.peer}"
        self.seq = 0
        self.seen = set()
        self.handlers = {}
        self._register_builtin_handlers()

    # -- GitHub transport (raw API, stdlib only) ---------------------------

    def _headers(self):
        h = {
            "Accept": "application/vnd.github.v3+json",
            "User-Agent": "data-bridge-plugin",
        }
        if self.gh_token:
            h["Authorization"] = f"Bearer {self.gh_token}"
        return h

    def _api(self, method, path, data=None):
        url = f"https://api.github.com{path}"
        body = json.dumps(data).encode() if data is not None else None
        req = urllib.request.Request(url, data=body, headers=self._headers(), method=method)
        try:
            with urllib.request.urlopen(req, timeout=30) as r:
                return json.loads(r.read().decode())
        except urllib.error.HTTPError as e:
            if e.code == 404:
                return None
            raise

    def _list_dir(self, dirpath):
        result = self._api("GET", f"/repos/{self.repo}/contents/{dirpath}")
        if not result or isinstance(result, dict):
            return []
        return [f["name"] for f in result if f["type"] == "file" and f["name"].endswith(".json")]

    def _read_file(self, path):
        result = self._api("GET", f"/repos/{self.repo}/contents/{path}")
        if not result or "content" not in result:
            return None
        return json.loads(base64.b64decode(result["content"]).decode())

    def _write_file(self, path, obj, message):
        # Get existing SHA for update, or None for create
        existing = self._api("GET", f"/repos/{self.repo}/contents/{path}")
        sha = existing.get("sha") if existing and isinstance(existing, dict) else None
        content = base64.b64encode(json.dumps(obj, indent=2).encode()).decode()
        data = {"message": message, "content": content}
        if sha:
            data["sha"] = sha
        return self._api("PUT", f"/repos/{self.repo}/contents/{path}", data)

    # -- Messaging ----------------------------------------------------------

    def _new_id(self):
        self.seq += 1
        ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S")
        return f"msg-{self.side}-{ts}-{self.seq:04d}"

    def send(self, msg_type, payload, needs_ack=True):
        """Send a structured message to the peer."""
        msg = {
            "id": self._new_id(),
            "from": self.side,
            "to": self.peer,
            "type": msg_type,
            "payload": payload,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "needs_ack": needs_ack,
        }
        path = f"{self.outbox_dir}/{msg['id']}.json"
        self._write_file(path, msg, f"bridge: {self.side} -> {self.peer} {msg_type}")
        return msg["id"]

    def _ack(self, original_id):
        ack = {
            "id": self._new_id(),
            "from": self.side,
            "to": self.peer,
            "type": "ack",
            "in_reply_to": original_id,
            "payload": {"status": "received"},
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
        path = f"{self.outbox_dir}/{ack['id']}.json"
        self._write_file(path, ack, f"bridge: ack {original_id}")

    def _respond(self, original_id, msg_type, payload):
        resp = {
            "id": self._new_id(),
            "from": self.side,
            "to": self.peer,
            "type": msg_type,
            "in_reply_to": original_id,
            "payload": payload,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
        path = f"{self.outbox_dir}/{resp['id']}.json"
        self._write_file(path, resp, f"bridge: response to {original_id}")

    # -- Handlers ------------------------------------------------------------

    def on(self, msg_type, fn):
        """Register a handler: fn(payload) -> response_payload or None."""
        self.handlers[msg_type] = fn

    def _register_builtin_handlers(self):
        # Health check — both sides must answer
        self.on("ping", lambda p: {"pong": True, "side": self.side})
        # Generic event ingestion (no response needed)
        self.on("event", lambda p: None)

    def _process_one(self, name):
        msg = self._read_file(f"{self.inbox_dir}/{name}")
        if not msg or msg.get("id") in self.seen:
            return False
        self.seen.add(msg["id"])

        msg_type = msg.get("type", "")
        # Don't process our own acks as work
        if msg_type == "ack":
            return True

        handler = self.handlers.get(msg_type)
        if handler:
            try:
                result = handler(msg.get("payload", {}))
                if result is not None:
                    self._respond(msg["id"], f"{msg_type}.response", result)
                elif msg.get("needs_ack"):
                    self._ack(msg["id"])
            except Exception as e:
                self._respond(msg["id"], f"{msg_type}.error", {"error": str(e)})
        elif msg.get("needs_ack"):
            self._ack(msg["id"])
        return True

    def poll_once(self):
        """Check inbox once, process all new messages. Returns count."""
        try:
            files = self._list_dir(self.inbox_dir)
        except Exception:
            return 0
        count = 0
        for name in sorted(files):
            try:
                if self._process_one(name):
                    count += 1
            except Exception:
                continue
        return count

    def run(self, once=False):
        print(f"[bridge] side={self.side} peer={self.peer} poll={self.poll_secs}s", flush=True)
        print(f"[bridge] inbox: {self.inbox_dir}", flush=True)
        print(f"[bridge] outbox: {self.outbox_dir}", flush=True)
        while True:
            n = self.poll_once()
            if n:
                print(f"[bridge] processed {n} message(s)", flush=True)
            if once:
                break
            time.sleep(self.poll_secs)


# ---------------------------------------------------------------------------
# Side-specific handlers
# ---------------------------------------------------------------------------

def register_medic_handlers(plugin):
    """Handlers for Medic's side."""
    # Laptop can push learnings directly
    def ingest_learnings(payload):
        # payload: {"learnings": [...], "source": "..."}
        # Medic processes these into fast-side profiles
        return {"received": len(payload.get("learnings", [])), "status": "queued_for_processing"}
    plugin.on("learnings.push", ingest_learnings)

    # Laptop can report GameGPT status
    def gamegpt_status(payload):
        return {"acknowledged": True}
    plugin.on("gamegpt.status", gamegpt_status)


def register_laptop_handlers(plugin):
    """Handlers for laptop side. Import GameGPT system for real execution."""
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "vendor", "pkg", "src"))

    def execute_profile(payload):
        # payload: {"profile_id": "...", "params": {...}}
        # Load the fast-side profile and execute via GameGPT application service
        # This is where the actual GameGPT integration lives
        profile_id = payload.get("profile_id", "?")
        return {"profile_id": profile_id, "status": "not_implemented",
                "note": "Wire to GameGPT ApplicationService here"}

    plugin.on("profile.execute", execute_profile)

    def export_learnings(payload):
        # payload: {"since": "ISO-8601"} — export ChatLearningStore entries
        return {"learnings": [], "status": "not_implemented",
                "note": "Wire to ChatLearningStore here"}

    plugin.on("learnings.export", export_learnings)


def main():
    ap = argparse.ArgumentParser(description="Data Bridge Plugin")
    ap.add_argument("--side", required=True, choices=["medic", "laptop"])
    ap.add_argument("--repo", default="FormatX66/medic-gpt-shared")
    ap.add_argument("--poll-secs", type=int, default=30)
    ap.add_argument("--once", action="store_true", help="Process inbox once and exit")
    ap.add_argument("--send", nargs=2, metavar=("TYPE", "JSON"),
                    help="Send one message and exit. e.g. --send ping '{}'")
    args = ap.parse_args()

    plugin = BridgePlugin(side=args.side, repo=args.repo, poll_secs=args.poll_secs)

    if args.side == "medic":
        register_medic_handlers(plugin)
    else:
        register_laptop_handlers(plugin)

    if args.send:
        msg_type, payload_json = args.send
        msg_id = plugin.send(msg_type, json.loads(payload_json))
        print(f"sent {msg_id}")
        return

    plugin.run(once=args.once)


if __name__ == "__main__":
    main()
