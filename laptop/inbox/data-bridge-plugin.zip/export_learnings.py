#!/usr/bin/env python3
"""
GameGPT Learnings Export — standalone, zero-LLM, zero-usage.

Finds the GameGPT ChatLearningStore on this laptop and exports it as JSON.
Run manually:  python export_learnings.py
Output: gamegpt-learnings-export.json in the current directory.

Then drop that file into the shared repo at:
  bridge/laptop-to-medic/
(or paste it to Medic — he'll process it into fast-side profiles)

Searches these locations for the learnings store:
  - .\\data\\chat_learned_values.json (relative to script)
  - %USERPROFILE%\\GameGPT-System\\data\\chat_learned_values.json
  - %USERPROFILE%\\GameGPT\\data\\chat_learned_values.json
  - Any GAMEGPT_HOME env var override
"""

import json
import os
import sys
from datetime import datetime, timezone
from pathlib import Path


def find_learned_values():
    candidates = []
    # 1. Relative to script location
    candidates.append(Path(__file__).parent / "data" / "chat_learned_values.json")
    # 2. GAMEGPT_HOME env override
    gh = os.environ.get("GAMEGPT_HOME")
    if gh:
        candidates.append(Path(gh) / "data" / "chat_learned_values.json")
    # 3. Known install locations
    home = Path(os.environ.get("USERPROFILE", str(Path.home())))
    for dirname in ("GameGPT-System", "GameGPT", "GameGPT-System-0.16.0"):
        candidates.append(home / dirname / "data" / "chat_learned_values.json")
    for c in candidates:
        if c.is_file():
            return c
    return None


def main():
    store_path = find_learned_values()
    if not store_path:
        print("ERROR: Could not find chat_learned_values.json", file=sys.stderr)
        print("Searched:", file=sys.stderr)
        print("  - .\\data\\chat_learned_values.json", file=sys.stderr)
        print("  - %USERPROFILE%\\GameGPT-System\\data\\", file=sys.stderr)
        print("  - %USERPROFILE%\\GameGPT\\data\\", file=sys.stderr)
        print("Set GAMEGPT_HOME env var to override.", file=sys.stderr)
        sys.exit(1)

    print(f"Found learnings store: {store_path}")
    raw = json.loads(store_path.read_text(encoding="utf-8"))
    records = raw.get("records", [])

    export = {
        "exported_at": datetime.now(timezone.utc).isoformat(),
        "source_file": str(store_path),
        "schema_version": raw.get("schema_version", "unknown"),
        "record_count": len(records),
        "records": records,
    }

    out = Path(__file__).parent / "gamegpt-learnings-export.json"
    out.write_text(json.dumps(export, indent=2, default=str), encoding="utf-8")
    print(f"Exported {len(records)} learning records -> {out}")
    print(f"File size: {out.stat().st_size:,} bytes")

    # Summary for quick eyeball
    for r in records:
        label = r.get("label", "?")
        game = r.get("game_key", "?")
        ver = r.get("verification", "?")
        addrs = len(r.get("addresses", []))
        print(f"  - [{game}] {label} ({ver}, {addrs} addresses)")


if __name__ == "__main__":
    main()
