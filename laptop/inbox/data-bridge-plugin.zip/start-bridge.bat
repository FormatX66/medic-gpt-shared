@echo off
REM GameGPT Data Bridge - one double-click setup
REM 1. Exports GameGPT learnings
REM 2. Starts the bridge plugin (laptop side)
REM No ChatGPT, no usage, just local Python.

cd /d "%~dp0"

echo === Step 1: Exporting GameGPT learnings ===
python export_learnings.py
if errorlevel 1 (
    echo.
    echo Export had an issue - continuing to start bridge anyway.
)
echo.
echo === Step 2: Starting bridge plugin (laptop side) ===
echo Leave this window open. The bridge is now listening for Medic.
echo Press Ctrl+C to stop.
echo.
python bridge_plugin.py --side laptop --poll-secs 30
pause
