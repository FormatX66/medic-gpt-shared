@echo off
REM GameGPT Data Bridge v17 - one double-click setup
REM v17 transport: medic->laptop via GitHub repo (git pull, no token needed)
REM                laptop->medic via webhook.site POST
REM No tokens, no GitHub auth, no ChatGPT, no usage. Just local Python + git.
REM Updates: Medic will tell you when a new ZIP is ready. Download and re-extract manually.

cd /d "%~dp0"

echo ============================================
echo  GameGPT Data Bridge v17
echo ============================================
echo.
echo === Checking git ===
git --version >nul 2>&1
if errorlevel 1 (
    echo WARNING: git not found on PATH. The bridge needs git to receive messages.
    echo Install Git for Windows from https://git-scm.com/download/win and restart.
    echo Continuing anyway - sending will work, receiving will not.
) else (
    echo git OK
)
echo.
echo === Step 1: Exporting GameGPT learnings ===
python export_learnings.py
echo.
echo === Step 2: Starting bridge plugin (laptop side) ===
echo Leave this window open. The bridge is now listening for Medic.
echo Press Ctrl+C to stop.
echo.
python bridge_plugin.py --side laptop --poll-secs 20
pause
