@echo off
REM GameGPT Data Bridge v10 - one double-click setup
REM No tokens, no GitHub auth, no ChatGPT, no usage. Just local Python.
REM   Both directions : via webhook.site (no account, no auth)

cd /d "%~dp0"

echo ============================================
echo  GameGPT Data Bridge v10
echo ============================================
echo.
echo === Step 1: Exporting GameGPT learnings ===
python export_learnings.py
echo.
echo === Step 2: Starting bridge plugin (laptop side) ===
echo Leave this window open. The bridge is now listening for Medic.
echo Press Ctrl+C to stop.
echo.
python bridge_plugin.py --side laptop --poll-secs 20
pause
