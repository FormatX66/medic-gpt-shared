@echo off
REM GameGPT Data Bridge - one double-click setup
REM No tokens, no GitHub auth, no ChatGPT, no usage. Just local Python.
REM   Medic -> laptop : via the public GitHub repo (read-only)
REM   Laptop -> Medic : via ntfy.sh (no account needed)

cd /d "%~dp0"

echo === Step 1: Exporting GameGPT learnings ===
python export_learnings.py
echo.
echo === Step 2: Starting bridge plugin (laptop side) ===
echo Leave this window open. The bridge is now listening for Medic.
echo Press Ctrl+C to stop.
echo.
python bridge_plugin.py --side laptop --poll-secs 30
pause
