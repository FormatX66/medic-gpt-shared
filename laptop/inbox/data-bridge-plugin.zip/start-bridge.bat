@echo off
REM GameGPT Data Bridge - one double-click setup
REM 1. Checks GitHub token (needed to write to the shared repo)
REM 2. Exports GameGPT learnings
REM 3. Starts the bridge plugin (laptop side)
REM No ChatGPT, no usage, just local Python.

cd /d "%~dp0"

if not exist ".github-token" (
    echo === GitHub access needed ===
    echo The bridge writes to our shared GitHub repo, so it needs a token.
    echo.
    echo Opening the token page - create a classic token with 'repo' scope,
    echo then paste it here. It stays on this laptop only.
    echo.
    start https://github.com/settings/tokens/new?scopes=repo^&description=laptop-bridge
    set /p TOKEN="Paste token: "
    echo %TOKEN% > .github-token
    echo Saved.
    echo.
)

echo === Step 1: Exporting GameGPT learnings ===
python export_learnings.py
echo.
echo === Step 2: Starting bridge plugin (laptop side) ===
echo Leave this window open. The bridge is now listening for Medic.
echo Press Ctrl+C to stop.
echo.
python bridge_plugin.py --side laptop --poll-secs 30
pause
