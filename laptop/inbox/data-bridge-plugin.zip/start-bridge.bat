@echo off
REM GameGPT Data Bridge v16 - one double-click setup, self-updating
REM No tokens, no GitHub auth, no ChatGPT, no usage. Just local Python.
REM   Both directions : via webhook.site (no account, no auth)
REM   Auto-update     : checks repo for newer version on every launch

cd /d "%~dp0"
set REPO=FormatX66/medic-gpt-shared
set LOCAL_VER=v16

echo ============================================
echo  GameGPT Data Bridge %LOCAL_VER% (self-updating)
echo ============================================
echo.

echo === Checking for updates ===
curl -s -m 15 "https://raw.githubusercontent.com/%REPO%/main/laptop/inbox/bridge-version.txt" -o "%TEMP%\bridge-version.txt" 2>nul
if exist "%TEMP%\bridge-version.txt" (
    set /p REMOTE_VER=<"%TEMP%\bridge-version.txt"
    echo Local: %LOCAL_VER%, Remote: %REMOTE_VER%
    if not "%REMOTE_VER%"=="%LOCAL_VER%" (
        echo New version available. Downloading...
        curl -s -m 60 -L "https://raw.githubusercontent.com/%REPO%/main/laptop/inbox/data-bridge-plugin.zip" -o "%TEMP%\bridge-update.zip"
        if exist "%TEMP%\bridge-update.zip" (
            echo Extracting update...
            powershell -command "Expand-Archive -Path '%TEMP%\bridge-update.zip' -DestinationPath '%~dp0' -Force"
            echo Update installed. Restarting...
            timeout /t 2 /nobreak >nul
            start "" "%~f0"
            exit /b 0
        ) else (
            echo Update download failed. Continuing with local version.
        )
    ) else (
        echo Already up to date.
    )
) else (
    echo Could not check for updates. Continuing with local version.
)
echo.
echo === Step 1: Exporting GameGPT learnings ===
python export_learnings.py
echo.
echo === Step 2: Starting bridge plugin (laptop side) ===
echo Leave this window open. The bridge is now listening for Medic.
echo Press Ctrl+C to stop.
echo.
python bridge_plugin.py --side laptop --poll-secs 20
pause
