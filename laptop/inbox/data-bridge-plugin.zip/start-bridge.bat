@echo off
REM GameGPT Data Bridge - one double-click setup
REM 1. Checks GitHub token (validates it before proceeding)
REM 2. Exports GameGPT learnings
REM 3. Starts the bridge plugin (laptop side)
REM No ChatGPT, no usage, just local Python.

cd /d "%~dp0"

:token_check
if not exist ".github-token" goto get_token
python bridge_plugin.py --side laptop --check-auth >nul 2>&1
if not errorlevel 1 goto token_ok
echo.
echo The saved token was rejected by GitHub. Let's try a fresh one.
del ".github-token"

:get_token
echo === GitHub access needed ===
echo The bridge writes to our shared GitHub repo, so it needs a token.
echo.
echo Create a classic token with 'repo' scope, then paste it here.
echo It stays on this laptop only.
echo.
start https://github.com/settings/tokens/new?scopes=repo^&description=laptop-bridge
set /p TOKEN="Paste token: "
echo %TOKEN% > .github-token
python bridge_plugin.py --side laptop --check-auth
if errorlevel 1 (
    echo.
    echo That token didn't work. Make sure you copied the full token
    echo starting with ghp_ and try again.
    echo.
    del ".github-token"
    goto get_token
)

:token_ok
echo.
echo === Step 1: Exporting GameGPT learnings ===
python export_learnings.py
echo.
echo === Step 2: Starting bridge plugin (laptop side) ===
echo Leave this window open. The bridge is now listening for Medic.
echo Press Ctrl+C to stop.
echo.
python bridge_plugin.py --side laptop --poll-secs 30
pause
