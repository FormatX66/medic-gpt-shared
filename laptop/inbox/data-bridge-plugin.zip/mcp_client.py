"""MCP client for GameGPT. Speaks JSON-RPC over stdio to the GameGPT MCP server.

This lets the data bridge invoke GameGPT tools directly (scan, read, write,
learned values) without going through ChatGPT.
"""
from __future__ import annotations

import json
import subprocess
import threading
from pathlib import Path
from typing import Any


class MCPError(Exception):
    pass


class GameGPTMCPClient:
    """Launches the GameGPT MCP server as a subprocess and speaks MCP to it."""

    def __init__(self, server_command: str = "gtp-games-raw-plugin-stdio",
                 gamegpt_home: Path | None = None):
        self.server_command = server_command
        self.gamegpt_home = gamegpt_home
        self.proc: subprocess.Popen | None = None
        self._request_id = 0
        self._lock = threading.RLock()
        self._response_buffer: dict[int, Any] = {}
        self._reader_thread: threading.Thread | None = None
        self._stderr_lines: list[str] = []
        self._stdout_bytes = 0

    def _drain_stderr(self):
        """Background drain of stderr so the pipe never blocks and we keep the tail."""
        try:
            for line in self.proc.stderr:
                self._stderr_lines.append(line.rstrip())
                # Keep last 50 lines
                if len(self._stderr_lines) > 50:
                    self._stderr_lines.pop(0)
        except Exception:
            pass

    def _stderr_tail(self, n: int = 20) -> str:
        return "\n".join(self._stderr_lines[-n:])

    def start(self) -> None:
        """Launch the MCP server subprocess."""
        import os, time
        with self._lock:
            if self.proc and self.proc.poll() is None:
                return  # already running
            cwd = str(self.gamegpt_home) if self.gamegpt_home else None
            # PYTHONUNBUFFERED=1 kills child block-buffering on pipes (Windows)
            env = dict(os.environ)
            env["PYTHONUNBUFFERED"] = "1"
            self._stderr_lines = []
            self._stdout_bytes = 0
            self.proc = subprocess.Popen(
                [self.server_command],
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                bufsize=1,
                cwd=cwd,
                env=env,
            )
            # Drain stderr in background (never block, keep tail for diagnostics)
            threading.Thread(target=self._drain_stderr, daemon=True).start()
            self._reader_thread = threading.Thread(
                target=self._read_loop, daemon=True)
            self._reader_thread.start()
            # Early-exit check: if the server died in the first 3s, report why
            time.sleep(3)
            rc = self.proc.poll()
            if rc is not None:
                raise MCPError(
                    f"MCP server exited on startup (rc={rc}). "
                    f"stderr:\n{self._stderr_tail()}")
            # MCP handshake: initialize
            try:
                self._mcp_request("initialize", {
                    "protocolVersion": "2024-11-05",
                    "capabilities": {},
                    "clientInfo": {"name": "medic-bridge", "version": "v16"},
                })
            except MCPError as e:
                rc = self.proc.poll()
                raise MCPError(
                    f"{e} (server rc={rc}, stdout_bytes={self._stdout_bytes}, "
                    f"stderr:\n{self._stderr_tail()})")
            # Send initialized notification
            self._mcp_notify("notifications/initialized", {})

    def stop(self) -> None:
        with self._lock:
            if self.proc:
                try:
                    self.proc.terminate()
                    self.proc.wait(timeout=5)
                except Exception:
                    try:
                        self.proc.kill()
                    except Exception:
                        pass
                self.proc = None

    def _mcp_request(self, method: str, params: dict) -> Any:
        """Send a JSON-RPC request and wait for the response."""
        with self._lock:
            if not self.proc or self.proc.poll() is not None:
                raise MCPError("MCP server not running")
            self._request_id += 1
            req_id = self._request_id
            msg = {
                "jsonrpc": "2.0",
                "id": req_id,
                "method": method,
                "params": params,
            }
            assert self.proc.stdin
            self.proc.stdin.write(json.dumps(msg) + "\n")
            self.proc.stdin.flush()
        # Wait for response (simple polling; production would use events)
        import time
        deadline = time.time() + 120
        while time.time() < deadline:
            with self._lock:
                if req_id in self._response_buffer:
                    resp = self._response_buffer.pop(req_id)
                    if "error" in resp:
                        raise MCPError(f"MCP error: {resp['error']}")
                    return resp.get("result")
            time.sleep(0.1)
        raise MCPError(f"MCP request timed out: {method}")

    def _mcp_notify(self, method: str, params: dict) -> None:
        """Send a JSON-RPC notification (no response expected)."""
        with self._lock:
            if not self.proc or self.proc.poll() is not None:
                return
            msg = {"jsonrpc": "2.0", "method": method, "params": params}
            assert self.proc.stdin
            self.proc.stdin.write(json.dumps(msg) + "\n")
            self.proc.stdin.flush()

    def _read_loop(self) -> None:
        """Background thread: read MCP responses from stdout."""
        assert self.proc and self.proc.stdout
        for line in self.proc.stdout:
            self._stdout_bytes += len(line)
            line = line.strip()
            if not line:
                continue
            try:
                msg = json.loads(line)
            except json.JSONDecodeError:
                continue
            req_id = msg.get("id")
            if req_id is not None:
                with self._lock:
                    self._response_buffer[req_id] = msg

    def list_tools(self) -> list[dict]:
        """List all MCP tools exposed by the GameGPT server."""
        result = self._mcp_request("tools/list", {})
        return result.get("tools", [])

    def call_tool(self, name: str, arguments: dict) -> Any:
        """Call an MCP tool by name."""
        result = self._mcp_request("tools/call", {
            "name": name,
            "arguments": arguments,
        })
        return result

    def is_running(self) -> bool:
        with self._lock:
            return self.proc is not None and self.proc.poll() is None
