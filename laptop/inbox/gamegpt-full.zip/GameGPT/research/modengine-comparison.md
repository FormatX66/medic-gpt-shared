# No Man's Sky: ModEngine/Lua modding vs Cheat Engine table coverage

Research date: 2026-09-19. Inert research only — no mods downloaded, installed, or executed.
Sources are linked inline at the bottom.

## Terminology note

There is **no NMS-specific tool called "ModEngine"** in the public modding ecosystem.
NMS Lua-based modding is done with **AMUMSS** (a Lua *script processor*, not a runtime
injector) plus MBINCompiler: Lua scripts describe edits to the game's `.mbin` data files,
AMUMSS decompiles them to `.exml`, applies the edits, recompiles, and repacks them into
`.pak` mods that the game loads at startup. ("ModEngine" is a FromSoftware-series mod
loader and is not applicable to NMS; this report treats "ModEngine approaches" as
AMUMSS/Lua `.pak` modding.)

This is a fundamentally different mechanism from Cheat Engine:

| | AMUMSS / Lua `.pak` mod | Cheat Engine table |
|---|---|---|
| Mechanism | Build-time edit of game data files | Runtime memory scan + code injection |
| When it acts | Game startup (loads `.pak`) | While game runs |
| What it changes | **Static config values** (rates, speeds, forces, costs) | **Live runtime state** (current HP, current units, flags) |
| Persistence | Survives save/load, works offline | Must be re-applied per session |
| "Freeze" semantics | Not possible (no per-frame writes) | Possible (timer-driven writes) |
| Fragility | Breaks across game patches until recompiled | Breaks across patches when AOBs shift |

## AMUMSS/Lua capabilities summary

AMUMSS Lua scripts target named `.mbin` files (`MBIN_FILE_SOURCE`) and edit named
properties inside them (`VALUE_CHANGE_TABLE`). The key globals files for gameplay tuning:

- **`GCPLAYERGLOBALS.GLOBAL.MBIN`** — jetpack forces/speeds/fill rates/drain, sprint
  stamina drain, melee boost, rocket boots, fall speed, mining laser heat rate, hazard
  protection drain/recharge, life support drain, shield/health regen. A published Lua
  example sets `JetpackFillRate`/`JetpackFillRateMidair` to 999 (effectively infinite),
  `JetpackUpForce`, `JetpackForce`, `JetpackDrainHorizontalFactor`, `RocketBoots*`
  drain speeds, etc.
- **`GCSPACESHIPGLOBALS.GLOBAL.MBIN` / `GCGAMEPLAYGLOBALS.GLOBAL.MBIN`** — ship speeds,
  maneuverability, pulse engine behavior, launch costs, shield recharge (the Modular
  Flight Framework edits exactly these blocks for ship speed/maneuverability).
- **`GCVEHICLEGLOBALS*.MBIN` (per exocraft)** — exocraft boost drain, fuel consumption,
  mining laser heat.
- **Weapon/product MBINs** — base damage numbers, cooldowns, clip sizes are data, so a
  Lua script *can* retune them (e.g. raise mining beam damage, lower cooldowns), but it
  cannot "freeze" runtime ammo or NOP a consumption check.
- **Save data is NOT touched.** Currencies, standings, inventory contents, and current
  HP/shield values live in the save file and in runtime memory only — no `.mbin`
  property controls them. For those, the "cleaner API" equivalent is the
  **NMSSaveEditor** (Java save editor: edits Units/Nanites/Quicksilver, inventory
  quantities, standings/reputation, exosuit/ship/multitool base stats), not a Lua mod.

AMUMSS also handles mod conflicts by merging Lua scripts into one `.pak` (alphabetical
load order), which is its main advantage over hand-edited `.pak`s: scripts re-apply to
the latest game files after a patch. Community resources: the
`nms-amumss-lua-mod-script-collection` repo (MetaIdea org), the NMS Modding Discord
(`#amumss-lua` room), Nexus Mods NMS section, and the NMS wiki.

## Overlap table

CE table: "No Man's Sky - BD - CT V1.32" (~138 AOB patterns).
"Lua equivalent" = achievable via AMUMSS/Lua `.pak` mod. "Save editor" = achievable via
NMSSaveEditor (cleaner than CE for save-data values). "CE-only" = requires runtime
memory injection.

### Exosuit

| CE script | Lua equivalent | Save editor | Verdict |
|---|---|---|---|
| Unlimited Run Stamina | **Yes** — sprint stamina drain rate in `GCPLAYERGLOBALS` | — | Lua replaces |
| Unlimited Shields | Partial — shield recharge rate/delay in globals; *freeze* is CE-only | — | Partial |
| Unlimited Jetpack Propulsion | **Yes** — `JetpackFillRate`, drain factors in `GCPLAYERGLOBALS` | — | Lua replaces |
| Unlimited Jetpack Aqua Propulsion | **Yes** — underwater jetpack globals | — | Lua replaces |
| Unlimited Life Support | **Yes** — life support drain rate in `GCPLAYERGLOBALS` | — | Lua replaces |
| Unlimited Health | Partial — health regen rates in globals; invulnerability is CE-only | — | Partial |
| Unlimited Environmental Suit (Oxygen/Thermals/Toxicity) | **Yes** — hazard protection drain rates / recharge amounts in globals | — | Lua replaces |
| Unlimited Cloak | Partial — cloak duration/drain may be global-tunable; freeze is CE-only | — | Partial |

### Exocraft

| CE script | Lua equivalent | Save editor | Verdict |
|---|---|---|---|
| Unlimited Exocraft Fuel | **Yes** — fuel consumption in `GCVEHICLEGLOBALS` | — | Lua replaces |
| Unlimited Exocraft Boost | **Yes** — boost drain in vehicle globals | — | Lua replaces |
| Unlimited Exocraft Thruster | **Yes** — thruster values in vehicle globals | — | Lua replaces |
| Unlimited Exocraft Mining Laser | **Yes** — exocraft laser heat rate | — | Lua replaces |

### Starship

| CE script | Lua equivalent | Save editor | Verdict |
|---|---|---|---|
| Unlimited Starship Shields | Partial — shield recharge rate; freeze is CE-only | — | Partial |
| Unlimited Launch Thruster | **Yes** — launch fuel cost in spaceship globals | — | Lua replaces |
| Unlimited Hyper Drive | **Yes** — warp cell cost / hyperdrive range in globals | — | Lua replaces |
| Unlimited Pulse Engine | **Yes** — pulse fuel drain in spaceship globals | — | Lua replaces |
| Zero Thermal Load (Photo Cannon) | Likely — weapon heat in weapon/player globals | — | Lua likely |
| Rocket Launcher - Hyper Cool Down | Likely — weapon cooldown values are data | — | Lua likely |

### Multitool

| CE script | Lua equivalent | Save editor | Verdict |
|---|---|---|---|
| Unlimited Mining Beam / No Overheat | **Yes** — mining laser heat rate in `GCPLAYERGLOBALS` | — | Lua replaces |
| One Shot Kills | Partial — base weapon damage is data (can be raised hugely); true one-shot is injection | — | Partial |
| Unlimited Boltcaster Ammo | Partial — clip/ammo values are data; *freeze* is CE-only | — | Partial |
| Unlimited Terrain Manipulator | Partial — charge consumption; freeze is CE-only | — | Partial |
| Unlimited Blaze Javelin Ammo | Partial — same as boltcaster | — | Partial |
| Unlimited Grenades | Partial — same pattern | — | Partial |
| Instant Charge / Unlimited Neutron Cannon Ammo | Partial — charge time is tunable; freeze is CE-only | — | Partial |
| No Topographic Scanner Recharge | Partial — scanner recharge time tunable | — | Partial |
| Instant Identification (Analysis Scanner) | **No** — timing/behavior logic, not a config value | — | **CE-only** |

### Crafting / Refiner

| CE script | Lua equivalent | Save editor | Verdict |
|---|---|---|---|
| Crafting consumes no inventory resources | Partial — recipe costs are per-product data (a Lua script could zero costs, but it is not a clean global); universal no-consume is a code patch | — | Partial / CE cleaner |
| Unlimited Refiner Fuel | **No** — runtime behavior | — | **CE-only** |
| Unlimited Refiner Resources | **No** — runtime behavior | — | **CE-only** |

### Inventory / Currency / Standings

| CE script | Lua equivalent | Save editor | Verdict |
|---|---|---|---|
| Last Moved Item / slot counts (Inventory) | **No** | **Yes** — NMSSaveEditor edits inventory quantities directly | Save editor replaces |
| Units / Nanites / Quicksilver | **No** | **Yes** — NMSSaveEditor edits all three currencies | Save editor replaces |
| Gek / Vy'keen / Korvax standings | **No** | **Yes** — NMSSaveEditor edits milestones/reputation | Save editor replaces |
| Merchants / Mercenaries / Explorers guild standings | **No** | **Yes** — same | Save editor replaces |
| Free Items / +600M Units | **No** | **Yes** | Save editor replaces |
| Remove All Technology Overloads | **No** | Possibly (raw JSON edit) | Save editor partial |

### Speed multipliers

| CE script | Lua equivalent | Save editor | Verdict |
|---|---|---|---|
| Ship Engine Speed multiplier | **Yes** — canonical Lua mod case (Modular Flight Framework) | — | Lua replaces |
| Pulse Engine Speed multiplier | **Yes** — spaceship globals | — | Lua replaces |
| Jetpack Speed / Aerial Force / Upward Force | **Yes** — `JetpackForce`, `JetpackUpForce`, `JetpackMaxSpeed` etc. | — | Lua replaces |
| Walk/Run Speed multiplier | **Yes** — movement speed globals | — | Lua replaces |

## Summary counts (approximate, by CE script entry)

- **Lua-replaceable:** ~20 entries (all drain-rate/fuel/speed/force/heat/cooldown globals —
  the bulk of Exosuit, Exocraft, Starship, and Speed Multiplier sections)
- **Partial (Lua can retune the underlying value, CE does the freeze/one-shot):** ~15
  entries (shields/health/cloak freeze, ammo freezes, one-shot kills, scanner)
- **Save-editor-replaceable:** ~12 entries (currencies, standings, inventory quantities)
- **CE-only (runtime logic, not config):** ~6 entries (analysis scanner instant ID,
  refiner fuel/resources, universal no-consume crafting, no-overheat-style behavior hacks)

## Recommendations

1. **Replace drain/fuel/speed AOBs with Lua mods.** Every "Unlimited X" script that works
   by freezing a depleting resource has a corresponding `.mbin` global (jetpack fill
   rate, life support drain, hazard drain, launch cost, boost drain, mining heat).
   Lua `.pak` mods are patch-resilient (re-run AMUMSS after updates), conflict-mergeable,
   and don't need per-session injection. This covers the majority of the CE table's
   gameplay value.
2. **Replace currency/standing/inventory AOBs with save editing.** NMSSaveEditor edits
   Units/Nanites/Quicksilver, standings, and item quantities deterministically with
   automatic backups — strictly safer than CE pointer scans against save-backed memory
   (which also must keep paired auto/manual saves in sync).
3. **Keep memory-level work only for true runtime behaviors:** refiner fuel/resources,
   instant analysis-scanner ID, universal no-consume crafting, and freeze-style
   invulnerability. These have no data-file representation; they are code-logic
   patches and stay in CE/AOB territory.
4. **Treat "Partial" entries as Lua-first.** E.g. instead of "Unlimited Boltcaster
   Ammo" via injection, a Lua mod can set clip size to a huge value and reduce
   consumption — not infinite, but stable and update-safe. Reserve CE for cases where
   the Lua ceiling is actually hit.
5. **Do not pursue a runtime "ModEngine" for NMS.** The ecosystem's Lua story is
   build-time data editing; there is no sanctioned runtime Lua API in NMS. Runtime
   needs stay with memory tools (CE) or the official-adjacent save editor.

## Sources

- AMUMSS (Lua script processor for NMS): https://github.com/HolterPhylo/AMUMSS
- AMUMSS Lua mod script collection (MetaIdea): https://github.com/metaidea/nms-amumss-lua-mod-script-collection/blob/HEAD/Hypn0tick/README.md
- Modular Flight Framework (Lua flight tuning): https://github.com/metaidea/nms-amumss-lua-mod-script-collection/blob/HEAD/Hypn0tick/01%20-%20Hypn0tick%20Mods/Modular%20Flight%20Framework/README.md
- Lua jetpack example (GCPLAYERGLOBALS values): https://www.youtube.com/watch?v=qTe4d3l5vDk
- Steam discussion: what Lua files are / AMUMSS usage: https://steamcommunity.com/app/275850/discussions/0/4362373157497980718/
- NMSSaveEditor (currencies, standings, inventory): https://github.com/goatfungus/NMSSaveEditor
- Save editor guide (GINX): https://www.ginx.tv/en/no-mans-sky/save-editor-how-to-use
- NMS wiki: Hazard Protection mechanics: https://nomanssky.fandom.com/wiki/Hazard_Protection
