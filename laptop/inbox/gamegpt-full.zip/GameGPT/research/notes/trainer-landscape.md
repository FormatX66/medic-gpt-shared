# No Man's Sky — trainer landscape (2026-09-18)

Status: **RESEARCH ONLY / UNVERIFIED.** Nothing below is confirmed
against the running game. Option lists change; treat them as snapshots,
not specs. Companions: `game-dossier.md`, `best-cheats.md`,
`modding-landscape.md`.

## 1. WeMod (trainer by MrAntiFun)

Thread: https://community.wemod.com/t/no-mans-sky-cheats-and-trainer-for-steam/90197
Xbox thread (has the 2026 update log): https://community.wemod.com/t/no-mans-sky-cheats-and-trainer-for-xbox/124451
GOG thread: https://community.wemod.com/t/no-mans-sky-cheats-and-trainer-for-gog/101982

- **36 options on Steam** (snapshot 2026-09-18): Unlimited Health, No
  Radiation, Radiation Rate, Unlimited Jetpack, Super Jetpack Speed,
  Unlimited Stamina, Stamina Consumption Rate, Stamina Gain Rate,
  Unlimited Life Support, Easy Atlas Pass, Easy Alien Translation, Easy
  Craft, Super Speed, Speed Multiplier, Easy Construction, Unlimited
  Materials Packs, Super Packs Size, Unlimited Units, Unlimited Nanite
  Clusters, Unlimited Quicksilver, Set Units, Set Nanite Clusters, Set
  Quicksilver, Set Packs Size, No Reload, Auto Reload, Unlimited Ammo,
  Unlimited Mining Beam Energy, No Tool Overheat, Tool Overheat Rate,
  Unlimited Ship Health, Instant Ship Gun Cooldown, Ship Gun Overheat
  Rate, Instant Ship Rocket Cooldown, Ship Rocket Heat Rate, One-Hit
  Kills.
- Per-store builds: Steam, GOG, and Xbox/Windows Store each get their
  own trainer (the app auto-detects the installed version).
  https://community.wemod.com/t/no-mans-sky-cheats-and-trainer-for-xbox/124451
- **Maintenance cadence**: the Steam changelog's most recent entries are
  09/13, 09/14, 09/16, and **09/17/2026** (yesterday) — all "Bug fixes
  and game compatibility improvements". Four compat pushes in five days
  is a hotfix storm right after an NMS patch (the pattern, not the
  cause, is the observation).
  https://community.wemod.com/t/no-mans-sky-cheats-and-trainer-for-steam/90197
- Recent feature adds show where demand is: Unlimited Jetpack +
  Unlimited Quicksilver (04/11/2026), Easy Construction (06/23/2026),
  and a 09/03/2025 batch of **rate tunables** (Radiation Rate, Stamina
  Consumption/Gain Rate, Speed Multiplier, Auto Reload, Tool/Ship-Gun/
  Ship-Rocket heat rates). (Same thread.)
- **Known breakage** (Steam thread, user reports after an update):
  Unlimited Jet Pack, Easy Atlas Pass, Easy Craft, Unlimited Materials
  Packs, Super Packs Size, Unlimited Units, Set Units, Unlimited Ammo
  all reported dead; Easy Craft also has a long-standing placeable
  bug — placeables like the portable refiner can't be placed while it
  is on, because the cheat tricks the craft check rather than zeroing
  costs. https://community.wemod.com/t/no-mans-sky-cheats-and-trainer-for-steam/90197?page=42
  and https://community.wemod.com/t/no-mans-sky-cheats-and-trainer-for-steam/90197?page=19

## 2. FLiNG

Page: https://flingtrainer.com/trainer/no-mans-sky-trainer/

- **27 options, Game Version v1.5-v7.x+, Last Updated 2026-09-13**
  (4 days before this writing): Infinite Health / Shield / Stamina,
  Jetpack Infinite Energy, Multi-Tool No Overheat, No Reload, Infinite
  Grenades, Infinite Items, No/Minimum Crafting Requirements,
  Super Damage/One Hit Destroy, Starship Infinite Health / Shield /
  Weapons No Overheat, Infinite Units, **Add Units**, **Set Game Speed**,
  Open Locks Without Atlas Pass, Translate All Alien Languages,
  Infinite Nanites, Infinite Quicksilver, Launch Thruster / Pulse Engine
  / Hyperdrive Infinite Energy, Scanner Instant Charge, Life Support /
  Hazard Protection / Multi-Tool Infinite Energy.
- **Update cadence from the download table**: builds dated 2024-05-02,
  2024-05-31, 2024-07-22, 2024-10-19, 2025-02-01, 2026-04-14,
  2026-09-13. Latest file: `No.Mans.Sky.v6.3-v7.x.Plus.27.Trainer-FLiNG`
  (970 KB, 9,712 downloads in ~4 days). Roughly: NMS-major-update →
  new FLiNG build within days-to-weeks. (Same page.)
- *Speculation*: the "v7.x" coverage plus CheatHappens' "The Swarm
  6.42" board note (see §3) suggests NMS may be at/near a v7.x build
  by Sep 2026 — verify against the installed build before trusting any
  trainer.

## 3. CheatHappens (MrAntiFun/Caliber)

Page: https://www.cheathappens.com/21242-PC-No_Mans_Sky_cheats
Board (ACTIVE): https://www.cheathappens.com/show_board2.asp?headID=130551&titleID=21242&onPage=121

- Current build (April 08, 2026, "XENO ARENA", Steam/GOG/Windows
  Store/Xbox GamePass, contributor Caliber): God Mode, Unlimited Hazard
  Protection, Unlimited Life Support Energy, Unlimited Stamina/Sprint,
  Unlimited Jetpack, Unlimited Tool Life Durability, No Tool Overheat,
  Unlimited Ammo, No Reload, Easy Terrain Manipulator + Minotaur Bore,
  Easy Craft/Build/Open, **Free Research in Construction Research
  Unit**, **Free Research 2**, Reset Resources, **Reset Wanted Level**,
  **No Alert**, No Space Weapon Overheat, Infinite Launch Thrusters,
  Infinite Impulse Drive, Unlimited Warp Cells, Easy Hyperdrive, Easy
  Interpret Languages, Minotaur set (jetpack/cannon/laser/bore),
  **Game Speed**, plus **editors for Credits / Nanite Clusters /
  Quicksilver**. (CheatHappens page; promo-era readme mirrored at
  https://megagames.com/trainers/no-mans-sky-beyond-v24-1-trainer-cheat-happens)
- **Patch-cadence signal**: on the CH board (Sep 18, 2025), trainer
  author Caliber is quoted as saying "8 patches in this month
  already" re: Hello Games' patch tempo (context: NMS updates breaking
  the trainer). https://www.cheathappens.com/show_board2.asp?headID=130551&titleID=21242&onPage=123
- Board notes the trainer was on "The Swarm 6.42" as of that page's
  crawl. https://www.cheathappens.com/show_board2.asp?headID=130551&titleID=21242&onPage=123

## 4. Rhark's Fearless Revolution trainer (community free trainer)

Thread: https://fearlessrevolution.com/viewtopic.php?t=21315

- **31 cheats, game version v156355, last updated 20.01.2026**:
  Infinite Health/Shield/Hazard Protection/Life Support/Sprint,
  Crafting Won't Consume Resources, Easy Access Locks, Easy
  Translation, Super Movement Speed, Infinite Grenades/Hyperdrive/
  Jetpack/Multi-Tool Energy/Resources, Infinite Ship Health/Shield,
  Max Nanites/Quicksilver/Units, No Multi-Tool/Ship/Rocket Overheat,
  No Reload, No Scanner Cooldown, Super Damage, plus **Edit: Units /
  Nanites / Quicksilver, Edit: Movement Speed Modifier, Damage
  Multiplier**.
- **Changelog = the breakage record** (abridged):
  - 05.09.2022 — "replaced Easy Craft option; **could not update**" it.
  - 12.06.2023 — "Updated to support build-11432080. **Many cheats
    were removed due to being unable to reproduce.**"
  - Then steady: 23.11.2023, 10.05.2024, 08.08.2024, 30.05.2025,
    20.01.2026 — each tied to a new game build.
- Takeaway: **crafting/economy hooks are the fragile ones**; simple
  drain-freeze cheats (health/stamina/overheat) survive. When a major
  build lands, some options don't get fixed — they get *dropped*.
  (Same thread.)

## 5. What the changelogs reveal about patch breakage

- **Who breaks first**: crafting/UI checks (Easy Craft, Easy Access
  Locks, Easy Atlas Pass), currency setters (Set Units, Unlimited
  Units), and inventory-stack tricks (Super Packs Size, Unlimited
  Materials Packs). Reported dead on WeMod Steam post-update;
  Rhark *deleted* options he couldn't re-find.
  https://community.wemod.com/t/no-mans-sky-cheats-and-trainer-for-steam/90197?page=42
  https://fearlessrevolution.com/viewtopic.php?t=21315
- **Update speed**: WeMod pushes compat fixes within ~1–3 days of an
  NMS patch (the 09/13–09/17/2026 run; Xbox trainer saw 02/24, 03/07,
  04/18, 06/15, 06/26/2026). FLiNG rebuilds in days-to-weeks. CH's
  Caliber tracks hotfix-by-hotfix ("8 patches in this month").
  Sources: §1–§3 links.
- **Hello Games' tempo is the treadmill**: frequent small patches
  (the CH "8 patches" quote; WeMod's four-updates-in-five-days run).
  Any GameGPT memory profile inherits exactly this treadmill — this
  is the operational argument for the weekly sweep.
  https://www.cheathappens.com/show_board2.asp?headID=130551&titleID=21242&onPage=123

## 6. Trainer options vs cheat tables (delta)

What trainers offer that Blind Distortion's table doesn't (per
`game-dossier.md` §1a feature list):
- **Rate/multiplier tunables** — Radiation Rate, Stamina Consumption/
  Gain Rate, Speed Multiplier, Overheat/Heat Rates, Damage Multiplier,
  Movement Speed Modifier (WeMod, Rhark).
- **Game Speed** (FLiNG, CH), **Add/Set currency with exact values**
  (WeMod "Set Units", FLiNG "Add Units", CH editors).
- **Wanted/alert control** — Reset Wanted Level, No Alert (CH only).
- **Free Research in Construction Research Unit** (CH only).
- Minotaur suite (CH), Easy Terrain Manipulator (CH).

What Blind Distortion's table offers that trainers don't:
- Corvette Building unlocks/scale/part unlocks, Settlement instant
  construction + requirement bypass, Xeno Arena gene edits/companion
  god-mode, faction/guild rank setters (Gek/Vy'keen/Korvax/guilds →
  99), Instant Mining + Instant Analysis Scanner, Instant Portal
  Activation + instant interaction, Refiner instant-finish + no
  consumption, Last Moved Inventory Item editing, No Tech Overloads,
  Runic Lens cloak, Nautilon boost, ship speed multipliers.

*Speculation*: the delta reflects audience, not just capability —
trainers sell to friction-removal players; tables serve
builders/completionists who want systems-level control.

## 7. Other makers (brief)

- **PLITCH** — 27 NMS cheats (free: Infinite Sprint, Infinite Jetpack,
  Set selected item to max count; premium: Godmode, Add Units, etc.),
  mobile-app activation. https://www.plitch.com/en/games/no-man-s-sky-989
  Marketing copy also advertises teleportation and instant building —
  UNVERIFIED, treat as claims. https://megagames.com/trainers/plitch-trainer-no-mans-sky
- **ModEngine** — paywalled table, free build ships 2 working cheats;
  see `game-dossier.md` §1a. Not a trainer in the WeMod sense.
- **MrAntiFun = WeMod's NMS trainer author** (users thank him in the
  WeMod threads); vg247 calls the MrAntiFun NMS Trainer "far and away
  the most popular" NMS mod. https://www.vg247.com/no-mans-sky-mods-cheats
- No standalone dR.oLLe or CheatEvolution NMS trainer surfaced in
  search (2026-09-18).

## 8. GameGPT implications

1. **The demand map is confirmed**: every trainer converges on
   movement/building/travel throttles — the same cluster `best-cheats.md`
   ranked. Voice triggers ("jetpack forever", "free build mode",
   "instant refine", "go faster") map 1:1 onto trainer options.
2. **Design lesson from WeMod's Easy Craft footgun**: the trainer
   fakes "has materials" instead of zeroing costs, which breaks
   placeable items (portable refiner). A GameGPT crafting cheat should
   zero costs / skip checks, not fake inventory. https://community.wemod.com/t/no-mans-sky-cheats-and-trainer-for-steam/90197?page=19
3. **Trainers are closed-source → product signal, not research
   leads.** They don't publish AOB anchors, so they can't feed the
   weekly sweep directly. Blind Distortion's table remains the anchor
   source; trainers tell us *what players want*, tables tell us *how
   to find it in memory*.
4. **Treadmill budget**: trainers update within days of each NMS patch
   and still drop unfixable options (Rhark 2023). Any GameGPT memory
   profile needs the same per-patch re-validation plan — nothing here
   changes the sweep requirement.

*End. All UNVERIFIED against the running game.*
