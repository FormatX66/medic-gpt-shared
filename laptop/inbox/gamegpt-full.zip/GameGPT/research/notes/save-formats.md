# No Man's Sky — save formats (deep dive)

Compiled 2026-09-17. Status: **RESEARCH ONLY / UNVERIFIED.** Nothing here
has been confirmed against the running game. Speculation is marked.
Every factual claim carries its source URL; summarize, never reproduce
large copyrighted text.

Companion notes: `game-dossier.md` §3 (overview), `modding-landscape.md`
§2 (editors). This note is the format-level detail those skim.

---

## 1. Save locations (PC)

- **Steam (Windows)**: `%AppData%\HelloGames\NMS\st_<SteamID>\` —
  https://github.com/korokun/libnom.io
- **GOG (Windows)**: `%AppData%\HelloGames\NMS\DefaultUser\` —
  https://github.com/korokun/libnom.io
- **Steam Deck / Proton (Linux)**: `~/.local/share/Steam/steamapps/compatdata/275850/pfx/drive_c/users/steamuser/AppData/Roaming/HelloGames/NMS/st_<SteamID>/` (libnom.io gives `Application Data/...` variant on SteamDeck; pljeroen/nmstoolkit gives `AppData/Roaming/...`) —
  https://github.com/korokun/libnom.io , https://github.com/pljeroen/nmstoolkit
- **Steam (macOS)**: `~/Library/Application Support/HelloGames/NMS/st_<SteamID>` —
  https://github.com/korokun/libnom.io
- **Microsoft Store (Windows PC)**: `%LocalAppData%\Packages\HelloGames.NoMansSky_bs190hzg1sesy\SystemAppData\wgs\<XboxID>_<GUID>\`, files `containers.index`. **Reloading modified saves while the game is running does not work** on this platform —
  https://github.com/korokun/libnom.io
- Non-PC (for completeness): PS4 `memory.dat` + `savedata*.hg` (homebrew or Save Wizard); PS5 unsupported by libnom.io (PS4 build played on PS5 works with extra steps); Switch `manifest*.dat` (homebrew JKSV/EdiZon); Xbox via MS-Store cloud sync —
  https://github.com/korokun/libnom.io

## 2. File layout: slots, pairs, metadata

- **15 save slots max.** Slot N = `saveN.hg` (slot 1 is the odd one: plain `save.hg`; there is **no** `save1.hg`) —
  https://github.com/pljeroen/nmstoolkit , https://steamcommunity.com/app/275850/discussions/0/2254559285377326878/?l=english&ctp=3
- Each slot is **4 files**: `save.hg` + `mf_save.hg` + `save2.hg` + `mf_save2.hg` (slot 2: `save3/4` + `mf_save3/4`, ... slot 15: `save29/30` + `mf_save29/30`) —
  https://steamcommunity.com/app/275850/discussions/0/3841053085042064909/?l=danish
- `mf_save*.hg` are **metadata files** paired one-to-one with each `save*.hg` —
  https://github.com/pljeroen/nmstoolkit
- `accountdata.hg` sits alongside — **account-level data (plain JSON, not compressed)**; community reports it holds cross-save cosmetic/quicksilver purchases (e.g. everything claimed at the Anomaly QS vendor) —
  https://github.com/pljeroen/nmstoolkit , https://steamcommunity.com/app/275850/discussions/0/3839928078013988420/?l=norwegian
- Slot-to-file mapping is **not** guaranteed ordered (a player's slots 1,2,3,5 can map to arbitrary file numbers) — check which pair is the target before editing —
  https://steamcommunity.com/app/275850/discussions/0/2254559285377326878/?l=english&ctp=3

### 2a. Auto-save vs manual/restore point

- One of the two pairs per slot is the **auto-save**, the other the **manual save ("restore point")**: ship exit and save beacons/save points write the manual pair; the game also keeps auto-saves —
  https://steamcommunity.com/app/275850/discussions/0/3841053085042064909/?l=danish , https://steamcommunity.com/app/275850/discussions/0/597412823492008349
- One community reporter's observation: **odd-numbered files ≈ auto-save, even-numbered ≈ manual save** — this is **not guaranteed** and not official; the reliable discriminator is **file modification timestamp** —
  https://steamcommunity.com/app/275850/discussions/0/2254559285377326878/?l=english&ctp=3
- Only one pair is needed to play a save; if one pair corrupts, deleting it forces the game to fall back to the other pair —
  https://steamcommunity.com/app/275850/discussions/0/597412823492008349
- **Editing practice**: community save-editor guidance says edit the most recent pair (the one the game will actually load) —
  https://steamcommunity.com/app/275850/discussions/0/601914519534582404
  ; GameGPT's prior verified work edits **both pairs together** (Units→2B, supercharge edits — see `game-dossier.md` §3). Rationale for the pair approach: whichever pair the game picks next, the edit holds; both editors auto-backup before writes so the blast radius is reversible —
  https://github.com/goatfungus/NMSSaveEditor
- *Speculation*: the `mf_save*.hg` metadata likely carries slot name, timestamp, and quick-look data used by the load menu (unconfirmed; editors treat them as a matched pair with the save).

## 3. Save container format

- `.hg` files (except `accountdata.hg`) are **LZ4 block-compressed, obfuscated JSON**.
- Block layout (per nmstoolkit, from reverse engineering): magic `0xFEEDA1E5` LE, compressed size, uncompressed size (512 KB except the last block), padding zeros, LZ4 data. Decompressed payload = JSON with a **trailing null byte** —
  https://github.com/pljeroen/nmstoolkit
- JSON keys are **obfuscated to 3-character codes**; mapping files (e.g. `jsonmap.txt`, or libNOM.map) translate, e.g. `F2P → Version`, `6f= → PlayerStateData`, `;l5 → Inventory`, `:No → Slots`, `b2n → Id`, `1o9 → Amount` —
  https://github.com/pljeroen/nmstoolkit , https://github.com/korokun/libnom.io
- Deps of a correct parser: LZ4 (K4os.Compression.LZ4), obfuscation map (libNOM.map), SpookyHash —
  https://github.com/korokun/libnom.io
- **Format versions** (the game's save-schema generations; all but the original are parseable by libNOM.io):
  - `2000` — vanilla, unsupported by libNOM.io (see MetaIdea's nms-savetool) —
    https://github.com/korokun/libnom.io
  - `2001` — Foundation 1.10 → Prisms 3.53
  - `2002` — Frontiers 3.60 → Adrift 4.72 (incl. Waypoint 4.00 extension)
  - `2003` — Worlds Part I 5.00 → The Cursed 5.29
  - **`2004` — Worlds Part II 5.50+, incl. 5.53 extension = current** —
    https://github.com/korokun/libnom.io
- *Speculation*: the top-level `Version` field in the JSON (e.g. `"Version": 46002` in the nmstoolkit example) appears to be a **build number**, not the 2001–2004 format generation; the format generation is likely tracked separately or implied by the game's build —
  https://github.com/pljeroen/nmstoolkit

## 4. JSON structure (deobfuscated keys)

Top level (per nmstoolkit example):
```json
{
  "Version": 46002, "Platform": "PC", "ActiveContext": "Main",
  "BaseContext": { "PlayerStateData": { ... } },
  "ExpeditionContext": { ... }   // same shape, expedition saves
}
```
https://github.com/pljeroen/nmstoolkit

### 4a. `PlayerStateData` — the big one

- **Position/universe** (two confirmed address forms):
  - `PlayerStateData.UniverseAddress.GalacticAddress.VoxelZ` (libNOM.io JSONPath example) —
    https://github.com/korokun/libnom.io
  - `PlayerStateData.UniverseAddress` → `RealityIndex` (galaxy number: 0 = Euclid, 1 = Hilbert…), `GalacticAddress` → `VoxelX`, `VoxelY`, `VoxelZ`, `SolarSystemIndex`, `PlanetIndex` —
    https://steamcommunity.com/app/275850/discussions/0/1369506834137834955/?l=schinese
  - A teleport/location edit must move **both** `UniverseAddress` **and** `SpawnStateData` together (old community guidance) —
    https://steamcommunity.com/app/275850/discussions/0/1369506834137834955/?l=schinese
- **Inventories** (same shape for exosuit/ship/multitool/freighter/vehicle/base storage):
  - `Inventory` (exosuit general), `Inventory_TechOnly`, `Inventory_Cargo`, `ShipInventory`, `WeaponInventory`, `FreighterInventory` —
    https://github.com/pljeroen/nmstoolkit
  - Supercharged slot locations per goatfungus issue #690: exosuit `Inventory_TechOnly`; multitool current `WeaponInventory` (and the matching entry under `Multitools → <slot> → Store`); freighter `FreighterInventory_TechOnly`; exocrafts `VehicleOwnership → <slot> → Inventory_TechOnly`; starships `ShipOwnership → <slot> → Inventory_TechOnly` —
    https://github.com/goatfungus/NMSSaveEditor/issues/690
  - Owned entities: `ShipOwnership[]`, `WeaponOwnership[]` (multitools), plus `VehicleOwnership`, `Multitools`, `FreighterOwnership`-style arrays —
    https://github.com/pljeroen/nmstoolkit , https://github.com/goatfungus/NMSSaveEditor/issues/690
  - Each inventory: `Slots[]`, `ValidSlotIndices[]`, `SpecialSlots[]` (supercharged = `TechBonus` type), `Width`, `Height`. Each slot: `Type.InventoryType` (`Substance`/`Product`/`Technology`), `Id`, `Amount`, `MaxAmount`, `DamageFactor`, `Index{X,Y}` —
    https://github.com/pljeroen/nmstoolkit
  - **Item-ID prefixes**: `^` = installed non-removable tech (e.g. `^LASER`, `^YOURSHIP_LAUNCH`); `YOURSHIP_*` / `YOURSUIT_*` / `YOURMULTI_*` / `YOURFREIG_*` / `YOURVEHIC_*` = installed base tech aliases (strip prefix to get catalogue ID, e.g. `YOURSHIP_PULSEDRIVE → SHIPJUMP1`); `UP_*` / `UA_*` / `U_*` = upgrade modules with tier digits (`UP_LASER1`); `#nnnnn` suffix = procedural seed (e.g. `^UP_BOLT4#52847`) —
    https://github.com/pljeroen/nmstoolkit
  - Vanilla inventory ceilings (exceed at own risk — "the game might BREAK"): cargo 10×12, tech 10×6, base storage 10×5 —
    https://github.com/goatfungus/NMSSaveEditor
- **Other documented keys**:
  - `SpawnStateData` (player spawn/position block; edit alongside `UniverseAddress` for teleports) —
    https://steamcommunity.com/app/275850/discussions/0/1369506834137834955/?l=schinese
  - `ExpeditionSeedsSelectedToday` (seen in a save-corruption workaround; expedition state) —
    https://gameranx.com/features/id/157641/article/no-mans-sky-next-psa-theres-a-new-save-corrupting-bug-heres-what-you-need-to-do/
  - Identity/mission keys surfaced by the GamePass→Steam conversion guide: `BaseStatId`, `CurrentMissionId`, `PreviousMissionId`, `MissionId`, `ObjectId`, `TraitIds`, `MultiplayerLobbyId`, plus platform `UID`/`USN` values —
    https://steamcommunity.com/app/275850/discussions/0/3316358999118787641/
  - `PlayerStateData` exists **in live memory** too, not just on disk ("Both of these variables are part of PlayerStateData, which is part of the save data in memory") — relevant to future memory work —
    https://fearlessrevolution.com/viewtopic.php?t=13080
- **Currency keys**: *unconfirmed at key level*. All three currencies are plain numeric values in `PlayerStateData` (every editor edits them; memory tables reach them as editable pointers via inventory UI structures). The widely-used quicksilver key is believed to be under a "Specials"-style name — **verify against a live save before scripting** —
  speculation, based on https://github.com/goatfungus/NMSSaveEditor and the memory-table finding in `game-dossier.md` §1a.
- **Total play time**: editable via NomNom; GameGPT's prior verified work used **decoded TotalPlayTime** to pick edit targets —
  https://github.com/zencq/NomNom ; prior work per `game-dossier.md` §3.

### 4b. What each editor proves is addressable

- **NomNom** (zencq): most complete; currencies, stats, fleets, inventories, fast travel to any system (i.e. UniverseAddress writes), appearances, knowledge/words, expedition + Twitch-drop rewards, total play time; manager can save as **human-readable JSON**, copy/move/swap slots, and **transfer a save to another platform**; auto-backup/recovery —
  https://github.com/zencq/NomNom
- **goatfungus NMSSaveEditor** (Java, "for WORLDS"): currencies; exosuit/multitool/ship/freighter base stats **incl. seed** (ship/multitool/companion identity is seed-driven); squadron wingmen; frigates; companions/pets (name/seed/biome/type); settlements (population/happiness/production/upkeep/debt); milestones/reputation; inventory add/clone/repair/refill/resize; **raw JSON editor**; known tech/products/**words/glyphs** toggles; account data + unlocks; base/freighter structure backup-restore across systems/saves; auto-backup to zip before writes; Steam/GOG + PS4 (Save Wizard) + MS Game Pass —
  https://github.com/goatfungus/NMSSaveEditor
- **libnom.io** (korokun, the .NET library under NomNom): read/write all formats 2001–2004 on all platforms; JSONPath get/set, e.g. `GetJsonValue("PlayerStateData.UniverseAddress.GalacticAddress.VoxelZ")` —
  https://github.com/korokun/libnom.io
- **nmstoolkit** (pljeroen, experimental): adds cross-save "vault" for transferring ships/multitools/companions between saves, discovery backup/restore, settlement editing with seed-based ownership —
  https://github.com/pljeroen/nmstoolkit
- **NMS Companion** (Nexus, on libnom.io): inventory transfer companion app —
  https://github.com/korokun/libnom.io

### 4c. Seeds = identity (key GameGPT concept)

- Ships, multitools, companions/pets, and upgrade modules carry **seed** values; editing the seed re-rolls the item's procedurally generated identity. The seed-hunting community deliberately keeps the seed→parts mapping private (nmstoolkit honors this for previews) —
  https://github.com/goatfungus/NMSSaveEditor , https://github.com/pljeroen/nmstoolkit

## 5. Cross-save (PC-edited data → console)

- **Cross-save arrived in The Cursed patch 5.25**: connect platform accounts to a Hello Games ID at https://cloud.nomanssky.com/cross-save ; up to **5 saves** in cross-platform storage; upload per-save from the cloud icon on any connected platform; download via the in-game Cross-Save Manager on the save-selection screen; size/timestamp mismatch → choose which version to keep —
  https://cloud.nomanssky.com/cross-save
- libNOM.io's readme states the GameGPT-relevant consequence directly: *"With the cross-save feature added in The Cursed patch 5.25 it is now easier than ever to edit your saves and play them on any platform. If you have No Man's Sky on any PC platform you can easily edit saves there and use them on another platform after uploading."* —
  https://github.com/korokun/libnom.io
- Independent confirmations: NomNom's manager can "transfer your save to another platform you own the game on" —
  https://github.com/zencq/NomNom ; community guide: use NomNom to export a GamePass save as JSON, remap `XB→ST`, UID/USN, and re-import into a Steam dummy save (risky, manual) —
  https://steamcommunity.com/app/275850/discussions/0/3316358999118787641/
- Caveats: cross-save is **opt-in per save** (upload icon), capped at 5, and a mismatch prompt can clobber edits — upload immediately after editing, from the PC, before playing elsewhere. Platform-identity fields (`UID`/`USN`, `Id`↔`ID` casing quirks) are the known friction in manual platform conversion —
  https://cloud.nomanssky.com/cross-save , https://steamcommunity.com/app/275850/discussions/0/3316358999118787641/

## 6. Quick-reference: keys to remember

| Path | What | Source |
|---|---|---|
| `PlayerStateData.UniverseAddress.GalacticAddress.{VoxelX,VoxelY,VoxelZ,SolarSystemIndex,PlanetIndex}` | position / fast travel | libnom.io, Steam community |
| `PlayerStateData.UniverseAddress.RealityIndex` | galaxy index (0=Euclid) | Steam community |
| `PlayerStateData.SpawnStateData` | spawn block (move with UniverseAddress) | Steam community |
| `PlayerStateData.Inventory{,_TechOnly,_Cargo}` / `ShipInventory` / `WeaponInventory` / `FreighterInventory` | inventories | nmstoolkit |
| `PlayerStateData.{ShipOwnership,WeaponOwnership,VehicleOwnership}` | owned ships/multitools/exocraft | nmstoolkit, goatfungus #690 |
| `…Inventory.Slots[]` `{Type,Id,Amount,MaxAmount,DamageFactor,Index}` | slot contents | nmstoolkit |
| `…Inventory.SpecialSlots[]` (`TechBonus`) | supercharged slots | nmstoolkit, goatfungus #690 |
| `accountdata.hg` | account unlocks, QS purchases | Steam community |
| `mf_save*.hg` | per-save metadata pair | nmstoolkit |
| `ExpeditionSeedsSelectedToday` | expedition state | Gameranx |
| `CurrentMissionId` etc. | mission state | Steam community |

## 7. Open questions / gaps

1. Exact JSON key names for the three currencies (Units / Nanites / Quicksilver) — need a live-save read or the libNOM.map key table.
2. `mf_save*.hg` content/schema — presumed metadata, unconfirmed.
3. Whether `Version: 46002`-style top-level version or something else gates the 2001–2004 format generations.
4. MS Store: edited saves load only if written while the game is **not** running; cross-save from a modified MS-Store save is untested in these sources.
5. Key casing/identity quirks in platform conversion (`Id` vs `ID`, UID/USN) — relevant only if doing manual platform transfers outside cross-save.

*End. UNVERIFIED research — confirm against the running game before any GameGPT profile use.*
