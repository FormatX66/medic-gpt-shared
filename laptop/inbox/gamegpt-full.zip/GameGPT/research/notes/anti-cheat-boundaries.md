# No Man's Sky — Anti-cheat & ban-safety boundaries (GameGPT safety fence)

Compiled 2026-09-18. Status: **RESEARCH ONLY / UNVERIFIED.** None of this
has been confirmed against the running game in a Bruce-authorized live
session. Community consensus below is years-consistent (2018 → 2025), but
Hello Games could change posture at any time. Re-check before any live
GameGPT profile work.

---

## 1. Anti-cheat software: none found

- **No EAC, no BattlEye, no proprietary kernel-level anti-cheat.**
  Community consensus across years: the game ships without any third-party
  anti-cheat client. ([Steam forums, Aug 2018](https://steamcommunity.com/app/275850/discussions/0/1743342383229088877/))
- **Steam VAC: NOT enabled for NMS (app 275850).** Multiple community
  threads state there is no VAC on this game
  ([Aug 2018 thread](https://steamcommunity.com/app/275850/discussions/0/1743342383229088877/)).
  SteamDB's app 275850 record shows no VAC/Steamworks anti-cheat flag
  (checked 2026-09-18; [steamdb.info/app/275850/info](https://steamdb.info/app/275850/info/)).
  A 2018 post explains the technical reason: "You cannot be VAC banned in
  games that are not Steam server protected. This game is Host only so
  they have no server detection's."
  ([source](https://steamcommunity.com/app/275850/discussions/0/1743342383229088877/))
- **Architecture is why.** NMS multiplayer is peer-to-peer / host-based,
  not dedicated-server with server-side validation, so there is no
  authority to run anti-cheat against.
  ([Steam forums, Aug 2018](https://steamcommunity.com/app/275850/discussions/0/1743342383229088877/))
- **Caveat — boilerplate warnings exist.** WeMod's NMS trainer page carries
  a moderator warning that multiplayer trainer use "can result in a ban
  from the servers, or a VAC ban from steam itself" and is used "at your
  own risk"
  ([WeMod NMS thread](https://community.wemod.com/t/no-mans-sky-cheats-and-trainer-for-steam/90197?page=19)).
  This reads as generic trainer-site CYA: it conflicts with the
  years-consistent community record (no VAC enabled, no documented
  cheat bans) and no such ban has ever been reported. Treat the warning as
  caution, not evidence.

## 2. Single-player safety: cheats are functionally safe

- **Community consensus (2018 → 2025): no bans for cheating in solo play —
  cheat tables, trainers, save editors, glitches are all tolerated.**
  - Aug 2018: "No VAC on this game, and if you cheat, for the moment you
    cant get banned, i have use cheat engine on this game on solo or on
    multi" ([Steam](https://steamcommunity.com/app/275850/discussions/0/1743342383229088877/))
  - Sep 2025: "No bans for mods. This is mostly a sp game with co-op mp
    tacked on. Use mods, glitches, save editors. All is good."
    ([Steam](https://steamcommunity.com/app/275850/discussions/0/604166953732567500/?ctp=2))
  - Legal-review site (2024): nothing in the NMS EULA/ToS regional
    documents reviewed mentions cheating/exploiting/hacking; only
    malicious activity (DDoS, server interference, malware) is
    termination-worthy
    ([ExpertBeacon](https://expertbeacon.com/is-cheating-allowed-in-no-mans-sky/))
- **Sean Murray (Hello Games founder) framing:** "A single player open
  universe game with a co-op component. Play it your way." — quoted in
  [ExpertBeacon](https://expertbeacon.com/is-cheating-allowed-in-no-mans-sky/).
  Repeated interviews: no interest in punishing cheating in an
  exploration game with no leaderboards and no competitive multiplayer
  ([same source](https://expertbeacon.com/is-cheating-allowed-in-no-mans-sky/)).
  In a gameplay showcase Murray spawned items/resources with console
  commands to build a base ([same source](https://expertbeacon.com/is-cheating-allowed-in-no-mans-sky/)).
- **No ban reports tied to cheating exist in the community record.** The
  only documented ban is a griefer (see §3) — banned for hate-speech
  griefing, not cheats.
- **Developer EULA caveat (on paper vs. in practice).** The EULA's
  §6.1 Code of Conduct states "All hacking, cheating, bug exploitation,
  misuse of the Game, trolling, deceptive or abuse conduct is prohibited"
  (quoted by a forum poster who read the EULA pre-Beyond, 2019;
  [Steam](https://steamcommunity.com/app/275850/discussions/0/1762481957312386651/?l=tchinese&ctp=3)).
  So the *legal right* to act exists, but in ~9 years of public record
  Hello Games has never exercised it against cheaters — only against
  griefers/hate-speech (§3). Verdict: paper clause, zero enforcement
  history for cheats.
- **Practical risk (not ban risk): crashes.** A 2018 Cheat Engine user
  reports the game gets unstable and crashes frequently with CE running
  ([Steam](https://steamcommunity.com/app/275850/discussions/0/1743342383229088877/));
  a 2021 WeMod user reports frequent crashes with the trainer active
  ([WeMod](https://community.wemod.com/t/no-mans-sky-cheats-and-trainer-for-steam/90197?page=19)).
  GameGPT's risk budget should weight *crash/instability* over *ban risk*.

## 3. Multiplayer / expeditions / Nexus: enforcement targets people, not cheats

- **The only documented permanent ban: a griefing troll, not a cheater.**
  Hello Games permanently banned a player terrorizing the Galactic Hub
  with hate-speech content (reported via base reports; Kotaku, ~2022;
  [Kotaku](https://kotaku.com/no-mans-sky-galactic-hub-bases-civilized-space-neo-nazi-1848739563),
  [ScreenRant](https://screenrant.com/no-mans-sky-griefer-ban-troll-galactic-hub/)).
  Enforcement was driven by community base-reports, not any automated
  cheat detection.
- **Hello Games' stated enforcement policy:** report problem players to
  the *platform holder* (Steam/Sony/Microsoft) for a platform-wide ban
  "rather than us banning them just from No Man's Sky." — quoted by a
  2025 Steam poster citing Hello Games
  ([Steam](https://steamcommunity.com/app/275850/discussions/0/604166953732567500/?ctp=2)).
  Per the same thread: "HG does not issue bans for pretty much anything
  other than extreme griefing/trolling and highly offensive naming of
  things. Definitely not for modding, save editing, or otherwise
  cheating."
- **Griefing tools HG *does* provide:** per-player network permission
  settings (text chat, VO, base building, PvP can be limited to
  no-one/friends/global) plus in-game and external moderation tools
  ([Polygon, 2021](https://www.polygon.com/22412342/no-mans-sky-role-play-community-infestation-griefing-pvp-combat/)).
  Sean Murray on griefing: the team watches it and treats it as an
  "isolated" issue because "griefing is not rewarded in No Man's Sky"
  ([Kotaku, 2018](https://kotaku.com/no-mans-sky-has-griefers-but-tools-to-keep-them-out-ar-1828205172)).
- **Cheating in MP carries social, not account, risk.** Hosts can kick
  players from their session
  ([Steam, 2018](https://steamcommunity.com/app/275850/discussions/0/1743342383229088877/));
  a WeMod poster advises making sure "anyone you interact/play with who
  may notice, is ok with it, you don't want to get reported"
  ([WeMod](https://community.wemod.com/t/no-mans-sky-cheats-and-trainer-for-steam/90197?page=19)).
  *Speculation:* reports about *cheating* almost certainly land in a
  queue that is never actioned; reports about *griefing/hate* are the
  ones HG acts on.
- **Expeditions:** no expedition-specific anti-cheat has ever been
  documented. Expeditions are seasonal shared-milestone modes with
  exclusive rewards, run on the same P2P architecture
  ([RPS](https://www.rockpapershotgun.com/no-mans-sky-new-expedition-update-launches-today)).
  Community members openly discuss replaying expeditions via shared save
  files ([GameRant](https://Gamerant.com/no-mans-sky-best-expeditions-to-replay-play-again-twice/),
  dossier §4b). *Speculation:* because expedition rewards are cosmetic /
  convertible to normal saves and there are no leaderboards with prizes,
  there is nothing to protect — consistent with zero enforcement.
- **Bottom line for GameGPT:** solo/private cheats = community-consensus
  safe; public-session cheats that affect others = kickable, and griefing
  with cheats (death traps, base destruction, hate content) is the one
  behavior class with an actual ban on record.

## 4. Steam VAC status (explicit)

- **NMS is not VAC-enabled.** See §1: no VAC flag in SteamDB's
  app-275850 record, multi-year community consensus ("No VAC on this
  game"), and no VAC-secured servers (P2P/host model). A VAC ban from
  running a trainer alongside NMS is not an attested risk; the only
  WeMod mention of it is boilerplate.
- *Unverified nuance:* whether VAC modules can flag third-party tools
  globally (independent of game) is outside this research — VAC bans
  require the account to be connected to a VAC-secured server while
  running cheat software, which NMS never does
  ([Steam VAC FAQ reference](https://help.steampowered.com/en/faqs/view/647C-5CC1-7EA9-3C29),
  via [Steam VAC discussion](https://steamcommunity.com/discussions/forum/9/601913251731836552)).

## 5. Mods in multiplayer: official stance and community practice

- **Hello Games provides an official /MODS folder and DISABLEMODS.txt**;
  an in-game warning screen appears when mods are detected, stating mods
  are not officially supported — it is a support disclaimer, not a ban
  threat ([Steam, 2019](https://steamcommunity.com/app/275850/discussions/0/1815422173036811221/?l=russian)).
- **"Hello Games has no public statement about mods, apart from
  recommending us to disable them when you have to troubleshoot a bug."**
  ([Steam, 2021](https://steamcommunity.com/app/275850/discussions/0/3044985412480720625/?l=czech))
- **Community consensus: no ramifications for using mods in multiplayer.**
  "This is a single player game with very minor MP elements... Feel free
  to Mod or Not it's up to you."
  ([Steam, 2021, marked best answer](https://steamcommunity.com/app/275850/discussions/0/3044985412480720625/?l=czech))
  The practical downside of mods is save/game breakage after updates
  (hence DISABLEMODS.txt), not bans
  ([Steam, 2018](https://steamcommunity.com/app/275850/discussions/0/1736588252379852763/?l=polish)).
- **Visual/cheat-adjacent mods are the most-endorsed on Nexus** (see
  dossier §2) — the modding scene operates fully in the open with no
  enforcement pushback.
- *Unverified nuance:* cosmetic mods on a modded client joining an
  unmodded host are client-side; the 2018 claim that planet-generation
  mods could propagate to joining players predates NEXT's MP model and
  may no longer apply — flag for the weekly sweep, not for safety.

## 6. GameGPT safety fence (distilled)

**Treat as community-consensus guidance, not legal advice. Everything
UNVERIFIED against the running game.**

| Category | Community verdict | Notes |
|---|---|---|
| Solo cheat tables (CE AOB scripts: god mode, infinite resources, speed, free craft, instant refine) | SAFE | No anti-cheat to detect them; no ban reports in ~9 yrs |
| Solo save edits (units, seeds, tech, inventory, words) | SAFE | Guarded paired-save path already proven; save editors are open community practice |
| Solo trainers (WeMod, MrAntiFun) | SAFE (solo) | Risk is crashes, not bans |
| Mods in solo | SAFE | Official /MODS folder; worst case = broken save after an update |
| Mods/cheats in private/co-op sessions with consenting players | SAFE (socially) | No enforcement; only social friction |
| Mods/cheats in public MP (Anomaly, random sessions) | LOW account risk, kickable | Hosts can kick; no documented cheat bans. Keep GameGPT cheats OUT of public sessions by default anyway — social risk, not safety |
| Expeditions with cheats | LOW risk, avoid | No expedition-specific anti-cheat documented; but expeditions are the one shared-progression context — GameGPT should default to clean saves there |
| Griefing with cheats (death traps, base attacks, offensive names/content) | **BANNABLE** | The ONE documented ban class; HG escalates to platform-holder bans |
| Cheats that harass/kill other players (PvP abuse) | **BANNABLE-adjacent** | EULA §6.1 prohibits it; enforcement history is via griefing reports |

**GameGPT profile rules derived from this:**
1. Default all voice-triggered cheats to **solo or private-session
   contexts only**. Never auto-enable cheats while the player is in a
   public session.
2. **Never touch another player**: no damage/debuff/position effects on
   non-hostile players, no base destruction, no name/content edits —
   this is the only ban-bearing boundary.
3. In **expeditions**, prefer no-cheat or cosmetic-only profiles until a
   live session confirms the posture.
4. Weight the risk budget toward **crash/stability** (attested) over
   **ban risk** (unattested): guarded writes, Last Known Good, restore
   paths — the existing GameGPT harness already does this.
5. Re-verify annually or on any "Hello Games enforcement" news; the
   weekly sweep watches the sources in dossier §7 — add
   [the ban-thread](https://steamcommunity.com/app/275850/discussions/0/604166953732567500/?ctp=2)
   and [Kotaku's moderation coverage](https://kotaku.com/no-mans-sky-galactic-hub-bases-civilized-space-neo-nazi-1848739563)
   as sentiment canaries.

## 7. Key sources

- https://steamcommunity.com/app/275850/discussions/0/1743342383229088877/ — "How is hacking handled now that multiplayer is available?" (2018; no VAC, host-model, no bans)
- https://steamdb.info/app/275850/info/ — SteamDB app record (no VAC flag; checked 2026-09-18)
- https://expertbeacon.com/is-cheating-allowed-in-no-mans-sky/ — ToS review + Murray quotes (2024)
- https://steamcommunity.com/app/275850/discussions/0/604166953732567500/?ctp=2 — "How can I get older rewards?" (Sep 2025; "No bans for mods... HG does not issue bans for pretty much anything other than extreme griefing")
- https://kotaku.com/no-mans-sky-galactic-hub-bases-civilized-space-neo-nazi-1848739563 — the one documented permanent ban (griefer, ~2022)
- https://screenrant.com/no-mans-sky-griefer-ban-troll-galactic-hub/ — same ban, second source
- https://www.polygon.com/22412342/no-mans-sky-role-play-community-infestation-griefing-pvp-combat/ — HG moderation statement (2021)
- https://kotaku.com/no-mans-sky-has-griefers-but-tools-to-keep-them-out-ar-1828205172 — Murray on griefing (2018)
- https://steamcommunity.com/app/275850/discussions/0/1762481957312386651/?l=tchinese&ctp=3 — EULA §6.1 Code of Conduct quote (2019)
- https://steamcommunity.com/app/275850/discussions/0/1815422173036811221/?l=russian — "will i get banned if i use mods?" (2019; official /MODS folder)
- https://steamcommunity.com/app/275850/discussions/0/3044985412480720625/?l=czech — modding + multiplayer ramifications (2021; best answer: none)
- https://community.wemod.com/t/no-mans-sky-cheats-and-trainer-for-steam/90197?page=19 — WeMod trainer thread (boilerplate MP warning; crash reports)

*End. All UNVERIFIED — confirm against the running game before GameGPT
profile use.*
