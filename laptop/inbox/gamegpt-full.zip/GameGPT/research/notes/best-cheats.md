# No Man's Sky — best-cheats research (2026-09-18)

Status: RESEARCH ONLY. Nothing here is verified against the running game.
Skyrim-style rule applies: no values are touched until Bruce authorizes a live run.

## What the table actually contains

`tables/NMSfrf.ModEngine.2024-07-09.CT` (ModEngine, Fearless Revolution,
posted 2024-07-09, Adrift Expedition era, Steam/EPiC/GamePass, CE 7.0+).

Honest accounting: the thread advertises 23 options, but the free table ships
only **2 working cheats** — both Auto Assembler scripts anchored on AOB
patterns (good: patch-resilient discovery anchors; still UNVERIFIED):

1. **Unlimited Stamina** — AOB `00 F3 0F 10 8B A4 30 00 00` in NMS.exe.
   Hooks the stamina-decrease path, forces the value to 1.0 (float).
2. **No Overheating** — AOB `F3 0F 10 8B A0 11 00 00` in NMS.exe.
   Same shape: zeroes the heat accumulation on the mining-laser path.

The third entry ("More CHEATS AVAILABLE HERE") is a promo dialog linking to
modengine.net — not a cheat. The remaining 21 advertised options (Infinite
Units, Unlimited Health/Jetpack, One-Hit Kills, Free Crafting, No Sentinels,
Bypass Atlas Locks, etc.) are **not in this file**.

The best-maintained community table — Blind Distortion's "No Man's Sky -
NMS (Steam)" (344 posts, 23 pages, last edited Sep 10, 2026, AOB-based) —
had its download pulled by the author on Sep 10, 2026 pending updates.
Watching for its repost is the highest-value next step; the weekly sweep
covers it.

## Fun-factor analysis (from the advertised feature set + game knowledge)

Ranked by what actually makes NMS more fun, not by what is easiest to find:

1. **Unlimited Jetpack + Stamina** — traversal is the game. Sprint-jump-jetpack
   chains turn planetary exploration from a walk into flight. Highest fun/$
2. **No Overheating (mining laser)** — removes the most annoying throttle in
   the early-game resource loop. Pure tedium deletion.
3. **Free Crafting / Easy Crafting** — base building is the creative core;
   resource costs are the tax on creativity. Zero-cost building unlocks the
   "toy" mode of the game.
4. **Unlimited Hyperdrive fuel** — the galaxy is the map; fuel is the loading
   screen between fun. Removing it makes exploration continuous.
5. **No Sentinels** — for builders and screenshotters; removes the combat
   interrupt from the chill loop. (One-Hit Kills is the mirror for combat fans.)
6. **Infinite Units** — economy-breaking, but NMS's economy is a means to
   ships/multitools, not the fun itself. Useful, not transformative.
7. **Decode All Words / Always Have Conversation Item** — quality-of-life for
   lore hunters; minor.
8. **Bypass Atlas Locks** — skips scripted gates; only fun if you have already
   played the Atlas path straight once.

Design note for GameGPT profiles: the fun cheats cluster around **removing
throttles on movement, building, and travel** — not god-mode combat. Voice
triggers ("jetpack forever", "free build mode") map naturally to these.

## Next verification steps (need Bruce + game running)

- Confirm the 2 AOB patterns still hit in the current NMS build.
- When Blind Distortion's table reposts, pull it — it is the deep table.
- Translate confirmed patterns into guarded GameGPT profiles (fresh pre-read,
  expected_current, readback — standard Tier rules).

## Research additions (2026-09-18 deep-research pass)

The ranking above holds up — the Blind Distortion feature list and Nexus
mod popularity confirm movement/building/travel throttles are the fun
center. But the deep pass surfaced cheat options the ranking missed:

- **Instant Refiner (refiner finishes instantly + consumes nothing)** —
  refiner waiting is pure dead time; the Blind Distortion table ships it
  as a dedicated option. Should rank alongside No Overheating as tedium
  deletion.
- **Speed Multipliers (ship / pulse engine / jetpack / walk-run)** — by
  BigJit901, in the Blind Distortion table. The ranking has "unlimited"
  cheats but no *faster* cheats; multipliers are arguably more fun than
  removes (speed *up* rather than cost *down*). Voice: "go faster".
- **Instant Interactions / Instant Portal Activation** — deletes the
  hold-E micro-wait scattered across the whole game. Small per instance,
  enormous in aggregate.
- **No Technology Overloads** — lets you install unlimited tech in an
  inventory; the upgrade-stack chase is the real progression (S-class /
  suspicious modules, supercharged slots), and this cheat is the
  "complete the build" button.
- **Corvette Building unlocks (Voyagers-era)** — remove finalization
  requirements, unlock all parts, remove invalid-build messages.
  Corvette building is the newest creative system; free-build powers
  apply here too.
- **Settlement: Instant Construction Completion** — settlement building
  has real-time waits; skipping them is the builder's equivalent of
  instant refine.
- **Max-out inventory stacks** — the inventory scarcity complaint is
  perennial; stack-to-max is a lighter touch than infinite everything.
- **No Reload / No Overheat (weapons)** — the combat mirror of No
  Overheating; belongs in the combat-fan mirror of rank 5.
- **Rank modifiers (Gek / Vy'keen / Korvax / guilds)** — faction standing
  grind bypass; minor, lore-adjacent.

High-risk category (keep separate from fun toggles): expedition reward
unlock editing, milestone/reputation edits — progression bypasses that
can cheapen the shared-universe experience for others. Voice-gate these
or keep them manual.
