# No Man's Sky — modding landscape

Compiled 2026-09-18. Status: **RESEARCH ONLY / UNVERIFIED.** Mods are
treated here as research maps (where values live, what players want),
not as trusted coordinates. Nothing here has been executed or verified
against the running game.

---

## 1. The toolchain

### MBINCompiler (monkeyman192) — the foundation
- https://github.com/monkeyman192/MBINCompiler
- Converts NMS's binary **MBIN** data files into editable XML-ish
  **MXML**, and back. NMS stores almost all game data (globals, reward
  tables, recipes, procedural rules) as MBINs inside PAKs; the compiler
  is how the community reads and edits them.
- Each NMS update can change MBIN formats, so the compiler ships a new
  version per game version. **Updated ~3 days before 2026-09-18** — a
  strong signal the tool is current with the latest NMS build, and a
  good weekly-watch source: a new compiler release usually means NMS
  updated and memory tables may have broken.
- libMBIN (the underlying C# library) ships structure definitions that
  name every field in every global file — a semantic map of what *can*
  exist at runtime, not proof of memory layout.

### AMUMSS (HolterPhylo) — the mod assembler
- https://github.com/HolterPhylo/AMUMSS (Nexus mods/957:
  https://www.nexusmods.com/nomanssky/mods/957)
- Lets modders write mods as **Lua scripts** (mod-definition scripts,
  not runtime scripts) that describe MBIN changes; AMUMSS applies them
  and bundles a `.pak`. It **auto-updates MBINCompiler** on launch and
  includes PAK browser / MXML exploration tools.
- Why it matters for research: a huge share of Nexus mods ship as
  AMUMSS Lua sources, so the *diff a mod makes* is human-readable —
  exactly which global fields change, and by how much. These diffs are
  the cleanest evidence of which tuning knobs exist.

### NMS Mod Builder / NMSPE (cmkushnir)
- https://github.com/cmkushnir/NMSModBuilder — PAK/mod search, conflict
  detection, viewers, diffs, query scripts. Also maintains per-version
  EXML caches (the repo's per-update branch notes, e.g. "NMS 5.10"
  branch notes, show how fields move between updates).

### Data layout (post-Worlds Part II)
- NMS 5.50 (Worlds Part II) changed the PAK container format; old
  HGPAKTool-era mods broke, and the new layout puts mod content under
  `GAMEDATA\MODS` (with EXML/MBIN overrides preserving vanilla paths)
  (https://steamcommunity.com/app/275850/discussions/0/595139710753505669/).
- Practical takeaway: "where does X live" answers from 2023 modding
  guides may be wrong for the current game; always prefer the newest
  compiler/wiki revision.

### The modding wiki (stepmodifications)
- Landing page: https://stepmodifications.org/wiki/NoMansSky:Landing_Page
- Current State of Modding:
  https://stepmodifications.org/wiki/NoMansSky:Current_State_of_Modding —
  "thousands of settings" exposed through global files.
- Key reference pages:
  - **GCPLAYERGLOBALS.GLOBAL** —
    https://stepmodifications.org/wiki/NoMansSky:Reference_Guides/Global_Files/GCPlayerGlobals —
    names and default values for jetpack, stamina, movement, life
    support, swimming, mech, etc. (e.g. `JetpackFillRate` 0.5,
    `JetpackMaxSpeed` 5, `JetpackMaxUpSpeed` 30, `GroundRunSpeed` 8).
  - **REWARDTABLE.MBIN** —
    https://stepmodifications.org/wiki/NoMansSky:Reference_Guides/Global_Files/GCRewardTable —
    under `METADATA/REALITY/TABLES/`; controls what missions/salvage/
    flora give (items, currencies, amounts).

---

## 2. Save editors (the persistence layer)

| Editor | Source | Notes |
|---|---|---|
| **NomNom** | https://github.com/zencq/NomNom | "Most complete savegame editor"; currencies, stats, inventories, fleets, fast travel, words/knowledge, expedition/Twitch rewards, total play time; auto-updates via libMBIN mapping |
| **goatfungus NMSSaveEditor** | https://github.com/goatfungus/NMSSaveEditor | Steam/GOG/PS4/Xbox; currencies, base stats incl. **seeds** (ship/multitool/companion identity), inventories, settlements, known tech/words/glyphs, account unlocks |
| **NMS Companion** | Nexus (uses libnom.io) | Companion app, inventory transfer |
| **libnom.io** | https://github.com/korokun/libnom.io | The .NET save library under the editors; save formats 2001–2004 documented |

What save editing proves (and therefore what the *guarded save-edit*
path already owns): currencies are plain numbers; ships/multitools/
companions are **seed integers** (change the seed, change the item's
identity); inventories are slot arrays (item ID + count); known
words/glyphs/tech are toggles. None of this needs live memory access.

---

## 3. Key mods and what each teaches

**Movement is the #1 modded axis** — evidence that throttles, not
power, are what players pay to remove:
- **Krypton** by Goldenveins & Gemini (jetpack/flight overhaul) and
  **Fluid Flight v1.3** (NMS v6.18-era flight model) — both rewrite
  `GCPLAYERGLOBALS` jetpack/flight fields. *Teaches*: the full movement
  feel is data-driven; a memory profile hunting "jetpack forever"
  should start from these field names.
- **Reduced Launch Cost 4.1** (top-endorsed) and **Auto-Sprint** —
  the two most-resented micro-taxes. *Teaches*: "remove launch fuel"
  and "always sprint" are evergreen cheat candidates.
- Steam jetpack-tweak threads (e.g.
  https://steamcommunity.com/app/275850/discussions/0/737034982498784595)
  publish exact field tweaks: fill/drain rates, speeds, force, height
  caps, underwater and space-jetpack values — a ready-made search
  vocabulary for runtime discovery.

**Building/friction removal is #2**:
- **Better NMS modpack** (Exosolar, built on Babscoole's modding) —
  removes per-part build limits, enables build-anywhere/rotation/
  scaling
  (https://www.nexusmods.com/nomanssky/mods/3056). *Teaches*: build
  limits are per-part tunables, not hardcoded — the "no build limits"
  cheat has a known data shape.
- **MrAntiFun NMS Trainer** — "far and away the most popular" NMS mod
  (https://www.vg247.com/no-mans-sky-mods-cheats): god mode, infinite
  stamina/jetpack/health, easy crafting, no reload, wanted-level reset,
  unlimited warp cells, currency editors. *Teaches*: the trainer
  feature list is a market-validated cheat ranking — it matches the
  `best-cheats.md` ranking closely.

**World/loop mods show what money can't buy**:
- **Big Things 5**, **Shaidak's Generation**, **Busier Space** —
  procedural-generation overhauls
  (https://gamerant.com/starfield-no-man-sky-mod-setting/). *Teaches*:
  exploration richness is a data knob (spawn tables, biome rules) —
  outside GameGPT's live-memory scope but relevant to "make exploring
  fun" requests.
- **REWARDTABLE.MBIN** editing — missions/salvage/flora rewards are
  data. *Teaches*: "more nanites per scan" is a table edit, not a
  memory hack — different tool, same outcome.

**What mods can't do (and memory/save edits can)**:
- Mods apply at load and affect tuning; they cannot freeze a draining
  value mid-frame (unlimited stamina *during* sprint), zero heat
  accumulation, or one-shot a sentinel — those need live hooks.
- Mods cannot change *your* currencies/inventory/identity — that's the
  save layer.
- Implication: the three layers (tuning mod / live memory / save edit)
  are complementary, not competing. GameGPT's voice cheats should pick
  the cheapest layer that delivers the effect.

---

## 4. Mods as GameGPT research inputs

1. **AMUMSS Lua diffs are the fastest way to learn a knob's name and
   range** — search a mod's source for the effect you want, read which
   fields it touches, then use those names as the vocabulary for live
   memory discovery.
2. **Mod popularity = cheat demand signal.** Endorsement counts on the
   Nexus top pages are a standing vote on which throttles hurt most.
   Watch them in the weekly sweep.
3. **Mod update churn mirrors table churn.** When MBINCompiler ships a
   new version or big mods need rebuilds, NMS updated — assume AOB
   patterns are stale until re-verified.
4. **Never execute or install mods during research.** Read sources,
   diffs, and docs only. NMS mods are inert data until the game loads
   them; keep it that way.

*End of landscape notes. UNVERIFIED research — confirm against the
running game before any GameGPT profile use.*
