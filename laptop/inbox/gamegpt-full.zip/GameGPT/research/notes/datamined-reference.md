# No Man's Sky — datamined reference

Compiled 2026-09-18. Status: **RESEARCH ONLY / UNVERIFIED.** Every
value below is a research lead until confirmed against the running
game in a Bruce-authorized live session. Speculation is marked as
such. Companion files: `game-dossier.md`, `modding-landscape.md`,
`best-cheats.md`, `../parsed/`, `../tables/`.

Scope: internal names, ID catalogs, economy numbers, and stat
formulas that GameGPT needs as vocabulary. No mods, no execution,
knowledge only.

---

## 1. Datamining sources, ranked by GameGPT usefulness

### 1a. Step modding wiki — the globals/fields authority
- https://stepmodifications.org/wiki/NoMansSky:Landing_Page
- Already cataloged in `modding-landscape.md` (GCPLAYERGLOBALS.GLOBAL,
  REWARDTABLE.MBIN, UNLOCKABLEITEMTREES.MBIN). Additions:
- **UnlockableItemTrees** —
  https://stepmodifications.org/wiki/NoMansSky:UnlockableItemTrees —
  full tech-tree declarations live in
  `METADATA\REALITY\TABLES\UNLOCKABLEITEMTREES.MBIN` (trees + cost
  types/currencies).
- **Reference Tables (2017, Path Finder era)** —
  https://stepmodifications.org/wiki/NoMansSky:Reference_Guides/Reference_Tables —
  marked stale on-page. Gmr_Leon's sheet covers biome types, damage
  types, tech crafting requirements, products/substances values, stat
  upgrades, creature data, weather tables. Only useful for historical
  ID cross-referencing, not current values.
- Reliability: high for field names; check revision date for values.

### 1b. zencq/Pi — procedural item database with internal names
- https://github.com/zencq/Pi
- "Collection of every procedural item in No Man's Sky": CSV +
  parquet per item with **seed, weighted perfection %, actual stats,
  and procedural names in different languages. Files and stats are
  named with the game internal names** (e.g. `UP_RAIL1` ranged raw
  30–40 while the UI showed +2%). Best seeds auto-collected in
  Pi.xlsx. Caveat: Corvette parts from Voyagers 6.00 / Breach 6.10 not
  yet included; some items lag the current game version.
- GameGPT relevance: highest. This is where internal upgrade-module
  IDs and their stat ranges live in machine-readable form.

### 1c. nomanssky.fandom.com — the display-name/values reference
- Community-curated; several pages explicitly cite datamined game
  files. Examples: Items value tables —
  https://nomanssky.fandom.com/wiki/Items ; Tradeable —
  https://nomanssky.fandom.com/wiki/Tradeable ; Inventory slot costs
  — https://nomanssky.fandom.com/wiki/Inventory ; Language —
  https://nomanssky.fandom.com/wiki/Language ; Hyperdrive Upgrade —
  https://nomanssky.fandom.com/wiki/Hyperdrive_Upgrade .
- Reliability: good for current-display values and crafting recipes;
  always check page update dates (several pages show "updated 625+
  days ago", i.e. wiki software revision age, not necessarily data
  age). Treat as second-tier vs. MBIN-derived data.

### 1d. nomanssky.info — item database (JS-heavy, unreadable via text)
- A text fetch of https://nomanssky.info failed (browser-service
  could not fetch). It is a community item database site, but I could
  not verify its contents, provenance, or currency this way. Needs a
  live-browser pass. Treat as unassessed.

### 1e. NMSCD crafting-map — recipe/ingredient graph
- https://github.com/NMSCD/crafting-map — "every possible crafting
  and recipe combination for any item" (live: nmscd.com/crafting-map).
  Crafting-tree source for "what do I need to make X" questions.

### 1f. Other catalogs
- **nomanssky.api** (gurrenm3, 2021-era) —
  https://github.com/gurrenm3/nomanssky.api — a C# memory-hooking API
  that claimed control of "all 20 Global MBin files" and
  Units/Nanites/Quicksilver/Health/Shield get/set. Old; the API shape
  (globals → hooked values) is what matters, not its code.
- **NMS Mod Builder / NMSPE** per-version EXML caches
  (https://github.com/cmkushnir/NMSModBuilder) — raw compiled game
  data per update, i.e. the closest thing to a complete internal-ID
  database. *Speculation*: mining these caches would yield the full
  item/tech ID list, but this needs someone with the repos pulled
  locally.

---

## 2. Internal item / technology / product IDs

- **Upgrade modules** — internal stat names live in zencq/Pi files
  (https://github.com/zencq/Pi); example internal stat `UP_RAIL1`.
- **Mission/quest IDs** — appear in saves as e.g. `ACT2_STEP8`,
  `ACT2_STEP9`; players have mapped steps to rewards by reading game
  data (Log Encryption Key = ACT2_STEP8, Vy'keen Tablet = STEP9,
  Divergence Cube = STEP10) —
  https://steamcommunity.com/app/275850/discussions/0/2577697394288891073/ .
  Save editors (NomNom, NMSSaveEditor) read these from libMBIN's
  mapping.json.
- **UnlockableItemTrees.MBIN** holds the blueprint-tree item list with
  internal IDs —
  https://stepmodifications.org/wiki/NoMansSky:UnlockableItemTrees .
- **AI ship strengths** are datamined IDs: `PIRATE_EASY` (Health 5200,
  LevelledExtraHealth 14000, LaserDamageLevel 1, Shield STANDARD),
  `STANDARD` shield (Health 5600, LevelledExtraHealth 19000,
  RechargeTime 5, RechargeDelayTime 6), `PIRATE` —
  https://steamcommunity.com/app/275850/discussions/0/3722818378187795904/?l=hungarian .
  AI ship damage is a flat value from damage tables keyed by
  `AI_SHIPGUN` (same post).
- **Gap**: no single public page was found that lists all current
  internal item/tech IDs in one place. The working recipe is:
  MBINCompiler-decompiled tables (MXML), NMSModBuilder EXML caches,
  zencq/Pi (procedural items), and save-editor mapping files. A
  future build could compile this into GameGPT's own ID reference.

---

## 3. Economy numbers (units / nanites / quicksilver)

All unit values below are fandom wiki display values (base sell),
UNVERIFIED. Currency math a companion needs for "how much" questions:

### 3a. High-value crafted products
- Circuit Board 916,250 | Living Glass 566,000 |
  Liquid Explosive 800,500 | Acid 188,000 | Heat Capacitor 180,000 |
  Lubricant 110,000 | Poly Fibre 130,000 | Unstable Gel 50,000 —
  https://nomanssky.fandom.com/wiki/Tradeable
- Advanced crafted: Cryogenic Chamber 3,800,000 |
  Portable Reactor 4,200,000 | Quantum Processor 4,400,000 —
  https://nomanssky.fandom.com/wiki/Tradeable
- Enriched: Geodesite 150,000 | Iridesite 150,000 |
  Enriched Carbon 50,000 | Nitrogen Salt 50,000 |
  Thermic Condensate 50,000 —
  https://nomanssky.fandom.com/wiki/Tradeable
- Alloys (Aronium, Dirty Bronze, Grantine, Herox, Lemmium,
  Magno-Gold): 25,000 each —
  https://nomanssky.fandom.com/wiki/Tradeable
- Starship subcomponents (salvage): Starship AI Valves 12,000,000 |
  Compressed Indium Scraps 3,000,000 | Subatomic Regulators 800,000 |
  Spool of Nano-Cables 400,000 | Tank of Coolant 200,000 |
  Thermal Panels 100,000 | Recycled Circuitry 600,000 |
  Reinforced Piping 50,000 | Handful of Cogs 10,000 —
  https://nomanssky.fandom.com/wiki/Items
- Smuggled (Outlaws): First Spawn Relics 98,000 | Banned Weapons
  83,000 | Counterfeit Circuits 68,000 | GrahGrah 58,000 |
  Prismatic Feathers 32,000 | Moon Ether 18,000 |
  Stolen DNA Samples 9,000 | Blood Salt 2,000 —
  https://nomanssky.fandom.com/wiki/Items
- Ancient bones (base ranges): Common 50,000–110,000 |
  Uncommon 200,000–650,000 | Rare 700,000–1,700,000 per bone;
  economy modifier can push above base —
  https://www.gamerguides.com/no-mans-sky/guide/walkthrough/economy/best-ways-to-make-units-quickly

### 3b. Inventory slot costs
- Exosuit cargo: first 5,000 units, capped 200,000/slot; maxing
  costs 36,750,000 total. Tech slots: first 1,000, capped 125,000;
  maxing costs 1,456,000 total —
  https://nomanssky.fandom.com/wiki/Inventory
- Starship slots: cost scales with total slot count (38→7M …
  56→25M … 66+→75M) —
  https://nomanssky.fandom.com/wiki/Inventory

### 3c. Nanites — sources (rates not firmly datamined)
- Sources per community guides: uploading discoveries, mission
  rewards, refining, killing sentinels —
  https://www.pushsquare.com/guides/no-manrs-sky-how-to-earn-quicksilver
  (guide also lists nanite methods; no fixed per-hour rates found).
- **Gap**: no reliable per-source nanite numbers surfaced in text
  search (reward tables would have them — see REWARDTABLE.MBIN in
  `modding-landscape.md` §1).

### 3d. Quicksilver
- Daily Nexus missions: **250 QS**, up to **3 stacked** (missed days
  queue up) — https://www.thegamer.com/no-mans-sky-how-to-farm-quicksilver/ ;
  https://steamcommunity.com/app/275850/discussions/0/3426690213919441075/?l=danish
  (one 2021 guide claimed 450/QS daily —
  https://gamerant.com/no-mans-sky-complete-guide-quicksilver/ —
  treat 250 as the long-standing figure).
- Weekend missions: **1,200 QS** —
  https://www.thegamer.com/no-mans-sky-how-to-farm-quicksilver/
- Condensed Stellar Ice (space encounter): chance of 100 QS per
  mining — https://www.pushsquare.com/guides/no-manrs-sky-how-to-earn-quicksilver
- Total needed to buy out the Quicksilver vendor: >200,000 QS —
  https://gamerant.com/no-mans-sky-complete-guide-quicksilver/

### 3e. Circuit-board farm economics (community-tested)
- ~880,000–1,000,000 units per board; ~5 boards/day from a biodome
  farm (frost crystal + echinocactus + star bulb + solarium),
  harvestable in minutes —
  https://steamcommunity.com/app/275850/discussions/0/3488626756877967680/?l=schinese

---

## 4. Stat formulas (datamined / community-derived)

### 4a. Upgrade stacking (frigate-fleet guide, empirical)
- Module percentages **multiply**, not add:
  `(100% + module_1) * (100% + module_2) * (100% + module_3)`
- Adjacency bonus adds ~**4.5% per adjacent module** into each
  module's term:
  `(100% + m1 + 4.5%*adj1) * (100% + m2 + 4.5%*adj2) *
  (100% + m3 + 4.5%*adj3)`, with FLOOR rounding on display —
  https://steamcommunity.com/sharedfiles/filedetails/?l=german&id=3124688065
- Fixed attribute module values: S 15% | A 11% | B 6% | C 2%
  (same guide).

### 4b. Supercharged slots
- ~**+25% to EVERY numeric parameter** of a module placed on a
  supercharged slot (empirical, sometimes observed higher); usually
  beats adjacency for placement decisions —
  https://steamcommunity.com/app/275850/discussions/4/3951406499783741552/?l=finnish
- Supercharged Optical Drill alone ≈ **2x mining yield** —
  https://steamcommunity.com/app/275850/discussions/0/3801650561761634881/

### 4c. Hyperdrive range
- Max **3 hyperdrive upgrade modules** per starship; more disables
  all of that type —
  https://nomanssky.fandom.com/wiki/Hyperdrive_Upgrade
- Warp fuel efficiency stacking: 1 module = 50% cost, 2 = 33%,
  3 = 25% per jump —
  https://nomanssky.fandom.com/wiki/Hyperdrive_Upgrade
- Module range stat ranges by class: C/B 50–100, A 115–165,
  S 165–220 (per-install draws), X 50–320 —
  https://nomanssky.fandom.com/wiki/Hyperdrive_Upgrade
- **Static progression seed per player**: module stats are drawn
  from a per-player sequence in installation order; the module item
  itself doesn't matter, only install order. Reloading offers the
  same pool —
  https://nomanssky.fandom.com/wiki/Hyperdrive_Upgrade ;
  https://steamcommunity.com/app/275850/discussions/0/2254559285378953502/?l=tchinese&ctp=3
- Ship base hyperdrive bonus range: 50–65% (S-class explorer/exotic
  max 64%); displayed stats round down the fractional part —
  https://steamcommunity.com/app/275850/discussions/0/3557193237113045227/?l=german
- Player-reached range: 3,000+ ly achievable with ~250-ly S modules
  + blueprint drives (same Steam thread).

### 4d. Mining / multitool
- Displayed mining bonus at S-class pistol: **220–235%** (200% class
  multiplier + mining function bonus) —
  https://steamcommunity.com/app/275850/discussions/4/3951406499783741552/?l=finnish
- Empirical yield comparison (same thread): a hazardous-flora node
  yielding 15–16 oxygen on an Experimental tool yields 32–36 on the
  maxed pistol — roughly **2x** for a ~2.2–2.35x displayed bonus,
  suggesting near-linear scaling of yield on mining bonus
  (*speculation*: sample size is one reporter's).
- Damage bonus affects mining beam damage; mining bonus affects
  extraction speed —
  https://steamcommunity.com/app/275850/discussions/4/3951406499783741552/?l=czech
- **Gap**: no per-tick mining-yield formula or node resource-count
  table was found in text sources.

### 4e. Enemy damage / scaling
- Pirate strengths datamined as IDs with flat stats (see §2);
  incoming AI ship damage is a flat value from the `AI_SHIPGUN`
  damage-table entry, identical across pirate difficulty tiers —
  https://steamcommunity.com/app/275850/discussions/0/3722818378187795904/?l=hungarian
- "LevelledExtraHealth" (e.g. 14,000–19,000) scales enemies against
  the player's own progression (exact driver unknown — *speculation*
  in the source, possibly tech/milestone-based).
- **Gap**: player-hazard drain rates (heat/cold/toxic/radiation per
  second) and the temperature-at-which-damage-starts table were only
  found in the stale 2017 sheet; no current datamined values found.

### 4f. Scanner
- Up to 3 scanner upgrades installable (3 in general inventory + 3
  in tech tab per an old quirk, reported 2019); scans with 3 S-class
  mods yielded 100k–500k units per plant/animal —
  https://steamcommunity.com/app/275850/discussions/0/1639794651165966059/

---

## 5. Language / word system internals

Datamined counts from the fandom Language page (game files, as of
Worlds Part I 5.03):
- **3,814 unique word groups** in the game files; **4,794 total
  speechtable words**: 1,149 Gek | 1,092 Korvax | 1,156 Vy'keen |
  1,135 Autophage | 261 Atlas | 1 "None" —
  https://nomanssky.fandom.com/wiki/Language
- **Learnable: 3,813 word groups**: 921 Gek | 858 Korvax |
  930 Vy'keen | 889 Autophage | 222 Atlas —
  https://nomanssky.fandom.com/wiki/Language
  (Relics update added 3 Gek / 2 Korvax / 2 Vy'keen learnable words.)
- One word group unlocks multiple words: learning Korvax "is"
  also grants "are"/"was"/"were" (distinct file entries, same
  group) — same page.
- The "None" faction's single word is "mining", likely belonging to
  Autophage — flagged as a probable bug (same page).
- Word sources: knowledge stones (1 word each), ruins (6–9 words per
  ruin), NPC "Request Dialect Help", cartographer
  Alien-Cartographic-Data maps (1–4 words, 1 Navigation Data each),
  encyclopedias/artifacts —
  https://www.trueachievements.com/game/No-Mans-Sky/walkthrough/7 ;
  https://nomanssky.fandom.com/wiki/Language
- GameGPT note: words are boolean known/unknown toggles in the save
  (see `game-dossier.md` §3b) — a "teach me all words" edit is a
  save-layer op, matching the existing "Decode All Words" cheats.

---

## 6. Gaps / open items

1. **nomanssky.info** — could not be read via text fetch (JS site);
   provenance and currency unassessed. Needs a live-browser pass.
2. **Nanite rates** — no per-source numbers found; REWARDTABLE.MBIN
   would have them (modding wiki reference).
3. **Hazard drain rates** — only stale 2017 values; current numbers
   not found in text sources.
4. **Mining yield formula** — only empirical ratios; per-tick /
   per-node math not documented anywhere found.
5. **Unified internal-ID list** — no single public catalog; best
   sources are zencq/Pi (procedural items), MBINCompiler-decompiled
   tables, NMSModBuilder EXML caches, and save-editor mapping files.
6. **fandom vs .info reliability** — fandom is community-curated
   with datamined citations but aging pages; nomanssky.info
   unassessed (see 1). Neither substitutes for MBIN-derived data.
7. Shield/hull base stats by ship class, refiner recipes/timings,
   and mission reward tables were not covered here — REWARDTABLE
   and globals references on the modding wiki are the entry points.

*End. All UNVERIFIED — confirm against the running game before any
GameGPT profile use.*
