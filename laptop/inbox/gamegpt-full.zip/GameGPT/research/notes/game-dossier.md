# No Man's Sky — GameGPT research dossier

Compiled 2026-09-18. Status: **RESEARCH ONLY / UNVERIFIED.** Every
address, pattern, and value below is a research lead until independently
confirmed against the running game in a Bruce-authorized live session.
Speculation is marked as such.

Companion files: `modding-landscape.md` (tools, save editors, key mods),
`best-cheats.md` (fun ranking), `../parsed/` (table extractions),
`../tables/` (source tables).

---

## 1. Cheat-table author ecosystem

### 1a. Fearless Revolution — the live center of NMS table work

**Blind Distortion — "No Man's Sky - NMS (Steam)"** —
https://fearlessrevolution.com/viewtopic.php?t=30442
- The best-maintained community table: 344 posts / 23 pages, edited 326
  times, last edited **2026-09-10**. Author pulled the download on
  2026-09-10 ("so much is broken", update promised within ~a week).
- The thread's feature list was captured live on 2026-09-18 (post "The
  Swarm Update") and reads as the current gold-standard cheat set:
  - **General**: gift-for-any-race, Instant Portal Activation, instant
    interaction (E key), Money (Units/Nanites/Quicksilver **editable
    pointers** — i.e. pointer-based, not just AOB), Remove Inventory
    Technology Overloads.
  - **Exosuit**: unlimited jetpack (+underwater), stamina, health, hazard
    suit, life support, oxygen, exosuit shields w/ recharge, Runic Lens
    cloak.
  - **Exocraft**: boost, Nautilon boost, fuel, thruster, mining laser,
    mounted cannon.
  - **Starship**: shields, launch thruster, pulse engine, hyperdrive, zero
    thermal load for photo cannon.
  - **Xeno Arena / companions**: gene edits, maxed genetic profiles, no
    damage, one-shot rival creatures.
  - **Multi-Tool**: unlimited gravitino coil, mining beam, one-shot kills,
    **Instant Mining**, No Mining Overheat, unlimited terrain manipulator,
    instant charge (Blaze Javelin, Neutron Cannon), unlimited ammo
    (Javelin/Bolt Caster/Grenades/Neutron Cannon), no reload, no overheat,
    **True Instant Analysis Scanner**.
  - **Crafting**: always-have-resources, crafting consumes nothing, free
    crafting, **refiner: unlimited fuel, consumes no resources, finishes
    instantly**.
  - **Inventory**: Last Moved Item into Slot (requested feature, AOB
    script published in-thread), max-out items, free items, no tech
    overloads.
  - **Ranking modifiers**: Gek / Vy'keen / Korvax / Merchants /
    Mercenaries / Explorers / Outlaws guilds (set to 99).
  - **Corvette Building** (Voyagers-era system): scale speed, part size,
    remove finalization requirements, unlock all parts, remove invalid
    build messages, part rotation values.
  - **Settlement**: always-have construction requirements, instant
    construction completion.
  - **Speed Multipliers** (code by BigJit901): ship engine, pulse engine,
    jetpack, walk/run speed.
- Method signals: AOB-dominant (`aobscanmodule` patterns posted in-thread,
  e.g. `8B 44 19 18 41 3B 45 18` for the Last Moved Inventory Item hook),
  plus editable **pointers** for currencies. Table targets CE 7.6.

**ModEngine — "No Man's Sky - table v: 1.0 CT"** —
https://fearlessrevolution.com/viewtopic.php?t=30134
- Posted 2024-07-09 (Adrift Expedition era), 700 downloads, thread rating
  1.0/1 vote. Advertises 23 features; the free file ships only 2 working
  AOB scripts (Unlimited Stamina, No Overheating) plus a promo dialog
  linking to modengine.net. The remaining 21 options are paywalled.
  Cataloged in `../parsed/NMSfrf.ModEngine.2024-07-09.json`.

**dinoid — GamePass/Windows Store port** —
https://fearlessrevolution.com/viewtopic.php?t=13080
- Adaptation of Steam tables (credits Squall8, Igromanru, YoucefHam),
  bundled with a trainer and a **save editor**. Shows the community
  pattern: tables get ported per storefront, and save editors are treated
  as complementary to memory tables.

**Cheat Happens / MrAntiFun trainer** (via
https://megagames.com/trainers/no-mans-sky-beyond-v24-1-trainer-cheat-happens)
- The vg247 roundup calls the MrAntiFun NMS Trainer "far and away the most
  popular" NMS mod
  (https://www.vg247.com/no-mans-sky-mods-cheats): god mode, infinite
  stamina/jetpack/health, easy crafting, no reload, reset wanted level,
  unlimited warp cells, easy hyperdrive, currency editors (Units, Nanites,
  Quicksilver). Confirms the demand profile: throttles > god-mode.

### 1b. GitHub table mirrors

- **themaoci/game-cheat-tables-ce-** —
  https://github.com/themaoci/game-cheat-tables-ce-/blob/HEAD/Readme.md —
  personal repo; readme states tables are "fixed by me or found on the
  internet" and some are "harvested from paid service like CheatEvolution
  or **ModEngine**". Ships `No Man's Sky Cheat Table.CT`. Freshness:
  readme updated ~110 days before 2026-09-18. Useful as a secondary
  source; provenance is explicitly harvested, not authored.
- **themaoci/Sintrix-Dump-Ct** —
  https://github.com/themaoci/Sintrix-Dump-Ct — 335 games / 564 tables
  dumped from sintrix.net. NMS coverage is only 2 ancient files
  (`No Man's Sky-v1.0.CT`, `no-mans-sky-v1.1.CT`) — launch-era, not
  useful for current builds, but a data point that Sintrix's NMS catalog
  is stale.
- **Hexorg/CheatEngineTables** —
  https://github.com/Hexorg/CheatEngineTables — old cheat-engine-forum
  dump; readme asks for maintainers to filter malicious/useless tables.
  No NMS-specific signal found; treat as archive, not a live source.
- **opencheattables.com** — searched 2026-09-18; no NMS-specific table
  surfaced in results. Not a current source for NMS.
- **vgtimes.com mirrors** — third-party archives of Blind Distortion's
  table (2024 snapshots, e.g. the 07.11.2024 / 22.55 KB "and other
  pointers" build). Provenance: third-party, but byte-identical archives
  of the author's work. Useful when the author's own download is pulled.

### 1c. Method notes (what the ecosystem teaches about NMS memory)

- **AOB-first**: the durable tables anchor on `aobscanmodule` patterns,
  not static addresses — NMS rebuilds shuffle addresses every update, so
  pointer-only tables die fast. This matches GameGPT's "research maps,
  not coordinates" rule.
- **Currencies are pointer-editable**: Blind Distortion's table exposes
  Units/Nanites/Quicksilver as editable pointers reached via inventory
  access — consistent with the save-game finding (§3) that currencies are
  plain values in the save JSON; the in-memory copies are reachable
  through inventory UI structures.
- **"Last Moved Inventory Item" pattern**: hooking the inventory-move code
  path to capture a live item pointer, then editing Name/Count/Max Count
  at +0/+18/+20. This is the community's generic item-editing primitive —
  directly relevant to any future GameGPT inventory work.

---

## 2. Nexus Mods landscape (summary)

Full detail in `modding-landscape.md`. Headlines:

- Nexus hosts the NMS mod scene
  (https://www.nexusmods.com/nomanssky/mods/topalltime?adult=2). The
  most-endorsed cheat-adjacent mods cluster on **movement, building, and
  friction removal**: jetpack/flight overhauls (Krypton by Goldenveins &
  Gemini; Fluid Flight v1.3 for NMS v6.18), Reduced Launch Cost 4.1,
  Auto-Sprint, Better NMS modpack (Exosolar/Babscoole — removes per-part
  build limits), More Words, and the perennial MrAntiFun trainer.
- The modding toolchain is mature and actively maintained:
  **MBINCompiler** (https://github.com/monkeyman192/MBINCompiler, updated
  ~3 days before 2026-09-18), **AMUMSS** (Nexus mods/957, Lua-script mod
  builder, auto-updates MBINCompiler), **NMS Mod Builder / NMSPE**
  (https://github.com/cmkushnir/NMSModBuilder). Post-Worlds-Part-2
  (5.50), PAKs changed format and mods live in `GAMEDATA\MODS`
  subfolders
  (https://steamcommunity.com/app/275850/discussions/0/595139710753505669/).
- The modding wiki (https://stepmodifications.org/wiki/NoMansSky:Landing_Page)
  documents the key insight: **NMS exposes thousands of tuning variables
  as named globals** (GCPLAYERGLOBALS etc.), and the
  `GCPLAYERGLOBALS.GLOBAL` reference lists exact field names and
  defaults — e.g. `JetpackFillRate` (0.5), `JetpackMaxSpeed` (5),
  `JetpackMaxUpSpeed` (30), `GroundRunSpeed` (8)
  (https://stepmodifications.org/wiki/NoMansSky:Reference_Guides/Global_Files/GCPlayerGlobals).
  These names are the vocabulary for both modding and future memory
  work: the globals are loaded into memory at runtime.

---

## 3. Save-game knowledge

### 3a. Locations and formats (via korokun/libnom.io —
https://github.com/korokun/libnom.io)

- **Steam (PC)**: `%AppData%\HelloGames\NMS\st_<SteamID>\`, files
  `save*.hg`. (GOG: `%AppData%\HelloGames\NMS\DefaultUser`.)
- **Microsoft Store**: `%LocalAppData%\Packages\HelloGames.NoMansSky_bs190hzg1sesy\SystemAppData\wgs\<XboxID>_<GUID>\`,
  `containers.index`. Note: reloading modified saves while the game runs
  does not work on this platform.
- Save **format versions**: 2001 (Foundation–Prisms), 2002 (+Waypoint ext,
  Frontiers–Adrift), 2003 (Worlds Part I–The Cursed 5.29), **2004**
  (Worlds Part II 5.50+, ext in 5.53). Current saves are format 2004.
- Internally the save is **JSON** (obfuscated, LZ4-compressed —
  libnom.io deps: libNOM.map obfuscation, K4os LZ4, SpookyHash). Fields
  are addressable by JSONPath, e.g.
  `PlayerStateData.UniverseAddress.GalacticAddress.VoxelZ`.
- **Cross-save** arrived in The Cursed patch 5.25
  (https://cloud.nomanssky.com/cross-save): edit on PC, upload, play
  anywhere — makes save editing platform-portable.
- NMS keeps **paired auto + manual saves**; the GameGPT project already
  edits them as a pair (prior verified work: Units→2B, supercharge
  edits, targets chosen by decoded TotalPlayTime).

### 3b. Save editors (what they prove is editable)

- **NomNom** (zencq, https://github.com/zencq/NomNom, updated ~58 days
  before 2026-09-18) — described by libnom.io as "the most complete
  savegame editor for No Man's Sky". Edits: currencies, stats, fleets,
  inventories, fast-travel to any system, appearances, knowledge/words,
  expedition/Twitch-drop rewards, **total play time**. Built on
  libMBIN's mapping.json with auto-updates.
- **goatfungus/NMSSaveEditor** (https://github.com/goatfungus/NMSSaveEditor,
  Java, WORLDS-compatible): currencies (Units, Nanites, Quicksilver);
  base stats for exosuit/multitools/ships/freighter (health, shield,
  type, class, **seed**); squadron wingmen; frigates; companions/pets
  (**seed**, biome, type); settlements (population, happiness,
  production, upkeep, debt); milestones/reputation; inventories with
  add/clone/repair/refill; known tech/products/**words/glyphs** toggles;
  account unlocks. Auto-backup before writes.
- **NMS Companion** (Nexus, uses libnom.io) — companion app with
  inventory transfer.

What this teaches GameGPT: currencies are plain numeric values; ships,
companions, and multitools are **seed-driven** (a seed integer determines
the procedurally generated item — editing the seed re-rolls identity);
known words/glyphs/tech are boolean toggles; inventories are slot arrays
with item IDs + counts. All of this is save-layer, not memory-layer —
the guarded-save-edit path, not the live-read path.

---

## 4. Community knowledge

### 4a. Known pain points and grinds (cheat-design fuel)

- **Launch thruster fuel** is the classic early-game tax: land/takeoff
  cycles burn fuel and strand players
  (http://www.megabearsfan.net/post/2016/08/25/No-Mans-Sky-game-review.aspx).
  The #2 most-endorsed recent Nexus mod is literally "Reduced Launch
  Cost 4.1". Modern difficulty settings eased it, and one 2025 Steam
  poster notes they "used cheat engine to give infinite launch thruster
  fuel (before difficulty changes) and now don't really ever have to use
  launch fuel"
  (https://steamcommunity.com/app/275850/discussions/0/592911760736326146)
  — i.e. the throttle still exists, players still route around it.
- **Recharge loops**: "Gather resources, recharge tech so I can gather
  resources to recharge tech" — the core grind complaint
  (https://steamcommunity.com/app/275850/discussions/0/1354868867708997070/?l=schinese&ctp=1).
  Maps directly to: unlimited life support / hazard protection / mining
  beam charge cheats.
- **Sentinel interrupts**: harvesting triggers sentinel attention; the
  No-Sentinels / reset-wanted-level cheats delete this interrupt for
  builders and explorers
  (https://gamefaqs.gamespot.com/boards/739857-no-mans-sky/75667986).
- **Inventory scarcity**: slot-limited inventories are a perennial
  complaint; "Unlock Inventory Slots" and inventory editors are standard
  cheat-table/save-editor fare.
- **Language grind**: learning Gek/Korvax/Vy'keen words one NPC at a
  time; "More Words" mod and "Easy Interpret Languages"/"Decode All
  Words" cheats address it.
- **Economy**: ships costing tens of millions of units vs. ~300k earned
  in 2 hours of early play
  (https://steamcommunity.com/app/275850/discussions/0/3771238415386701740/?l=tchinese).
  Cryo-pump crafting arbitrage and S-tier scanner upgrades are the
  legit catch-up mechanics
  (https://www.polygon.com/no-mans-sky-next-guide/2018/8/3/17648574/units-nanites-farming-quick/).
- Counter-note: NMS now has **custom difficulty settings**, so many
  survival throttles can be dialed down in-game without any cheating —
  cheats should target what settings *can't* do (free building, instant
  refine, speed).

### 4b. Coordinate and save sharing communities

- **r/NMSCoordinateExchange** and the **Galactic Hub Project** (80+
  players mapped the Rentocniijik Expanse: 60+ systems, ~200 planets;
  http://kotaku.com/a-team-of-no-mans-sky-players-have-spent-months-mapping-1793135734).
  Players share portal glyph addresses for ships, multitools, freighters,
  and planets.
- **Portal glyph math is public**: galactic coordinates
  (`XXXX:YYYY:ZZZZ:WWWW`) convert to 12-glyph portal addresses via
  published converters (nmsportals.github.io); the hex math is documented
  in Steam guides
  (https://steamcommunity.com/app/275850/discussions/0/2577697791651464012/?l=bulgarian).
  Relevance: a GameGPT "take me to this ship" feature could accept glyph
  addresses; no memory work needed for the lookup, only for verifying
  arrival.
- **Expedition replays via community save files**: CWMonkey publishes
  files on GitHub to replay any of the 18 expeditions
  (https://Gamerant.com/no-mans-sky-best-expeditions-to-replay-play-again-twice/).
  Save-file distribution is an established community practice.

---

## 5. Game systems reference (cheat-design-relevant)

- **Currencies** (three):
  - **Units** — the trade currency: ships, multitools, freighters,
    resources at Galactic Trade Terminals. Earned by selling, missions,
    scanning (with S-tier scanner upgrades, hundreds of thousands per
    scan). Ships run to hundreds of millions
    (https://www.polygon.com/no-mans-sky-next-guide/2018/8/3/17648574/units-nanites-farming-quick/,
    https://gamerant.Com/no-mans-sky-best-ways-earn-units/).
  - **Nanites** — the upgrade currency: exosuit/multitool/starship
    upgrade modules from technology merchants. Earned by uploading
    discoveries, missions, refining, killing sentinels
    (https://www.pushsquare.com/guides/no-mans-sky-how-to-get-nanites).
  - **Quicksilver** — event currency: spent at the Quicksilver Synthesis
    Companion on the Space Anomaly for cosmetics/decorations. Earned via
    daily Nexus missions (250 QS, stack 3) and weekend missions (1200 QS)
    (https://www.thegamer.com/no-mans-sky-how-to-farm-quicksilver/).
- **Core loops**: explore (scan flora/fauna/minerals → upload for
  nanites/units), survive (hazard protection, life support), build
  (bases, freighters, **corvettes** — player-built capital ships from
  the Voyagers update — settlements), trade (units economy), fight
  (sentinels, pirates).
- **Tech & upgrades**: exosuit / multitool / starship tech installed in
  general + technology inventories; **S-class and X-class ("suspicious")**
  upgrade modules with percentage stats (e.g. +722% jetpack tanks);
  **supercharged slots** multiply adjacent tech; the Steam community's
  max-stat threads show the upgrade chase is the real progression
  (https://steamcommunity.com/app/275850/discussions/0/601901034049177246/).
  "No Technology Overloads" (Blind Distortion) removes install limits —
  a cheat only a memory/save edit can provide.
- **Expeditions**: seasonal mode, all players start on the same planet,
  milestone phases with exclusive rewards (ships, frigates, cosmetics);
  rewards convert to normal saves afterward; ~18 expeditions as of Aug
  2025; Hello Games re-runs recent ones around New Year
  (https://www.rockpapershotgun.com/no-mans-sky-new-expedition-update-launches-today,
  https://Gamerant.com/no-mans-sky-best-expeditions-to-replay-play-again-twice/).
- **Multiplayer structure**: the Space Anomaly as social hub, Nexus
  missions (incl. quicksilver dailies/weeklies), weekend event missions,
  Twitch drops, cross-save across platforms. Anti-cheat posture: NMS is
  primarily co-op/PvE; the cheat scene operates openly (Fearless
  Revolution, trainers sold commercially), but expedition leaderboards
  and shared-universe griefing are the social boundaries — GameGPT
  cheats should stay in solo/private sessions.

---

## 6. GameGPT design implications (synthesis — partially speculative)

1. **Three value layers, three profile families**:
   - *Tuning globals* (jetpack fill rates, speeds, costs) — loaded from
     MBINs into memory; named fields are known from the modding wiki.
     *Speculation*: a memory profile could target these post-load, but
     the mod path (EXML) already does it persistently and even works in
     multiplayer per mod authors — for tuning, mods may beat memory
     writes.
   - *Live state* (stamina, health, heat, ammo counts) — classic AOB
     hook territory; the two parsed ModEngine scripts show the exact
     shape (float forced to 1.0 / heat zeroed at the accumulation
     site).
   - *Persistent state* (currencies, inventory, tech, seeds, words) —
     save JSON; the paired-save guarded edit path already works (Units→2B
     verified).
2. **Voice-trigger mapping writes itself**: "jetpack forever" →
   JetpackFillRate-class effect; "free build mode" → crafting-consumes-
   nothing + no build limits; "instant refine" → refiner instant finish;
   "chill mode" → no sentinels + hazard protection; "max my scanner" →
     S-tier-equivalent scan rewards is save/tech-layer, harder — say so.
3. **What settings can't do is the cheat frontier**: custom difficulty
   already covers survival throttles; the remaining cheat value is
   creative-mode powers (free crafting, instant construction, corvette
   part unlocks, no tech overloads) and time deletion (instant refine,
   instant mining, instant portal).
4. **Community maintenance burden is the risk**: Blind Distortion's table
   breaks "so much" every major update (Sep 2026 pull). Any GameGPT
   memory profile inherits that treadmill — AOB patterns must be
   re-validated per game update, which is exactly what the weekly sweep
   is for.

---

## 7. Sources the weekly sweep should watch

- https://fearlessrevolution.com/viewtopic.php?t=30442 — Blind
  Distortion's table (download repost watch; currently pulled).
- https://fearlessrevolution.com/viewtopic.php?t=30134 — ModEngine
  thread (in case the free table ever grows).
- https://www.nexusmods.com/nomanssky/mods/topalltime?adult=2 and
  https://www.nexusmods.com/nomanssky/mods/top — new cheat-adjacent
  mods signal what players want.
- https://github.com/monkeyman192/MBINCompiler — new releases =
  NMS updated = tables likely broken.
- https://github.com/themaoci/game-cheat-tables-ce- — harvested NMS
  table updates.
- https://github.com/zencq/NomNom and
  https://github.com/goatfungus/NMSSaveEditor — save-format changes
  flag game updates affecting both save edits and memory layouts.
- https://stepmodifications.org/wiki/NoMansSky:Landing_Page — global
  field documentation.

*End of dossier. All UNVERIFIED research — confirm against the running
game before any GameGPT profile use.*
