# No Man's Sky — modding APIs, frameworks, and script-level tooling

Compiled 2026-09-17. Status: **RESEARCH ONLY / UNVERIFIED.** No code was
run, nothing was installed, and no hooked function, offset, or pattern
below has been confirmed against the running game. Signatures rot every
game update — treat all of them as stale until re-validated.

See also: `game-dossier.md` (cheat tables, saves), `modding-landscape.md`
(MBIN/AMUMSS data modding).

---

## 1. State of play: runtime scripting is real, and it's small

NMS modding is *mostly* data-driven MBIN edits, but there **is** a script-
extender / runtime-injection scene. The old one is dead; the live one is
Python-based and maintained by the MBINCompiler author himself.

### 1a. NMSE / "NMS Extender" (2016, DEAD)
- Ant2888's **NMS Extender – NMSE** (Nexus mods/9, v1.1.1b): a DLL injector
  (`NMSE_Core_1_0.dll`, `NMSE_steam.dll`, `NMSELauncher.exe`) that let C++
  mods run inside NMS — advertised for "entire UI overhauls, different NPC
  interactions". Last updated **30 Aug 2016**; not viable for current builds.
- Source: https://www.nexusmods.com/nomanssky/mods/9
- Name-collision warning: **unrelated** modern projects reuse the "NMSE"
  acronym for save editors — e.g. `rinhatayuun/nmse` and `vectorcmdr/nmse`
  ("NO MAN'S SAVE EDITOR", .NET, updated ~Sep 2026). Don't confuse them.
  - https://github.com/rinhatayuun/nmse
  - https://github.com/vectorcmdr/nmse
- The stepmodifications wiki confirms the gap NMSE was meant to fill:
  "There is currently no way to natively access scripting otherwise"
  without exe modification or runtime code injection.
  - https://stepmodifications.org/wiki/NoMansSky:Current_State_of_Modding

### 1b. Reloaded2 + NoMansSky.Api (C#, community, stalled-looking)
- **gurrenm3/NoMansSky.Api** — C# modding API built on the general-purpose
  **Reloaded2** mod loader/hooking framework
  (https://github.com/Reloaded-Project/Reloaded-II) and
  Reloaded.ModHelper. README claims: control of all 20 global MBINs,
  events (`OnMainMenu`, `OnProfileSelected`, `OnGameJoined`), hooked game
  loop (`OnUpdate` every frame), get/set stats (Units, Nanites,
  Quicksilver, Health, Shield) with `OnValueChanged` events, limited
  inventory support, and `new Signature().Scan()` helpers for AOB-style
  signature scanning.
  - https://github.com/gurrenm3/NoMansSky.Api
- Setup requires removing SteamDRM from NMS.exe with Steamless for
  debugging — a heavy, version-fragile route. A Debugger mod for it exists
  (`thatbomberdev/nms-debugger-reloaded`), linking to the API wiki at
  https://github.com/gurrenm3/NoMansSky.Api/wiki
  - https://github.com/thatbomberdev/nms-debugger-reloaded

### 1c. pyMHF + NMS.py (Python, CURRENT — the one to watch)
- **pyMHF** — monkeyman192's generic "python Modding and Hooking Framework":
  pure-Python function hooks via MinHook (through `cyminhook`) + `pymem`,
  before/after multi-detours, per-mod auto-generated GUI tabs with live
  reload, and an **HTTP API layer** (see §5).
  - https://github.com/monkeyman192/nms.py (README points at pyMHF)
  - Docs: https://monkeyman192.github.io/pyMHF/
  - Install: `python -m pip install nmspy`, run with `pymhf run nmspy`
  - PyPI: https://pypi.org/project/NMSpy/
- **NMS.py** — monkeyman192's NMS-specific library on pyMHF: "expose
  internal game functions for No Man's Sky". Hooked-function database lives
  in the package (`tools/data.json`, `nmspy/data/types.py`,
  `nmspy/data/functions/hooks.py`, `nmspy/data/structs.py` — **contents not
  yet read**; repo root pages render README-only in text view, so this is
  the #1 follow-up fetch for future memory work).
  - https://github.com/monkeyman192/nms.py
  - Older fork by the original author (ThatBomberDev) is ~2 years stale;
    the monkeyman192 fork was updated ~4 days before 2026-09-17.
  - RE method documented in CONTRIBUTING: function signatures located by
    comparing the latest `NMS.exe` against the Mac binary or the 4.13
    (Fractal) binary; byte patterns made with IDA Fusion / SigmakerEX.
  - Credits "RaYRoD for initially discovering the pdb" — i.e. an NMS debug
    symbol file was found at some point and underpins the naming.
  - Explicit anti-abuse stance: "this library will never contain functions
    relating to online functionality".

---

## 2. Published internal function names (all from NMS.py-family sources)

These names were found in hooked-function definitions and experiment
scripts; they confirm Hello Games' naming conventions:
engine/toolkit classes are `cTk*`, game-code classes are `cGc*`, audio is
Audiokinetic's `AK::*`. Patterns are summarized, not reproduced in full.

| Function / class | Where published | Notes |
|---|---|---|
| `cTkFileSystem::Construct` | ThatBomberDev/NMS.py-Experiments `manualHook.py` | AOB pattern published; experiment writes `isModded` bool at `this+0x467A` to suppress the .pak "modded" warning |
| `cGcNameGenerator::GenerateMessageInABottleText` | same file | Hooks message-in-a-bottle text gen; uses `cTkFixedString` |
| `cGcPlayerState::GetRandomWord` | same file | Returns alien-word ID for a race enum: 0=Traders, 1=Warriors, 2=Explorers, 3=Robots, 4=Atlas, 5=Diplomats, 6=Exotics, 7=None, 8=Builders; result written to a 0x800-char buffer |
| `cGcScanEventManager::FindWeekendInterstellarEvent` | same repo, `weekendMissionRE.py` | Returns scan event; universal address read at `result+8` |
| `cGcMPMissionSelectionHelper::GetMissionTargetUA` | same file | missionId = 0x128-char buffer; missionSeed/targetSeed as u64 |
| `cGcFrontendPageMultiplayerMissionGiver::GetMultiplayerWeekendMissionsList` | same file | Hook attempt commented out as crash-prone (bad FUNCDEF) — evidence the DB is genuinely experimental |
| `cTkAudioManager::Play` | pyMHF docs ("Creating hook definitions") | AOB signature `48 83 EC ? 33 C9 4C 8B D2 ...` published as the canonical hooking example; two overloads documented |
| `AK::SoundEngine::PostEvent` | pyMHF docs | **Exported** by NMS.exe; mangled name published: `?PostEvent@SoundEngine@AK@@YAII_KIP6AXW4AkCallbackType@@PEAUAkCallbackInfo@@@ZPEAXIPEAUAkExternalSourceInfo@@I@Z` — a callable entry point into Wwise audio |
| `AK::MemoryMgr::SetPoolName` | WinDbg crash dump on Steam forums | Confirms symbol-style names resolve against NMS.exe in the wild |
| `TkAudioID` (mpacName / muID / mbValid), `cTkFixedString` | pyMHF docs + experiments | Struct field names used in hook definitions |

Sources:
- https://github.com/ThatBomberDev/NMS.py-Experiments/blob/main/manualHook.py
- https://github.com/ThatBomberDev/NMS.py-Experiments/blob/main/weekendMissionRE.py
- https://monkeyman192.github.io/pyMHF/docs/creating_hook_definitions.html
- https://steamcommunity.com/app/275850/discussions/1/1640927348824137765/?l=brazilian (crash dump with `NMS!AK::MemoryMgr::SetPoolName`)

**Naming convention (speculation, grounded):** `cTk*` = toolkit/engine
layer, `cGc*` = game code, matching the MBIN class prefixes (`Gc*`,
`Tk*`) in libMBIN. The pyMHF docs note the hard part is "getting a
pointer to the instance of the class" — usually captured from a hook's
`this` argument.

---

## 3. What the frameworks expose (API surface for mods)

**NMS.py / pyMHF** (Python; from docs + READMEs):
- `function_hook` / `static_function_hook` decorators: hook by **byte
  signature** or relative offset; call the original or call game functions
  directly from Python via ctypes type hints.
- Partial-struct support: declare only the struct fields you need
  (`@partial_struct`), at known offsets — same shape as the GameGPT
  "research maps, not coordinates" approach.
- `nmspy.decorators.main_loop` — per-frame Python callback; `on_key_pressed`
  / `on_key_release` hooks.
- `call_function` (pymhf) — invoke game functions from a mod.
- Mods install like normal mods under `GAMEDATA/MODS/`; the framework
  launches the game for you (`pymhf run nmspy`).
- Sources: https://monkeyman192.github.io/pyMHF/ ,
  https://monkeyman192.github.io/pyMHF/docs/creating_hook_definitions.html

**NoMansSky.Api** (C#/Reloaded2; README-level only):
- `OnMainMenu`, `OnProfileSelected`, `OnGameJoined` events; `OnUpdate`
  per-frame; Units/Nanites/Quicksilver/Health/Shield get/set with
  `OnValueChanged`; inventory support.
- https://github.com/gurrenm3/NoMansSky.Api

**NMS Mod Builder / NMSPE** (cmkushnir; build-time tool, NOT runtime):
- PAK conflict detection, EXML caches, viewers/diffs — plus a **plugin
  API**: `Plugins/Sample/` in the repo, and in-app C# scripting tiers
  (Utility / Query / Mod scripts) that compile against `libMBIN.dll` and
  get full enum/struct/field reflection in the "libMBIN API" tab.
  Useful for *generating* mods and discovering field names, not for live
  hooks.
- https://github.com/cmkushnir/NMSModBuilder

---

## 4. The "action" system: data-side, not a callable API

- **MBIN classes** `GcActionTrigger` and `GcActionTriggerState` exist
  (listed in the old MBINCompiler class-coverage checklist,
  https://github.com/emoose/mbincompiler/issues/67).
- Per the stepmodifications wiki, "ActionTriggers" are scripted *inside
  entity scene data*: particle effects firing, messages displaying,
  elements of an object being switched off/removed — i.e. declarative
  event scripting attached to objects, alongside `custominteraction`
  types in `NMS_DIALOG_GCALIENPUZZLETABLE.MBIN` for new dialogue pools.
- Nothing found suggests these are callable at runtime; they are data the
  engine interprets. For GameGPT, "callable game logic" lives in §2-style
  hooked functions, not in ActionTriggers.
- https://stepmodifications.org/wiki/NoMansSky:Current_State_of_Modding

---

## 5. UI / overlay injection — the closest thing to a GameGPT bridge

- **pyMHF auto-GUI**: every loaded mod gets its own tab in an external
  window with `gui_button` / `gui_variable` controls and a live "reload"
  button (mod code re-hooks without restarting). External window, not
  in-game overlay.
- **NMS-Newton** (monkeyman192's flagship NMS.py mod, orbital dynamics):
  - custom **dialogue options** injected at the Station Core interaction
    (turn planetary sim on/off) — proof of in-game UI/dialogue hooking;
  - a **custom in-game UI** showing the orbital period of the planet your
    ship points at;
  - **in-game text-chat commands**: `/mod newton`, `/mod newton
    enable|disable`, `/mod newton speed X` — proof the chat input path is
    interceptable.
  - https://github.com/monkeyman192/NMS-Newton
- **pyMHF HTTP API** (`pymhf.core.http_api.endpoint`, FastAPI/uvicorn):
  any mod property/method becomes `GET`/`PUT` (or read-only WEBSOCKET)
  at `<ModName>/<name>`, with auto Swagger docs. This is the closest thing
  found to a machine-callable bridge into the running game — a GameGPT
  companion mod could expose e.g. `GET Newton/player_stats` and
  `PUT` endpoints for cheats.
  - https://monkeyman192.github.io/pyMHF/docs/http_api.html
  - Caveat: uvicorn server only starts if a mod with an endpoint exists at
    initial load; websocket support is read-only.
- NoMansSky.Api also lists "Custom UI" as a *planned* feature (not
  shipped), per its README.

---

## 6. GameGPT relevance (synthesis)

1. **NMS.py is the live research map.** It's maintained by the
   MBINCompiler author, hook definitions name real internal functions
   with byte signatures, and the PDB-discovery lineage means the naming
   (`cTk*`/`cGc*`) is trustworthy. Its `data.json`/`types.py` function
   database is the single most valuable unread artifact for future memory
   work.
2. **pyMHF's HTTP API + GUI is the natural GameGPT actuator shape**: a
   Python mod that hooks game functions and exposes GET/PUT endpoints
   could be driven by voice commands without touching Cheat Engine —
   same "callable game logic" goal as the CE tables, minus the per-update
   AOB treadmill for everything already wrapped. (The treadmill remains
   for the signatures themselves.)
3. **Chat-command interception (`/mod ...`) is a proven in-game command
   channel** — directly analogous to GameGPT's voice-command mapping,
   if a mod is ever acceptable in the loop.
4. **No Lua runtime scripting exists.** AMUMSS Lua is mod-*definition*
   only (build-time). The only "script extenders" are the dead 2016 NMSE
   and the current native-injection frameworks above.

## 7. Gaps / follow-ups

- **Unread:** NMS.py's hooked-function DB — `tools/data.json`,
  `nmspy/data/types.py`, `nmspy/data/functions/hooks.py`,
  `nmspy/data/structs.py`, and the `example_mods/` folder
  (https://github.com/monkeyman192/nms.py ; PyPI package `NMSpy`).
  Everything in §2 is from *examples*, not the DB itself.
- **Unread:** how NMS-Newton implements chat-command interception and the
  custom orbital-period UI (which functions hooked).
- **Unread:** NoMansSky.Api's source tree (actual signatures behind the
  README claims) and its wiki beyond the home page.
- **Freshness:** all signatures/patterns predate the Sep 2026 "Swarm"
  update window; Blind Distortion's table was pulled 2026-09-10 as "so
  much is broken" — assume NMS.py hooks need re-validation too.
- **Boundary:** none of this has been executed or verified against the
  running game; the GameGPT project's "no live claims from readback"
  rule applies.

*End of notes. UNVERIFIED research — confirm against the running game in
a Bruce-authorized live session before any GameGPT profile use.*
