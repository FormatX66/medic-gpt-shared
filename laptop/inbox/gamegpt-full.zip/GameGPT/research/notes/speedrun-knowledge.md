# No Man's Sky — Speedrun/TAS Mechanical Knowledge

Compiled 2026-09-18. Status: **RESEARCH ONLY / UNVERIFIED.** Every
mechanic below is scraped from community sources and is NOT confirmed
against the running game until a Bruce-authorized live session tests it.
Speculation is marked as such.

Dossier (no duplication): `game-dossier.md` (cheat tables, save editors,
tuning globals), `modding-landscape.md`, `best-cheats.md`.

---

## 1. speedrun.com categories (from the public API, 2026-09-18)

Full-game (per-game) categories —
https://www.speedrun.com/api/v1/games/nms/categories
- **Space Station** — reach the space station, timer stops on exiting
  ship there. Rules note "All pray to the RNG overlords" (fresh-save
  start spawn luck matters).
- **Artemis Path** — complete the Artemis storyline ("reset the
  simulation"); timer stops when choosing the new galaxy.
- **Atlas Path** — complete the Atlas Path; timer stops on birthing a
  new star.
- **Galaxy Center** — timer stops on locking in the final warp.
- **The Long Road Home** — create a base on starting planet, then travel
  to the center of **all 255 galaxies** and return home. *Portals are
  allowed; station/base teleporters are banned.* Up to 5 players in
  shifts.
- Per-level category **Main** with milestone levels (seen on the
  leaderboard page as Magnate, Legend, Naturalist —
  https://www.speedrun.com/nms).
- Misc categories: **Die In A Volcano**, **Black Hole**, **Bread**
  (permadeath, glitchless, "make bread as fast as possible"),
  **SpaceStationDirector%** (become Director of any Space Station; full
  RTA ruleset — save editors banned, unmodded, single player, no
  co-op/trading/teleports to foreign bases, segmented runs allowed).

The default front-page leaderboard shows top times ~1m44s (Skiiac,
Origins) down through ~25m (Beyond era) — leaderboard context in the
rendered page does not name which category that table was, so treat
the 1m44s figure as unattributed until a categorized leaderboard is
checked. 232 followers / 220 runs / 71 players total —
https://www.speedrun.com/nms — the scene is small and mostly dormant
since ~2023.

## 2. The Artemis% guide — the single richest mechanical document

Guide: https://www.speedrun.com/nms/guides/lcarw
("Artemis% is fresh file → centre of galaxy via storyline; ~20 warps,
~3 hours with optimizations").

Route-critical mechanics it documents:
- **"Scooting"** (guide author's name): *alternate the Analysis Visor
  focus (zoom) and the melee punch — each cancels the other's cooldown,
  so you can perpetually chain the punch's forward momentum and glide
  forward rapidly on flat ground. Costs health (frequent fall damage);
  worse on hills; saves jetpack + life support.* (same URL)
- **Punch-jetpack boost**: "By Punching and Jetpacking before the Punch
  animation completes, you'll get a great boost forward... most
  beneficial from going from high ground to low ground. Keep enough
  charge to cushion or you'll die." (same URL)
- **Melee boost lineage**: punch (Q/RB/R1) then jetpack (Space) a split
  second after, mid-swing, preserves the lunge momentum; running start
  multiplies it; feather the jetpack. Present since 2016; Hello Games
  never removed it and appears to have embraced it ("the devs approve
  so it is definitely not cheating") —
  https://kotaku.com/no-man-s-sky-s-weird-melee-jump-is-still-the-most-fun-t-1797979942,
  https://www.videogamer.com/guides/how-to-melee-boost-in-no-mans-sky/,
  https://www.gamerguides.com/no-mans-sky/guide/walkthrough/tips-and-tricks/how-to-melee-boost
- **Refiner-in-route**: early portable refiner is part of the speedrun
  build order (90 Ferrite → 90 Pure Ferrite while grinding; copper →
  chromatic metal; rusted metal → ferrite; 250 Carbon → Condensed
  Carbon for warp cells; refiner sits "doing its thing" while you
  grind — i.e. refiners run in real time during play, no rest needed).
  (Artemis% guide, same URL)
- **Run config**: windowed mode, minimal graphics, offline, permadeath;
  LiveSplit; keyboard is faster in menus, controller preferred for
  ship flight; graphics settings affect "scoot" feel. (same URL)
- **Ship-swap resource extraction**: at crashed ships, swap ships and
  dismantle the broken one's tech (Launch Optimizers etc.) for mats,
  then swap back. (same URL)

## 3. Movement tech beyond melee boost

- **Cliff/wall climb**: walk into a cliff or crater wall while holding
  forward and boosting — you fly up alongside it *without expending
  jetpack fuel* (terrain-collision edge case).
  https://www.alphr.com/games/1002181/no-mans-sky-tips-tricks/
- **Rocket Boots + Airburst Engine**: double-tap lift-off combo as an
  alternative to melee timing.
  https://steamcommunity.com/app/275850/discussions/0/532101451410899300/?ctp=3
- **Orbit boost trick**: boost out of the atmosphere into vacuum, then
  pulse — "a five-minute flight can be cut down to no more than twenty
  seconds"; atmospheric drag is the governing constraint.
  https://www.gamespot.com/gallery/no-mans-sky-13-things-you-probably-didnt-know-you-/2900-830/
- **Porpoising**: fly up and over just before exiting atmosphere —
  faster at altitude; cuts a 20-minute ETA to <3.
  https://steamcommunity.com/app/275850/discussions/0/1745605598720429281/
- **Pulse-drive keeps boost on**: fly the Pulse Drive *toward* the
  planet; it auto-disengages while keeping the ship boost engaged — as
  long as you don't tap the boost key again.
  https://steamcommunity.com/app/275850/discussions/0/2789318172121692045/?l=greek
- **Ship speed numbers** (community-measured, no upgrades — treat as
  approximate): atmosphere avg ~70u/s, boost to 190u/s; open-space boost
  ~2,200u/s; Pulse Jump ~40,000u/s; near space stations ~1,900u/s; near
  Anomaly ~120u/s; atmosphere exit causes speed to rise linearly then
  suddenly double at the boundary.
  https://nomanssky.fandom.com/wiki/Pulsing_Heart
  (older Pulse Engine page lists ~20,000u/s pulse and 1,800u/s boost —
  numbers drift across eras; verify in-game.)
  https://nomanssky.fandom.com/wiki/Pulse_Engine
- **Brake-drift**: slam brake + turn for instant reversals (added in
  the day-one patch era), used in combat/pirate escapes.
  https://www.gamespot.com/gallery/no-mans-sky-13-things-you-probably-didnt-know-you-/2900-830/

## 4. Glitches and exploits (patched vs surviving)

### 4a. Item duplication (mostly patched; the famous ones)
- **Grave dupe (launch era, 2016)**: die in ship → grave marker holds
  ship inventory → reload the pre-death save → inventory restored AND
  grave still collectible → exponential doubling. **Patched in 1.07**
  (graves no longer visible after loading a previous save) —
  https://www.eurogamer.net/no-mans-sky-exploit-how-to-get-unlimited-warp-cells-atlas-stones-and-rare-resources
- **Pre-launch infinite warp cell / rare-goods trading exploits**:
  removed in the 1.03 day-one patch (Sean Murray's words: "People using
  these cheats were ruining the game for themselves...").
  https://www.pcgamer.com/massive-no-mans-sky-day-one-patch-increases-galaxy-sizes-fixes-exploits/
- **NEXT-era refiner dupe (2018, patch 1.51/1.52)**: place portable
  refiner, insert item, place a second refiner directly *in front* of
  it (not beside) — item appears in the new one (~80% success).
  https://oneangrygamer.net/2018/07/no-mans-sky-next-guide-how-to-do-the-duplication-glitch-after-patch/
- **Synthesis 2.17 patch notes** (2019): "Fixed an exploit that allowed
  for infinite creation of stellar metals" AND "Fixed an item
  duplication exploit."
  https://www.gamerevolution.com/guides/620172-no-mans-sky-2-17-update-patch-notes-the-synthesis-update
- **Sep 2025 experimental branch**: "Fixed an issue that could cause
  many duplicate items to be created in inventories" (Voyagers era;
  likely corvette-related).
  https://steamcommunity.com/app/275850/discussions/0/797840845858483112/
- **Base-part refund dupe (reported ~Sep 2025)**: picking up a placed
  base part (e.g. Large Refiner) refunds full material cost while the
  part can be re-placed at no cost; portable units duplicate in
  inventory. Accidental-triggering was the reporter's complaint — NOT
  confirmed patched; appears tied to relocation targeting highlighting
  a nearby decoration/wall.
  https://steamcommunity.com/app/275850/discussions/0/5077247524952779630/
- **Current refiner state (2025)**: medium/large refiners have UI bugs
  (output counter defaulting to 0/0 — workaround: lift and re-insert
  the input item), and a long-standing "bug" where refiner contents
  vanish if you walk away while processing — community advice is
  "never wander away from your refiners while they are working."
  These are bugs, not exploits, but they bound refiner-based
  automation: batch refiner work must be *attended*.
  https://steamcommunity.com/app/275850/discussions/2/601913886224070601
  https://steamcommunity.com/app/275850/discussions/2/597412189643642717
  https://steamcommunity.com/app/275850/discussions/0/691994366768762569

### 4b. Portal mechanics and constraints (mechanically rich; speedrun-banned in some categories)
- **12-glyph addresses**: first glyph = planet index in system; glyphs
  map to hex digits 0–F (sunset=0 … atlas=F).
  https://allthings.how/no-man-s-sky-how-to-unlock-all-16-portal-glyphs/
- **Portal Interference**: after portal travel you cannot warp out,
  build a base, or use station teleporters — escape only via the return
  portal or by finding an existing base's teleport module.
  https://steamcommunity.com/app/275850/discussions/0/3317353727665194881/
- **Addresses are galaxy-locked**: the glyphs stay with you, but a
  galaxy change means rebuilding the destination network.
  https://allthings.how/no-man-s-sky-how-to-unlock-all-16-portal-glyphs/
- **"Approximating"**: partial/unknown glyphs get randomly altered by
  the game — same input can land on different planets.
  https://steamcommunity.com/app/275850/discussions/0/1651043320653481924/?l=schinese
- **First-glyph indexing bug**: in systems with <6 planets the first
  glyph→planet mapping is off by one, and the last planet is
  unreachable by portal (documented at length; treated as a bug by the
  reporter, behavior unchanged across eras).
  https://steamcommunity.com/app/275850/discussions/4/1486613649677493656/?l=greek
- **Expedition portal detour (Jan 2025)**: during an expedition, when
  the milestone says portal to the next rendezvous, switching the
  selected milestone to a different one makes the portal behave as a
  *regular* portal — enter any address, go fetch a ship, return, and
  resume. Confirms expedition portals are regular portals with a
  mission lock layered on top.
  https://steamcommunity.com/app/275850/discussions/0/595139065567784694
- **Black-hole tech rules**: black holes throw you ~6,000 ly toward
  the center (max hyperdrive warp ~3,000 ly) and break non-essential
  ship tech in the general inventory — mitigate by keeping important
  tech in the technology inventory; Atlas Path completion reveals
  nearby black holes.
  https://steamcommunity.com/app/275850/discussions/0/3317353727665194881/

### 4c. Save/reload manipulation (soft exploits, mostly unpatchable)
- **Multitool cabinet reroll**: at a cabinet, save+reload to re-roll
  which multitool spawns — the community treats this as standard
  ship/MT hunting procedure.
  https://steamcommunity.com/app/275850/discussions/0/6821308966003208709/
- **Crashed-ship seed/slot reroll**: ships are seed-driven (dossier
  §3b); class/seed outcomes are set per-encounter, so autosave + reload
  around the encounter re-rolls what you find — consistent with the
  save editors exposing a ship "seed" field.
  https://github.com/goatfungus/NMSSaveEditor (cited in game-dossier.md)
- **Paired saves as manipulation primitive**: auto + manual save pair
  (dossier §3a) is exactly what makes grave-dupe-style reload tricks
  possible — the game keeps two save slots you can toggle between.

## 5. Expedition speedruns (informal, community-tracked — no speedrun.com category)

- Expedition speedrun records are community-tracked (YouTube/Discord),
  not on speedrun.com.
- Expedition 19 (Voyagers/corvette expedition): record cited at 36 min,
  then 31m50s; new players finish under 2 hours.
  https://steamcommunity.com/app/275850/discussions/0/597413522044070969
- 2026 "Remnant" expedition: ~1h31 (ElanPaul) with sub-90-min attempts
  on YouTube.
  https://www.youtube.com/watch?v=cqM7enlvqaY
- Voyagers expedition (Expedition 20): speedrunners finishing under an
  hour; casual guides "Corvette Expedition in 90 Minutes".
  https://steamcommunity.com/app/275850/discussions/0/597413188027506324
- Expeditions are deliberately linear and completable in a few hours —
  the speedrun-relevant knowledge is route planning, not glitches.

## 6. RNG / determinism knowledge

- **Deterministic generation**: a single 64-bit input seed → galactic
  map; star coordinates feed the PRNG that places planets; planet
  location feeds terrain/climate/flora/fauna generation. Same universe
  for every player, regenerable on demand — no save-file storage of
  terrain (Sean Murray: "every planet has a single number, a random
  seed, that defines everything").
  https://lotswife.com.au/infinite-worlds-procedural-generation-in-no-mans-sky/
  https://massivelyop.com/2016/02/21/no-mans-sky-will-have-a-physically-accurate-universe-almost/
- **Player-built changes are layered**: terrain/base edits are stored
  deltas applied *on top of* procedural generation on revisit.
  https://steamcommunity.com/app/275850/discussions/0/1753525517908587573/?l=vietnamese
- **Speedrun-relevant RNG (not seeded by the player)**: starting-planet
  spawn (cave/hazard proximity — guide recommends resetting the save
  for a better spawn), trade-terminal stock, animal scan values,
  crashed-ship tech contents, storm timing. The game gives the player
  no control over the galaxy seed — unlike a ROM randomizer, nothing
  to fixate for a companion to manipulate; the leverage point is
  *detection* (read current values) not *prediction*.

## 7. TAS / frame-data: absent

- No No Man's Sky TAS, frame-data tables, or emulator-based research
  surfaced. Search returns only generic TAS explainers (Wikipedia,
  tasvideos definitions).
  https://en.wikipedia.org/wiki/Tool-assisted_speedrun
- The movement tech that exists (melee boost, scooting) is described
  qualitatively ("a split second after", "half a second later") with
  no frame counts, no input-sequence logs, no measured velocities.
- *Speculation*: this is likely because (a) the game is PC/modern —
  no emulator with savestate/frame-advance exists for it, and
  (b) TAS culture targets completion of defined games, while NMS's
  flagship categories are fuzzy. GameGPT should treat all movement
  timings as human-feel, not frame data, until it measures them live.

## 8. Patch timeline of relevant exploits (rough)

| Era | What changed | Source |
|---|---|---|
| Pre-launch | 1.03 removes infinite warp-cell + rare-goods trading exploits | https://www.pcgamer.com/massive-no-mans-sky-day-one-patch-increases-galaxy-sizes-fixes-exploits/ |
| Patch 1.07 (2016) | Grave-dupe removed (graves invisible after loading previous save) | https://www.eurogamer.net/no-mans-sky-exploit-how-to-get-unlimited-warp-cells-atlas-stones-and-rare-resources |
| NEXT 1.51–1.52 (2018) | Refiner-placement dupe still worked; labeled "may be patched" | https://oneangrygamer.net/2018/07/no-mans-sky-next-guide-how-to-do-the-duplication-glitch-after-patch/ |
| Synthesis 2.17 (2019) | "Fixed an item duplication exploit"; infinite stellar metals fixed | https://www.gamerevolution.com/guides/620172-no-mans-sky-2-17-update-patch-notes-the-synthesis-update |
| Atlas Rises → present | Portal Interference (no base/warp after portal) persists | https://gamefaqs.gamespot.com/boards/739857-no-mans-sky/77329295 |
| Voyagers era (2025) | Refiner UI bugs; refiner contents vanishing unattended; inventory-dupe fix in experimental | https://steamcommunity.com/app/275850/discussions/2/601913886224070601, https://steamcommunity.com/app/275850/discussions/0/797840845858483112/ |
| Sep 2025 | Base-part pickup refund dupe reported (unconfirmed patched) | https://steamcommunity.com/app/275850/discussions/0/5077247524952779630/ |

## 9. GameGPT relevance (synthesis — partially speculative)

1. **Movement tech is the highest-value companion knowledge**: melee
   boost and "scooting" are input patterns GameGPT can *demonstrate*
   or coach — and since speedrunning favors them, a "get me there
   fast" voice command maps naturally to them. Their qualitative
   timing ("split second") is a good candidate for live measurement
   into frame/ms numbers via input-macro testing.
2. **Portal interference is the #1 mechanical constraint a companion
   must respect**: any "take me to X" feature must account for the
   no-warp/no-build/no-teleport lock after portal travel and
   galaxy-locked addresses — these are hard game rules, not
   preferences.
3. **Refiner behavior bounds automation**: refiners process in real
   time while you play (speedrun route uses this as parallel work),
   but unattended refiners can eat their contents — a companion
   scheduling refiner batches must stay in the area or pull results
   before leaving.
4. **No TAS/frame-data exists** — GameGPT would be the first to
   measure NMS movement at input granularity; that is a genuine gap,
   not a solved problem to harvest.
5. **Generation is deterministic but player-uncontrollable** — the
   companion's edge is reading state (current system, portal lock
   status, grave presence) rather than predicting seeds.

*End. All UNVERIFIED — confirm against the running game before any
GameGPT profile use.*
