# No Man's Sky — top gameplay mods (Nexus Mods demand signals)

Compiled 2026-09-17 (research session). Status: **RESEARCH ONLY / UNVERIFIED.**
Nothing here has been confirmed against the running game. Mods are treated as
research maps: where values live, what players want. **Summarized, not
reproduced** — quotes are short and mechanical.

Companions: `game-dossier.md`, `modding-landscape.md`, `best-cheats.md`.

---

## 1. What the Nexus top pages show right now

Source page: https://www.nexusmods.com/nomanssky/mods/topalltime?adult=2
(fetched 2026-09-17; renders the "past two weeks" top-30 list; several
entries' names did not survive text extraction — those are listed by rank
only and are a **gap**).

### Cheat-adjacent mods in the current top 30 (past two weeks)

| Rank | Mod | What players want (demand signal) | Where the value lives |
|---|---|---|---|
| #2 | **Reduced Launch Cost 4.1** | Launch-fuel tax is still the #1 resented throttle. Free / 5% / 10% options | Ship launch cost tuning (GCSPACESHIPGLOBALS-class) |
| #4 | **Better Rewards** | Economy shortcut: more currency, 2x mining yield, 5x frigate-expedition units/nanites | `REWARDTABLE.MBIN`, `EXPEDITIONREWARDTABLE.MBIN` |
| #17 | **Remove Technology Overload** (6.21 Remnant Compatible) | Equip >3 tech of same type; stack sizes **x100**; more exosuit slots | Tech-install limits + stack caps (GCTECHNOLOGYTABLE-class) |
| #18 | **Instant Text Display (ITD)** | Friction deletion: interaction text renders instantly | Text/display timing tuning |
| #19 | **Fast Refiners** | Refiners + Food Processors 10x faster; ships an **"Instant Refiners"** variant "for all you cheaters" | Refiner process-time tuning |
| #28 | **NMS Extender (NMSE)** | "Modders can create mods that run directly inside of NMS" — runtime behavior, not just data | The only Nexus path to in-game code execution |
| — | **Fine LOD** (#12), **No Fade** (#22) | Performance/friction, not cheats | LOD tuning |
| #13 | **NomNom** | Save editor (already documented in dossier §3b) | Save JSON |

Also spotted on adjacent top lists:
- **Better Planet Generation** (#3 past two weeks) — exploration richness is a
  data knob; outside live-memory scope.
- **Auto-Sprint (sort of)** — recently added; sets medium-run speed to sprint
  speed ("closest we can come to automatic sprint").
  https://www.nexusmods.com/nomanssky/mods/toprecent
- **More Words** — learns more words per NPC/stone/monolith/Atlas orb (grind
  deletion, mirrors "Decode All Words" cheats).
- **Equalized Exotic Spawns** — exotic ship spawn 1/21 instead of 1/301
  ("while keeping ship seeds intact/vanilla") — proves spawn chance is a
  tunable and seeds are separable from spawn rate.
- **Clean HUD _ THE TRAVELLER** (https://www.nexusmods.com/nomanssky/mods/1563)
  — confirms players strip warning/alert clutter; mentions ship summon/takeoff
  fuel behavior.
- **Prepare to Sky Edition** (https://www.nexusmods.com/nomanssky/mods/2225) —
  progression overhaul; documents **mining speed = beam damage vs
  minerals/flora**: its "Hijacked Laser" deals **9.33x damage = 6x faster
  mining**, 1.33x damage vs Sentinels/Creatures, **0.3x resource yield**,
  heats **2x faster**, "reloads" (cools) **2x faster**, uses fuel **3x** as
  fast, costs **2x** to recharge. Old-school fast-mining mods targeted
  `NMS_REALITY_GCTECHNOLOGYTABLE.MBIN`
  (https://videogamemods.com/nomanssky/mods/fast-mininglaunchcostreductionhyperdrive-base-1000lyminerheattime-increase/).

### Economy data point (Better Rewards, full detail)

https://www.nexusmods.com/nomanssky/mods/1460 — crawled 2026-09-16:
- Covers: space station + Nexus missions, interactable objects (abandoned
  buildings, damaged machinery, waypoints), Sentinels, alien interactions.
- **Words**: 3x from knowledge stones/dictionaries (3 words per stone); **5
  Atlas words** instead of 1; 15% chance to learn from non-NPC sources.
- **Resources**: 2x mining-beam yield, but only on objects that **explode** as
  mined; also containers, depots, guild rewards, asteroids, ship drops.
- **Frigate expeditions**: 5x units + nanites, 2x products (Storage
  Augmentation, NipNip Buds), 3x resources (Copper/Emeril/Cadmium).
- Page says **updated to NMS version 7.01 (Build ID: 25233815) on
  2026.09.11** — note: Fast Refiners cites "THE SWARM" v6.44 (build
  23583900). Version numbering between the two mod pages disagrees; both
  quoted as written.

**GameGPT read**: the economy throttle players pay to delete is *waiting and
small numbers* (refine time, stack caps, launch cost, reward sizes), not
god-mode combat. Every one of these mods is a validated cheat design.

---

## 2. Movement mods — the value maps

### Krypton Ultimate Jetpack & Flight Overhaul v3.8 (Goldenveins & Gemini)

https://www.youtube.com/watch?v=BQVLhC3bcC4 (author's own summary in video
description; Nexus page fetch failed 2026-09-17 — noted gap):
- **Files modified**: `GCPLAYERGLOBALS.MBIN`, `GCCHARACTERGLOBALS.MBIN`,
  `GCSPACESHIPGLOBALS.MBIN`, `GCCAMERAGLOBALS.MBIN` — the full movement stack.
- **Infinite jetpack**: mid-air regeneration + tank fill rates set near-instant.
- **Rocket Boots**: boost force **120**, impulse **8.0** (greatly raised).
- Increased max fall speed; "Hard Landing" animations disabled; zero-G
  spacewalks (gravity constraints removed).
- Camera: vertical spring + camera shake zeroed while jetpacking/falling;
  FOV lock against high-speed "fisheye"; fixed 4.0 follow distance.
- Ship: pulse (mini-warp) speed up; low-flight hover/ground clearance
  tightened; screen shake removed; higher landing speeds, 90° landing angles;
  Corvette thrust/speed up.

**GameGPT read**: the entire "movement feel" is four named global files.
A "jetpack forever" profile starts at these field names.

### Fluid Flight v1.3 (Goldenveins & Gemini & Claude Sonnet 4.5; for NMS v6.18)

https://www.nexusmods.com/nomanssky/mods/4048 — announced verbatim at
https://steamcommunity.com/app/275850/discussions/0/737034982498784595.
This is the richest field-level documentation found: exact vanilla defaults
vs. modded values. Vanilla numbers summarized (mod numbers in parentheses):

- **Jetpack flight**: Fill Rate 0.5 (1.5); Midair Fill 0.25 (0.75); Min Fuel
  Required 0.5 (0.25); Horizontal Speed **5 (45)**; Vertical Speed 30 (40);
  Forward Thrust 31 (50); Upward Thrust 30 (40); Ignition Boost 60 (65);
  Braking 2.2 (0.9); Horizontal Drain 2.5 (1.0).
- **Height limits**: Terrain Range 3 (99,999); Prime Range 5 (99,999);
  Non-Terrain Range 1.1 (99,999) — i.e. height caps are three plain fields.
- **Rocket Boots**: Initial Impulse 3.0 (1.5); Boost Force 68 (60); Downward
  Correction 0.3 (0.05); Min Height 2.0 (1.0); Max Height 6.0 (3.0);
  Drift Force 0.5 (0.01); Drift Duration 2.0s (1.0).
- **Underwater**: Max Speed 15 (25); Thrust 12 (20); Surface Escape 8 (18);
  Escape Force 20 (35); Drain 0.4 (0.3); Fill Rate 1.0 (5.0).
- **Space jetpack**: Thrust 40 (65); Upward 30 (50); Ignition 15 (25);
  Max Speed 10 (18); Drain 0.3 (0.2). **Spacewalk**: Max Speed 1,000 (1,600).

**GameGPT read**: every jetpack/swim/space behavior is a named float in
GCPLAYERGLOBALS with known vanilla defaults — a ready search vocabulary for
runtime discovery. Field names are inferred from the stat labels; the
stepmodifications GCPlayerGlobals reference already documents
`JetpackFillRate` (0.5), `JetpackMaxSpeed` (5), `JetpackMaxUpSpeed` (30),
`GroundRunSpeed` (8) — consistent with the above.

---

## 3. Inventory / stack mods — where the caps live

- **Remove Technology Overload** (top-30 #17): >3 same-type tech,
  **stack sizes x100**, more exosuit slots — tech limits and stack caps are
  tunables, not hardcoded.
- **Vanilla stack caps** (community-reported): Normal **9999**, Survival
  **500**, Permadeath **250**
  (https://community.wemod.com/t/no-mans-sky-cheats-and-trainer-for-steam/90197?page=23).
  Stack relaxation to 9999 landed in Beyond 2.0.
- **Bodie420 "Bigger Stacks"**: 10x stacks + 48 suit tech slots
  (https://allmods.net/no-mans-sky-mods/cheats/bigger-stacks-and-suit-tech-slots-expand-to-48/).
- Players still hunt simple stack-only mods (Steam thread looking to replace
  "DDEMONZ BIGGER STAKZ":
  https://steamcommunity.com/app/275850/discussions/0/685240346634996062).

---

## 4. Cheats-with-a-UI: closest analogs to GameGPT

NMS mods are load-time `.pak` data — there is **no Skyrim-MCM-style in-game
menu mod on Nexus**. The analogs live off-Nexus or one layer down:

1. **NMS Extender (NMSE)** — Nexus top-30 #28: "a tool in which modders can
   create mods that run directly inside of NMS allowing for almost anything
   to be possible." This is the only Nexus-listed path to runtime/UI behavior.
   (Page fetch failed; mechanics unconfirmed — gap.)
2. **MrAntiFun trainer** — "far and away the most popular" NMS mod per
   https://www.vg247.com/no-mans-sky-mods-cheats: god mode, infinite
   stamina/jetpack/health, easy crafting, no reload, wanted-level reset,
   unlimited warp cells, currency editors (Units/Nanites/Quicksilver). The
   feature list is a market-validated cheat ranking; mirrors `best-cheats.md`.
3. **WeMod trainer thread** documents the stack-cap mechanics cheats hit:
   "Unlimited Materials" forces stacks to 9999 (fills automatically); "Super
   Pack Sizes" → 99,999; moving an oversized stack with the cheat off splits
   at the vanilla cap
   (https://community.wemod.com/t/no-mans-sky-cheats-and-trainer-for-steam/90197?page=23).
   This proves stack max is a **live, changeable value** — exactly the class
   of thing a voice toggle would set.
4. **Blind Distortion's Fearless Revolution table** (dossier §1a) — the
   AOB-pointer cheat set; download pulled 2026-09-10, watch for repost.
5. **Caution**: fake "NO MAN'S SKY CHEAT MENU 2026" repos exist
   (e.g. https://github.com/hudzaifahlilop/no-mans-sky-ultimate-2026 —
   "Press F1 → cheat menu", links to `getloader.click`). Looks like a
   scam/malware lure. Do not download, do not trust.

**GameGPT read**: GameGPT's voice-trigger design has no direct Nexus
predecessor — the closest existing UX is the trainer toggle list. The
voice-trigger ranking should mirror the MrAntiFun/WeMod toggle lists, which
themselves mirror the Nexus demand ranking.

---

## 5. Weekly-sweep additions from this pass

- https://www.nexusmods.com/nomanssky/mods/topalltime?adult=2 and
  https://www.nexusmods.com/nomanssky/mods/top — new cheat-adjacent mods
  signal demand shifts (e.g. "Auto-Sprint (sort of)" is new).
- https://www.nexusmods.com/nomanssky/mods/4048 (Fluid Flight) — watch for
  v1.4+; its changelogs will document which GCPLAYERGLOBALS fields move per
  NMS update.
- https://www.nexusmods.com/nomanssky/mods/1460 (Better Rewards) — economy
  tuning canary.
- Fast Refiners' page — build-ID/version references for NMS updates.

## Gaps / unverified

- Individual Nexus mod pages (4048, 1460, NMSE, Reduced Launch Cost) failed
  to fetch via text extraction on 2026-09-17 — details above come from the
  top-list text and web-search caches, not the mod pages themselves. Field
  names inferred from stat labels (e.g. Fluid Flight's) are not yet
  cross-checked against MBINCompiler/libMBIN definitions.
- Exact endorsement/download counts per mod not captured (top page showed
  ranks and some endorsement numbers, but name/number pairing was lossy).
- NMSE's actual mechanism (how it runs code inside NMS) is unknown from
  this pass — its page needs a successful read.
- Version discrepancy: Better Rewards says NMS 7.01 (build 25233815,
  2026.09.11); Fast Refiners says "THE SWARM" v6.44 (build 23583900).
  Unresolved — treat both as reported.

*End. All UNVERIFIED — confirm against the running game before any GameGPT
profile use.*
