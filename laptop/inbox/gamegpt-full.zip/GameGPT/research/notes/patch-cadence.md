# No Man's Sky — Patch Cadence & Breakage Patterns (GameGPT research)

Compiled 2026-09-18. Status: **RESEARCH ONLY / UNVERIFIED.**
Everything below is public-source research. No pattern, version, or
durability claim has been confirmed against the running game — every
cheat vector is a research lead until a Bruce-authorized live session
validates it. Companion: `game-dossier.md` (what to cheat), this file is
*when things break and which vectors survive*.

---

## 1. Hello Games' update rhythm

- **Major named updates every ~7–16 weeks.** Days-between-major-release
  since mid-2024, per the fan wiki's patch-notes table:
  49 / 49 / 15 / 83 / 56 / 70 / 84 / 56 / 111 / 57 / 49
  ([fandom patch notes](https://nomanssky.fandom.com/wiki/Patch_notes)).
  Median ≈ 57 days; plan on 4–5 majors per year.
- **2025–2026 major update timeline:**
  | Version | Name | Date | High-level change |
  |---|---|---|---|
  | 5.50 | Worlds Part II | 2025-01-29 | Gas giants, deep oceans, lighting overhaul, new story ([VGC](https://www.videogameschronicle.com/news/no-mans-skys-latest-update-worlds-part-ii-adds-trillions-of-new-planets/)) |
  | 5.60 | Relics | 2025-03-26 | Fossil hunting, settlement improvements ([recipes guide](https://nomansskyrecipes.com/blog/no-mans-sky-returning-player-guide-2026/)) |
  | 5.70 | Beacon | 2025-06-04 | Settlements round 2, Switch 2 launch ([recipes guide](https://nomansskyrecipes.com/blog/no-mans-sky-returning-player-guide-2026/)) |
  | 6.00 | Voyagers | 2025-08-27 | Corvettes (player-built capital ships), highest-ever concurrents ([PC Gamer](https://www.pcgamer.com/games/survival-crafting/no-mans-sky-is-rerunning-all-of-its-expeditions-from-2025-while-also-giving-players-another-chance-to-add-mass-effects-normandy-to-their-spaceship-collection/)) |
  | 6.10 | Breach | 2025-10-22 | Corvette wreck salvage, zero-g missions ([recipes guide](https://nomansskyrecipes.com/blog/no-mans-sky-returning-player-guide-2026/)) |
  | 6.20 | Remnant | 2026-02-11 | *(high-level content not confirmed in sources read)* |
  | 6.30 | Xeno Arena | 2026-04-08 | Pokémon-style turn-based creature battles ([VGC](https://www.videogameschronicle.com/news/no-mans-sky-gets-a-new-update-adding-xeno-arena-a-pokemon-style-turn-based-battle-mode/)) |
  | 6.40 | The Swarm | 2026-05-27 | Expedition 22 (~8 weeks), swarmer enemies, space-combat rework ([PSU](https://www.psu.com/news/no-mans-sky-update-6-4-out-now-with-the-swarm-expedition-stability-improvements-more-full-patch-notes-listed/), [patch notes mirror](https://comicbook.com/gaming/news/nms-no-mans-sky-update-patch-notes-swarm/)) |
- **Every major brings an expedition** (seasonal milestone mode, ~5
  weeks, exclusive rewards convertible to normal saves):
  17 Titan (2025-02-12), 18 Relics (2025-03-27), 19 Corvette (2025-09-03),
  20 Breach (2025-10-22), 21 Remnant (2026-02), 22 The Swarm (2026-05)
  ([expedition list](https://nomanssky.fandom.com/wiki/List_of_Expeditions)).
  New expeditions ≈ 4–5/year, each tied to a major update's new systems.
- **Holiday/year-end redux cycle:** Hello Games re-runs the year's
  expeditions back-to-back in ~2-week slots (Nov → mid-Jan). 2025-26
  redux: Beachhead (Nov 7–18), Titan (Nov 19–Dec 2), Relics (Dec 3–16),
  Corvette (Dec 17–30), Breach (Dec 31–Jan 13)
  ([nomanssky.com](https://www.nomanssky.com/2025/11/holiday-expeditions-2025/)).
  New-player spikes ride these; cheats are most *wanted* then but the
  code churn makes tables most *broken* then.

## 2. Patch mechanics: experimental branch + hotfix storms

- **Steam experimental branch = early warning.** Opt in via
  Steam → Properties → Betas → code `3xperimental`. Hello Games pushes
  rapid hotfix builds there in the first days after a major release,
  then rolls the same fixes to all platforms. Example threads (dated
  chains of daily builds): [01/11](https://steamcommunity.com/app/275850/discussions/0/1644304412657181002/?l=thai),
  [09/09](https://steamcommunity.com/app/275850/discussions/0/3044985412470101044/?l=hungarian),
  [17/09](https://steamcommunity.com/app/275850/discussions/0/5086242673959671077/?ctp=7).
  **GameGPT implication:** an update lands on experimental days before
  main — tables (and GameGPT profiles) can be re-validated there
  *before* the breakage wave hits the public branch.
- **Post-major hotfix storms are normal.** Voyagers (6.00, Aug 27 2025)
  got 6.03, 6.04, 6.05, 6.05.1, 6.06 within ~3 weeks of launch —
  crash fixes, collision fixes, corvette QoL ([6.03](https://steamcommunity.com/app/275850/discussions/0/601914519534471291/?ctp=3),
  [6.04](https://steamcommunity.com/app/275850/discussions/0/601914904286532874/?ctp=2),
  [6.05](https://steamcommunity.com/app/275850/discussions/0/597412189643567444/?ctp=9),
  [6.06](https://steamcommunity.com/app/275850/discussions/0/597413188027465984)).
  Assume any GameGPT profile needs re-checking after *each* of these,
  not just the headline update.
- **Hotfixes can break memory without touching data.** 6.05.1 was a
  22 MB download that did **not** change the save version number
  (still 4194), per a Steam poster — "no major files changed… you can
  (for now anyway) play Experimental or Main and be on the same
  version" ([6.05.1 thread](https://steamcommunity.com/app/275850/discussions/0/597412189643764883)).
  Save editors survive these; AOB/memory work may not.

## 3. What breaks cheat tables per patch — community evidence

### 3a. The treadmill is real and documented

- **Blind Distortion's table** (best-maintained NMS table, 344 posts,
  326 edits) — author **pulled the download on 2026-09-10 ("so much is
  broken")**, update promised within ~a week
  ([thread](https://fearlessrevolution.com/viewtopic.php?t=30442),
  per dossier capture 2026-09-18). This is the flagship table dying on
  the current patch.
- **Aquarius (5.10, Sep 2024) broke six scripts at once** in one
  user's report: Unlimited Run Stamina, No Mining Overheat, Unlimited
  Boltcaster Ammo, No Boltcaster Reload, Max Inventory, Free Crafting
  ([page 2](https://fearlessrevolution.com/viewtopic.php?t=30442&start=15)).
  A content update touching weapons/survival systems kills exactly the
  hooks that touch those systems.
- **Single patches silently kill single options.** Jun 2026: "Unlimited
  environmental suit option doesn't find the right address and can't be
  activated… Confirmed. Last patch was the culprit."
  ([page 22](https://fearlessrevolution.com/viewtopic.php?t=30442&start=315)).
  The failure mode is `aobscanmodule` no longer matching — i.e. AOB
  churn, not logic bugs.
- **Sometimes code paths disappear entirely.** Rhark's NMS trainer
  changelog: "12.06.2023 — Updated to support build-11432080. **Many
  cheats were removed due to being unable to reproduce.**"
  ([trainer thread](https://fearlessrevolution.com/viewtopic.php?t=21315)).
  Not every break is fixable by re-finding the pattern; some features
  genuinely vanish when HG refactors the code.

### 3b. AOB churn vs pointer invalidation

- **Pointers are the fragile layer — the author says so himself.**
  Blind Distortion's "Max out current inventory items" entry carries the
  warning: *"Not an AOB script so may break in the future"*, and it
  broke the very next day after an update ("working till yesterday and
  it is now broken", fixed in v1.31)
  ([page 6](https://fearlessrevolution.com/viewtopic.php?p=379347)).
  Pointer-only entries die on every recompile.
- **AOB patterns survive small patches, die on refactors.** Community
  wisdom on frequently-updated games: re-find the instruction, diff old
  vs new AOB, wildcard the changed bytes — "so you have to update it
  less… you will still at times have to tweak it"
  ([FearLess advice thread](https://fearlessrevolution.com/viewtopic.php?t=19457)).
  Wildcarded patterns (per the thread's example, tolerate byte-level
  churn) handle recompiler register-shuffling but not restructured code.
- **BigJit901's speed scripts "might last a few patches"** — the
  community's own longevity estimate for well-written AOB hooks is
  *a few patches*, not months
  ([page 6](https://fearlessrevolution.com/viewtopic.php?p=379347)).
- **Currency pointers are the exception that proves the rule.**
  Units/Nanites/Quicksilver are exposed as *editable pointers* reached
  through inventory access (dossier §1c). They keep working because the
  path is "open inventory UI → value lives in a reachable structure",
  not because pointers are durable — the same update that shuffled
  Max Inventory broke the currency path for other authors' tables in the
  past.

### 3c. What this means about HG's builds

- Every update rebuilds `NMS.exe`; addresses shuffle → **no static
  offsets, ever** (community uses `aobscanmodule`, never hardcoded
  addresses — see the Last Moved Inventory Item script anchored at
  `8B 44 19 18 41 3B 45 18`
  ([page 3](https://fearlessrevolution.com/viewtopic.php?t=30442&start=30))).
- Feature-scope updates refactor the touched systems' code (AOB churn
  localized to those systems); compiler-version changes shuffle the
  whole binary. *Speculation:* the Swarm-era breakage that killed "so
  much" of Blind Distortion's table (Sept 2026) reads like the latter —
  but the exact post-6.40 build is unverified; see gaps §6.

## 4. MBINCompiler release cadence — the data-structure canary

- **The project states it outright:** "every update to the game breaks
  any number of MBIN formats. This requires updating MBINCompiler for
  each game update" ([readme](https://github.com/monkeyman192/mbincompiler/blob/HEAD/README.md),
  same at [repo](https://github.com/monkeyman192/MBINCompiler)). Each
  MBINCompiler release is version-locked to an NMS version; old MBINs
  may not decompile with new versions.
- **Format migrations happen.** As of Worlds Part II (5.50),
  MBINCompiler stopped generating EXML and emits **MXML** (the format
  NMS actually expects) ([readme](https://github.com/monkeyman192/mbincompiler/blob/HEAD/README.md)).
  Tooling assumptions rot too — GameGPT docs must not hardcode
  EXML-only workflows.
- **Release cadence mirrors NMS's.** The releases page currently shows
  a burst of pre-releases: v6.43.0-pre1, v6.44.0-pre1/pre2/pre3,
  v6.45.0-pre1, v7.00.0-pre1, v7.01.0-pre1, v7.02.0-pre1/pre2,
  v7.03.2-pre1 ([releases](https://github.com/monkeyman192/MBINCompiler/releases)).
  *Speculation:* pre1/pre2/pre3 chains = HG iterating builds per NMS
  patch; the **v7.x** tags (while public NMS is 6.4) suggest either
  experimental/partner builds of a next major, or a numbering change —
  unverified. Either way, the *rate* of new tags is the signal: a burst
  of MBINCompiler releases = data structures are churning = global-
  tuning and mod-layer work needs re-checking.
- **Save editors as second canary.** NMSSaveEditor ships a release per
  NMS version, lagging by days–weeks: 5.0→same-day (1.17.0, 21 Jul
  2024), 6.0 Voyagers→3 days (1.19.0, 30 Aug 2025), 6.4 Swarm→~10 days
  (1.21.0, 6 Jun 2026)
  ([changelog](https://github.com/goatfungus/NMSSaveEditor/blob/master/CHANGELOG.md)).
  The community fills maintenance gaps with unofficial hotfix builds
  (e.g. vectorcmdr's 1.19.6/1.19.7 Voyagers hotfixes while waiting for
  a PR merge, ([releases](https://github.com/vectorcmdr/NMSSaveEditor/releases))).
  When a new NMSSaveEditor drops, the save format changed; when it
  *doesn't* drop after an NMS patch, saves are stable.

## 5. GameGPT guidance — vector durability ranking for NMS

Ordered most → least patch-durable, with maintenance cost:

1. **Save-file edits (guarded, paired auto+manual).** Save format
   2004 since Worlds Part II; hotfixes leave it alone (§2). NMSSaveEditor
   lag days = window where editors misread new fields, but old fields
   (currencies, inventories, seeds, words) rarely move. **Maintenance:
   re-validate per major only.** Already Bruce-verified (Units→2B).
2. **Config/global tuning via mod layer (MBIN/MXML, GCPLAYERGLOBALS).**
   Named fields (JetpackFillRate etc.) persist across versions unless
   HG renames the struct; the EXML→MXML migration shows format
   assumptions rot. **Maintenance: re-validate per major via
   MBINCompiler diff; recompile mod.** Often obsoleted entirely by
   custom difficulty settings (dossier §4a).
3. **Wildcarded AOB memory hooks.** The community's durable primitive;
   survives register shuffling, dies on refactors. Community lifespan
   estimate: *a few patches*. **Maintenance: re-scan after every
   update + hotfix; experimental branch gives a head start.**
4. **Inventory-path pointers (currencies etc.).** Works only via live
   UI structures; dies whenever HG touches the inventory code path
   (author's own warning: "not an AOB script so may break in the
   future"). **Maintenance: highest — re-find every patch.**
5. **Static offsets.** Don't exist in the community's practice.
   **Maintenance: infinite. Never use.**

### Operating rules distilled

- **Never ship a profile during the first 2 weeks after a major.**
  That's the hotfix-storm window (§2); wait for the table community's
  fixes to land and patterns to re-settle.
- **Track the two canaries:** new
  [MBINCompiler release](https://github.com/monkeyman192/MBINCompiler/releases)
  = data structures changed; new
  [NMSSaveEditor release](https://github.com/goatfungus/NMSSaveEditor/blob/master/CHANGELOG.md)
  = save format changed. Feed both into the weekly sweep's watch list
  (dossier §7 already lists them — add the *why*).
- **Use the experimental branch as the re-validation sandbox.** Builds
  appear days before main; a GameGPT profile can be checked against
  experimental before users hit the breakage wave.
- **Prefer system-localized AOBs.** Breakage clusters in the systems
  the update touched (Aquarius broke weapon/survival hooks, §3a). A
  profile touching *many* systems (Blind Distortion's mega-table)
  maximizes per-update breakage; GameGPT's per-feature profiles
  (jetpack-only, refine-only) isolate the blast radius.
- **Treat Blind Distortion's table state as a health meter.**
  Author pulls download / mass edits = the current NMS build is hostile
  to memory work; a fresh stable table = green light to re-validate
  GameGPT profiles.

---

## 6. Gaps (unverified / needs a live session or more reading)

- The exact post-6.40 build that broke Blind Distortion's table in
  Sept 2026 is unidentified (MBINCompiler's v7.x pre-releases hint at
  new builds, but that linkage is speculation).
- Remnant (6.20) high-level content wasn't in the sources read — not
  needed for cadence, noted for completeness.
- Whether hotfix builds between majors (6.03–6.06 style) change
  `NMS.exe` bytes enough to invalidate AOBs is assumed from community
  behavior, not measured — a live session could diff scans across two
  hotfixes.
- GOG/Microsoft Store builds lag Steam by days; table authors mostly
  target Steam — GameGPT profiles on Game Pass may need per-platform
  re-finding.

*All factual claims above are public-source research, UNVERIFIED
against the running game. Confirm against a live build before any
GameGPT profile use.*
