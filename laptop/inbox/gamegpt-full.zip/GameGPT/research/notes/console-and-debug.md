# NMS — console, debug modes, launch flags

Compiled 2026-09-17. Status: **RESEARCH ONLY / UNVERIFIED.** No
console/debug claim below has been tested against the running game.
Speculation is marked. Companion files: `game-dossier.md`,
`modding-landscape.md`, `best-cheats.md`.

---

## 1. Is there a dev console? — No public evidence of one

- **No developer console exists in retail NMS builds as far as the
  community can tell.** The community's cheat scene is entirely
  memory tables, trainers, save editors, and data mods — there is no
  `~`-key console, no `enablecheats`-style toggle, no documented
  command set. A 2018 Steam thread title says it outright:
  "…a game like this for pc **WITH NO command options**?"
  (https://steamcommunity.com/app/275850/discussions/0/1762481957306574092/).
- GameFAQs' NMS "cheats" are save/exploit tricks (ship-skin save
  dance, grave dupe, word-farming loop), not console commands
  (https://www.gamespot.com/games/no-mans-sky/cheats/).
- **Junk-page warning:** "Best No Man's Sky Console Commands" pages
  exist (e.g. https://ftp.sleeklens.com/no-mans-sky-console-commands/),
  but they describe fantasy "terrain material replacement / object
  placement via text directives" — nothing that matches any real NMS
  interface. Treat as SEO spam, not evidence.

## 2. Debug camera / free camera — Photo Mode *is* the debug camera

- NMS ships a built-in free camera: **Photo Mode** (quick menu → Camera
  icon; PC: `Z` for the menu). It detaches the camera, lets you float
  anywhere in real time, changes time of day, fog/cloud levels, and
  applies filters. Added in the Path Finder update
  (https://store.steampowered.com/news/posts/?feed=steam_community_announcements&appids=275850&enddate=1489762893).
- **Hidden options:** pressing Square/X while in Photo Mode reveals an
  options panel that the base UI doesn't advertise
  (https://www.gamesradar.com/no-mans-sky-hidden-mechanics/).
- Camera limits are data-driven in `GCCAMERAGLOBALS.GLOBAL.MBIN` — camera
  mods edit it (e.g. "Better Indoor Camera", 2018,
  https://videogamemods.com/nomanssky/mods/better-indoor-camera/).
- A Nexus mod **"Free Camera For Build And Photo"** removed the build
  camera's sphere limitation; it broke when Voyagers-era corvette
  mechanics changed build-camera rules, and players were hunting a new
  way to disable the limitation as of ~2026
  (https://steamcommunity.com/app/275850/discussions/4/604166953732469082).
  *Takeaway: the free-camera range is a tunable value, not a hardcoded
  debug switch.*
- In-ship free-look exists (Alt key on PC; limited degrees)
  (https://steamcommunity.com/app/275850/discussions/0/1744478429685098680/).

## 3. Launch flags / command-line arguments

- **No documented NMS-specific command-line flags were found.** Unlike
  Source-engine games, NMS has no `-console`, `-novid`-style catalog
  (the only such list surfaced was for Source games:
  https://community.pcgamingwiki.com/topic/4571-harmful-misconceptions-in-launch-options-and-console-commandsarguments-for-source-engine-based-games/).
- What the community actually puts in Steam launch options:
  - Environment variables, e.g. `PROTON_LOG=1 %command%` for Proton
    logging
    (https://steamcommunity.com/app/275850/discussions/0/1643167006262841468/?l=hungarian&ctp=2);
  - Vulkan layer overrides to spoof GPU vendor ID (2019 NVIDIA perf fix:
    `VK_LAYER_PATH=... VK_INSTANCE_LAYERS=... %command%`)
    (https://www.gamingonlinux.com/2019/08/hello-games-appear-to-be-keeping-an-eye-on-steam-play-with-no-mans-sky-temp-fix-needed-for-nvidia/page=1/).
- CPU affinity: players launch `NMS.exe` from the command line with
  restricted affinity then restore it at the menu to improve thread
  spread — proof the exe accepts plain launching, but the flag used
  is Windows', not NMS's
  (https://steamcommunity.com/app/275850/discussions/0/601907544254915641).
- **The real toggles live in `Binaries\SETTINGS\*.MXML`**, not on the
  command line: `TKGRAPHICSSETTINGS.MXML` (fullscreen, FOV, thread
  counts, `RemoveBaseBuildingRestrictions`, DLSS/Reflex options) and
  `GCMODSETTINGS.MXML` (`DisableAllMods`). Steam threads routinely have
  users paste these files for troubleshooting
  (https://steamcommunity.com/app/275850/discussions/0/601905246717975779).
- Mod enable/disable flag history:
  - Old: delete/rename `DISABLEMODS.TXT` in `GAMEDATA\PCBANKS` → game
    shows a "modded version" warning splash
    (https://steamcommunity.com/app/275850/discussions/1/154643795212172610?l=vietnamese);
  - Current (post-Worlds, Feb 2025): `GCMODSETTINGS.MXML` →
    `<Property name="DisableAllMods" value="false" />`, mods in
    `GAMEDATA\MODS` subfolders
    (https://steamcommunity.com/app/275850/discussions/0/797839485450684357,
    https://steamcommunity.com/app/275850/discussions/0/595139814470206422/).
- **Experimental branch** (not debug, but pre-release): Steam betas tab,
  code `3xperimental`
  (https://steamcommunity.com/app/275850/discussions/0/2941371547486129419/?l=japanese).

## 4. Hidden menus / debug UI

- **"Ambient" hidden game mode** — a leftover dev/tester mode in retail
  builds: Creative-like, no saving, lets you pick a starting planet
  from an Escape-key UI before spawning. Reached by editing a save's
  raw JSON version field to `6152` (Creative = 5128, Normal = 4616 at
  the time)
  (https://steamcommunity.com/app/275850/discussions/0/2860219962096854698/).
  *Speculation:* likely a Hello Games QA start-scouting tool. Its
  presence proves debug scaffolding ships in retail builds — there may
  be more undiscovered toggles.
- Mod-detection warning splash on load when mods are present
  (added by Hello Games, patch 1.12)
  (https://www.pcgamer.com/a-new-no-mans-sky-patch-addresses-problems-with-mods/).
- "Toggle game view" in the X quick menu (first/third person)
  (https://steamcommunity.com/app/275850/discussions/0/1744478429685098680/).
- **No other hidden menus documented.** The VelocityRa modding guide
  mentions "NMSE" for injecting code into the game
  (https://github.com/VelocityRa/NoMansSkyModdingGuide) — a lead,
  unverified here.

## 5. Console-adjacent: runtime hooking frameworks

These are the closest thing NMS has to a console — scriptable,
live hooks:

- **NMS.py** (thatbomberdev) — "a NMS hooking and modding framework
  built around pymem and cyminhook". Runs the game start-paused for
  better hook coverage, serves a log terminal on `127.0.0.1:6770`,
  and lets Python mods hook live functions
  (https://github.com/thatbomberdev/nms.py). Companion experiments
  repo: https://github.com/ThatBomberDev/NMS.py-Experiments
  ("quick hooks and tests … used to **debug** and recreate parts of
  No Man's Sky").
  *Caveat:* README install docs reference NMS 4.13 (Fractals, 2023) —
  may not track current builds. UNVERIFIED.
- **NoMansSky.Api** (gurrenm3) — "a C# modding API … made with
  Reloaded2". Hooks the game loop (per-frame `OnUpdate`), exposes
  get/set for Units, Nanites, Quicksilver, Health, Shield, complete
  control of all 20 global MBINs, and signature-scanning helpers
  (https://github.com/gurrenm3/NoMansSky.Api).

## 6. Save editors as debug-adjacent tools

- **goatfungus NMSSaveEditor** (Java, WORLDS-compatible;
  https://github.com/goatfungus/NMSSaveEditor) — debug-like powers:
  - Set Units / Nanites / Quicksilver; edit ship/multitool/exosuit/
    freighter stats **and seeds** (seed = identity); companions,
    settlements, milestones/reputation.
  - Inventories: **add items and tech directly** (choose specific item),
    clone, repair/recharge/refill, resize slots beyond vanilla limits
    (with "the game might BREAK" warning).
  - Toggle known technologies, products, **words, and glyphs**; account
    data and unlocks.
  - Delete/export/import multitools, ships, frigates; backup/restore
    base/freighter structures across systems and saves.
  - **Raw JSON editor** — the same capability used to unlock Ambient
    mode (§4).
- **NomNom** (zencq; https://github.com/zencq/NomNom) — "the most
  complete savegame editor": fast travel **to any system**, trigger
  space battles, manage fleets, edit currencies/stats/inventories,
  expedition + Twitch-drop rewards, knowledge/records editing,
  appearance editing, raw JSON editor, save-as-human-readable-JSON,
  cross-platform save transfer. Versioned to mirror game versions;
  auto-updates via libMBIN.
- Older **NMSSE** (nomansskymods.com) was the editor used for the
  Ambient-mode unlock (§4); superseded by the two above.

## 7. Developer commentary on the lack of a console

- **None found.** No interview, patch note, or Hello Games statement
  addressing "why no console" surfaced in this pass — searching Sean
  Murray/cheats interviews returned nothing relevant.
- The closest on-record posture: Hello Games "hasn't attempted to shut
  down" save editors
  (https://www.thegamer.com/no-mans-sky-save-editor-how-to-use-guide/).
  They built mod detection as a *warning screen*, not a ban system
  (https://www.pcgamer.com/a-new-no-mans-sky-patch-addresses-problems-with-mods/),
  and the cheat scene operates openly alongside shared-universe play.
- *Speculation:* NMS's custom engine, live-service shared universe,
  and console-first certification likely all push against a public
  console — but that's inference, not a cited statement.

---

## GameGPT implications

1. **There is no console to drive.** GameGPT cannot issue console
   commands — the voice layer must map to memory hooks (Cheat Engine
   style), save edits, or MBIN mod diffs. NMS.py/NoMansSky.Api are the
   nearest analogues to a console, but both are community reverse-
   engineering projects of uncertain freshness.
2. **Photo Mode is the debug camera proxy.** Anything "show me / look
   at X" can use the built-in free camera; its limits live in
   `GCCAMERAGLOBALS` tunables, not a debug switch.
3. **Debug scaffolding ships in retail builds** (Ambient mode proves
   it). More hidden toggles may exist — the weekly sweep should watch
   for new "hidden mode" threads and NMS.py/NoMansSky.Api activity.
4. **Settings MXML files are the only sanctioned tweak surface.**
   `TKGRAPHICSSETTINGS` / `GCMODSETTINGS` toggles are stable, safe,
   and read/writeable without hooks — prefer them where they cover the
   effect (e.g. `RemoveBaseBuildingRestrictions`).
5. **Save editors already own the "debug-like" powers** (teleport via
   coordinates/fast-travel, spawn items, unlock tech/words/glyphs).
   Don't rebuild what they do; GameGPT's unique value is *live*,
   voice-triggered effects (jetpack forever, instant refine, no
   sentinels).

*End. All UNVERIFIED research — confirm against the running game before
any GameGPT profile use.*
