# No Man's Sky — config & tuning files

Compiled 2026-09-18. Status: **RESEARCH ONLY / UNVERIFIED.** Nothing here
has been confirmed against the running game. Prose is minimal; every
claim carries its source URL. Companion files: `game-dossier.md`
(ecosystem), `modding-landscape.md` (toolchain, globals-as-mod-layer).

---

## 1. `Binaries/SETTINGS` — the user-editable config folder

Steam path: `...\steamapps\common\No Man's Sky\Binaries\SETTINGS\`. All
files are plain-text XML (MXML), editable in any text editor
(https://stepmodifications.org/wiki/NoMansSky:Game_Structure). A real
install listing (from a GitHub issue tree dump) shows four files:
`GCMODSETTINGS.MXML`, `GCUSERSETTINGSDATA.MXML`, `TKGAMESETTINGS.MXML`,
`TKGRAPHICSSETTINGS.MXML`
(https://github.com/valvesoftware/steam-for-linux/issues/12690).
VR users additionally get `TKGRAPHICSSETTINGS.VR`-style variants, which
can be deleted to regenerate defaults
(https://re-actor.net/no-mans-sky-vr-guide-to-fix-performance/).

Community convention: set a settings file **read-only after editing**,
or in-game changes overwrite your tweaks
(https://stepmodifications.org/wiki/NoMansSky:Game_Structure).

### 1a. TKGRAPHICSSETTINGS.MXML — graphics + extras

Template `TkGraphicsSettings`. Documented properties (1.5-era default
dump — newer builds bump `Version` to 9+ and add more fields; treat the
list as the floor, not the ceiling):

- `FoVOnFoot`, `FoVInShip` (float, default 75.0)
- `GenerationDetail` — maps to in-game "Planet Quality"; affects render
  distance per community guides
- `TextureStreamingEx` (Auto), `TexturePageSizeKb` (64)
- `NumHighThreads`, `NumLowThreads` (CPU thread counts)
- `ResolutionWidth`, `ResolutionHeight`, `UseScreenResolution`,
  `ResolutionScale`
- `MaxframeRate`, `VsyncEx` (On/Off), `GSync`
- `ShadowDetail`, `TextureDetail`, `TerrainQualityEx`,
  `ReflectionsQuality`, `AntiAliasingEx2`, `MotionBlurQuality`,
  `MotionBlurStrength`, `AnisotropyLevel`, `AmbientOcclusion`
- `Brightness`, `Monitor`, `FullScreen`, `Borderless`
- `RemoveBaseBuildingRestrictions`, `MouseClickSpeedMultiplier`,
  `UseTerrainTextureCache`, `ShowRequirementsWarnings`

Source for the property list:
https://gist.github.com/m-p-3/3597a7bd7c6ffbb1d91cb125580acb30.
Deleting the file resets graphics to defaults (a standard crash/fix
step)
(https://steamcommunity.com/app/275850/discussions/0/601905246717971518).

### 1b. TKGAMESETTINGS.MXML — key bindings

Holds **all** remappable controls, including ones hidden from the
in-game menus. Each action is a `GcInputActionMapping.xml` property with
an optional `RemappedKey` numeric value. Community example rebinding
`UI_Left`/`UI_Right` for a one-handed player:
https://steamcommunity.com/app/275850/discussions/0/1693788384137659209/?l=ukrainian.
A Hello Games developer confirmed on Steam that "not all keybindings
are shown in the options menu" and pointed users to this file
(https://steamcommunity.com/app/275850/discussions/2/1736595131054981273/).
Mouse buttons >3 bind via this file even when the in-game rebind menu
shows them as white diamonds
(https://steamcommunity.com/app/275850/discussions/0/2974027717615815194/?l=koreana).

### 1c. GCUSERSETTINGSDATA.MXML — settings + unlocks + catalog

Per the modding wiki: "main game settings and unlocked products and
items as seen in the catalog"
(https://stepmodifications.org/wiki/NoMansSky:Game_Structure). It also
holds shared catalog discoveries (every item discovered in any save —
back this file up with your saves for full progression)
(https://stepmodifications.org/wiki/NoMansSky:Game_Structure).
Community expedition-reward guides edit it **offline** to unlock missed
expedition/Twitch rewards (items up to expedition 8 era), then go
read-only or launch offline so the server doesn't revert
(https://steamcommunity.com/sharedfiles/filedetails/?l=norwegian&id=2511541099).
Related: `accountdata.hg` / `mf_accountdata.hg` in the per-user save
dir record Quicksilver purchases and account unlocks
(https://steamcommunity.com/app/275850/discussions/0/3814039097890666403/).

### 1d. GCMODSETTINGS.MXML — mod loading control

Post–Worlds Part II (5.50+), this file replaced DISABLEMODS.txt (see
§2). Contents:

- `<Property name="DisableAllMods" value="false" />` — global kill
  switch. **The game itself flips this to `true` after a crash when
  mods are installed** (not proof the crash was mod-caused), so "mods
  silently stopped loading" almost always means this line changed
  (https://steamcommunity.com/app/275850/discussions/0/797839485450684357,
  https://forums.nexusmods.com/topic/13511758-no-mans-sky-support-suggestion/).
- Per-mod `GcModSettingsInfo` entries with `Name`, `Author`, `ID`,
  `ModPriority`, `Enabled`, `EnabledVR`, `Dependencies` — real example
  (`MAXINVENTORYSIZE`) quoted in
  https://steamcommunity.com/app/275850/discussions/0/682986292645092512/?ctp=2.
- Conflict rule: lower `ModPriority` wins; applied in two stages —
  MBIN replacements first, then EXML patches on top
  (https://steamcommunity.com/app/275850/discussions/0/595139710753505669/).
- Deleting the file is the standard fix: it regenerates with defaults
  (`DisableAllMods=false`)
  (https://nomanssky.miraheze.org/wiki/Mods).
- Mod files now live in `No Man's Sky\GAMEDATA\MODS\<ModName>\` as
  **EXML or MBIN** (PAK is dead; MXML is not loaded except
  `LocTable.mxml`)
  (https://steamcommunity.com/app/275850/discussions/0/595139814470206422,
  https://nomanssky.fandom.com/wiki/Mods).

---

## 2. DISABLEMODS.txt — the old mod gate (deprecated)

Original mechanism (2016 patch 1.12): a file named `DISABLEMODS.TXT` in
`\GAMEDATA\PCBANKS` disabled all mods; deleting/renaming it enabled
them, with a mod-detection warning splash at boot
(https://www.pcgamer.com/a-new-no-mans-sky-patch-addresses-problems-with-mods/,
https://steamcommunity.com/app/275850/discussions/1/154643795212172610?l=english).
**As of NMS 5.50 (Worlds Part II, Jan 2025) DISABLEMODS.txt is no
longer used or recognized by the game**; enablement moved to
GCMODSETTINGS.MXML (§1d)
(https://steamcommunity.com/app/275850/discussions/0/601901034049213548).
Vestige: a 2025 player logfile still showed a failed load of
`...\AppData\Roaming\HelloGames\NMS\st_...\cache\DISABLEMODS`
(https://steamcommunity.com/app/275850/discussions/0/682986292645092512/?ctp=2)
— the engine still probes a cache path for it, but it no longer gates
mods.

---

## 3. GCDEBUGOPTIONS.GLOBAL — debug-adjacent globals (mod-only)

This is **not** a user config file. It is a shipped global data file
(template `cGcDebugOptions`) inside the game's data, editable only via
mods. The stepmodifications global-file index describes it as "Very
global game settings with a lot of impact on every game aspect"
(https://stepmodifications.org/wiki/NoMansSky:Reference_Guides/Global_Files).
Community-documented toggles in it:

- `DisableSaveSlotSorting` — flipped by the "Unsorted Saves" mod
  (https://github.com/monkeyman192/mbincompiler/issues/174).
- A profanity-filter boolean "fully hooked up, but not assigned to a
  menu option" — a mod flips it directly
  (https://github.com/azure-fang/no-man-s-sky-mods).
- Tutorial skip / faster boot: the "Training Skip / Quick Bootup" mod
  touches `GCDEBUGOPTIONS.GLOBAL.MBIN` plus `BOOTLOGOPC.MBIN` and
  `DEFAULTSAVEDATA*` (https://vgtimes.com/games/no-mans-sky/files/24154-training-skip.html).
- `HotReloadModGlobals` (a DebugOptions property): per the community
  "Modding after 5.58" doc, enabling it lets modders **hot-swap edited
  globals without restarting the game**; caveats — values locked while
  in use may not take, and some values can't be edited via hot swap at
  all
  (https://steamcommunity.com/app/275850/discussions/0/595139710753505669/).

⚠️ Caution: in March 2025 players reported that **mods containing
GCDEBUGOPTIONS broke save loading** (Hello Games shipped an
experimental fix for mod-induced corrupt game data), and the community
advised avoiding GCDEBUGOPTIONS mods at the time
(https://steamcommunity.com/app/275850/discussions/0/601899933994360035).
Treat it as the highest-impact, highest-risk global.

Reverse-engineering lead: the exe contains an in-game **debug options
UI** structure with categories `[01] Developer Cheats` … `[27]
Settlements` (incl. Screen, Startup, Game State, Graphics, Networking,
FrameRate, Base Building, Generation, Determinism) — found via IDA
string analysis in 2022, with no publicly known keybind to open it
(https://forums.atlas-65.com/t/no-mans-sky-mods/7590?page=7). Speculation:
Hello Games may keep QA tooling wired in production builds; whether any
of it is reachable is unknown.

---

## 4. Documented config-file tweaks (community inventory)

- **FOV beyond in-game limits** — `FoVOnFoot`/`FoVInShip` in
  TKGRAPHICSSETTINGS.MXML accept values above the in-game max (120).
  Community norm is 140–160; one Worlds Part II guide notes the in-game
  max of 120 "feels like ~70" and runs 160 before the ship cockpit
  looks wrong
  (https://gist.github.com/chopstix2594/8ab1ba4541ac5e5184d784c1c93b87e6,
  https://videogamemods.com/nomanssky/mods/fov-adjustment-beyond-100/).
  In-game graphics changes reset the FOV back; set read-only or re-edit
  (https://steamcommunity.com/app/275850/discussions/0/360672137536127096/?l=portuguese).
- **Vignette / scanlines** — now an in-game toggle: Options > Camera >
  Comfort ("vignette and scanlines" setting)
  (https://steamcommunity.com/app/275850/discussions/1/601914519534767710).
  Historically also editable via a graphics-file switch (exact name
  unverified — a 2020 thread mentions setting a scan/vignette key to
  false)
  (https://steamcommunity.com/app/275850/discussions/0/2254559285375182485/?l=german&ctp=1).
- **Chromatic aberration** — no documented config-file switch found.
  Only removal path on record is mods (Celestaux's NEXT-era mod with
  four variants: CA+scanlines+vignette combos)
  (https://www.dsogaming.com/news/this-mod-removes-the-chromatic-aberration-scanlines-and-vignette-effects-from-no-mans-sky-next/).
  The visual-overlays data-side knob is in `GCGRAPHICSGLOBALS.GLOBAL`
  ("light, shadows, DOF blur, vignette effects")
  (https://stepmodifications.org/wiki/NoMansSky:Reference_Guides/Global_Files)
  — mod territory, not config.
- **Physics-adjacent settings** — no physics keys exist in the SETTINGS
  MXML files. Movement feel (jetpack fill/drain, speeds, force, height
  caps) lives in `GCPLAYERGLOBALS` / `GCCHARACTERGLOBALS` /
  `GCSPACESHIPGLOBALS` and is edited by mods
  (https://steamcommunity.com/app/275850/discussions/0/737034982498784595,
  https://stepmodifications.org/wiki/NoMansSky:Reference_Guides/Global_Files).
- **Mouse smoothing** — in-game mouse-smoothing options exist, but no
  documented config-file key was found; the only mouse-related
  graphics-config key on record is the older `MouseClickSpeedMultiplier`
  (https://steamcommunity.com/app/275850/discussions/1/601907675997959229).
- **Network settings** — no user-facing network keys in the SETTINGS
  files found. Network tuning is data-side: `GCATLASGLOBALS.GLOBAL`
  ("Some Network Settings") and `GCMULTIPLAYERGLOBALS.GLOBAL`
  ("Multiplayer and connection settings")
  (https://stepmodifications.org/wiki/NoMansSky:Reference_Guides/Global_Files)
  — mod territory.
- **Thread counts / custom resolution / FPS cap** — `NumHighThreads`,
  `NumLowThreads`, custom `ResolutionWidth`/`ResolutionHeight`,
  `MaxframeRate` in TKGRAPHICSSETTINGS.MXML are documented community
  tweaks for post-update performance recovery
  (https://steamcommunity.com/app/275850/discussions/0/3826424631144988875/?l=brazilian&ctp=8).

---

## 5. Other MXML/JSON-adjacent files in install & save dirs

- **Save dir**: `%AppData%\HelloGames\NMS\st_<SteamID>\` holds
  `save*.hg`, `accountdata.hg`, `mf_accountdata.hg`, and a `cache\`
  subfolder (DDS/texture caches; also probed for a vestigial
  `DISABLEMODS` entry) — save layout detail in `game-dossier.md` §3.
- **GAMEDATA\SHADERCACHE** — shader caches; clearing is a documented
  perf fix but is cache management, not tuning
  (https://steamcommunity.com/app/275850/discussions/1/601914224408663911).
- **HDR `.cube` LUT files** in the install are plain text and editable
  per the modding wiki
  (https://stepmodifications.org/wiki/NoMansSky:Game_Structure) — niche,
  not gameplay tuning.
- **No other user-facing JSON/MXML gameplay-tuning config found** in
  the install or save dirs. Gameplay tuning is data-side (globals,
  tables, defaults) reached via mods — see `modding-landscape.md`.

---

## 6. GameGPT implications

1. **FOV is the one voice-command-grade config tweak.** "Widen my FOV"
   = edit `FoVOnFoot`/`FoVInShip` in TKGRAPHICSSETTINGS.MXML (values
   140–160), read-only to keep it. Unverified: whether it needs a
   restart or takes effect on settings reload.
2. **Mod on/off is file-togglable.** `DisableAllMods` in
   GCMODSETTINGS.MXML is a plain boolean — a "turn mods off" voice
   command could flip it (and per-mod `Enabled` flags). Caveat: the
   game auto-sets it true after crashes, so toggling must be
   idempotent and logged. Unverified against a live install.
3. **Key rebinding is config-layer.** TKGAMESETTINGS.MXML covers
   bindings the in-game UI hides (including mouse buttons >3) — relevant
   if GameGPT ever needs to synthesize inputs for actions the UI won't
   bind.
4. **The live tuning loop is `HotReloadModGlobals` + EXML patch mods.**
   Once enabled (via a GCDEBUGOPTIONS mod), global tweaks hot-apply
   without restart — this is the config-adjacent mechanism closest to
   "live" tuning, but it requires the modding pipeline
   (MBINCompiler/AMUMSS) and carries the GCDEBUGOPTIONS corruption risk
   above. Speculation: a GameGPT "tune jetpack live" feature would sit
   here, not in config files.
5. **Physics/movement, network, and visual overlays are mod-layer, not
   config-layer.** GameGPT voice effects like "jetpack forever" can't
   be done by editing SETTINGS files — they need EXML/MBIN mods or
   live memory hooks, consistent with the dossier's three-layer model.

*End of notes. UNVERIFIED research — confirm against the running game
before any GameGPT profile use.*
