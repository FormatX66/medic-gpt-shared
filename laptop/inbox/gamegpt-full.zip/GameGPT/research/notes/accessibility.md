# No Man's Sky — accessibility & difficulty systems (2026-09-18)

Status: RESEARCH ONLY / UNVERIFIED. Nothing below is confirmed against the
running game. Companion files: `game-dossier.md` (full research), `best-cheats.md`.

Thesis: NMS's difficulty system *is* the cheat vector. Custom difficulty
(adjustable mid-save) and Creative Mode cover most of `best-cheats.md`'s
fun list legitimately — no memory work needed.

## 1. Custom difficulty settings — the full list

Source: NMS wiki "Game mode", current as of Voyagers update (Oct 21, 2025) —
https://nomanssky.fandom.com/wiki/Game_mode
Accessible in-game: Esc → Options → Difficulty. Adjustable at any time on
existing saves (Waypoint update onward).
https://www.rockpapershotgun.com/no-mans-sky-focuses-on-customising-and-accessibility-in-its-relaxed-waypoint-40-update
Settings can be irreversibly locked per save via "Difficulty Setting Changes"
at the bottom of the list.
https://steamcommunity.com/app/275850/discussions/0/4625854789815689294/
Non-Custom saves that don't match a preset are treated as Custom.
https://nomanssky.fandom.com/wiki/Game_mode

### Survival Settings
- **Survival Elements** — None / Health Only / Hazards & Health / Full
  (whether life support + hazard protection need managing)
- **Survival Difficulty** — Relaxed (~0.33x drain) / Standard (1x) / Challenging (3x drain)
- **Natural Resources** — Abundant (2x yield) / Standard (1x) / Scarce (0.5x)
  (base mining beam: 4/2/1 units per tick on Abundant/Standard/Scarce)
- **Sprinting** — Infinite / Relaxed (stamina only, no life-support drain) / Standard
- **Scanner Recharge** — Very Fast (5x) / Fast (3x) / Standard (1x) / Challenging (0.2x)
- **Damage Levels** — None / Minimal / Standard / Challenging
  (damage the *player takes*; there is **no "damage dealt" slider** — one-shot kills stay memory-side)
- **Technology Damage** — None / Minimal / Challenging (chance tech breaks when hit)
- **Death Consequences** — No Item Loss / Standard (recoverable grave) / Items Destroyed / Save Deleted (permadeath)
- **Fishing Timing** — includes **Auto-Catch**: at the easiest setting no input
  needed beyond casting; harder = slower/more demanding.
  https://steamcommunity.com/app/275850/discussions/0/660467026274449977
  https://nomanssky.fandom.com/wiki/Fishing
  (Not on the wiki's Game-mode page — post-Aquarius addition, community-documented only.)

### Crafting and Items Settings
- **Fuel Usage** — Free / Discounted (0.375x) / Standard (1x) / Expensive (1.5x)
  — covers mining laser, terrain manipulator, and *ammo* (free use in Relaxed-style setups);
  still not "no overheat", which is a separate throttle
- **Crafting** — Free / Standard (the "free build mode" voice trigger, no memory needed)
- **Recipes and Blueprints** — All Unlocked / Learnable (save-creation only)
- **Purchases** — Free / Discounted / Standard / Expensive
  (microprocessors: 10,500 / 27,500 / 104,000 Units; upgrade prices 80% / 100% / ~167%)
- **Availability** — Abundant / Standard / Scarce (shop stock range)
- **Inventory Stack Limits** — Standard / Restricted / Harsh
  (exosuit cargo slot: 9999 / 500 / 300 of a resource; Harsh products ~30% of Standard.
  On existing saves you can only *raise* stack limits, never lower them.
  There is **no above-Standard option** — maxed stacks stay save/memory-side.)

### Combat Settings
- **Enemy Strength** — Weak / Standard / Challenging (enemy *health* only)
- **On-Foot Combat** — None / Minimal / Standard / Hostile (frequency of ground combat)
- **Space Combat** — None / Minimal / Standard / Hostile
- **Creatures** — Passive (never attack) / Defensive / Predators On

### Ease of Use
- **Tutorial Missions** — Enabled / Disabled (save-creation only)
- **Inventory Transfer Range** — Infinite / Nearby (ship/freighter always in reach)
- **Hyperdrive System Access** — Unrestricted / Specialised (warp-drive requirements)
- **Base Power** — Free / Standard (bases need no power)
- **Reputation & Standing Gain** — Very Fast (5x) / Fast (2x) / Standard / Challenging
- **Starting Slots** — Maximum / Standard (squadron/companion slots, save-creation only)

Permadeath lockout: when Death Consequences = Save Deleted, only the **bold**
subset above stays editable — notably: Survival Elements, Survival Difficulty,
Natural Resources, Sprinting, Scanner Recharge, Damage Levels, Technology
Damage, Death Consequences, Fuel Usage, Purchases, Availability, Inventory
Stack Limits, Enemy Strength, On-Foot Combat, Space Combat, Reputation Gain,
Starting Slots, Tutorial Missions.
https://nomanssky.fandom.com/wiki/Game_mode
Caniplaythat counts 24 settings in 4 categories; Fishing Timing makes 25.
https://caniplaythat.com/2022/10/10/no-mans-sky-titled-update-sets-waypoint-for-accessibility/

## 2. Creative Mode — the first-class god mode

Source: https://nomanssky.fandom.com/wiki/Game_mode
- All blueprints + construction parts unlocked from the start.
- Crafting and building free; most material usage in dialogue/repairs free
  (some quests still require real items).
- Rechargeable tech (engines, mining beam, etc.) recharged by clicking it —
  fuel costs gone.
- Shields, hazard protection, life support, oxygen **never run out**.
- Sentinels and hostile fauna **do not appear** (except scripted cases).
- Death is impossible (comparison table: Death → "Impossible", Costs → "None",
  Resources → "Infinite").
- Story, black holes, bases, exocraft, freighters all work — the *full* game
  except survival pressure.
- **Trophies/achievements do not unlock** — the one cost of the mode.
  https://www.techradar.com/news/heres-everything-included-in-the-massive-no-mans-sky-update

vs. survival-with-cheats (dossier §6's frame): Creative gives everything
except *time deletion*. It cannot do: instant refiner completion, instant
mining/portal/interaction, speed multipliers, no-tech-overload installs,
instant construction, above-Standard stack sizes. Those remain memory/save
territory.

## 3. Accessibility settings (Options → Accessibility)

Known entries (community-documented; **no single authoritative list found** —
the fandom Accessibility page could not be fetched 2026-09-18):
- **Hazard Effects** slider — default 100%, min 35%, max 130%. Reduces weather
  visual effects.
  https://steamcommunity.com/app/275850/discussions/0/660467026274449977
- **Galaxy Map Color Filter** — multiple colorblind filters for star colors
  (community says 3–4 options).
  https://steamcommunity.com/app/275850/discussions/0/601909079150998855
- **Screen shake** slider — 0–10; setting to 0 kills it; added ~Sentinel 3.8.
  https://steamcommunity.com/app/275850/discussions/0/4300317773578093031/?l=vietnamese&ctp=3
- **UI-transition screen flashes** — toggle in Accessibility tab (bright white
  flashes during UI transitions can be disabled).
  https://steamcommunity.com/app/275850/discussions/0/694248493352604251
- **HUD Scale** (pre-existing) + **menu text enlargement** (4.10, readability at distance).
  https://nomanssky.fandom.com/wiki/Update_4.10
- **Analysis Visor auto-scan** (4.10) — fauna/flora/minerals auto-scan when
  centered, no second button press.
  https://nomanssky.fandom.com/wiki/Update_4.10
- **Third-person camera**: auto-rotation can be disabled (manual camera
  control); character can be shown on right side of screen (left-hand
  multi-tool) (both 4.10).
  https://nomanssky.fandom.com/wiki/Update_4.10
- **Quick charge** (4.10) — refiners/base parts fully refuelled with one press.
  https://nomanssky.fandom.com/wiki/Update_4.10
- **Warp/loading screens** redesigned to be friendlier for vertigo/seizures;
  damage flashes kept intentionally as visual cues for deaf players.
  https://steamcommunity.com/app/275850/discussions/0/4300317773578093031/?l=vietnamese&ctp=3
- Console: **Custom Button Assignments** under Accessibility (platform feature).
  https://whatculture.com/gaming/no-man-39-s-sky-16-things-you-didn-39-t-know-you-could-do?page=11
- **Bait-box fishing-line colour** customizable (colorblind help for fishing).
  https://steamcommunity.com/app/275850/discussions/0/660467026274449977

### Not found (marked gaps)
- **Aim assist strength**: NMS has built-in auto-aim (analysis-visor lock-on,
  space-combat aim) but **no user-facing strength slider found**. A Dec 2025
  Steam thread explicitly calls adjustable aim assist "a missing accessibility
  option", and the suggested workaround is a mod that *removes* auto-aim.
  https://steamcommunity.com/app/275850/discussions/0/694247829077495848
  https://www.dsogaming.com/news/this-no-mans-sky-mod-completely-disables-auto-aim-allowing-for-more-challenging-gunplay/
  Auto-aim described in https://www.vg247.com/no-mans-sky-tips
- **Auto-follow**: no such option found. Closest match is the 4.10
  third-person camera auto-rotation toggle.
- **Time-scale / slowdown**: no official slow-motion or time-scale assist
  found. (Speculation: nothing in difficulty or accessibility menus covers
  this; the closest legitimate time-skip is Creative/Crafting: Free.)

## 4. Where settings live

- **Graphics/visual settings**: `TKGRAPHICSSETTINGS.MXML` in
  `<Steam>/steamapps/common/No Man's Sky/Binaries/SETTINGS/`. Deleting it
  resets to defaults — documented fix path in support threads.
  https://steamcommunity.com/app/275850/discussions/0/757303296993008786
  https://www.rockpapershotgun.com/no-mans-sky-fixes-and-workarounds
  (Graphics-only — difficulty/accessibility not confirmed in this file.)
- **Difficulty settings**: per-save. Esc → Options → Difficulty shows the
  active set for the current save; save editors can read/change them (used to
  bypass the "Difficulty Setting Changes" lock).
  https://steamcommunity.com/app/275850/discussions/0/4625854789815689294/
  (Exact save-JSON key not confirmed from these sources — speculation: stored
  alongside the save's GameMode ident.)
- **Game mode itself**: historically a "Version" number at the top of the raw
  save JSON (e.g. NEXT-era: normal 4626 / creative 5138 / survival 5650 /
  permadeath 6664) — 2018-era thread; current format versions are 2001–2004
  (dossier §3a). Current-era numbers unverified.
  https://steamcommunity.com/app/275850/discussions/0/1736588252417810625/?l=tchinese

## 5. best-cheats.md mapping: legitimate settings vs. real memory/save work

**Achievable purely through legitimate settings** (Custom difficulty /
Creative Mode — no memory or save editing):
- Unlimited sprint → Sprinting: Infinite
- Free crafting / free building → Crafting: Free
- Free purchases, cheaper upgrades → Purchases: Free/Discounted
- No fuel costs (launch thruster, pulse engine, mining laser, terrain
  manipulator, **ammo**) → Fuel Usage: Free
- No sentinels / no combat / passive creatures → On-Foot Combat: None,
  Space Combat: None, Creatures: Passive (or Creative Mode, which removes
  them entirely)
- No damage, no tech breakage → Damage Levels: None, Technology Damage: None
- No death penalty → Death Consequences: No Item Loss (or Creative: impossible)
- Fast scanning → Scanner Recharge: Very Fast (5x)
- Faster faction standing → Reputation & Standing Gain: Very Fast (5x)
  (direct set-to-99 still needs save edit — dossier §1a)
- Infinite inventory reach → Inventory Transfer Range: Infinite
- No base power management → Base Power: Free
- Unrestricted warping → Hyperdrive System Access: Unrestricted
- Auto-catch fishing → Fishing Timing: Auto-Catch
- Easier combat (but not one-shot) → Enemy Strength: Weak
- Everything at once → Creative Mode (free build/craft/recharge, infinite
  survival stats, no sentinels, full story) — cost: no achievements

**Still need memory/save work** (no difficulty or accessibility setting covers):
- Unlimited jetpack / infinite stamina drain-rate override beyond Sprinting: Infinite
- No mining-laser **overheat** (Fuel Usage: Free removes cost, not heat)
- Instant refiner finish / refiner consumes nothing
- Instant mining, instant interactions, instant portal activation
- Speed multipliers (ship / pulse / jetpack / walk-run)
- No technology overloads (unlimited tech installs per inventory)
- Corvette building unlocks (all parts, remove finalization/invalid-build)
- Settlement instant construction completion
- Stack sizes above Standard limits
- Infinite / editable Units, Nanites, Quicksilver
- Decode-all-words / all blueprints beyond save-creation unlock
- Bypass Atlas locks
- One-shot kills (no "damage dealt" slider)

**Partial coverage** (legitimate setting gets partway, save/memory finishes):
- Infinite Units → Purchases: Free removes the *need* for units in most cases;
  the number itself still needs a save edit
- Max inventory → stacks capped at Standard legitimately; beyond that is save/memory
- Free ammo → Fuel Usage: Free (ammo), but no-reload/no-overheat is memory

*End. All UNVERIFIED — confirm against the running game before GameGPT use.*
