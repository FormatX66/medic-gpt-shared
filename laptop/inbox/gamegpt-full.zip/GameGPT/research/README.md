# GameGPT research catalog

Recurring sweep target: cheat tables and community knowledge for the
GameGPT game list, cataloged as research material for profile building.

## Game list (2026-09-17, per Bruce)

- no-mans-sky — No Man's Sky (Tier 2 live target)
- joe-danger — Joe Danger (Hello Games)
- joe-danger-2 — Joe Danger 2 (Hello Games)
- the-last-campfire — The Last Campfire (Hello Games)
- light-no-fire — Light No Fire (Hello Games, unreleased — placeholder)

Scope: other games by the same studio, and games on the same engine
(NMS runs Hello Games' proprietary engine, so this is the Hello Games catalog).

## Layout per game

- `tables/` — downloaded .CT files, kept with provenance (source URL, author,
  table date, game version). Inert research: never executed.
- `parsed/` — machine-readable extraction (entries, types, pointer chains,
  offsets, AOB patterns), every address marked UNVERIFIED until a
  Bruce-authorized live read confirms it.
- `notes/` — "best cheats" research: which cheats actually make the game fun,
  from table contents + community signal + game knowledge.

## Rules

- Imported tables are research maps, not trusted coordinates.
- No Lua/AA in tables is ever executed — XML parsed only.
- Nothing here is a GameGPT profile until separately reviewed and translated
  into guarded profiles.
