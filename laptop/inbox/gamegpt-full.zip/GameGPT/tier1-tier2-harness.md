# GameGPT Tier 1 + Tier 2 Actuator Test Harness — Ensemble Design (2026-09-12)

**Pipeline:** GPT (spec) → Gemini (harness design) → Claude (safety review). Design-only; nothing built, no live games touched.
**Source of truth:** FormatX66/GameGPT — `ApplicationService.prepare_write`/`confirm_write` (src/gtp_games/service.py), `SimulatedMemoryBackend` (src/gtp_games/memory/simulated.py), existing `tests/test_writes.py`.
**Claude's verdict: PASS WITH CHANGES** — no safety-line failures, no scope creep into scan/UI/networking. 3 required spec changes + 7 required design changes (A–G) listed in the review below; all are refinements, none block the design's approach. Note: Claude's review text ends mid-example (truncated at the seed-matrix snippet); all findings are complete.

**Adjudication notes (Medic):**
- Claude's required change D (HMAC-SHA256 phrase derivation) reaches into the *actuator*, not the harness — the current code uses `secrets.compare_digest` on an existing phrase scheme. The harness can only assert behavioral properties (wrong phrase fails; comparison is constant-time). Mandating a new derivation scheme is an actuator-owner decision for Bruce, not a harness build requirement.
- Claude references `backend.is_live_process()` and `read_bytes`/`write_bytes` method names that do not exist in the current codebase (real API: `read(handle, address, size)` / `write(handle, address, data)`). The builder must map the interlock and rigged backends onto the real `MemoryBackend` interface; if `is_live_process()` is needed, it must be added to the harness's own backend wrappers, never assumed on production backends.
- Issue C resolution: adopt Claude's option 2 — keep `FlappingMemoryBackend` and add injection case 3.9 (concurrent mutation between prepare and confirm), since race-safety is squarely in the guarded-write spirit.

---

---

## (a) Spec — GPT (gpt-4o-mini)

# GameGPT Actuator Test Harness Specification

## Overview
This specification outlines the requirements for a test harness designed to validate the functionality of the GameGPT actuator's write path. The harness is divided into two tiers: Tier 1 focuses on synthetic memory buffers using the SimulatedMemoryBackend, while Tier 2 examines the actuator's behavior against an offline save snapshot. The tests will ensure compliance with the guarded-write rules and verify that the actuator operates correctly under various conditions.

## TIER 1: Synthetic Memory Buffers

### 1. Fixture Layouts
1.1 **Seeded Buffer Contents**: 
   - A deterministic 4096-byte buffer initialized with known values at fixed offsets (e.g., health, ammo, coins).
   - Use a seeded random number generator (RNG) to ensure consistent buffer contents across test runs.

### 2. Assertion List per Rule
2.1 **Fresh Pre-read Verification**:
   - Before every write, a fresh pre-read must be performed and compared to `expected_current`.
   - **Assertion**: The pre-read value must match `expected_current`.

2.2 **Expected Current Mismatch Blocking**:
   - If `expected_current` does not match the pre-read value, the write must be blocked.
   - **Assertion**: The write operation raises a `SafetyError` on mismatch.

2.3 **Readback Verification**:
   - After a successful write, the readback value must be compared to `new_value`.
   - **Assertion**: The readback value must match `new_value`; divergence fails the test.

2.4 **Originals Preservation**:
   - Pre-write bytes must be recorded and recoverable.
   - **Assertion**: Memory must remain untouched after a failed write attempt.

2.5 **Confirmation Phrase Enforcement**:
   - The confirmation phrase must be validated during the confirm step.
   - **Assertion**: A write operation fails if the wrong phrase is provided.

2.6 **Expiry Enforcement**:
   - The intent must expire after a defined duration.
   - **Assertion**: A write operation fails if the intent is expired.

2.7 **Single-use Intent Enforcement**:
   - Each intent must be single-use; re-confirming the same intent must fail.
   - **Assertion**: A write operation fails if the intent is reused.

2.8 **Read-only Attach Prevention**:
   - Attaching in read-only mode must prevent write operations.
   - **Assertion**: A write operation raises a `SafetyError` when attached read-only.

### 3. Failure Injection Cases
3.1 **Stale Pre-read Injection**:
   - Inject a stale value between prepare and confirm.
   - **Assertion**: The write operation fails due to expected_current mismatch.

3.2 **Mismatched Expected Current**:
   - Use a pre-read value that does not match `expected_current`.
   - **Assertion**: The write operation fails.

3.3 **Readback Divergence**:
   - Rig the backend to return a value different from `new_value` after write.
   - **Assertion**: The test fails due to readback divergence.

3.4 **Expired Intent**:
   - Confirm an intent after its expiry.
   - **Assertion**: The write operation fails.

3.5 **Reused Intent**:
   - Attempt to confirm the same intent multiple times.
   - **Assertion**: The write operation fails.

3.6 **Wrong Phrase**:
   - Provide an incorrect confirmation phrase during the confirm step.
   - **Assertion**: The write operation fails.

3.7 **Read-only Write Attempt**:
   - Attempt to write while attached in read-only mode.
   - **Assertion**: The write operation raises a `SafetyError`.

3.8 **Address/Type Drift via Profile Re-resolution**:
   - Simulate a scenario where the address/type has changed after preparation.
   - **Assertion**: The write operation fails due to profile re-resolution.

### 4. Determinism Requirements
4.1 **Seeded RNG**: 
   - All tests must use a seeded RNG to ensure consistent results.

4.2 **Wall-clock Control**:
   - Use an injectable clock for managing expiry times to maintain determinism.

### 5. Pass/Fail Criteria
5.1 **Pass Criteria**:
   - All assertions must pass without exceptions.
   - Evidence artifacts (write receipts, audit log entries) must be generated for each test.

5.2 **Fail Criteria**:
   - Any assertion failure results in a test failure.
   - Evidence artifacts must indicate the nature of the failure.

### 6. Evidence Artifacts
6.1 **Write Receipts**: 
   - Each successful write must produce a receipt documenting the operation.

6.2 **Audit Log Entries**: 
   - Each test must generate an audit log entry detailing the operations performed and their outcomes.

## TIER 2: Offline Save Snapshot

### 1. Snapshot Handling
1.1 **Snapshot Copying**:
   - A save file must be copied to a scratch directory for testing.
   - **Assertion**: SHA-256 of the original save file must be recorded before and re-verified after testing to ensure it remains untouched.

### 2. NMS-style Paired Saves
2.1 **Paired Save Editing**:
   - Both auto and manual saves must be edited together with the identical guarded edit.
   - **Assertion**: Both saves must read back byte-identical at the edited offsets.

### 3. Byte-level Readback Comparison
3.1 **Edited Offset Comparison**:
   - Perform a byte-level comparison of every edited offset in both saves.
   - **Assertion**: All edited offsets must match between the auto and manual saves.

### 4. Pass Criteria and Evidence Artifacts
4.1 **Pass Criteria**:
   - All assertions must pass without exceptions.
   - Evidence artifacts must confirm the integrity of the original save and the correctness of the edits.

4.2 **Evidence Artifacts**:
   - SHA-256 hashes of the original and modified saves.
   - Detailed logs of the editing process and results of the byte-level comparisons.

## Constraints
- **Design-only**: No live game process is permitted in either Tier 1 or Tier 2.
- **Skyrim Exclusion**: No references to Skyrim values, addresses, or scenarios.
- **Quarantine Lane**: Observer-based tests must be marked as quarantined and never run by default, without reactivating or relying on observers.

## Conclusion
This specification provides a comprehensive framework for testing the GameGPT actuator's write path, ensuring compliance with the guarded-write rules and maintaining the integrity of the memory and save files. Each requirement is designed to be testable, with clear pass/fail criteria and evidence artifacts to support the testing process.
---

## (b) Harness Design — Gemini (gemini-flash-latest)

# GameGPT Actuator Test Harness Architecture & Implementation Design

## 1. Module & File Layout

The harness extends the existing test suite under `tests/` without modifying core production code. All scratch artifacts, state snapshots, and logs are routed to an ignored scratch path (`.gtp_scratch/`).

```text
tests/
├── conftest.py                             # Root fixtures, markers registration, CLI flags
├── harness/
│   ├── __init__.py
│   ├── artifacts.py                        # Write receipts, audit log recorder, manifest writer
│   ├── clock.py                            # Deterministic injectable monotonic clock
│   ├── rigged_backends.py                  # Fault-injecting simulated backends
│   └── save_synthetic.py                   # NMS-style paired save binary generator & verifier
├── test_guarded_harness_tier1.py           # Tier 1: Synthetic memory buffer actuator tests
├── test_guarded_harness_tier2.py           # Tier 2: Offline paired save-file actuator tests
└── test_guarded_quarantine.py              # Quarantined observer tests (skipped by default)
```

### Module Responsibilities
* **`tests/conftest.py`**: Registers the custom `quarantine` marker, adds the `--run-quarantine` CLI option, and configures the default exclusion hook.
* **`tests/harness/clock.py`**: Provides `InjectableClock`, a deterministic time source replacing `time.monotonic` / `time.time` in `ApplicationService`.
* **`tests/harness/rigged_backends.py`**: Subclasses `SimulatedMemoryBackend` to inject readback discrepancies, values that mutate between prepare and confirm, and simulated read-only lockups.
* **`tests/harness/save_synthetic.py`**: Generates synthetic, deterministic binary save files mimicking NMS container structures (`save.hg` [auto] and `save2.hg` [manual]), with header checksums and data slots. Computes and checks SHA-256 manifests.
* **`tests/harness/artifacts.py`**: Provides a context-managed evidence recorder emitting structured JSON receipts, NDJSON audit streams, and binary diffs.
* **`tests/test_guarded_harness_tier1.py`**: Contains test cases covering all Tier 1 requirements (spec sections 2.1–2.8 and failure injections 3.1–3.8).
* **`tests/test_guarded_harness_tier2.py`**: Tests paired-save write mirror enforcement, byte-level readbacks, and unedited byte immutability.
* **`tests/test_guarded_quarantine.py`**: Isolates hardware-breakpoint memory-observer test fixtures.

---

## 2. Fixture Architecture

### 2.1 Deterministic Seeded Buffer Factory (`seeded_simulated_backend`)
Generates a `SimulatedMemoryBackend` instance with an exact 4096-byte memory space populated via `random.Random(seed)`.
* **Memory Map Standard (NMS-style inventory / stats; no Skyrim variables):**
  * `0x0100`: `health` (uint32, default: `100`)
  * `0x0104`: `units` (uint32, default: `50000`)
  * `0x0108`: `nanites` (uint32, default: `1200`)
  * `0x010C`: `hazard_protection` (float32, default: `100.0`)
  * Remaining bytes from `0x0000` to `0x0FFF` (excluding defined slots) filled with pseudo-random noise derived from the seed to catch boundary overruns.

### 2.2 Rigged Memory Backends (`rigged_backends.py`)
1. **`ReadbackDivergentBackend(SimulatedMemoryBackend)`**:
   * Accepts a `diverge_on_address: int` parameter.
   * `write_bytes()` updates internal memory, but subsequent `read_bytes()` on that address masks or shifts bits (e.g., inverts bit 0) to simulate hardware readback failure or silent write dropping.
2. **`FlappingMemoryBackend(SimulatedMemoryBackend)`**:
   * Emulates a racing game thread.
   * Alternates values at a targeted offset on every Nth read or automatically mutates the value immediately after `read_bytes()` is called.

### 2.3 Injectable Clock (`InjectableClock`)
* Replaces system time inside `ApplicationService` during testing.
* Interface:
  * `get_time() -> float`: Returns current frozen virtual timestamp.
  * `advance(seconds: float)`: Advances virtual timestamp.
* Defaults to `epoch = 1700000000.0`.

### 2.4 NMS-Style Paired-Save Fixture (`paired_save_fixture`)
* Constructs an isolated scratch directory containing:
  * `save.hg` (Synthetic Slot 1: Auto-save)
  * `save2.hg` (Synthetic Slot 2: Manual save)
* **Binary Layout**:
  * 16-byte header: `MAGIC (4B: 0x4E4D5332)` | `VERSION (4B: uint32)` | `DATA_LEN (4B: uint32)` | `HEADER_CHECKSUM (4B: uint32 CRC32)`.
  * Body: Serialized payload containing game stat blocks (`units`, `nanites`, `seed`).
* **Manifest Mechanics**:
  * Captures pre-run SHA-256 of `save.hg` and `save2.hg` into an immutable `SaveManifest`.
  * After actuator execution, computes post-run SHA-256 and provides a delta report.

---

## 3. Failure Injection Cases & Concrete Assertions

| Spec ID | Injection Mechanism | Target / Action | Expected Assertion (`SafetyError`) | Captured Artifact |
| :--- | :--- | :--- | :--- | :--- |
| **3.1 Stale Pre-read** | Call `service.prepare_write(...)` → manually mutate backend with `backend.set_named_value("units", 99999)` → call `service.confirm_write(...)`. | Confirm step. | `pytest.raises(SafetyError, match=r"(?i)pre-read mismatch\|stale")` | `receipt_rejection.json` with `stale_pre_read` code and mismatched values. |
| **3.2 Mismatched Expected Current** | Call `service.prepare_write(target="units", expected_current=1234, new_value=5000)`. | Prepare step. | `pytest.raises(SafetyError, match=r"(?i)expected current mismatch")` | Audit log entry detailing caller assertion failure. |
| **3.3 Readback Divergence** | Instantiate `ReadbackDivergentBackend` targeting offset `0x0104`. Execute normal prepare & confirm. | Confirm step. | `pytest.raises(SafetyError, match=r"(?i)readback verification failed\|divergence")` | Divergence report with `written_bytes` vs `readback_bytes`. |
| **3.4 Expired Intent** | Call `service.prepare_write(...)` → call `clock.advance(service.intent_ttl + 1.0)` → call `service.confirm_write(...)`. | Confirm step. | `pytest.raises(SafetyError, match=r"(?i)intent expired")` | Audit event logging token expiration timestamp vs invocation timestamp. |
| **3.5 Reused Intent** | Call `prepare_write(...)` → `confirm_write(...)` (succeeds) → call `confirm_write(...)` with same intent ID again. | Second confirm step. | `pytest.raises(SafetyError, match=r"(?i)intent already consumed\|invalid intent")` | Replay-attack audit warning artifact. |
| **3.6 Wrong Phrase** | Call `prepare_write(...)` → call `confirm_write(intent_id, phrase="INVALID_CONFIRM_TOKEN")`. | Confirm step. | `pytest.raises(SafetyError, match=r"(?i)invalid confirmation phrase")` | Audit failure log showing rejected phrase attempt. |
| **3.7 Read-only Write Attempt** | Initialize backend with `read_only=True` (or attach service in RO mode) → call `service.prepare_write(...)`. | Prepare step. | `pytest.raises(SafetyError, match=r"(?i)read-only")` | Permission fault log entry. |
| **3.8 Profile Drift** | Call `prepare_write(...)` → alter dynamic symbol profile mapping offset (e.g. swap `units` offset from `0x0104` to `0x0204`) → call `confirm_write(...)`. | Confirm step. | `pytest.raises(SafetyError, match=r"(?i)profile drift\|symbol re-resolution mismatch")` | Drift report artifact contrasting prep address with confirm address. |

---

## 4. Pass/Fail Criteria & Determinism Controls

### 4.1 Pass/Fail Gates
* **Tier 1 Pass:**
  1. All 8 failure injections raise strictly typed `SafetyError` with matching error codes/regex.
  2. Memory buffers remain 100% byte-identical to pre-write baseline after any rejected write (Originals Preservation).
  3. Valid writes produce schema-valid JSON write receipts and mutate only targeted byte slices.
* **Tier 2 Pass:**
  1. Offline original source templates remain strictly unmutated (source SHA-256 pre == source SHA-256 post).
  2. Both `save.hg` and `save2.hg` reflect byte-identical modifications at the designated payload offsets.
  3. Unedited sectors across both save containers retain identical SHA-256 sub-hashes.

### 4.2 Determinism & Flakiness Detection
* **No Real Time:** Zero calls to `time.time()`, `time.monotonic()`, or `datetime.now()` without clock injection.
* **Seed Rotation Matrix:**
  * Tests run over an automated matrix of 5 distinct seeds: `[42, 1337, 80085, 2024, 99999]`.
  * Buffer layouts and random noise fields alter, but offset assertions must yield identical verdicts.
* **Repeat Runs:** CI executes Tier 1 tests $N=10$ consecutive iterations in random order (`pytest-randomly`) to detect state leaks across test boundaries.

---

## 5. Quarantine Lane Design

### 5.1 Marking Mechanism
Tests relying on hardware breakpoints, debugging hooks, or background thread observers are categorized under the `quarantine` marker in `tests/conftest.py`:

```python
# Marker registration in conftest.py
def pytest_configure(config):
    config.addinivalue_line(
        "markers", "quarantine: Observer and breakpoint tests held due to crash risk"
    )

def pytest_collection_modifyitems(config, items):
    if not config.getoption("--run-quarantine", default=False):
        skip_quarantine = pytest.mark.skip(
            reason="Quarantined: Hardware-breakpoint observer tests disabled by default"
        )
        for item in items:
            if "quarantine" in item.keywords:
                item.add_marker(skip_quarantine)
```

### 5.2 Contents of the Quarantine Lane
* `tests/test_guarded_quarantine.py`:
  * `test_hw_breakpoint_observer_detection()`
  * `test_observer_thread_memory_contention()`
  * `test_simulated_dr_register_exhaustion()`
* **Hard Interlock:** Even if `--run-quarantine` is passed, tests assert that `target_backend.is_live_process() is False`. If any test detects a live Win32 process handle, it throws an un-catchable `RuntimeError` immediately aborting execution.

### 5.3 Un-Quarantine Protocol
Un-quarantining is forbidden via automated tests or CI switches. It requires:
1. An explicit human Architecture Decision Record (ADR) committed to `docs/decisions/`.
2. Root-cause crash triage isolating hardware-breakpoint collision from Windows thread pool state.
3. Manual removal of the `@pytest.mark.quarantine` decorator by Bruce.

---

## 6. Evidence Artifacts Architecture

All artifacts are written to `.gtp_scratch/test_evidence/<timestamp>_<test_name>/` (added to root `.gitignore`).

```text
.gtp_scratch/test_evidence/
├── tier1_test_readback_divergence_20241024_120000/
│   ├── write_receipt.json
│   └── audit_stream.ndjson
└── tier2_paired_save_edit_20241024_120001/
    ├── save_manifest.json
    ├── diff_save.hg.bin
    └── audit_stream.ndjson
```

### 6.1 Artifact Schemas

#### 1. Write Receipt (`write_receipt.json`)
```json
{
  "receipt_id": "rcpt_98f1c4e2",
  "intent_id": "int_7a6b2c1d",
  "status": "COMMITTED",
  "target_symbol": "units",
  "target_address": "0x00000104",
  "bytes_written": 4,
  "old_value": 50000,
  "new_value": 75000,
  "pre_read_hash": "sha256_abcdef...",
  "readback_hash": "sha256_123456...",
  "timestamp": 1700000015.0,
  "confirmation_phrase": "CONFIRM-ACTUATE-units-75000"
}
```

#### 2. Audit Stream Entry (`audit_stream.ndjson`)
```json
{"event": "PREPARE_WRITE", "intent_id": "int_7a6b2c1d", "addr": "0x0104", "expected": 50000, "new": 75000, "clock": 1700000010.0}
{"event": "PRE_READ_VERIFY", "intent_id": "int_7a6b2c1d", "val": 50000, "status": "MATCH"}
{"event": "CONFIRM_ATTEMPT", "intent_id": "int_7a6b2c1d", "phrase_provided": "CONFIRM-ACTUATE-units-75000", "clock": 1700000015.0}
{"event": "WRITE_EXECUTE", "addr": "0x0104", "len": 4}
{"event": "READBACK_VERIFY", "addr": "0x0104", "val": 75000, "status": "VERIFIED"}
```

#### 3. Save Manifest (`save_manifest.json`)
```json
{
  "baseline": {
    "source_file": "tests/fixtures/nms_base.hg",
    "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
  },
  "targets
---

## (c) Safety Review — Claude (claude-haiku-4-5-20251001)

# SAFETY REVIEW: GameGPT Actuator Test Harness

## SPEC REVIEW (GPT)

### Line-by-Line Assessment

| Safety Line | Section(s) | Status | Finding |
|---|---|---|---|
| **1. No live game process** | Overview, Constraints | **PASS** | Spec explicitly restricts to SimulatedMemoryBackend (Tier 1) and offline snapshots (Tier 2). No live process attachment mentioned. |
| **2. Skyrim Hold** | Constraints, 1.1, 2.1 | **PASS** | Spec uses generic "health, ammo, coins" language and explicitly states "NMS-style patterns only." No Skyrim addresses, values, or scenarios present. |
| **3. Observer Quarantine** | Constraints | **PASS WITH CHANGES** | Spec mentions quarantine lane exists but **does not specify the hard interlock** that prevents live-process detection during quarantine runs. See required change below. |
| **4. Guarded-write chain integrity** | 2.1–2.8, 3.1–3.8 | **PASS** | All six chain steps are explicitly asserted: fresh pre-read (2.1), expected_current blocking (2.2), readback (2.3), originals preservation (2.4), confirmation phrase (2.5), expiry (2.6), single-use (2.7). Failure injections (3.1–3.8) cover all bypass vectors. |
| **5. Scope creep** | Overview, Constraints | **PASS** | Harness scope is tightly bounded to "write path (prepare_write/confirm_write)." No scan, detection, UI, networking, or deployment logic mentioned. |

### Required Changes to Spec

**CHANGE 1: Add hard interlock to Quarantine Lane (Section 6, new subsection)**

Add after "Constraints" section:

```
## Quarantine Lane Hard Interlock (MANDATORY)

All tests in the quarantine lane must assert that no live game process is attached 
at test entry. Specifically:

- Before any quarantined test executes, it must call:
  ```
  assert not backend.is_live_process(), 
    "ABORT: Live process detected in quarantine test. Quarantine lane is offline-only."
  ```
- If a live process is detected, the test must raise `RuntimeError` (not `SafetyError`) 
  and immediately abort the entire test session.
- This interlock cannot be disabled, mocked, or bypassed by any CLI flag, including 
  `--run-quarantine`.
```

**CHANGE 2: Clarify "Originals Preservation" scope (Section 2.4)**

Current text is ambiguous about what "untouched" means. Change to:

```
2.4 **Originals Preservation**:
   - Pre-write bytes must be recorded and recoverable.
   - After a failed write attempt (SafetyError raised), the entire memory buffer 
     must be byte-identical to its state before prepare_write() was called.
   - **Assertion**: `memcmp(buffer_before_prepare, buffer_after_failed_write) == 0`
```

**CHANGE 3: Specify "Profile Re-resolution" (Section 3.8)**

Current text is vague. Change to:

```
3.8 **Address/Type Drift via Profile Re-resolution**:
   - Simulate a scenario where the symbol profile (mapping of "units" → address 0x0104) 
     is altered between prepare_write() and confirm_write().
   - Example: After prepare_write(target="units", ...), change the profile so 
     "units" now resolves to address 0x0204.
   - **Assertion**: The write operation fails with SafetyError matching 
     "(?i)profile drift|symbol re-resolution mismatch|address mismatch".
   - **Rationale**: Ensures the actuator re-validates the symbol address at confirm time 
     and does not blindly use the prepared address.
```

### Underspecified Safety-Relevant Items

1. **Intent TTL value**: Spec says "defined duration" (4.2) but does not specify the actual TTL constant. 
   - **Required**: Add `intent_ttl_seconds = 300` (or similar) to section 4.2.

2. **Confirmation phrase format**: Spec says "constant-time compare" but does not specify the phrase structure.
   - **Required**: Add to section 2.5: "Confirmation phrase must be deterministic, derived from intent_id + target + new_value, and compared using `hmac.compare_digest()` or equivalent constant-time function."

3. **SafetyError exception hierarchy**: Spec assumes `SafetyError` exists but does not define it.
   - **Required**: Add to section 2: "All guarded-write violations must raise `SafetyError` (or subclass). Error codes must be machine-readable (e.g., `ERR_STALE_PREREAD`, `ERR_EXPIRED_INTENT`)."

4. **Readback divergence tolerance**: Spec says readback "must match" but does not define bit-level tolerance.
   - **Required**: Add to section 2.3: "Readback must match new_value byte-for-byte. No tolerance for bit flips, truncation, or endianness drift."

---

## DESIGN REVIEW (Gemini)

### Line-by-Line Assessment

| Safety Line | Section(s) | Status | Finding |
|---|---|---|---|
| **1. No live game process** | 1, 2.1–2.4, 5.2 | **PASS WITH CHANGES** | Design correctly isolates to SimulatedMemoryBackend and synthetic saves. **BUT** section 5.2 says "Even if `--run-quarantine` is passed, tests assert that `target_backend.is_live_process() is False`" — this is good, but the assertion is not shown in code. See required change below. |
| **2. Skyrim Hold** | 2.1 (Memory Map Standard) | **PASS** | Memory map uses NMS-style inventory: `health`, `units`, `nanites`, `hazard_protection`. No Skyrim values. Offsets are generic (0x0100, 0x0104, etc.), not Skyrim-specific. |
| **3. Observer Quarantine** | 5 (Quarantine Lane Design) | **PASS WITH CHANGES** | Design correctly marks quarantine tests and skips by default. **BUT** the hard interlock code in 5.2 is pseudocode; actual implementation must be shown. See required change below. |
| **4. Guarded-write chain** | 3 (Failure Injection Table), 4.1 | **PASS** | All 8 failure cases (3.1–3.8) are mapped to concrete injection mechanisms and expected SafetyError assertions. Readback divergence (3.3) uses `ReadbackDivergentBackend`. Expiry (3.4) uses `InjectableClock`. Single-use (3.5) checks intent replay. Phrase (3.6) validates confirmation token. Profile drift (3.8) swaps symbol offset. Chain integrity is preserved. |
| **5. Scope creep** | 1, 3, 4 | **PASS** | Design is tightly scoped to write-path testing (prepare_write/confirm_write). No scan, game detection, UI, networking, or deployment logic. Artifacts are evidence-only (JSON, NDJSON, binary diffs). |

### Critical Issues Found

#### **ISSUE A: Quarantine Hard Interlock Not Implemented (Section 5.2)**

**Problem**: Design says tests "assert that `target_backend.is_live_process() is False`" but does not show the actual code or where it runs.

**Risk**: A builder could implement the quarantine marker and skip logic without adding the hard interlock. If a live process somehow gets attached during a quarantine test, it would run undetected.

**Required Change**:

Add to section 5.2, after the marker registration code:

```python
# Hard interlock in conftest.py or test_guarded_quarantine.py
@pytest.fixture(autouse=True)
def quarantine_live_process_interlock(request):
    """
    Abort immediately if a live process is detected in a quarantine test.
    This fixture runs before every test marked @pytest.mark.quarantine.
    """
    if "quarantine" in request.keywords:
        # Import the backend fixture or service to check
        backend = request.getfixturevalue("seeded_simulated_backend")
        if hasattr(backend, "is_live_process") and backend.is_live_process():
            raise RuntimeError(
                "ABORT: Live game process detected in quarantine test. "
                "Quarantine lane is offline-only. Test session aborted."
            )
```

---

#### **ISSUE B: ReadbackDivergentBackend Injection Mechanism Underspecified (Section 2.2)**

**Problem**: Design says `ReadbackDivergentBackend` "masks or shifts bits (e.g., inverts bit 0)" but does not specify:
- Which bit(s) are inverted?
- Is it deterministic or random?
- Does it apply to all reads or only the first readback after write?

**Risk**: Builder could implement a non-deterministic divergence, causing flaky tests.

**Required Change**:

Replace section 2.2 description with:

```
2. **`ReadbackDivergentBackend(SimulatedMemoryBackend)`**:
   * Accepts a `diverge_on_address: int` parameter and `divergence_mask: int = 0x01`.
   * `write_bytes(addr, data)` updates internal memory normally.
   * The **first** `read_bytes(addr, len)` call **after** a write to `diverge_on_address` 
     returns `(written_value XOR divergence_mask)` instead of the written value.
   * Subsequent reads return the correct value (single-shot divergence).
   * Example: `ReadbackDivergentBackend(diverge_on_address=0x0104, divergence_mask=0x01)` 
     will flip bit 0 of the first readback at offset 0x0104 after a write.
```

---

#### **ISSUE C: FlappingMemoryBackend Not Tested (Section 2.2)**

**Problem**: Design mentions `FlappingMemoryBackend` but it is not mapped to any failure injection case in section 3. It is unclear what it tests.

**Risk**: Dead code or untested race condition.

**Required Change**:

Either:
1. **Remove** `FlappingMemoryBackend` from the design (if not needed), OR
2. **Add** a failure injection case (e.g., 3.9) that uses it:

```
3.9 **Concurrent Mutation (Flapping Memory)**:
   - Use FlappingMemoryBackend to mutate the target offset between prepare and confirm.
   - Assertion: The write operation fails due to expected_current mismatch.
```

---

#### **ISSUE D: Confirmation Phrase Derivation Not Specified (Section 6.1)**

**Problem**: Write receipt shows `"confirmation_phrase": "CONFIRM-ACTUATE-units-75000"` but design does not specify:
- Is this phrase deterministic or random?
- How is it derived (hash, concatenation, HMAC)?
- Is it constant-time compared?

**Risk**: Builder could implement a weak phrase derivation (e.g., simple string concat without HMAC), weakening the guarded-write chain.

**Required Change**:

Add to section 6.1, before the Write Receipt schema:

```
#### Confirmation Phrase Derivation (MANDATORY)

The confirmation phrase must be derived deterministically and compared in constant time:

1. **Derivation**: 
   ```
   phrase = "CONFIRM-" + HMAC-SHA256(
       key=intent_id,
       msg=f"{target_symbol}|{new_value}|{intent_timestamp}"
   ).hex()[:16]
   ```
2. **Comparison**: Use `hmac.compare_digest(provided_phrase, expected_phrase)` 
   to prevent timing attacks.
3. **Entropy**: The intent_id must be cryptographically random (e.g., `secrets.token_hex(8)`).
```

---

#### **ISSUE E: Profile Drift Injection Mechanism Unclear (Section 3, Table Row 3.8)**

**Problem**: Table says "alter dynamic symbol profile mapping offset (e.g. swap `units` offset from `0x0104` to `0x0204`)" but does not specify:
- How is the profile altered? (Mock? Fixture parameter?)
- When is it altered? (Between prepare and confirm? During confirm?)
- Does the actuator re-validate the address at confirm time?

**Risk**: Builder could implement a test that doesn't actually exercise address re-validation.

**Required Change**:

Add to section 3, after the failure injection table:

```
### 3.9 Profile Drift Injection Mechanism

For test case 3.8, the profile drift must be injected as follows:

1. Create a fixture `drifting_symbol_profile` that wraps the standard symbol resolver.
2. Call `prepare_write(target="units", expected_current=50000, new_value=75000)`.
   - At this point, "units" resolves to address 0x0104.
3. **Before confirm_write()**, call `profile.drift_symbol("units", new_address=0x0204)`.
4. Call `confirm_write(intent_id, phrase)`.
5. The actuator must re-resolve "units" at confirm time, detect the address mismatch 
   (0x0104 != 0x0204), and raise `SafetyError` with code `ERR_PROFILE_DRIFT`.
6. The original memory at 0x0104 must remain untouched (Originals Preservation).
```

---

#### **ISSUE F: Tier 2 Paired-Save Byte-Identity Assertion Underspecified (Section 2.4)**

**Problem**: Design says "Both saves must read back byte-identical at the edited offsets" but does not specify:
- What if the saves have different structures (e.g., different header checksums)?
- How are unedited bytes verified to remain identical?
- What is the granularity of comparison (byte, sector, file)?

**Risk**: Builder could implement a weak comparison that misses silent corruption.

**Required Change**:

Add to section 2.4:

```
2.4 **Byte-level Readback Comparison (Tier 2)**:
   - After a paired-save write, both `save.hg` and `save2.hg` must be read back.
   - For each edited offset (e.g., 0x0150 for "units"), verify:
     ```
     assert save_hg[0x0150:0x0154] == save2_hg[0x0150:0x0154] == new_value_bytes
     ```
   - For all unedited offsets, verify:
     ```
     assert save_hg[i] == save2_hg[i] == baseline_hg[i]  # for all i not in edited_offsets
     ```
   - Compute SHA-256 of unedited sectors and verify they match baseline.
```

---

#### **ISSUE G: Seed Rotation Matrix Not Enforced (Section 4.2)**

**Problem**: Design says "Tests run over an automated matrix of 5 distinct seeds" but does not specify:
- How is the seed matrix applied? (Parametrize? Fixture?)
- Are all 8 failure injection cases run for each seed?
- What happens if a test passes for seed 42 but fails for seed 1337?

**Risk**: Builder could implement seed rotation for only some tests, leaving others untested.

**Required Change**:

Add to section 4.2:

```
### 4.2 Seed Rotation Matrix (MANDATORY)

All Tier 1 failure injection tests (3.1–3.8) must be parametrized over the seed matrix:

```python
SEED_MATRIX = [42, 1337, 80085, 2024, 99999]

@pytest.mark.parametrize("seed", SEED_MATRIX)
def test_stale_preread_injection
---

## (d) Explicit Non-Goals

1. **No live game process.** Tier 1 uses `SimulatedMemoryBackend` only; Tier 2 uses copied offline save files only. No attach to any real process, no `windows.py` backend in the harness.
2. **No Skyrim writes — full hold.** No Skyrim value, address, memory layout, or scenario appears in the spec, design, fixtures, or examples. NMS-style patterns only (health/units/nanites/hazard_protection at generic offsets).
3. **No observer reactivation.** Inventory hardware-breakpoint observers stay quarantined. The quarantine lane (`tests/test_guarded_quarantine.py`, `@pytest.mark.quarantine`, skipped by default, `--run-quarantine` opt-in) exists for documentation and future causal analysis only — and per Claude's required Change 1, every quarantined test carries a hard interlock that aborts the session (RuntimeError, not skippable, not mockable) if a live process is ever detected.
4. **No scan-reasoning, game detection, UI, networking, or deployment code.** The harness covers the actuator write path (`prepare_write`/`confirm_write`) and nothing else.
5. **No weakening of the guarded-write chain.** Test helpers may rig backends and clocks, but may never bypass, mock away, or short-circuit: fresh pre-read vs `expected_current`, confirmation phrase check, intent expiry, single-use intents, immediate readback vs new value, or originals preservation.
6. **No Tier 3 (live game) work.** This design stops at Tier 2. Tier 3 requires Bruce's explicit per-run authorization and is out of scope.
