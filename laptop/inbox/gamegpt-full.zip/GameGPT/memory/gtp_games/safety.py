from __future__ import annotations

import fnmatch
import os
import re

from gtp_games.config import Settings
from gtp_games.errors import SafetyError
from gtp_games.models import MemoryRegion, ProcessInfo, ProcessSession

_DENIED_PROCESS_PATTERNS = (
    "*easyanticheat*",
    "*easy anti-cheat*",
    "*battleye*",
    "*vgc.exe*",
    "*vgtray*",
    "*vanguard*",
    "*faceit*",
    "*equ8*",
    "*xigncode*",
    "*nprotect*",
    "*gameguard*",
)


class SafetyPolicy:
    def __init__(self, settings: Settings) -> None:
        self.settings = settings

    def validate_process(self, process: ProcessInfo, *, write_enabled: bool) -> None:
        if process.pid in {0, 4, os.getpid()}:
            raise SafetyError("refusing to attach to a system-reserved or service PID")
        match_values = self._process_match_values(process)
        if any(
            fnmatch.fnmatch(value, pattern)
            for value in match_values
            for pattern in _DENIED_PROCESS_PATTERNS
        ):
            raise SafetyError("refusing to attach to an anti-cheat or protected security process")
        if write_enabled:
            if not self.settings.allow_writes:
                raise SafetyError("writes are disabled; set GTP_ALLOW_WRITES=true before startup")
            patterns = self.settings.allowed_process_patterns
            if not patterns:
                raise SafetyError("writes require at least one GTP_ALLOWED_PROCESSES pattern")
            if not any(
                fnmatch.fnmatch(value, normalized_pattern)
                for value in match_values
                for pattern in patterns
                for normalized_pattern in self._normalized_patterns(pattern)
            ):
                raise SafetyError(
                    f"{process.name} is not in the configured write-enabled process allowlist"
                )

    @staticmethod
    def _process_match_values(process: ProcessInfo) -> set[str]:
        values = {process.name.lower()}
        if process.executable:
            executable = process.executable.lower()
            values.update({executable, os.path.basename(executable)})
        return values | {value.replace("\\", "/") for value in values}

    @staticmethod
    def _normalized_patterns(pattern: str) -> set[str]:
        normalized = pattern.lower()
        return {normalized, normalized.replace("\\", "/")}

    def validate_write(
        self,
        session: ProcessSession,
        region: MemoryRegion,
        *,
        address: int,
        size: int,
        is_scan_candidate: bool,
        reason: str,
    ) -> None:
        self.validate_direct_write(
            session,
            region,
            address=address,
            size=size,
            reason=reason,
        )
        if not is_scan_candidate:
            raise SafetyError("writes are limited to current scan candidates in this session")

    def validate_direct_write(
        self,
        session: ProcessSession,
        region: MemoryRegion,
        *,
        address: int,
        size: int,
        reason: str,
    ) -> None:
        """Validate a user-directed scalar write to the selected game process."""

        if not self.settings.allow_writes or not session.write_enabled:
            raise SafetyError("this session is not write-enabled")
        if size <= 0 or size > 8:
            raise SafetyError("writes are limited to scalar values of at most eight bytes")
        if not region.contains(address, size):
            raise SafetyError("the write crosses the selected memory region boundary")
        if not region.writable:
            raise SafetyError("the target memory region is not writable")
        if region.executable:
            raise SafetyError("writes to executable memory are not permitted")
        if len(reason.strip()) < 3:
            raise SafetyError("a short human-readable reason is required")
        if re.search(r"anti.?cheat|bypass|multiplayer|online", reason, re.IGNORECASE):
            raise SafetyError("the stated write purpose is outside the local personal-game scope")
