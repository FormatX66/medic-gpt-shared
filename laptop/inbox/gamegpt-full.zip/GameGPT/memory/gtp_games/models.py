from __future__ import annotations

from datetime import UTC, datetime
from enum import StrEnum
from typing import Any

from pydantic import BaseModel, ConfigDict, Field


class ValueType(StrEnum):
    I8 = "i8"
    U8 = "u8"
    I16 = "i16"
    U16 = "u16"
    I32 = "i32"
    U32 = "u32"
    I64 = "i64"
    U64 = "u64"
    F32 = "f32"
    F64 = "f64"


class Comparison(StrEnum):
    EXACT = "exact"
    CHANGED = "changed"
    UNCHANGED = "unchanged"
    INCREASED = "increased"
    DECREASED = "decreased"


class CheatAction(StrEnum):
    SET = "set"
    HOLD = "hold"


class ScanKind(StrEnum):
    EXACT = "exact"
    UNKNOWN = "unknown"


class LocatorKind(StrEnum):
    RAW_ADDRESS = "raw_address"
    MODULE_OFFSET = "module_offset"
    POINTER_CHAIN = "pointer_chain"
    AOB = "aob"
    AOB_POINTER = "aob_pointer"


class DiscoveryTargetState(StrEnum):
    QUEUED = "queued"
    SCANNING = "scanning"
    OBSERVING = "observing"
    REVISIT_PENDING = "revisit_pending"
    CANDIDATE = "candidate"
    LOCKED = "locked"
    CONFIRMED = "confirmed"
    EXHAUSTED = "exhausted"


class MemoryRegionKind(StrEnum):
    PRIVATE = "private"
    IMAGE = "image"
    MAPPED = "mapped"
    OTHER = "other"


class ProcessInfo(BaseModel):
    pid: int
    name: str
    executable: str | None = None
    started_at: float | None = None
    memory_bytes: int | None = None
    gpu_percent: float | None = None
    game_score: int = Field(default=0, ge=0, le=100)
    likely_game: bool = False
    game_reasons: list[str] = Field(default_factory=list)
    attachable: bool = True
    blocked_reason: str | None = None


class MemoryRegion(BaseModel):
    base_address: int = Field(ge=0)
    size: int = Field(gt=0)
    readable: bool
    writable: bool
    executable: bool
    private: bool = True
    committed: bool = True
    guarded: bool = False
    kind: MemoryRegionKind = MemoryRegionKind.PRIVATE
    allocation_base: int | None = Field(default=None, ge=0)
    main_module: bool = False
    resident: bool | None = None
    name: str | None = None

    @property
    def end_address(self) -> int:
        return self.base_address + self.size

    def contains(self, address: int, size: int = 1) -> bool:
        return self.base_address <= address and address + size <= self.end_address


class ProcessSession(BaseModel):
    model_config = ConfigDict(arbitrary_types_allowed=True)

    id: str
    pid: int
    process_name: str
    executable: str | None = None
    process_started_at: float | None = None
    game_key: str | None = None
    game_name: str | None = None
    selected_table_path: str | None = None
    selected_table_status: str | None = None
    write_enabled: bool
    backend_name: str
    attached_at: datetime = Field(default_factory=lambda: datetime.now(UTC))
    backend_handle: Any = Field(exclude=True)


class ScanCandidate(BaseModel):
    address: int
    value: int | float


class ScanSummary(BaseModel):
    id: str
    session_id: str
    scan_kind: ScanKind = ScanKind.EXACT
    value_type: ValueType
    normalized: bool = False
    comparison: Comparison
    generation: int
    result_count: int
    truncated: bool
    scope_truncated: bool = False
    scanned_bytes: int
    eligible_bytes: int = 0
    selected_region_count: int = 0
    cache_backed: bool = False
    cached_bytes: int = 0
    cache_reused: bool = False
    reused_from_scan_id: str | None = None
    candidates: list[ScanCandidate] = Field(default_factory=list)


class ScanCandidateStability(BaseModel):
    address: int = Field(ge=0)
    observations: int = Field(default=0, ge=0)
    changed: int = Field(default=0, ge=0)
    unchanged: int = Field(default=0, ge=0)
    increased: int = Field(default=0, ge=0)
    decreased: int = Field(default=0, ge=0)
    distinct_values: int = Field(default=1, ge=1)
    first_value: int | float
    current_value: int | float


class MemoryLocator(BaseModel):
    kind: LocatorKind
    module: str | None = None
    module_offset: int | None = None
    pointer_offsets: list[int] = Field(default_factory=list, max_length=8)
    aob_pattern: str | None = Field(default=None, max_length=4096)
    aob_offset: int = 0
    aob_displacement_offset: int | None = Field(default=None, ge=0, le=64)
    aob_instruction_size: int | None = Field(default=None, ge=1, le=64)
    address: int | None = Field(default=None, ge=0)
    match_count: int | None = Field(default=None, ge=0)


class ValidationRule(BaseModel):
    value_min: float | None = None
    value_max: float | None = None
    expected_directions: list[Comparison] = Field(default_factory=list)
    minimum_change_events: int = Field(default=3, ge=0)
    minimum_launches: int = Field(default=2, ge=1)
    require_unique_aob: bool = True
    require_non_raw_locator: bool = True
    require_source_correlation: bool = True
    notes: list[str] = Field(default_factory=list)


class ScanActivity(BaseModel):
    operation_id: str
    session_id: str
    operation: str
    state: str
    processed_bytes: int = Field(default=0, ge=0)
    total_bytes: int = Field(default=0, ge=0)
    processed_regions: int = Field(default=0, ge=0)
    total_regions: int = Field(default=0, ge=0)
    result_count: int = Field(default=0, ge=0)
    scan_id: str | None = None
    cache_backed: bool = False
    message: str = ""
    error: str | None = None


class WatchSample(BaseModel):
    captured_at: datetime = Field(default_factory=lambda: datetime.now(UTC))
    candidates: list[ScanCandidate] = Field(default_factory=list)


class WatchResult(BaseModel):
    scan_id: str
    session_id: str
    value_type: ValueType
    samples: list[WatchSample] = Field(default_factory=list)


class HealthBarDetection(BaseModel):
    x: int = Field(ge=0)
    y: int = Field(ge=0)
    width: int = Field(gt=0)
    filled_width: int | None = Field(default=None, gt=0)
    height: int = Field(gt=0)
    percent: float = Field(ge=0, le=100)
    confidence: float = Field(ge=0, le=1)
    color: str
    zone: str = "unknown"
    hud_target: str | None = None
    hud_label: str | None = None
    classification_reason: str | None = None


class VisibleValueDetection(BaseModel):
    x: int = Field(ge=0)
    y: int = Field(ge=0)
    width: int = Field(gt=0)
    height: int = Field(gt=0)
    current_value: int | float
    scan_value: int | float
    value_type: ValueType = ValueType.I32
    normalized: bool = False
    confidence: float = Field(ge=0, le=1)
    target: str
    label: str
    zone: str = "unknown"


class HealthBarResult(BaseModel):
    session_id: str
    pid: int
    window_title: str
    captured_at: datetime = Field(default_factory=lambda: datetime.now(UTC))
    image_width: int = Field(gt=0)
    image_height: int = Field(gt=0)
    capture_status: str = "captured"
    message: str | None = None
    excluded_regions: list[tuple[int, int, int, int]] = Field(default_factory=list)
    detections: list[HealthBarDetection] = Field(default_factory=list)
    visible_values: list[VisibleValueDetection] = Field(default_factory=list)


class InventoryStackDetection(BaseModel):
    x: int = Field(ge=0)
    y: int = Field(ge=0)
    width: int = Field(gt=0)
    height: int = Field(gt=0)
    current_value: int = Field(ge=0)
    maximum_value: int | None = Field(default=None, ge=1)
    confidence: float = Field(ge=0, le=1)
    selected: bool = False
    item_label: str | None = None
    raw_item_label: str | None = None
    reference_url: str | None = None
    reference_confidence: float | None = Field(default=None, ge=0, le=1)


class InventoryScreenResult(BaseModel):
    session_id: str
    pid: int
    window_title: str
    captured_at: datetime = Field(default_factory=lambda: datetime.now(UTC))
    image_width: int = Field(gt=0)
    image_height: int = Field(gt=0)
    capture_status: str = "captured"
    message: str | None = None
    menu_detected: bool = False
    selected_item_label: str | None = None
    guide_url: str | None = None
    reference_catalog_checked: bool = False
    reference_source: str | None = None
    excluded_regions: list[tuple[int, int, int, int]] = Field(default_factory=list)
    detections: list[InventoryStackDetection] = Field(default_factory=list)


class SavedInventoryStack(BaseModel):
    container_path: str
    container_name: str
    container_kind: str
    stack_size_group: str | None = None
    valid_slot_count: int = Field(ge=0)
    width: int | None = Field(default=None, ge=0)
    height: int | None = Field(default=None, ge=0)
    substance_storage_multiplier: int | float | None = Field(default=None, ge=0)
    product_storage_multiplier: int | float | None = Field(default=None, ge=0)
    item_type: str
    item_id: str
    item_name: str | None = None
    amount: int = Field(ge=-1, le=0xFFFFFFFF)
    max_amount: int = Field(ge=0, le=0xFFFFFFFF)
    index_x: int = Field(ge=0)
    index_y: int = Field(ge=0)
    slot_ordinal: int | None = Field(default=None, ge=0)
    reference_url: str | None = None
    reference_source: str | None = None


class SavedInventoryResult(BaseModel):
    session_id: str | None = None
    pid: int | None = Field(default=None, ge=0)
    save_profile: str
    save_filename: str
    modified_at: datetime
    total_stacks: int = Field(ge=0)
    returned_stacks: int = Field(ge=0)
    visited_nodes: int = Field(ge=0)
    truncated: bool = False
    reference_catalog_checked: bool = False
    reference_source: str | None = None
    read_only: bool = True
    game_memory_write_performed: bool = False
    imported_code_executed: bool = False
    provenance: list[str] = Field(default_factory=list)
    stacks: list[SavedInventoryStack] = Field(default_factory=list)


class SavedInventoryLiveCandidate(BaseModel):
    slot_address: int = Field(ge=0)
    count_address: int = Field(ge=0)
    maximum_address: int = Field(ge=0)
    slot_address_hex: str
    count_address_hex: str
    item_id: str
    count: int = Field(ge=0, le=0xFFFFFFFF)
    maximum: int = Field(ge=0, le=0xFFFFFFFF)
    index_x: int = Field(ge=0)
    index_y: int = Field(ge=0)
    item_type: int = Field(ge=0)
    flag_0: int = Field(ge=0, le=1)
    flag_1: int = Field(ge=0, le=1)
    saved_coordinate_match: bool = False
    saved_amount_match: bool = False
    saved_maximum_match: bool = False
    neighbor_matches: int = Field(default=0, ge=0)
    neighbor_checks: int = Field(default=0, ge=0)
    suggested_primary: bool = False
    address_valid_for_current_process_only: bool = True


class SavedInventoryLiveResolution(BaseModel):
    schema_version: str = "gtp-saved-inventory-live-resolution/v1"
    session_id: str
    pid: int = Field(ge=0)
    process_name: str
    process_started_at: float | None = None
    build_identity: str
    save_profile: str
    save_filename: str
    save_modified_at: datetime
    item_id: str
    live_item_id: str
    container_name: str
    stack_size_group: str | None = None
    saved_count: int = Field(ge=-1, le=0xFFFFFFFF)
    saved_maximum: int = Field(ge=0, le=0xFFFFFFFF)
    saved_index_x: int = Field(ge=0)
    saved_index_y: int = Field(ge=0)
    saved_slot_ordinal: int | None = Field(default=None, ge=0)
    search_mode: str
    same_process_hint_count: int = Field(default=0, ge=0)
    selected_region_count: int = Field(default=0, ge=0)
    scanned_bytes: int = Field(default=0, ge=0)
    scope_truncated: bool = False
    elapsed_ms: int = Field(default=0, ge=0)
    candidate_count: int = Field(default=0, ge=0)
    returned_candidate_count: int = Field(default=0, ge=0)
    suggested_primary_count_address: int | None = Field(default=None, ge=0)
    selection_basis: str | None = None
    read_only: bool = True
    game_memory_write_performed: bool = False
    imported_code_executed: bool = False
    address_valid_for_current_process_only: bool = True
    message: str
    candidates: list[SavedInventoryLiveCandidate] = Field(default_factory=list)


class UnrealGlobalCandidate(BaseModel):
    pattern: str
    match_address: int = Field(ge=0)
    slot_address: int = Field(ge=0)
    world_address: int | None = Field(default=None, ge=0)
    valid: bool = False
    confidence: float = Field(default=0, ge=0, le=1)
    reasons: list[str] = Field(default_factory=list)


class UnrealDiscoveryResult(BaseModel):
    session_id: str
    engine_family: str = "Unreal Engine"
    main_module_base: int = Field(ge=0)
    main_module_size: int = Field(ge=0)
    gworld_module_offset: int | None = Field(default=None, ge=0)
    gworld_slot: int | None = Field(default=None, ge=0)
    world_address: int | None = Field(default=None, ge=0)
    selected_pattern: str | None = None
    scanned_bytes: int = Field(default=0, ge=0)
    scope_truncated: bool = False
    read_only: bool = True
    candidates: list[UnrealGlobalCandidate] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)


class UnrealGasCandidate(BaseModel):
    address: int = Field(ge=0)
    object_address: int = Field(ge=0)
    object_path: str
    field_offset: int = Field(ge=0)
    value_type: ValueType
    value: int | float
    likely_max_address: int | None = Field(default=None, ge=0)
    likely_max_value: int | float | None = None
    score: int = Field(default=0, ge=0)
    evidence: list[str] = Field(default_factory=list)


class UnrealGasScanSummary(BaseModel):
    id: str
    session_id: str
    stage: str
    comparison: Comparison = Comparison.UNCHANGED
    generation: int = Field(default=0, ge=0)
    result_count: int = Field(default=0, ge=0)
    object_count: int = Field(default=0, ge=0)
    field_count: int = Field(default=0, ge=0)
    scanned_bytes: int = Field(default=0, ge=0)
    truncated: bool = False
    read_only: bool = True
    player_pawn_address: int | None = Field(default=None, ge=0)
    player_pawn_path: str | None = None
    gworld: UnrealDiscoveryResult
    candidates: list[UnrealGasCandidate] = Field(default_factory=list)


class UnrealGasWatchSample(BaseModel):
    captured_at: datetime = Field(default_factory=lambda: datetime.now(UTC))
    candidates: list[UnrealGasCandidate] = Field(default_factory=list)


class UnrealGasWatchResult(BaseModel):
    scan_id: str
    session_id: str
    read_only: bool = True
    samples: list[UnrealGasWatchSample] = Field(default_factory=list)


class UnrealGasTemporalCandidate(BaseModel):
    address: int = Field(ge=0)
    object_address: int = Field(ge=0)
    object_path: str
    field_offset: int = Field(ge=0)
    value_type: ValueType
    baseline_value: int | float
    lowest_value: int | float
    final_value: int | float
    drop_sample: int = Field(ge=1)
    minimum_sample: int = Field(ge=1)
    recovery_steps: int = Field(ge=2)
    recovery_fraction: float = Field(ge=0)
    event_sample: int | None = Field(default=None, ge=1)
    event_count: int = Field(default=1, ge=1)
    score: int = Field(default=0, ge=0)
    evidence: list[str] = Field(default_factory=list)


class UnrealGasCandidateGroup(BaseModel):
    id: str
    score: int = Field(default=0, ge=0)
    member_count: int = Field(ge=1, le=4)
    correlated_address_count: int = Field(ge=1)
    members: list[UnrealGasTemporalCandidate] = Field(min_length=1, max_length=4)
    evidence: list[str] = Field(default_factory=list)


class UnrealGasTemporalResult(BaseModel):
    scan_id: str
    session_id: str
    sample_count: int = Field(ge=5, le=60)
    interval_ms: int = Field(ge=100, le=2000)
    captured_seconds: float = Field(ge=0)
    sampled_field_count: int = Field(ge=0)
    matched_field_count: int = Field(ge=0)
    group_count: int = Field(ge=0)
    read_only: bool = True
    groups: list[UnrealGasCandidateGroup] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)


class UnrealGasMonitorStatus(BaseModel):
    id: str
    scan_id: str
    session_id: str
    state: str
    interval_ms: int = Field(ge=100, le=2000)
    duration_seconds: int = Field(ge=1, le=3600)
    sample_count: int = Field(default=0, ge=0)
    paused_sample_count: int = Field(default=0, ge=0)
    waiting_for_game: bool = False
    foreground_only: bool = True
    sampled_field_count: int = Field(default=0, ge=0)
    matched_field_count: int = Field(default=0, ge=0)
    group_count: int = Field(default=0, ge=0)
    started_at: datetime
    finished_at: datetime | None = None
    read_only: bool = True
    groups: list[UnrealGasCandidateGroup] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)


class GameProfileCandidate(BaseModel):
    address: int = Field(ge=0)
    object_address: int = Field(ge=0)
    object_path: str
    object_name: str = ""
    class_name: str = ""
    field_offset: int = Field(ge=0)
    value_type: ValueType
    baseline_value: int | float
    current_value: int | float
    minimum_value: int | float
    maximum_value: int | float
    changed_samples: int = Field(default=0, ge=0)
    increased_samples: int = Field(default=0, ge=0)
    decreased_samples: int = Field(default=0, ge=0)
    unchanged_samples: int = Field(default=0, ge=0)
    distinct_value_count: int = Field(default=1, ge=1)
    likely_max_address: int | None = Field(default=None, ge=0)
    likely_max_value: int | float | None = None
    suggested_features: list[str] = Field(default_factory=list)
    category: str = "unknown"
    relevance: str = "unknown"
    confidence: float = Field(default=0, ge=0, le=1)
    score: int = Field(default=0, ge=0)
    evidence: list[str] = Field(default_factory=list)


class GameProfileMonitorStatus(BaseModel):
    id: str
    scan_id: str
    session_id: str
    state: str
    interval_ms: int = Field(ge=250, le=5000)
    duration_seconds: int = Field(ge=1, le=3600)
    sample_count: int = Field(default=0, ge=0)
    paused_sample_count: int = Field(default=0, ge=0)
    waiting_for_game: bool = False
    foreground_only: bool = True
    object_count: int = Field(default=0, ge=0)
    sampled_field_count: int = Field(default=0, ge=0)
    changed_field_count: int = Field(default=0, ge=0)
    candidate_count: int = Field(default=0, ge=0)
    useful_candidate_count: int = Field(default=0, ge=0)
    secondary_candidate_count: int = Field(default=0, ge=0)
    unknown_candidate_count: int = Field(default=0, ge=0)
    ignored_engine_field_count: int = Field(default=0, ge=0)
    started_at: datetime
    finished_at: datetime | None = None
    saved_path: str | None = None
    read_only: bool = True
    candidates: list[GameProfileCandidate] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)


class GameValueTableEntry(BaseModel):
    id: str
    name: str
    status: str
    object_path: str
    field_offset: int = Field(ge=0)
    value_type: ValueType
    likely_max_offset: int | None = Field(default=None, ge=0)
    profile_id: str | None = None
    baseline_value: int | float | None = None
    current_value: int | float | None = None
    minimum_value: int | float | None = None
    maximum_value: int | float | None = None
    suggested_features: list[str] = Field(default_factory=list)
    category: str = "unknown"
    relevance: str = "unknown"
    confidence: float = Field(default=0, ge=0, le=1)
    source_kind: str
    source_id: str | None = None
    locator: MemoryLocator | None = None
    validation_rule: ValidationRule | None = None
    validated_events: int = Field(default=0, ge=0)
    validated_launches: int = Field(default=0, ge=0)
    validated_process_starts: list[float] = Field(default_factory=list)
    source_correlated: bool = False
    stability_score: float = Field(default=0, ge=0, le=1)
    write_test_status: str = "untested"
    evidence: list[str] = Field(default_factory=list)
    updated_at: datetime = Field(default_factory=lambda: datetime.now(UTC))


class GameValueTable(BaseModel):
    schema_version: str = "gtp-game-value-table/v1"
    game_key: str
    process_name: str
    executable: str | None = None
    game_build_identity: str | None = None
    created_at: datetime = Field(default_factory=lambda: datetime.now(UTC))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(UTC))
    saved_path: str
    read_only_discovery: bool = True
    confirmed_features: list[GameValueTableEntry] = Field(default_factory=list)
    candidate_features: list[GameValueTableEntry] = Field(default_factory=list)
    source_ledgers: list[str] = Field(default_factory=list)
    selected_source_table: str | None = None
    selected_source_build_identity: str | None = None
    selected_source_status: str | None = None
    notes: list[str] = Field(default_factory=list)


class NmsSaveSnapshotInfo(BaseModel):
    profile: str
    filename: str
    modified_at: datetime
    size_bytes: int = Field(ge=0)
    sha256: str
    currencies: dict[str, int] = Field(default_factory=dict)
    read_only: bool = True


class NmsSaveFieldChange(BaseModel):
    path: str
    before: Any = None
    after: Any = None
    numeric_delta: int | float | None = None
    score: int = Field(default=0, ge=0)
    labels: list[str] = Field(default_factory=list)


class NmsSaveComparisonReport(BaseModel):
    older: NmsSaveSnapshotInfo
    newer: NmsSaveSnapshotInfo
    total_changed_fields: int = Field(ge=0)
    returned_changed_fields: int = Field(ge=0)
    currency_changes: dict[str, int] = Field(default_factory=dict)
    changes: list[NmsSaveFieldChange] = Field(default_factory=list)
    read_only: bool = True
    warnings: list[str] = Field(default_factory=list)


class PortableGameValueTableEntry(BaseModel):
    id: str
    name: str
    status: str
    object_path: str
    field_offset: int = Field(ge=0)
    value_type: ValueType
    likely_max_offset: int | None = Field(default=None, ge=0)
    suggested_features: list[str] = Field(default_factory=list)
    category: str = "unknown"
    relevance: str = "unknown"
    confidence: float = Field(default=0, ge=0, le=1)
    locator: MemoryLocator | None = None
    validation_rule: ValidationRule | None = None
    validated_events: int = Field(default=0, ge=0)
    validated_launches: int = Field(default=0, ge=0)
    validated_process_starts: list[float] = Field(default_factory=list)
    source_correlated: bool = False
    stability_score: float = Field(default=0, ge=0, le=1)
    write_test_status: str = "untested"


class PortableGameValueTable(BaseModel):
    schema_version: str = "gtp-portable-game-value-table/v1"
    game_key: str
    process_name: str
    game_build_identity: str | None = None
    exported_at: datetime = Field(default_factory=lambda: datetime.now(UTC))
    confirmed_features: list[PortableGameValueTableEntry] = Field(default_factory=list)
    candidate_features: list[PortableGameValueTableEntry] = Field(default_factory=list)
    contains_raw_addresses: bool = False
    contains_executable_scripts: bool = False
    contains_machine_paths: bool = False
    notes: list[str] = Field(default_factory=list)


class GameValueTableExportResult(BaseModel):
    exported_path: str
    table: PortableGameValueTable


class GameValueTableSelectionResult(BaseModel):
    selected_path: str
    target_table_path: str
    game_key: str
    source_build_identity: str | None = None
    current_build_identity: str | None = None
    game_match: bool
    build_match: bool
    status: str
    imported_confirmed_as_candidates: int = Field(default=0, ge=0)
    imported_candidates: int = Field(default=0, ge=0)
    write_ready: bool = False
    notes: list[str] = Field(default_factory=list)


class DiscoveryCandidate(BaseModel):
    id: str
    target: str
    value_type: ValueType
    locator: MemoryLocator
    current_value: int | float | None = None
    stability: ScanCandidateStability | None = None
    validation_rule: ValidationRule
    confidence: float = Field(default=0, ge=0, le=1)
    validated_events: int = Field(default=0, ge=0)
    validated_launches: int = Field(default=0, ge=0)
    validated_process_starts: list[float] = Field(default_factory=list)
    source_correlated: bool = False
    locked_for_run: bool = False
    write_test_status: str = "untested"
    reference_name: str | None = None
    reference_url: str | None = None
    promoted: bool = False
    evidence: list[str] = Field(default_factory=list)


class DiscoveryTargetStatus(BaseModel):
    name: str
    purpose: str = ""
    experiment_prompt: str = ""
    requires_visible_value: bool = False
    state: DiscoveryTargetState = DiscoveryTargetState.QUEUED
    value_type: ValueType
    normalized: bool = False
    scan_id: str | None = None
    generation: int = Field(default=0, ge=0)
    candidate_count: int = Field(default=0, ge=0)
    restart_count: int = Field(default=0, ge=0)
    change_events: int = Field(default=0, ge=0)
    last_direction: Comparison | None = None
    exact_value: int | float | None = None
    exact_value_source: str | None = None
    scanned_exact_value: int | float | None = None
    failed_exact_value: int | float | None = None
    rollback_scan_ids: list[str] = Field(default_factory=list)
    rejected_candidate_ids: list[str] = Field(default_factory=list)
    requires_behavior_capture: bool = False
    behavior_capture_state: str | None = None
    behavior_capture_label: str | None = None
    behavior_capture_started_at: datetime | None = None
    behavior_event_count: int = Field(default=0, ge=0)
    revisit_after: datetime | None = None
    candidates: list[DiscoveryCandidate] = Field(default_factory=list)
    notes: list[str] = Field(default_factory=list)


class CheatDiscoveryRunStatus(BaseModel):
    id: str
    process_name: str
    session_id: str | None = None
    pid: int | None = None
    process_started_at: float | None = None
    game_key: str = "no-man-s-sky"
    state: str = "starting"
    target_order: list[str] = Field(default_factory=list)
    active_target: str | None = None
    cycle_count: int = Field(default=0, ge=0)
    write_enabled: bool = False
    started_at: datetime = Field(default_factory=lambda: datetime.now(UTC))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(UTC))
    saved_path: str | None = None
    table_path: str | None = None
    save_provider_checked: bool = False
    save_provider_name: str | None = None
    save_snapshot_id: str | None = None
    save_rescan_count: int = Field(default=0, ge=0)
    targets: list[DiscoveryTargetStatus] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)


class UnrealGasProfile(BaseModel):
    id: str
    name: str = "Health"
    process_name: str
    executable: str | None = None
    game_build_identity: str | None = None
    selected_pattern: str
    gworld_module_offset: int = Field(ge=0)
    object_path: str
    field_offset: int = Field(ge=0)
    value_type: ValueType
    likely_max_offset: int | None = Field(default=None, ge=0)
    saved_at: datetime = Field(default_factory=lambda: datetime.now(UTC))
    saved_path: str
    read_only: bool = True


class UnrealGasProfileValue(BaseModel):
    profile: UnrealGasProfile
    address: int = Field(ge=0)
    value: int | float
    likely_max_address: int | None = Field(default=None, ge=0)
    likely_max_value: int | float | None = None
    resolved_object_address: int = Field(ge=0)
    read_only: bool = True


class GameCheatFeature(BaseModel):
    id: str
    name: str
    description: str
    status: str
    source_kind: str
    source: str | None = None
    profile_id: str | None = None
    value_type: ValueType | None = None
    current_value: int | float | None = None
    maximum_value: int | float | None = None
    category: str = "gameplay"
    relevance: str = "useful"
    confidence: float = Field(default=0, ge=0, le=1)
    available_actions: list[CheatAction] = Field(default_factory=list)
    discovery_run_id: str | None = None
    discovery_candidate_ids: list[str] = Field(default_factory=list)
    write_tested_candidate_ids: list[str] = Field(default_factory=list)
    evidence: list[str] = Field(default_factory=list)


class WebCheatSource(BaseModel):
    title: str
    url: str
    source_kind: str
    host: str
    direct_table: bool = False
    feature_hints: list[str] = Field(default_factory=list)
    evidence: list[str] = Field(default_factory=list)


class WebCheatDiscoveryResult(BaseModel):
    game_name: str
    game_key: str
    game_build_identity: str | None = None
    status: str
    searched_at: datetime = Field(default_factory=lambda: datetime.now(UTC))
    sources: list[WebCheatSource] = Field(default_factory=list)
    queries: list[str] = Field(default_factory=list)
    cache_path: str | None = None
    notes: list[str] = Field(default_factory=list)


class GameCheatCatalog(BaseModel):
    id: str
    session_id: str
    process_name: str
    game_name: str | None = None
    executable: str | None = None
    game_key: str
    game_build_identity: str | None = None
    status: str
    mount_stage: str = "Starting read-only mount"
    mount_steps_completed: int = Field(default=0, ge=0)
    mount_steps_total: int = Field(default=3, ge=1)
    useful_feature_count: int = Field(default=0, ge=0)
    secondary_feature_count: int = Field(default=0, ge=0)
    ignored_feature_count: int = Field(default=0, ge=0)
    first_connected_at: datetime = Field(default_factory=lambda: datetime.now(UTC))
    refreshed_at: datetime = Field(default_factory=lambda: datetime.now(UTC))
    write_enabled: bool = False
    profile_scan_id: str | None = None
    profile_monitor_id: str | None = None
    game_table_path: str | None = None
    web_discovery_status: str = "not_started"
    web_sources: list[WebCheatSource] = Field(default_factory=list)
    sources_checked: list[str] = Field(default_factory=list)
    suggested_research_queries: list[str] = Field(default_factory=list)
    features: list[GameCheatFeature] = Field(default_factory=list)
    notes: list[str] = Field(default_factory=list)


class HoldIntentView(BaseModel):
    id: str
    session_id: str
    feature_id: str
    feature_name: str
    address: int
    value_type: ValueType
    expected_current: int | float
    hold_value: int | float
    interval_ms: int = Field(ge=100, le=5000)
    duration_seconds: int = Field(ge=1, le=3600)
    reason: str
    expires_at: datetime
    confirmation_phrase: str


class HoldStatus(BaseModel):
    id: str
    session_id: str
    feature_id: str
    feature_name: str
    address: int
    value_type: ValueType
    hold_value: int | float
    interval_ms: int
    started_at: datetime
    expires_at: datetime
    active: bool
    write_count: int = Field(default=0, ge=0)
    stopped_reason: str | None = None


class CheatTableHint(BaseModel):
    description: str
    context: list[str] = Field(default_factory=list)
    value_type: ValueType | None = None
    address_expression: str | None = None
    address_chain: list[str] = Field(default_factory=list)
    module: str | None = None
    module_offset: int | None = None
    pointer_offsets: list[int] = Field(default_factory=list)
    script_present: bool = False


class GameBuildFingerprint(BaseModel):
    executable_name: str
    size_bytes: int = Field(ge=1)
    modified_at: datetime
    sample_identity: str
    sha256: str
    store: str | None = None
    store_app_id: str | None = None
    store_build_id: str | None = None


class CheatTableSourceBuild(BaseModel):
    author: str | None = None
    release_label: str | None = None
    updated_at: str | None = None
    process_names: list[str] = Field(default_factory=list)
    executable_sha256: str | None = None
    build_identity: str | None = None
    store_app_id: str | None = None
    store_build_id: str | None = None


class CheatTableCheck(BaseModel):
    description: str
    value_type: ValueType | None = None
    address: int | None = None
    value: int | float | None = None
    status: str
    script_ignored: bool = False


class CheatTableSignature(BaseModel):
    name: str
    module: str | None = None
    pattern: str
    matches: list[int] = Field(default_factory=list)
    scope_truncated: bool = False


class CheatTableModuleOffset(BaseModel):
    module: str
    offset: int
    expression: str


class CheatTableScriptFinding(BaseModel):
    description: str
    language: str
    sha256: str
    directives: list[str] = Field(default_factory=list)
    rejected_directives: list[str] = Field(default_factory=list)
    read_only_plan: list[str] = Field(default_factory=list)
    signatures: list[CheatTableSignature] = Field(default_factory=list)
    module_offsets: list[CheatTableModuleOffset] = Field(default_factory=list)
    status: str


class CheatTableStructureField(BaseModel):
    description: str
    offset: int = Field(ge=0)
    value_type: str | None = None
    bytesize: int | None = Field(default=None, ge=0)


class CheatTableStructure(BaseModel):
    name: str
    field_count: int = Field(ge=0)
    fields: list[CheatTableStructureField] = Field(default_factory=list)


class CheatTableOverlayFinding(BaseModel):
    kind: str
    name: str
    element_count: int = Field(default=0, ge=0)
    status: str = "reference only; never loaded or displayed"


class CheatTableResult(BaseModel):
    schema_version: str = "gtp-cheat-table-reference/v1"
    source_path: str
    source_kind: str = "file"
    source_sha256: str
    table_version: str | None = None
    hint_count: int
    ignored_script_count: int
    locator_pattern_count: int = Field(default=0, ge=0)
    build_compatibility: str = "unverified"
    source_build: CheatTableSourceBuild = Field(default_factory=CheatTableSourceBuild)
    current_build: GameBuildFingerprint | None = None
    live_validation_performed: bool = False
    reference_only: bool = True
    auto_assembler_executed: bool = False
    lua_executed: bool = False
    hints: list[CheatTableHint] = Field(default_factory=list)
    checks: list[CheatTableCheck] = Field(default_factory=list)
    script_findings: list[CheatTableScriptFinding] = Field(default_factory=list)
    structures: list[CheatTableStructure] = Field(default_factory=list)
    overlays: list[CheatTableOverlayFinding] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)


class WriteIntentView(BaseModel):
    id: str
    session_id: str
    address: int
    value_type: ValueType
    expected_current: int | float
    new_value: int | float
    reason: str
    expires_at: datetime
    confirmation_phrase: str


class WriteResult(BaseModel):
    intent_id: str
    address: int
    value_type: ValueType
    previous_value: int | float
    new_value: int | float
    verified: bool
    operation_id: str | None = None
    receipt_id: str | None = None
    status: str = "verified"
    readback_value: int | float | None = None
    rollback_token: str | None = None
    rollback_available: bool = False
    replayed: bool = False


class RollbackResult(BaseModel):
    receipt_id: str
    rollback_token: str
    original_receipt_id: str
    address: int
    value_type: ValueType
    previous_value: int | float
    restored_value: int | float
    verified: bool
    status: str = "rolled_back"
