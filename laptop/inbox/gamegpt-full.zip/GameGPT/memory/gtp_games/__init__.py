"""GTP Games local memory-assistant package."""

__version__ = "0.16.0"
