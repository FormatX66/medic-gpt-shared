class GTPError(Exception):
    """Base error safe to expose through the local API."""


class NotFoundError(GTPError):
    pass


class SafetyError(GTPError):
    pass


class BackendError(GTPError):
    pass


class ScanLimitError(GTPError):
    pass


class ConfigurationError(GTPError):
    pass
