from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

from gtp_games.models import MemoryRegion, ProcessInfo


class MemoryBackend(ABC):
    name: str

    @abstractmethod
    def list_processes(self) -> list[ProcessInfo]:
        raise NotImplementedError

    def find_process(self, pid: int) -> ProcessInfo | None:
        """Return one process, allowing native backends to avoid a full inventory."""

        return next((process for process in self.list_processes() if process.pid == pid), None)

    @abstractmethod
    def attach(self, pid: int, *, write_enabled: bool) -> Any:
        raise NotImplementedError

    @abstractmethod
    def close(self, handle: Any) -> None:
        raise NotImplementedError

    @abstractmethod
    def regions(self, handle: Any) -> list[MemoryRegion]:
        raise NotImplementedError

    @abstractmethod
    def read(self, handle: Any, address: int, size: int) -> bytes:
        raise NotImplementedError

    @abstractmethod
    def write(self, handle: Any, address: int, data: bytes) -> None:
        raise NotImplementedError
