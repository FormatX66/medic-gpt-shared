from __future__ import annotations

from dataclasses import dataclass
from threading import RLock
from time import time

from gtp_games.codec import encode_value
from gtp_games.errors import BackendError, NotFoundError, SafetyError
from gtp_games.memory.base import MemoryBackend
from gtp_games.models import MemoryRegion, ProcessInfo, ValueType


@dataclass(frozen=True)
class SimulatedHandle:
    pid: int
    write_enabled: bool
    started_at: float


class SimulatedMemoryBackend(MemoryBackend):
    name = "simulated"
    pid = 4242
    process_name = "gtp-simulated-game"
    base_address = 0x10000000
    memory_size = 4096

    _named_values: dict[str, tuple[int, ValueType]] = {
        "health": (0x100, ValueType.I32),
        "ammo": (0x104, ValueType.I32),
        "coins": (0x108, ValueType.I32),
        "health_decoy": (0x180, ValueType.I32),
    }

    def __init__(self) -> None:
        self._memory = bytearray(self.memory_size)
        self._lock = RLock()
        self._started_at = time()
        self._running = True
        self._store_named("health", 100)
        self._store_named("ammo", 30)
        self._store_named("coins", 7)
        self._store_named("health_decoy", 100)

    def list_processes(self) -> list[ProcessInfo]:
        if not self._running:
            return []
        return [
            ProcessInfo(
                pid=self.pid,
                name=self.process_name,
                executable="/simulated/gtp-game",
                started_at=self._started_at,
                memory_bytes=self.memory_size,
                gpu_percent=0.0,
                game_score=100,
                likely_game=True,
                game_reasons=["practice game simulator"],
            )
        ]

    def attach(self, pid: int, *, write_enabled: bool) -> SimulatedHandle:
        if pid != self.pid or not self._running:
            raise NotFoundError(f"simulated process {pid} was not found")
        return SimulatedHandle(
            pid=pid,
            write_enabled=write_enabled,
            started_at=self._started_at,
        )

    def close(self, handle: SimulatedHandle) -> None:
        return None

    def regions(self, handle: SimulatedHandle) -> list[MemoryRegion]:
        self._validate_handle(handle)
        return [
            MemoryRegion(
                base_address=self.base_address,
                size=self.memory_size,
                readable=True,
                writable=True,
                executable=False,
                private=True,
                name="simulated-game-state",
            )
        ]

    def read(self, handle: SimulatedHandle, address: int, size: int) -> bytes:
        self._validate_handle(handle)
        offset = self._offset(address, size)
        with self._lock:
            return bytes(self._memory[offset : offset + size])

    def write(self, handle: SimulatedHandle, address: int, data: bytes) -> None:
        self._validate_handle(handle)
        if not handle.write_enabled:
            raise SafetyError("the simulated process was attached read-only")
        offset = self._offset(address, len(data))
        with self._lock:
            self._memory[offset : offset + len(data)] = data

    def set_named_value(self, name: str, value: int | float) -> int:
        if name not in self._named_values:
            raise NotFoundError(f"unknown simulated value: {name}")
        with self._lock:
            self._store_named(name, value)
        offset, _ = self._named_values[name]
        return self.base_address + offset

    def named_value_address(self, name: str) -> int:
        if name not in self._named_values:
            raise NotFoundError(f"unknown simulated value: {name}")
        return self.base_address + self._named_values[name][0]

    def stop_process(self) -> None:
        with self._lock:
            self._running = False

    def restart_process(self) -> None:
        with self._lock:
            self._started_at = max(time(), self._started_at + 0.001)
            self._running = True

    def _store_named(self, name: str, value: int | float) -> None:
        offset, value_type = self._named_values[name]
        encoded = encode_value(value_type, value)
        self._memory[offset : offset + len(encoded)] = encoded

    def _validate_handle(self, handle: SimulatedHandle) -> None:
        if (
            not isinstance(handle, SimulatedHandle)
            or handle.pid != self.pid
            or not self._running
            or handle.started_at != self._started_at
        ):
            raise BackendError("invalid simulated process handle")

    def _offset(self, address: int, size: int) -> int:
        offset = address - self.base_address
        if offset < 0 or size < 0 or offset + size > self.memory_size:
            raise BackendError(f"address range 0x{address:X}+{size} is outside simulated memory")
        return offset
