from __future__ import annotations

import ctypes
import os
import sys
from ctypes import wintypes
from dataclasses import dataclass

import psutil

from gtp_games.errors import BackendError, NotFoundError, SafetyError
from gtp_games.game_detection import (
    WindowsProcessMetrics,
    collect_windows_process_metrics,
    enrich_process_metrics,
)
from gtp_games.memory.base import MemoryBackend
from gtp_games.models import MemoryRegion, MemoryRegionKind, ProcessInfo

PROCESS_QUERY_INFORMATION = 0x0400
PROCESS_VM_OPERATION = 0x0008
PROCESS_VM_READ = 0x0010
PROCESS_VM_WRITE = 0x0020

MEM_COMMIT = 0x1000
MEM_MAPPED = 0x40000
MEM_IMAGE = 0x1000000
MEM_PRIVATE = 0x20000
PAGE_GUARD = 0x100
PAGE_NOACCESS = 0x01
PAGE_EXECUTE = 0x10
PAGE_EXECUTE_READ = 0x20
PAGE_EXECUTE_READWRITE = 0x40
PAGE_EXECUTE_WRITECOPY = 0x80
PAGE_READONLY = 0x02
PAGE_READWRITE = 0x04
PAGE_WRITECOPY = 0x08

_READABLE = {
    PAGE_READONLY,
    PAGE_READWRITE,
    PAGE_WRITECOPY,
    PAGE_EXECUTE_READ,
    PAGE_EXECUTE_READWRITE,
    PAGE_EXECUTE_WRITECOPY,
}
_WRITABLE = {PAGE_READWRITE, PAGE_WRITECOPY, PAGE_EXECUTE_READWRITE, PAGE_EXECUTE_WRITECOPY}
_EXECUTABLE = {PAGE_EXECUTE, PAGE_EXECUTE_READ, PAGE_EXECUTE_READWRITE, PAGE_EXECUTE_WRITECOPY}
LIST_MODULES_ALL = 0x03


@dataclass(frozen=True)
class WindowsHandle:
    raw: int
    pid: int
    write_enabled: bool


if sys.platform == "win32":
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    psapi = ctypes.WinDLL("psapi", use_last_error=True)

    class MEMORY_BASIC_INFORMATION(ctypes.Structure):
        _fields_ = [
            ("BaseAddress", ctypes.c_void_p),
            ("AllocationBase", ctypes.c_void_p),
            ("AllocationProtect", wintypes.DWORD),
            ("PartitionId", wintypes.WORD),
            ("RegionSize", ctypes.c_size_t),
            ("State", wintypes.DWORD),
            ("Protect", wintypes.DWORD),
            ("Type", wintypes.DWORD),
        ]

    class MODULEINFO(ctypes.Structure):
        _fields_ = [
            ("lpBaseOfDll", ctypes.c_void_p),
            ("SizeOfImage", wintypes.DWORD),
            ("EntryPoint", ctypes.c_void_p),
        ]

    class PSAPI_WORKING_SET_EX_INFORMATION(ctypes.Structure):
        _fields_ = [
            ("VirtualAddress", ctypes.c_void_p),
            ("VirtualAttributes", ctypes.c_size_t),
        ]

    kernel32.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
    kernel32.OpenProcess.restype = wintypes.HANDLE
    kernel32.CloseHandle.argtypes = [wintypes.HANDLE]
    kernel32.CloseHandle.restype = wintypes.BOOL
    kernel32.VirtualQueryEx.argtypes = [
        wintypes.HANDLE,
        ctypes.c_void_p,
        ctypes.POINTER(MEMORY_BASIC_INFORMATION),
        ctypes.c_size_t,
    ]
    kernel32.VirtualQueryEx.restype = ctypes.c_size_t
    kernel32.ReadProcessMemory.argtypes = [
        wintypes.HANDLE,
        ctypes.c_void_p,
        ctypes.c_void_p,
        ctypes.c_size_t,
        ctypes.POINTER(ctypes.c_size_t),
    ]
    kernel32.ReadProcessMemory.restype = wintypes.BOOL
    kernel32.WriteProcessMemory.argtypes = [
        wintypes.HANDLE,
        ctypes.c_void_p,
        ctypes.c_void_p,
        ctypes.c_size_t,
        ctypes.POINTER(ctypes.c_size_t),
    ]
    kernel32.WriteProcessMemory.restype = wintypes.BOOL
    psapi.EnumProcessModulesEx.argtypes = [
        wintypes.HANDLE,
        ctypes.POINTER(wintypes.HMODULE),
        wintypes.DWORD,
        ctypes.POINTER(wintypes.DWORD),
        wintypes.DWORD,
    ]
    psapi.EnumProcessModulesEx.restype = wintypes.BOOL
    psapi.GetModuleInformation.argtypes = [
        wintypes.HANDLE,
        wintypes.HMODULE,
        ctypes.POINTER(MODULEINFO),
        wintypes.DWORD,
    ]
    psapi.GetModuleInformation.restype = wintypes.BOOL
    psapi.GetModuleFileNameExW.argtypes = [
        wintypes.HANDLE,
        wintypes.HMODULE,
        wintypes.LPWSTR,
        wintypes.DWORD,
    ]
    psapi.GetModuleFileNameExW.restype = wintypes.DWORD
    psapi.QueryWorkingSetEx.argtypes = [wintypes.HANDLE, ctypes.c_void_p, wintypes.DWORD]
    psapi.QueryWorkingSetEx.restype = wintypes.BOOL
else:
    kernel32 = None
    psapi = None
    MEMORY_BASIC_INFORMATION = object  # type: ignore[misc,assignment]
    MODULEINFO = object  # type: ignore[misc,assignment]
    PSAPI_WORKING_SET_EX_INFORMATION = object  # type: ignore[misc,assignment]


class WindowsMemoryBackend(MemoryBackend):
    name = "windows"

    def __init__(self) -> None:
        if sys.platform != "win32" or kernel32 is None:
            raise BackendError("the Windows memory backend requires a native Windows run")

    def list_processes(
        self,
        *,
        pids: set[int] | None = None,
        include_gpu: bool = True,
    ) -> list[ProcessInfo]:
        processes: list[ProcessInfo] = []
        metrics = (
            collect_windows_process_metrics()
            if include_gpu
            else WindowsProcessMetrics(None, {}, {})
        )
        if pids is None:
            candidates = list(psutil.process_iter(["pid", "name", "exe"], ad_value=None))
        else:
            candidates = []
            for target_pid in sorted(pids):
                try:
                    candidates.append(psutil.Process(target_pid))
                except (psutil.AccessDenied, psutil.NoSuchProcess, psutil.ZombieProcess):
                    continue
        for process in candidates:
            try:
                info = (
                    process.as_dict(attrs=["pid", "name", "exe"], ad_value=None)
                    if pids is not None
                    else process.info
                )
                pid = int(info["pid"])
                name = info.get("name") or f"pid-{pid}"
                try:
                    memory = process.memory_info()
                    memory_bytes = int(getattr(memory, "private", memory.rss))
                except (psutil.AccessDenied, psutil.NoSuchProcess, psutil.ZombieProcess):
                    memory_bytes = metrics.memory_bytes_by_pid.get(pid)
                try:
                    started_at = float(process.create_time())
                except (psutil.AccessDenied, psutil.NoSuchProcess, psutil.ZombieProcess):
                    started_at = metrics.started_at_by_pid.get(pid)
            except (psutil.AccessDenied, psutil.NoSuchProcess, psutil.ZombieProcess):
                continue

            processes.append(
                ProcessInfo(
                    pid=pid,
                    name=name,
                    executable=info.get("exe") or None,
                    started_at=started_at,
                    memory_bytes=memory_bytes,
                )
            )
        enriched = enrich_process_metrics(processes, metrics.gpu_percent_by_pid)
        return sorted(enriched, key=lambda item: (-item.game_score, item.name.lower(), item.pid))

    def find_process(self, pid: int) -> ProcessInfo | None:
        processes = self.list_processes(pids={pid}, include_gpu=False)
        return processes[0] if processes else None

    def attach(self, pid: int, *, write_enabled: bool) -> WindowsHandle:
        if pid <= 0 or pid == os.getpid():
            raise SafetyError("refusing to attach to this service or a reserved PID")
        access = PROCESS_QUERY_INFORMATION | PROCESS_VM_READ
        if write_enabled:
            access |= PROCESS_VM_OPERATION | PROCESS_VM_WRITE
        raw = kernel32.OpenProcess(access, False, pid)
        if not raw:
            error = ctypes.get_last_error()
            if not psutil.pid_exists(pid):
                raise NotFoundError(f"process {pid} no longer exists")
            raise BackendError(f"OpenProcess failed for PID {pid} (Windows error {error})")
        return WindowsHandle(raw=int(raw), pid=pid, write_enabled=write_enabled)

    def close(self, handle: WindowsHandle) -> None:
        if handle.raw:
            kernel32.CloseHandle(wintypes.HANDLE(handle.raw))

    def regions(self, handle: WindowsHandle) -> list[MemoryRegion]:
        regions: list[MemoryRegion] = []
        modules = self._module_ranges(handle)
        address = 0
        max_user_address = 0x00007FFFFFFFFFFF
        raw_handle = wintypes.HANDLE(handle.raw)
        while address < max_user_address:
            mbi = MEMORY_BASIC_INFORMATION()
            queried = kernel32.VirtualQueryEx(
                raw_handle,
                ctypes.c_void_p(address),
                ctypes.byref(mbi),
                ctypes.sizeof(mbi),
            )
            if queried == 0:
                break
            base = int(mbi.BaseAddress or 0)
            size = int(mbi.RegionSize)
            protection = int(mbi.Protect) & 0xFF
            guarded = bool(int(mbi.Protect) & PAGE_GUARD)
            committed = int(mbi.State) == MEM_COMMIT
            region_type = int(mbi.Type)
            if region_type == MEM_PRIVATE:
                kind = MemoryRegionKind.PRIVATE
            elif region_type == MEM_IMAGE:
                kind = MemoryRegionKind.IMAGE
            elif region_type == MEM_MAPPED:
                kind = MemoryRegionKind.MAPPED
            else:
                kind = MemoryRegionKind.OTHER
            module_name = None
            main_module = False
            if kind is MemoryRegionKind.IMAGE:
                for module_base, module_end, module_path, is_main in modules:
                    if module_base <= base < module_end:
                        module_name = module_path
                        main_module = is_main
                        break
            readable = committed and not guarded and protection in _READABLE
            regions.append(
                MemoryRegion(
                    base_address=base,
                    size=size,
                    readable=readable,
                    writable=committed and not guarded and protection in _WRITABLE,
                    executable=committed and protection in _EXECUTABLE,
                    private=kind is MemoryRegionKind.PRIVATE,
                    committed=committed,
                    guarded=guarded,
                    kind=kind,
                    allocation_base=int(mbi.AllocationBase or 0),
                    main_module=main_module,
                    name=module_name,
                )
            )
            next_address = base + max(size, 1)
            if next_address <= address:
                break
            address = next_address
        return self._annotate_residency(raw_handle, regions)

    @staticmethod
    def _annotate_residency(
        raw_handle: wintypes.HANDLE,
        regions: list[MemoryRegion],
    ) -> list[MemoryRegion]:
        if psapi is None or not regions:
            return regions
        info_array = (PSAPI_WORKING_SET_EX_INFORMATION * len(regions))()
        for index, region in enumerate(regions):
            info_array[index].VirtualAddress = ctypes.c_void_p(region.base_address)
        ok = psapi.QueryWorkingSetEx(
            raw_handle,
            ctypes.byref(info_array),
            ctypes.sizeof(info_array),
        )
        if not ok:
            return regions
        return [
            region.model_copy(
                update={"resident": bool(int(info_array[index].VirtualAttributes) & 1)}
            )
            for index, region in enumerate(regions)
        ]

    @staticmethod
    def _module_ranges(handle: WindowsHandle) -> list[tuple[int, int, str, bool]]:
        if psapi is None:
            return []
        raw_handle = wintypes.HANDLE(handle.raw)
        needed = wintypes.DWORD()
        capacity = 1024
        module_array = (wintypes.HMODULE * capacity)()
        ok = psapi.EnumProcessModulesEx(
            raw_handle,
            module_array,
            ctypes.sizeof(module_array),
            ctypes.byref(needed),
            LIST_MODULES_ALL,
        )
        if not ok:
            return []
        count = min(capacity, int(needed.value) // ctypes.sizeof(wintypes.HMODULE))
        try:
            executable = os.path.normcase(psutil.Process(handle.pid).exe())
        except (psutil.AccessDenied, psutil.NoSuchProcess, psutil.ZombieProcess):
            executable = ""
        ranges: list[tuple[int, int, str, bool]] = []
        for index in range(count):
            module = module_array[index]
            info = MODULEINFO()
            if not psapi.GetModuleInformation(
                raw_handle,
                module,
                ctypes.byref(info),
                ctypes.sizeof(info),
            ):
                continue
            path_buffer = ctypes.create_unicode_buffer(32768)
            copied = psapi.GetModuleFileNameExW(
                raw_handle,
                module,
                path_buffer,
                len(path_buffer),
            )
            path = path_buffer.value if copied else ""
            base = int(info.lpBaseOfDll or 0)
            size = int(info.SizeOfImage)
            if base and size:
                ranges.append(
                    (
                        base,
                        base + size,
                        path,
                        bool(path and os.path.normcase(path) == executable),
                    )
                )
        return ranges

    def read(self, handle: WindowsHandle, address: int, size: int) -> bytes:
        if size <= 0:
            raise BackendError("read size must be positive")
        buffer = ctypes.create_string_buffer(size)
        read_count = ctypes.c_size_t()
        ok = kernel32.ReadProcessMemory(
            wintypes.HANDLE(handle.raw),
            ctypes.c_void_p(address),
            buffer,
            size,
            ctypes.byref(read_count),
        )
        if not ok or read_count.value != size:
            error = ctypes.get_last_error()
            raise BackendError(
                f"ReadProcessMemory failed at 0x{address:X} for {size} bytes "
                f"(read {read_count.value}, Windows error {error})"
            )
        return buffer.raw[:size]

    def write(self, handle: WindowsHandle, address: int, data: bytes) -> None:
        if not handle.write_enabled:
            raise SafetyError("the process session was attached read-only")
        if not data:
            raise BackendError("write data cannot be empty")
        source = ctypes.create_string_buffer(data, len(data))
        written = ctypes.c_size_t()
        ok = kernel32.WriteProcessMemory(
            wintypes.HANDLE(handle.raw),
            ctypes.c_void_p(address),
            source,
            len(data),
            ctypes.byref(written),
        )
        if not ok or written.value != len(data):
            error = ctypes.get_last_error()
            raise BackendError(
                f"WriteProcessMemory failed at 0x{address:X} for {len(data)} bytes "
                f"(wrote {written.value}, Windows error {error})"
            )
