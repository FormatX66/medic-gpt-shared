# GameGPT — Laptop Testing Package

## What's here

- `copilot/` — R&D copilot (CLI + GUI). Advisory only, never touches the game.
- `corpus/` — NMS AOB pattern corpus (49 patterns, 3 quarantined).
- `research/` — NMS research: corpus extraction summary, AMUMSS/Lua vs Cheat Engine comparison.
- `specs/` — Profile schema and Stage 1 R&D spec.
- `memory/` — GTP Games Windows memory backend (read/write) with safety policy.
- `tier1-tier2-harness.md` — Test harness documentation.

## Quick start

1. Double-click `copilot/run-copilot-gui.bat` to open the copilot GUI.
2. Go to the Plan tab, enter a cheat goal (e.g. "unlimited stamina").
3. Follow the experiment plan. Do memory scans with your own tools.
4. Load scan results in the Rank tab to get ranked candidates.

## Memory backend

The `memory/` folder has the Windows process memory reader/writer.
Requires: `pip install psutil`

Safety: all writes go through `safety.py` SafetyPolicy. Never write to a
game without completing the verification checklist (fresh pre-read,
expected_current assertion, immediate + independent readback).

## Tier 3 rules

- The game must be running for live tests.
- Each live test needs explicit authorization.
- Never modify Skyrim values (unverified).
- NMS writes require: fresh pre-read, expected_current, immediate readback,
  independent readback, originals preserved.
