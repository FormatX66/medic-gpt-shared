# GameGPT Stage 1 R&D Copilot — Specification v0.1

**Status:** draft (ensemble-reviewed, not yet sealed)
**Date:** 2026-09-18
**Authors:** Medic (integration), GPT (architecture), Claude (red-team), Gemini (corpus priors)

## 1. What Stage 1 is

A human plays the game with Cheat Engine doing discovery. The copilot **assists and never
executes**. It suggests scan parameters, proposes the next experiment, ranks candidates by
learned priors, and drafts the sealed profile JSON at session end. Every copilot output is
advisory; every state change in the game is performed by the human.

Stage 1 is the answer to "the human is faster at asking the right question": the copilot
makes the human faster at asking, while the human keeps the judgment the machine lacks.

### What Stage 1 is not

- Not an autonomous discovery agent (that is Stage 2/3).
- Not a write path. The copilot receives scan *results*; it never gets a write primitive,
  debugger attach, or script-execution channel into the game process.
- Not a validator. Copilot involvement never upgrades a profile's lifecycle status on its
  own. Only the human review gate (Section 7) can do that.

## 2. Non-negotiable trust boundaries

1. **Read-only memory access.** Copilot ingests structured scan results. No write
   primitive, no attach, no script channel. Ever.
2. **Human-in-the-loop commit gate.** Every copilot output lands in a staging area with a
   diff view and mandatory approval. No auto-publish. No "apply all suggestions" button
   that writes to the validated library.
3. **Explicit uncertainty markers.** Below-threshold confidence (fewer than three
   confirming scans, pointer depth > 4, AOB collisions > 1, under-represented engine)
   is flagged `"confidence": "low"` with a plain-language warning. No silent best-guesses.
4. **Suggestions phrased as questions.** "Could this be health? How will you verify?"
   — never "This is health." Presentation must not manufacture false precision.

## 3. Observation inputs and ingestion

The copilot observes, in order of implementation priority:

| Input | Ingestion mechanism | Notes |
|---|---|---|
| Scan history | Structured import from Cheat Engine (scan-result export / clipboard paste of address lists) | Read-only; copilot never drives the scanner |
| Candidate lists | Same import path, with per-scan metadata (scan #, type, comparison used) | Carries the experiment context each scan ran under |
| Process/module info | Human-provided or read-only companion readout (module base, build string) | Build string feeds the profile's exact-build stamp |
| Human annotations | Lightweight note field per session ("jetpack drain looks like a float near player struct") | The riskiest input: treated as untrusted hint, never fact |
| Research corpus | Local checkout of `FormatX66/GameGPT` research/ + specs/ | Powers the priors engine (Section 6) |

Design rule: the ingestion path must be cheaper than typing. If importing scan results
costs the human more effort than the suggestion saves, the copilot has failed its UX
contract. Target: suggestions in well under a second, one-key accept/dismiss,
non-intrusive overlay or side panel.

## 4. Assist loop

1. **Suggest scan parameters.** Given the cheat goal and session history, recommend value
   type, bounds, and scan mode. Each suggestion carries a type-confidence score and
   ranked alternatives — never a single asserted type (type confusion corrupts adjacent
   memory; see failure modes).
2. **Propose the next experiment.** Ordered, with explicit per-step success criteria,
   e.g. "Take damage → rescan decreased → success = candidate set shrinks and the top
   candidate's value tracks the HUD number." The human performs the in-game action.
3. **Rank candidates.** Grounded heuristics, not vibes:
   - module-base proximity and heap-region stability across scans;
   - value entropy across the experiment sequence (does it move when it should,
     stay still when it shouldn't);
   - cross-reference against the corpus priors (Section 6) and the AOB shape rules;
   - **display-copy flag:** addresses touched by render/UI threads are marked
     `display-likely` and ranked below authoritative-state candidates.

## 5. Experiment-design engine

A cheat goal decomposes into an ordered experiment plan. Example — "unlimited stamina":

1. **Baseline:** exact-value or unknown-initial scan while stamina is full.
2. **Drain:** sprint until stamina drops → scan decreased.
3. **Recover:** stand still → scan increased.
4. **Isolate:** repeat drain/recover until the candidate set is small; rank per Section 4.
5. **Authority test:** write a test value (human performs the write in Cheat Engine),
   then apply an **external stimulus** — take an action in-game that must reflect from
   the authoritative address (e.g. sprint and watch the real drain resume from the
   modified base). A display copy passes readback but fails this test.

### Discovery-vector ordering (durability ranking)

For a requested cheat, the copilot suggests discovery vectors in this order, from the
research corpus:

1. **Save edits** — schema-stable across versions, immune to runtime memory shifts.
2. **Config/MBIN data tuning** (e.g. `GCPLAYERGLOBALS.GLOBAL`) — survives recompiles,
   no code injection (profile schema v0.1.1 already supports config-key resolution).
3. **Wildcarded AOB hooks** — default runtime mechanism; wildcards absorb relocation
   drift. Caveat: hotfixes rot them (observed: 4 trainer compat pushes in 5 days).
4. **Pointer chains** — capped at ≤2 indirection levels in copilot suggestions; deeper
   flagged high-fragility; must validate across game states (menu, gameplay, pause,
   transition).
5. **Static offsets** — never suggested. Dead on arrival against rebuild pipelines.

## 6. Hypothesis priors (seed data)

Seeded from the current corpus (No Man's Sky; critically narrow — two real AOBs).
Confidence degrades explicitly for under-represented engines; the copilot must display
corpus composition (e.g. "78% Unreal-pattern data") and drop to hypothesis-only mode
(questions, not ranked suggestions) below threshold.

| Category | Likely type(s) | Plausible range | Likely home | Conf. |
|---|---|---|---|---|
| Stamina / drain rates | float | 0.0–1.0 (or 0–100) | Heap struct field, hooked at drain path | High |
| Heat / overheat | float | 0.0–1.0 (or 0–100) | Heap struct field, hooked at accumulation path | High |
| Currencies (Units, Nanites) | i64 / u32 | 0–4,294,967,295 | Save JSON path or UI pointer chain | High |
| Inventory count / stack | i32 / i16 | 1–9,999 | Heap item node | High |
| Health (player/ship) | float | 0.0–100.0 | Heap entity struct field | Med |
| Ammo (bullets) / energy | i32 / float | 0–MaxClip / 0.0–100.0 | Weapon state struct | Med |
| Cooldowns | float | 0.0–T_max s | Heap struct (frame-delta timers are f32) | Med |
| Speed multipliers | float | 1.0–10.0 | Engine globals / tuning data | Med |
| Position / coordinates | float[3] or double[3] | planetary scale | Root spatial transform | Low |
| Timers / crafting delays | float or i64 ticks | seconds or epoch | Heap struct or save JSON | Low |
| Outgoing damage | float (multiplier) | 1.0–10⁶ | Code-path hook, not a static attribute | Low |

### AOB shape rule (entity rates/drains)

Observed skeleton across both real signatures: SSE scalar float load
(`F3 0F 10` = `movss`) from a large-displacement struct field off a persistent base
register (`rbx`/`rdi`/`rsi`), feeding subsequent arithmetic. Copilot masks for
`F3 0F 10 [ModR/M] [4-byte offset]` (or `F2 0F 10` for `movsd` doubles); expects core
player variables at deep offsets (>0x1000) inside monolithic actor structs; anchors the
hook at the read immediately before the subtraction. (Disassembly reading is inference
from byte patterns — UNVERIFIED, no disassembler run in this corpus.)

### AOB session rule

An AOB derived from a single session may contain session-specific bytes (session IDs,
timestamps, ASLR-shifted relative offsets). Copilot must derive AOB candidates from
**≥3 separate game launches**, diff them, and justify every wildcard placement. The
trigger runtime logs match addresses and flags the profile for re-validation if the
address moves.

## 7. Profile drafting and the human review gate

At session end the copilot drafts the sealed profile JSON (v0.1.1 schema): cheat goal,
resolution method, guarded steps (pre-read → assert predicate → write → readbacks),
exact game-build stamp, cooldowns, gates, mutual exclusions.

**The draft cannot become `validated` until the human completes the mandatory
verification checklist in tooling** — not as a suggestion, as an enforced gate:

- [ ] Authoritative address confirmed via **external stimulus** (in-game effect observed
      from the modified base; display-copy ruled out).
- [ ] Min / max / mid writes tested; game behaves sanely at each.
- [ ] ±32 bytes of adjacent memory verified uncorrupted after writes.
- [ ] Assert predicates deliberately failed (wrong expected value) to prove the guard
      actually guards — no tautologies (`gte 0` on unsigned, `eq written_value`,
      `not-null` on primitives are rejected by static analysis).
- [ ] Human documents **why this address is authoritative** and **why each guard
      guards** (predicate rationale).
- [ ] Every evidence reference resolves to a real file in the hashed session manifest —
      no synthetic identifiers.

Related profiles (health / max_health / shield) get proposed exclusion groups; addresses
within 256 bytes default to mutually exclusive unless the human overrides with cause.

## 8. Failure modes addressed

- **Display-copy poisoning** (Critical): ranked below authoritative candidates;
  two-phase validation with external stimulus; proposed schema field
  `validation_stimulus`.
- **Tautological predicates** (Critical): static-analysis rejection; semantic
  constraints (ammo ≤ max clip, health ≤ max health); proposed `predicate_rationale`.
- **Single-session AOB overfitting** (Critical): ≥3 sessions, wildcard justification,
  proposed `aob_session_count` / `aob_stability_hash`.
- **Type confusion** (High): confidence + alternatives; type confirmed by
  multi-value change test; proposed `type_confirmation_method`; trigger rejects
  write-size/type-size mismatch.
- **Corpus bias** (High): engine declared upfront; composition displayed;
  hypothesis-only mode below threshold.
- **Automation bias / rubber-stamping** (High): the Section 7 checklist is the gate;
  suggestions phrased as questions; optional randomized challenge validations.
- **Pointer-chain fragility** (High): ≤2 indirections suggested; cross-state
  validation; proposed `pointer_stability_test`; AOBs preferred.
- **Cooldown/gate underspecification** (Medium): cooldowns derived from observed
  update-loop frequency (≥2× loop time); conservative defaults; proposed
  `gate_verification_method`.
- **Mutual-exclusion omission** (Medium): copilot proposes exclusion groups;
  proposed `related_profiles` with trigger-side enforcement.
- **Evidence fabrication** (Medium): evidence bound to hashed session manifest at
  creation; R&D harness injects real session metadata as read-only facts.

Schema fields in Section 7–8 marked "proposed" are candidates for profile schema v0.2,
not adopted in v0.1.1.

## 9. Corpus expansion priorities (signal per effort)

1. **NMS.py / pyMHF hook database** (`tools/data.json`, `nmspy/data/types.py`) —
   real class definitions, vtables, member offsets, verified hook points. Turns
   guesses into lookups.
2. **Decompiled MBIN globals** (`GCPLAYERGLOBALS.GLOBAL`) — unlocks the cheapest
   copilot path: "change this tuning variable, no memory write needed."
3. **Blind Distortion full table recovery** — the only known source of real
   pointer-chain paths and UI-hook scripts; takes the corpus from 2 AOBs to dozens.
4. **Trainer version diffs across patches** — empirical "what rots" data; feeds the
   wildcard-mask heuristics directly.
5. **Cross-game C++ engine corpora** — generalize beyond one engine.

## 10. Open questions for Stage 2

- Scripted experiment sequences for predictable games (human supervises, machine
  drives the experiment order).
- Vision-based ground-truth observation ("the bar moved") to close the loop without
  human eyes.
- Whether the copilot's session workspace can feed R&D run IDs and evidence
  references automatically, removing the fabrication vector entirely.
