# GameGPT Cheat Profile Schema — v0.1.1 (DRAFT)

**Status:** draft. Everything here is UNVERIFIED until a profile passes Tier-3
live proof against the running game.

## What this is

The profile is the sealed contract between GameGPT's two systems:

- **R&D** is the only thing allowed to *learn*. It discovers addresses,
  validates AOBs against the running game, works out the guarded write
  sequence, and seals the result into a profile. Slow, careful,
  ensemble-reviewed. It never acts fast and never improvises.
- **The trigger side** is deliberately *dumb*. Voice in ("heal"), intent
  matched, validated profile loaded, guarded write executed, readback
  confirmed, done. It can only run profiles R&D already sealed. It cannot
  discover, guess, or retry blindly. Its safety comes from what it *can't* do.

The profile is the only artifact that crosses from one side to the other.
Machine-readable JSON; the schema (`profile.schema.json`) is the law.
If a profile doesn't validate against the schema, the trigger side refuses
to load it — no exceptions, no fallbacks.

## Lifecycle

```
R&D discovers → draft profile → live validation (Tier 3) → validated
    → trigger side may execute
    → game patches → build stamp mismatch → NOT executed
    → R&D re-validates → validated again, or deprecated
    → crash correlation → quarantined (human ADR + Bruce to release)
```

Key rule: the trigger side checks the profile's `validation.game_build`
against the running game before every fire, with **exact string equality**.
Mismatch = no run, automatic report back to R&D. Stale profiles never execute.

A profile may only carry `status: validated` together with `validated_at`,
`rd_run_id`, and `evidence_ref` — the schema enforces this. Validation is a
provenance claim, not a flag.

## What's in a profile

| Section | Purpose |
|---|---|
| `profile_id`, `game`, `status` | Identity. Status is `draft` / `validated` / `deprecated` / `quarantined`. |
| `target` | What the cheat does, in plain language, plus the **transparent** intent phrases that may fire it. No hidden trigger words — sealed 2026-09-17. |
| `address_resolution` | How to find the address **fresh at fire time**. A recipe, never a baked address. AOB scan, pointer chain, save-file JSONPath, or config-file key. Carries its own time budget, cache policy, and invalidation events. |
| `value` | Data type, valid range (type-checked: numeric types need numeric bounds), what the value means. |
| `write_sequence` | The guarded steps: pre-read → assert (closed predicate grammar) → write (exactly one payload) → immediate readback → independent readback. Originals preserved for forensics only. |
| `trigger_rules` | Cooldowns, per-session fire caps, gating from a **closed enum**, mutually exclusive profiles. Behavior control lives in the profile (R&D's domain), not in trigger code. |
| `failure_policy` | Hardcoded fail-closed for divergent readback, resolution failure, and timeout. AOB scans must return **exactly one** match. **No auto-restore** — sealed 2026-09-17. All `const` in the schema, not choices. |
| `safety` | Vector classification (`memory-write` / `save-edit` / `config-file`) and durability rank from community evidence: save-edit > data tuning > wildcarded AOB > pointer > static offsets (never). |
| `validation` | Which exact game build this was proven against, when, by which R&D run, and what re-triggers validation. |

## Closed grammars (new in v0.1.1)

The v0.1.0 red-team found every free-text field was a hole. v0.1.1 closes them:

- **Predicates** (`write_sequence.steps[].predicate`): `{target: pre-read|readback,
  op: eq|ne|lt|lte|gt|gte|in-range|not-null, operand}`. The trigger side
  evaluates these mechanically. No expressions, no scripts, no strings
  pretending to be logic.
- **Tolerance**: `exact`, or `{epsilon: <positive number>}` for floats.
- **Save paths** (`save_field.json_path`): dot-notation and array indices
  only (`$.A.B[0].C`). No filters, no wildcards, no expressions — enforced by
  regex in the schema.
- **Gating** (`trigger_rules.gating`): closed enum
  (`single-player`, `private-session`, `game-focused`). New gates require a
  schema version bump — deliberately, so behavior changes stay visible.

## Loader rules (trigger-side, normative)

These are enforced by the trigger-side loader, stated here so R&D authors
against them:

1. Refuse any profile that fails schema validation.
2. Refuse any `validated` profile whose `game_build` doesn't exactly match
   the running game.
3. Refuse to load two `validated` profiles with overlapping `intent_phrases`
   — intent collisions are an R&D error, resolved in R&D, never at fire time.
4. Refuse any `validated` profile missing `validated_at`, `rd_run_id`, or
   `evidence_ref`.

## Known races and how v0.1.1 treats them

**TOCTOU (pre-read → assert → write vs. a multithreaded game):** acknowledged,
not eliminated. Mitigations, in order: the assert and the write are issued as
a tight pair with no intervening work; the immediate readback catches any
divergence; on divergence the fire fails closed and the event is reported to
R&D. The schema does not pretend the window is zero — it makes the window
small and the failure safe.

**Cache staleness:** a `per-session` cached address is invalidated on game
restart, build change, any divergent readback, or manual signal
(`invalidate_on`, defaulting to the first three). When in doubt the trigger
side re-resolves; resolution is budgeted, failure is closed.

## Design decisions baked in

1. **No baked addresses, ever.** Resolution recipe with a time budget; the
   trigger side remembers nothing across restarts it can't re-derive.
2. **Failure is always closed.** Fail-closed on divergent readback,
   resolution failure, and timeout are schema constants. A profile cannot
   opt out.
3. **Build stamps are the patch defense.** Exact-match build comparison plus
   the weekly research sweep and the Steam experimental branch as early
   warning: stale profiles die quietly instead of corrupting a patched game.
4. **Trigger behavior is data, not code.** Cooldowns, gating, and exclusions
   ship inside the profile so R&D tunes behavior without touching the
   trigger runtime.
5. **`preserve_original` is evidence, not a rollback mechanism.** There is no
   `restore` op and no automatic restore path — sealed 2026-09-17. The
   original is kept in the fire log for R&D forensics.
6. **HMAC stays dormant** (sealed 2026-09-17, unit-tested). The schema
   reserves an `integrity` section for activation later.

## Deliberately NOT in v0.1.1

- **Code-cave / injected-code semantics.** AOB-hook cheats that patch
  instructions (like the ModEngine stamina entry) need code-patch semantics
  the current `write_sequence` doesn't model. The example in
  `examples/nms-unlimited-stamina.mem.json` marks this boundary explicitly.
  v0.2 work.
- **Multi-address transactions** (all-or-nothing across several writes).
- **Conditional branching** inside the write sequence.
- Anything that weakens the fail-closed rule.

## Examples

- `examples/nms-units-max.save.json` — save-edit profile (the proven
  Units→2B path), illustrative values, status `draft`.
- `examples/nms-unlimited-stamina.mem.json` — memory AOB profile from the
  real ModEngine table pattern, marked where v0.1.1 stops.

## Changelog

- **v0.1.1** — Ensemble red-team hardening: closed predicate/tolerance
  grammars, restricted save-path dialect, exact-one AOB match policy,
  fail-closed on resolution failure and timeout, typed range bounds,
  exactly-one write payload, closed gating enum, removed `restore` op,
  `preserve_original` defined as evidence-only, `validated` status requires
  full provenance, build comparison fixed to exact match, loader rules
  (intent collisions, stale profiles), TOCTOU and cache-invalidation
  treatment.
- **v0.1.0** — Initial draft: R&D/trigger contract, guarded write sequence,
  fail-closed constants, build stamps.

## Changing this schema

Schema changes are R&D decisions: propose, ensemble-review, version-bump
(`schema_version` is a `const` — old profiles declare which schema they
were written against and the trigger side enforces it).
