# GameGPT Stage 1 R&D Copilot

Advisory-only assistant for cheat-discovery research. It suggests experiment
plans, ranks scan candidates, and drafts sealed profile JSONs. It **never**
touches game memory, never performs writes, and never asserts a finding as
fact — every output is a suggestion or a question for the human researcher.

Spec: `../specs/rd-copilot-stage1.md` (Sections 4–7).

## Files

| File | Role |
|---|---|
| `copilot.py` | CLI entry point (`plan` / `rank` / `draft`) |
| `planner.py` | Experiment planner: cheat goal → ordered experiment plan (baseline → drain → recover → isolate → authority test) + discovery-vector ordering (save edits → config/MBIN → AOB → pointer chains ≤2 → never static offsets) |
| `ranker.py` | Candidate ranker: hypothesis priors (spec §6) + value entropy across the experiment sequence + display-copy flag; confidence high/med/low with plain-language rationale |
| `drafter.py` | Profile drafter: confirmed candidate + session metadata → sealed profile JSON with the mandatory verification checklist as `verification_pending` (always `status: "draft"` — only the human review gate can validate) |

Stdlib only. No dependencies.

## Usage

```bash
# 1. Get an experiment plan for a cheat goal
python3 copilot.py plan "unlimited stamina"

# 2. Rank scan results (JSON: goal, scans with labels, results)
python3 copilot.py rank scans.json --goal "unlimited stamina"

# 3. Draft a sealed profile from a confirmed candidate
python3 copilot.py draft candidate.json --goal "unlimited stamina" \
    --build "5.12.3 (build 98765)" --out profile.json
```

### Scan-results JSON format

```json
{
  "goal": "unlimited stamina",
  "module_base": "0x7FF612340000",
  "scans": [
    {"scan_number": 0, "label": "baseline",
     "stimulus": "stamina full, standing still", "mode": "exact value"},
    {"scan_number": 1, "label": "drain",
     "stimulus": "sprinted until bar ~half", "mode": "decreased value"},
    {"scan_number": 2, "label": "recover",
     "stimulus": "stood still 10s", "mode": "increased value"}
  ],
  "results": [
    {"address": "0x2A4F8C10", "value": 1.0,
     "scan_number": 0, "value_type": "float"}
  ]
}
```

Label each scan with what you did in-game (`drain`, `recover`, `damage`,
`heal`, `fire`, `reload`, `earn`, `spend`, …). The ranker uses these labels
to check whether each candidate moved in the experiment's expected direction.

### Candidate JSON format (for `draft`)

```json
{
  "address": "0x2A4F8C10",
  "value_type": "float",
  "resolution_method": "aob_hook",
  "session": {
    "game": "No Man's Sky",
    "build": "5.12.3 (build 98765)",
    "module_base": "0x7FF612340000",
    "scans_performed": 4,
    "authority_test": "wrote 0.5, sprinted, drain resumed from modified base",
    "notes": "free text"
  }
}
```

`resolution_method`: `save_edit` | `config_tuning` | `aob_hook` |
`pointer_chain` | `unknown`.

## Trust boundaries (non-negotiable)

1. **Read-only.** The copilot ingests structured results. No write primitive,
   no attach, no script channel into the game process. Ever.
2. **Human commit gate.** Drafts are `status: "draft"` with the full
   verification checklist pending. Copilot output never upgrades a profile.
3. **Explicit uncertainty.** Below threshold (< 3 confirming scans, no seeded
   priors, display-likely) → `"confidence": "low"` with a plain-language
   warning. No silent best-guesses.
4. **Suggestions as questions.** "Could this be health? How will you verify?"
   — never "This is health."

## Ranking heuristics

- **Priors match** (§6 table): value type + plausible range for the goal
  category (stamina/heat float 0–1, currencies i64/u32, health float 0–100…).
- **Entropy**: candidates that move when the experiment demands it
  (drain → down, recover → up) rank above static ones.
- **Display-copy flag**: UI-scale round numbers that never move are marked
  `display-likely` and sink below authoritative-state candidates.
- **Confirming scans**: < 3 scans caps confidence at low.
- **Corpus bias**: unknown goals degrade to hypothesis-only mode (questions,
  not findings); the corpus composition is always displayed.

## Verification checklist (draft gate)

Every drafted profile carries these six items as `verification_pending`
(spec §7). The draft cannot become `validated` until a human completes all
of them in tooling:

1. Authoritative address confirmed via **external stimulus**.
2. Min / max / mid writes tested; game sane at each.
3. ±32 bytes adjacent memory verified uncorrupted.
4. Assert predicates deliberately failed (no tautologies).
5. Human documents why the address is authoritative and why each guard guards.
6. Every evidence reference resolves to a real file in the hashed manifest.

## AOB corpus adapter (2026-09-19)

`corpus_adapter.py` bridges the structured NMS AOB corpus into the copilot:

- `copilot.py corpus "<goal>"` — look up known AOB patterns for a cheat goal
- `copilot.py plan "<goal>"` — now includes corpus hits alongside the experiment plan
- `--include-quarantined` — surface crash-labeled entries (excluded by default)
- `--no-corpus` — skip the lookup

Corpus: `../research/no-mans-sky/aob-corpus.json` (49 entries, 3 quarantined,
provenance hash embedded per entry). See `../research/no-mans-sky/` for the
extraction summary and the AMUMSS/Lua-vs-Cheat-Engine comparison.
