"""
GameGPT Stage 1 R&D Copilot — experiment planner (planner.py)

Advisory only. This module suggests experiment sequences and discovery vectors
for cheat research; it never performs writes, never touches game memory, and
never asserts a finding as fact. All output is framed as suggestions and
questions for the human researcher to verify.

Spec reference: ~/workspace/gamegpt/specs/rd-copilot-stage1.md, Sections 4–5.
"""

from __future__ import annotations

# ---------------------------------------------------------------------------
# Goal categories: keyword matching + seeded priors (spec Section 6)
# ---------------------------------------------------------------------------

GOAL_CATEGORIES: dict[str, dict] = {
    "stamina": {
        "keywords": ("stamina", "sprint", "endurance", "run"),
        "label": "stamina (drain/recover rate)",
        "likely_types": ["float"],
        "type_alternatives": ["double"],
        "plausible_range": "0.0–1.0 (or 0–100)",
        "priors_confidence": "High",
        "cycle": ("drain", "recover"),
        "authority_stimulus": (
            "sprint in-game and watch whether the real drain resumes from the "
            "modified base — a display copy passes readback but fails this test"
        ),
    },
    "heat": {
        "keywords": ("heat", "overheat", "temperature"),
        "label": "heat / overheat (accumulation rate)",
        "likely_types": ["float"],
        "type_alternatives": ["double"],
        "plausible_range": "0.0–1.0 (or 0–100)",
        "priors_confidence": "High",
        "cycle": ("accumulate", "cool"),
        "authority_stimulus": (
            "fire the weapon / run the engine in-game and watch whether heat "
            "accumulates from the modified base"
        ),
    },
    "health": {
        "keywords": ("health", "hp", "hitpoints", "hit points", "life"),
        "label": "health (player/ship)",
        "likely_types": ["float"],
        "type_alternatives": ["double", "i32"],
        "plausible_range": "0.0–100.0",
        "priors_confidence": "Med",
        "cycle": ("damage", "heal"),
        "authority_stimulus": (
            "take a hit in-game and watch whether the damage lands on the "
            "modified value rather than a copy"
        ),
    },
    "ammo": {
        "keywords": ("ammo", "bullets", "rounds", "energy", "charge"),
        "label": "ammo / energy (consumable pool)",
        "likely_types": ["i32", "float"],
        "type_alternatives": ["i16"],
        "plausible_range": "0–MaxClip / 0.0–100.0",
        "priors_confidence": "Med",
        "cycle": ("fire", "reload"),
        "authority_stimulus": (
            "fire in-game and watch whether the count decrements from the "
            "modified base"
        ),
    },
    "currency": {
        "keywords": ("units", "nanites", "currency", "credits", "money", "coins",
                     "gold", "score", "points"),
        "label": "currency (accumulating counter)",
        "likely_types": ["i64", "u32"],
        "type_alternatives": ["i32"],
        "plausible_range": "0–4,294,967,295",
        "priors_confidence": "High",
        "cycle": ("earn", "spend"),
        "authority_stimulus": (
            "earn or spend in-game and watch whether the total updates from "
            "the modified value"
        ),
    },
    "cooldown": {
        "keywords": ("cooldown", "timer", "crafting", "delay", "recharge"),
        "label": "cooldown / timer",
        "likely_types": ["float"],
        "type_alternatives": ["i64"],
        "plausible_range": "0.0–T_max seconds",
        "priors_confidence": "Med",
        "cycle": ("trigger", "expire"),
        "authority_stimulus": (
            "trigger the ability in-game and watch whether the timer runs "
            "from the modified value"
        ),
    },
    "speed": {
        "keywords": ("speed", "velocity", "multiplier", "movement"),
        "label": "speed multiplier",
        "likely_types": ["float"],
        "type_alternatives": ["double"],
        "plausible_range": "1.0–10.0",
        "priors_confidence": "Med",
        "cycle": ("boost", "normal"),
        "authority_stimulus": (
            "move in-game and watch whether the motion reflects the "
            "modified multiplier"
        ),
    },
    "position": {
        "keywords": ("position", "coordinates", "teleport", "location", "x/y/z",
                     "xyz"),
        "label": "position / coordinates",
        "likely_types": ["float[3]", "double[3]"],
        "type_alternatives": ["float"],
        "plausible_range": "planetary scale",
        "priors_confidence": "Low",
        "cycle": ("move", "compare"),
        "authority_stimulus": (
            "move in-game and watch whether the world position tracks the "
            "modified coordinates"
        ),
    },
    "damage": {
        "keywords": ("damage", "dps", "attack", "outgoing"),
        "label": "outgoing damage (multiplier)",
        "likely_types": ["float"],
        "type_alternatives": ["double"],
        "plausible_range": "1.0–10⁶",
        "priors_confidence": "Low",
        "cycle": ("hit", "compare"),
        "authority_stimulus": (
            "strike a target in-game and watch whether the damage scales "
            "with the modified multiplier"
        ),
    },
}

# Prefixes humans use when naming goals; stripped before keyword matching.
_GOAL_PREFIXES = ("unlimited ", "infinite ", "no ", "max ", "godmode ",
                  "god mode ", "one-hit ", "permanent ")


def normalize_goal(cheat_goal: str) -> str:
    """Lowercase a cheat goal and strip common request prefixes."""
    goal = cheat_goal.strip().lower()
    for prefix in _GOAL_PREFIXES:
        if goal.startswith(prefix):
            goal = goal[len(prefix):]
            break
    return goal


def classify_goal(cheat_goal: str) -> tuple[str | None, dict | None]:
    """
    Return (category_key, category_data) for a cheat goal, or (None, None)
    when the goal matches no seeded priors (hypothesis-only mode per spec
    Section 6: questions, not ranked suggestions).
    """
    goal = normalize_goal(cheat_goal)
    for key, data in GOAL_CATEGORIES.items():
        if any(kw in goal for kw in data["keywords"]):
            return key, data
    return None, None


# ---------------------------------------------------------------------------
# Experiment plan generation (spec Section 5)
# ---------------------------------------------------------------------------

def build_experiment_plan(cheat_goal: str) -> dict:
    """
    Build an ordered experiment plan for a cheat goal.

    Returns a dict with: goal, category, priors, corpus_note, phases,
    discovery_vectors. Every phase carries the human's in-game action, the
    suggested scan mode, and explicit success criteria. Advisory language
    throughout — the human performs every action.
    """
    category_key, category = classify_goal(cheat_goal)
    known = category is not None
    if not known:
        # Hypothesis-only mode: generic plan, priors unknown.
        category = {
            "label": "unclassified — hypothesis-only mode",
            "likely_types": ["unknown — start with unknown-initial-value scan"],
            "type_alternatives": ["float", "i32", "i64"],
            "plausible_range": "unknown",
            "priors_confidence": "Low (no seeded priors)",
            "cycle": ("change", "observe"),
            "authority_stimulus": (
                "perform the in-game action tied to the goal and watch "
                "whether the effect reflects the modified value"
            ),
        }
        category_key = "unclassified"

    cycle_down, cycle_up = category["cycle"]
    label = category["label"]

    phases = [
        {
            "step": 1,
            "name": "Baseline",
            "human_action": (
                f"Put the game in a neutral state for {label} "
                f"(e.g. full {cycle_down} pool, standing still, no effects active)."
            ),
            "suggested_scan": (
                f"exact-value or unknown-initial-value scan; value type "
                f"{category['likely_types'][0]} "
                f"(alternatives if the set looks wrong: "
                f"{', '.join(category['type_alternatives'])})"
            ),
            "success_criteria": (
                "Candidate set is captured; note the count. "
                "Could the top candidates plausibly live in the player struct?"
            ),
        },
        {
            "step": 2,
            "name": f"{cycle_down.capitalize()}",
            "human_action": (
                f"In-game, drive {label} in the {cycle_down} direction "
                f"(e.g. sprint, take damage, fire, spend)."
            ),
            "suggested_scan": "decreased-value (or changed-value) rescan",
            "success_criteria": (
                "Candidate set shrinks. The survivors should track the on-screen "
                f"value as it {cycle_down}s — do they?"
            ),
        },
        {
            "step": 3,
            "name": f"{cycle_up.capitalize()}",
            "human_action": (
                f"In-game, drive {label} in the {cycle_up} direction "
                f"(e.g. stand still, heal, reload, earn)."
            ),
            "suggested_scan": "increased-value (or changed-value) rescan",
            "success_criteria": (
                "Candidate set shrinks further. Survivors should track the "
                f"on-screen value as it {cycle_up}s. "
                "A value that moved on drain but not on recover is suspicious — "
                "could it be a display copy?"
            ),
        },
        {
            "step": 4,
            "name": "Isolate",
            "human_action": (
                f"Repeat the {cycle_down}/{cycle_up} cycle until the candidate "
                "set is small (single digits is a good target)."
            ),
            "suggested_scan": "alternating decreased/increased rescans; consider an unchanged-value scan while idle to cull noise",
            "success_criteria": (
                "Small candidate set. Rank per the copilot's ranker before "
                "touching anything — which candidates moved when they should "
                "and stayed still when they shouldn't?"
            ),
        },
        {
            "step": 5,
            "name": "Authority test (human performs the write)",
            "human_action": (
                "In Cheat Engine, write a test value to the top candidate. "
                "Then apply an EXTERNAL STIMULUS in-game: "
                f"{category['authority_stimulus']}."
            ),
            "suggested_scan": "none — observe the game itself",
            "success_criteria": (
                "PASS: the in-game effect reflects the modified base "
                "(authoritative address). FAIL: readback looks right but the "
                "game ignores it (display copy — go back to step 4). "
                "How will you rule out a display copy before drafting a profile?"
            ),
        },
    ]

    return {
        "goal": cheat_goal,
        "category": category_key,
        "category_label": label,
        "known_priors": known,
        "priors": {
            "likely_types": category["likely_types"],
            "type_alternatives": category["type_alternatives"],
            "plausible_range": category["plausible_range"],
            "confidence": category["priors_confidence"],
        },
        "corpus_note": (
            "Priors seeded from the No Man's Sky research corpus "
            "(critically narrow: two real AOBs). Confidence degrades for "
            "under-represented engines — treat these as hypotheses, not facts."
        ),
        "phases": phases,
        "discovery_vectors": build_discovery_vectors(category_key, cheat_goal),
        "advisory": (
            "This plan is a suggestion, not an instruction. Every in-game "
            "action and every write is performed by you, the human researcher. "
            "The copilot never touches the game."
        ),
    }


def build_discovery_vectors(category_key: str, cheat_goal: str) -> list[dict]:
    """
    Ordered discovery vectors per spec Section 5 (durability ranking):
    save edits → config/MBIN → AOB → pointer chains (≤2) → never static offsets.
    """
    tuning_hint = {
        "stamina": "check GCPLAYERGLOBALS.GLOBAL for stamina drain/recover tuning",
        "heat": "check GCPLAYERGLOBALS.GLOBAL for heat accumulation tuning",
        "health": "check player globals for health tuning",
        "ammo": "check weapon globals for clip/energy tuning",
        "speed": "check engine/player globals for speed multipliers",
    }.get(category_key)
    mbins = (
        f" First look: {tuning_hint} — a tuning variable needs no memory write."
        if tuning_hint
        else " Check the game's config/MBIN globals for a tuning variable tied to this goal — a tuning change needs no memory write."
    )
    return [
        {
            "rank": 1,
            "vector": "save edits",
            "why": "Schema-stable across versions; immune to runtime memory shifts.",
            "suggested_first_step": (
                f"Does the {cheat_goal} value persist in a save file? "
                "If yes, a save edit may be the most durable path — could you inspect a save?"
            ),
        },
        {
            "rank": 2,
            "vector": "config / MBIN data tuning",
            "why": "Survives recompiles; no code injection.",
            "suggested_first_step": mbins.strip(),
        },
        {
            "rank": 3,
            "vector": "wildcarded AOB hook",
            "why": "Default runtime mechanism; wildcards absorb relocation drift. Caveat: hotfixes rot AOBs (observed: 4 trainer compat pushes in 5 days).",
            "suggested_first_step": (
                "If the value is a drain/accumulation rate, mask for the AOB shape rule "
                "(spec Section 6): SSE scalar float load F3 0F 10 [ModR/M] [4-byte offset] "
                "off a persistent base register, at a deep struct offset (>0x1000). "
                "Derive from ≥3 separate game launches and justify every wildcard."
            ),
        },
        {
            "rank": 4,
            "vector": "pointer chains (≤2 indirections)",
            "why": "Fragile — suggested only at ≤2 levels; deeper is flagged high-fragility and must validate across game states (menu, gameplay, pause, transition).",
            "suggested_first_step": (
                "Could a pointer scan from the candidate reach a stable module base "
                "within 2 hops? If it needs more, prefer the AOB vector instead."
            ),
        },
        {
            "rank": 5,
            "vector": "static offsets — NOT SUGGESTED",
            "why": "Dead on arrival against rebuild pipelines. Listed only so it is explicitly excluded.",
            "suggested_first_step": "None. Do not use static offsets.",
        },
    ]


# ---------------------------------------------------------------------------
# Human-readable rendering
# ---------------------------------------------------------------------------

def render_plan(plan: dict) -> str:
    """Render an experiment plan as readable advisory text."""
    lines = [
        f"Experiment plan — {plan['goal']}",
        f"Category: {plan['category_label']}",
        f"Priors: types {', '.join(plan['priors']['likely_types'])}; "
        f"range {plan['priors']['plausible_range']}; "
        f"confidence {plan['priors']['confidence']}",
        f"Corpus note: {plan['corpus_note']}",
        "",
        "Discovery vectors (try in this order):",
    ]
    for v in plan["discovery_vectors"]:
        lines.append(f"  {v['rank']}. {v['vector']} — {v['why']}")
        lines.append(f"     Suggested first step: {v['suggested_first_step']}")
    lines.append("")
    lines.append("Experiment phases:")
    for p in plan["phases"]:
        lines += [
            f"",
            f"  Step {p['step']} — {p['name']}",
            f"    Your action: {p['human_action']}",
            f"    Suggested scan: {p['suggested_scan']}",
            f"    Success looks like: {p['success_criteria']}",
        ]
    lines += ["", plan["advisory"]]
    return "\n".join(lines)
