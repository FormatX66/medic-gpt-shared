# NMS BD Cheat Table — AOB Corpus Summary

- **Source file:** `No Man's Sky - BD - CT V1.32.CT` (Cheat Engine 45 XML, 160,393 bytes)
- **Provenance SHA-256:** `b5313bc8cb05d3f73f9a78d5e9507e77310a823d36dfca8a6d0d7597c99fe095`
- **AA scripts parsed:** 46 (of 75 total cheat entries)
- **AOB pattern entries:** 49 (49 `aobscanmodule` calls; this table uses exact byte patterns — no wildcards)
- **Quarantined entries:** 3 (under the "Test Scripts - Do not use..... Game Crash" group)
- **Target module:** {'NMS.exe': 49}
- **Total pattern bytes:** 486
- **Injection forms:** 42 jmp-to-newmem hooks, 46 use alloc(); all target `NMS.exe`

## Category breakdown

| Category | Count |
|---|---|
| multitool | 10 |
| starship | 9 |
| jetpack | 5 |
| hazard/environment | 5 |
| exocraft | 4 |
| shields | 3 |
| crafting/refiner | 3 |
| inventory/quantity | 3 |
| stamina | 1 |
| life_support | 1 |
| health | 1 |
| cloak | 1 |
| exosuit | 1 |
| currency | 1 |
| movement/speed | 1 |

## Quarantined (do NOT use for live research)

- `No Boltcaster Over Heat New` (label: `INJECT`) — group: "Test Scripts - Do not use..... Game Crash"
- `No Boltcaster Over Heat` (label: `NOBLASTERCOOL`) — group: "Test Scripts - Do not use..... Game Crash"
- `Unlimited Shields` (label: `AOBShields`) — group: "Test Scripts - Do not use..... Game Crash"

## Notes

- All 49 patterns are exact byte matches (0 wildcards). Patterns range 6–11 bytes.
- One AA script ("nMax out current inventory items...") uses a hardcoded
  `define(address,"NMS.exe"+...)` instead of AOBScan — no pattern entry was created for it,
  but it is listed here for completeness: it edits inventory quantities directly and is NOT
  under the crash-test group.
- 3 of the 4 scripts under the crash-test group contain AOB scans and are quarantined above;
  the 4th (inventory max-out) has no scan and is not in the corpus.
- Corpus is inert parsing only — nothing was executed, attached, or validated against a live game.
- The `ranker.py` R&D copilot currently consumes structured scan-result JSON; a dedicated
  ingestion adapter is still required to feed these raw AOB patterns into it.
