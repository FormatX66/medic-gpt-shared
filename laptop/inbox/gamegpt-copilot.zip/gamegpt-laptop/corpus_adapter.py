"""
GameGPT Stage 1 R&D Copilot — AOB corpus ingestion adapter (corpus_adapter.py)

Bridges the structured AOB pattern corpus (extracted from Cheat Engine tables)
into the copilot's workflow. The ranker works on live scan results; this adapter
provides prior knowledge: "for this cheat goal, here are known-good AOB patterns
from the corpus."

Quarantined entries (crash-labeled) are excluded by default and only surfaced
with an explicit flag, always marked as quarantined.

Corpus schema (per entry):
    script_name, group_path, pattern_label, target_module, aob_bytes,
    byte_count, wildcard_positions, wildcard_count, injection {...},
    quarantine (bool), category, script_text, provenance_hash
"""

from __future__ import annotations

import json
import re
from pathlib import Path

def _find_corpus() -> Path:
    here = Path(__file__).resolve().parent
    candidates = [
        here / "corpus" / "aob-corpus.json",  # laptop package layout
        here.parent / "research" / "no-mans-sky" / "aob-corpus.json",  # repo layout
    ]
    for c in candidates:
        if c.is_file():
            return c
    return candidates[0]


DEFAULT_CORPUS = _find_corpus()

# Goal keyword -> corpus categories. Kept deliberately broad; the copilot
# refines with the planner's goal classification.
_GOAL_CATEGORY_HINTS: dict[str, list[str]] = {
    "stamina": ["stamina"],
    "sprint": ["stamina", "movement/speed"],
    "run": ["stamina", "movement/speed"],
    "health": ["health"],
    "shield": ["shields"],
    "jetpack": ["jetpack"],
    "boost": ["jetpack", "starship"],
    "life support": ["life_support", "life-support"],
    "hazard": ["hazard/environment", "hazard"],
    "environment": ["hazard/environment", "hazard"],
    "cloak": ["cloak"],
    "exocraft": ["exocraft"],
    "starship": ["starship"],
    "ship": ["starship"],
    "multitool": ["multitool"],
    "weapon": ["multitool"],
    "boltcast": ["multitool"],
    "craft": ["crafting/refiner", "crafting"],
    "refin": ["crafting/refiner", "crafting"],
    "inventory": ["inventory/quantity", "inventory"],
    "unit": ["currency"],
    "nanite": ["currency"],
    "quicksilver": ["currency"],
    "standing": ["standings"],
    "reputation": ["standings"],
    "speed": ["movement/speed", "movement"],
    "exosuit": ["exosuit"],
}


def load_corpus(path: str | Path | None = None) -> list[dict]:
    """Load the AOB corpus JSON. Returns [] if missing/unreadable."""
    p = Path(path) if path else DEFAULT_CORPUS
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return []


def _normalize(text: str) -> str:
    return re.sub(r"[^a-z0-9]+", " ", text.lower()).strip()


def _goal_keywords(goal: str) -> set[str]:
    return set(_normalize(goal).split())


def _entry_text(entry: dict) -> str:
    parts = [entry.get("script_name", ""), entry.get("category", "")]
    parts.extend(entry.get("group_path", []))
    return _normalize(" ".join(parts))


def find_relevant(
    goal: str,
    corpus: list[dict] | None = None,
    include_quarantined: bool = False,
    max_results: int = 10,
) -> list[dict]:
    """
    Find corpus entries relevant to a cheat goal.

    Scoring: category hint match (2 pts) + keyword overlap on name/group (1 pt
    per shared token). Quarantined entries are excluded unless
    include_quarantined=True, and are always flagged in the output.
    Returns slimmed dicts sorted by score desc, then script name.
    """
    entries = corpus if corpus is not None else load_corpus()
    goal_norm = _normalize(goal)
    keywords = _goal_keywords(goal)

    # Categories hinted by goal keywords.
    hinted: set[str] = set()
    for kw, cats in _GOAL_CATEGORY_HINTS.items():
        if kw in goal_norm:
            hinted.update(_normalize(c) for c in cats)

    scored: list[tuple[int, dict]] = []
    for e in entries:
        if e.get("quarantine") and not include_quarantined:
            continue
        cat_norm = _normalize(e.get("category", ""))
        score = 0
        if cat_norm and cat_norm in hinted:
            score += 2
        text_tokens = set(_entry_text(e).split())
        score += len(keywords & text_tokens)
        if score > 0:
            scored.append((score, e))

    scored.sort(key=lambda t: (-t[0], t[1].get("script_name", "")))
    out = []
    for score, e in scored[:max_results]:
        out.append(
            {
                "script_name": e.get("script_name"),
                "category": e.get("category"),
                "pattern_label": e.get("pattern_label"),
                "target_module": e.get("target_module"),
                "aob_bytes": e.get("aob_bytes"),
                "byte_count": e.get("byte_count"),
                "wildcard_count": e.get("wildcard_count", 0),
                "injection_form": {
                    k: v
                    for k, v in e.get("injection", {}).items()
                    if k.startswith("uses_")
                },
                "quarantine": bool(e.get("quarantine")),
                "relevance_score": score,
                "provenance_hash": e.get("provenance_hash"),
            }
        )
    return out


def render_corpus_hits(hits: list[dict]) -> str:
    """Human-readable summary of corpus hits for the copilot to display."""
    if not hits:
        return "No known AOB patterns in the corpus match this goal."
    lines = ["Known AOB patterns from corpus (prior knowledge, not validated):"]
    for h in hits:
        q = " [QUARANTINED — do not use]" if h["quarantine"] else ""
        lines.append(
            f"  - {h['script_name']} ({h['category']}){q}\n"
            f"    AOB: {h['aob_bytes']}  [{h['byte_count']} bytes, "
            f"{h['wildcard_count']} wildcards]  score={h['relevance_score']}"
        )
    lines.append(
        "These are starting points for live validation, not confirmed addresses."
    )
    return "\n".join(lines)


def corpus_stats(corpus: list[dict] | None = None) -> dict:
    """Quick stats for diagnostics."""
    entries = corpus if corpus is not None else load_corpus()
    cats: dict[str, int] = {}
    quarantined = 0
    for e in entries:
        cats[e.get("category", "?")] = cats.get(e.get("category", "?"), 0) + 1
        if e.get("quarantine"):
            quarantined += 1
    return {
        "total": len(entries),
        "quarantined": quarantined,
        "categories": cats,
    }
