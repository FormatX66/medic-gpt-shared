"""
GameGPT Stage 1 R&D Copilot — candidate ranker (ranker.py)

Takes structured scan results and ranks candidates with grounded heuristics
(spec Sections 4 and 6):

  - hypothesis priors: value type + plausible range matched to the cheat goal;
  - value entropy: does the value move when the experiment says it should,
    and stay still when it shouldn't;
  - display-copy flag: round numbers at UI scale, or values that fail to track
    the experiment stimulus, are marked `display-likely` and ranked below
    authoritative-state candidates.

Advisory only: output is suggestions and questions, never assertions. Below
threshold → "low" confidence with a plain-language warning (spec Section 2).

Expected input JSON:
{
  "goal": "unlimited stamina",
  "module_base": "0x7FF600000000",          # optional, for proximity notes
  "scans": [                                # experiment context per scan
    {"scan_number": 0, "label": "baseline",
     "stimulus": "stamina full, standing still", "mode": "exact value"},
    {"scan_number": 1, "label": "drain",
     "stimulus": "sprinted until bar ~half", "mode": "decreased value"},
    ...
  ],
  "results": [                              # one entry per address per scan
    {"address": "0x1A2B3C", "value": 1.0,
     "scan_number": 0, "value_type": "float"},
    ...
  ]
}

Stimulus labels drive the entropy check: scans labelled "drain"/"damage"/"fire"/
"earn"/"trigger"/"move" should show a decrease (or change) from baseline; scans
labelled "recover"/"heal"/"reload"/"spend"/"expire"/"compare" should show the
opposite movement. Labels are matched loosely by keyword.
"""

from __future__ import annotations

import math
from collections import defaultdict

from planner import classify_goal, GOAL_CATEGORIES

# ---------------------------------------------------------------------------
# Heuristic constants
# ---------------------------------------------------------------------------

# A candidate needs at least this many confirming scans before it can be
# ranked above "low" (spec Section 2: explicit uncertainty markers).
MIN_CONFIRMING_SCANS = 3

# Labels whose scans should show the value moving DOWN from baseline.
DOWN_LABELS = ("drain", "damage", "fire", "spend", "trigger", "move",
               "hit", "accumulate", "change")
# Labels whose scans should show the value moving UP from the drained state.
UP_LABELS = ("recover", "heal", "reload", "earn", "expire", "compare",
             "cool", "normal", "observe")


def _label_direction(label: str) -> str | None:
    label = label.lower()
    if any(k in label for k in DOWN_LABELS):
        return "down"
    if any(k in label for k in UP_LABELS):
        return "up"
    return None


def _is_round_number(value) -> bool:
    """
    Round numbers at UI scale (100.0, 50.0, 1000) smell like display copies.
    Integer-valued floats only count when they're multiples of 10 — a bare
    1.0 (full bar) or 0.5 is too common in authoritative state to flag.
    """
    if isinstance(value, bool):
        return False
    if isinstance(value, int):
        return value != 0 and value % 10 == 0 and abs(value) <= 1_000_000
    if isinstance(value, float):
        return (value != 0.0 and value.is_integer()
                and int(value) % 10 == 0 and abs(value) <= 1_000_000)
    return False


def _in_plausible_range(value, plausible_range: str) -> bool | None:
    """Best-effort range check against the priors table strings."""
    try:
        v = float(value)
    except (TypeError, ValueError):
        return None
    rng = plausible_range
    if "0.0–1.0" in rng or "0.0-1.0" in rng:
        return 0.0 <= v <= 1.0 or 0.0 <= v <= 100.0
    if "0.0–100.0" in rng or "0–MaxClip" in rng:
        return 0.0 <= v <= 100.0 or 0 <= v <= 9999
    if "4,294,967,295" in rng:
        return 0 <= v <= 4_294_967_295
    if "1.0–10" in rng:
        return 0.5 <= v <= 10.0 or 1.0 <= v <= 1e6
    if "planetary" in rng:
        return abs(v) > 100.0
    return None  # unknown range format — don't penalize


def _type_matches(value_type: str, likely_types: list[str]) -> bool:
    vt = value_type.strip().lower()
    return any(lt.lower() in vt or vt in lt.lower() for lt in likely_types)


# ---------------------------------------------------------------------------
# Trajectory / entropy analysis
# ---------------------------------------------------------------------------

def _trajectory(values_by_scan: dict[int, object]) -> dict:
    """Summarize how a candidate's value moved across scans."""
    ordered = [values_by_scan[s] for s in sorted(values_by_scan)]
    nums = []
    for v in ordered:
        try:
            nums.append(float(v))
        except (TypeError, ValueError):
            nums.append(None)
    real = [n for n in nums if n is not None]
    if not real:
        return {"moves": False, "variance": 0.0, "deltas": []}
    deltas = [b - a for a, b in zip(real, real[1:]) if a is not None and b is not None]
    mean = sum(real) / len(real)
    var = sum((x - mean) ** 2 for x in real) / len(real)
    moves = any(abs(d) > 1e-9 for d in deltas)
    return {"moves": moves, "variance": var, "deltas": deltas,
            "first": real[0], "last": real[-1]}


def _entropy_score(traj: dict, scan_dirs: dict[int, str | None]) -> tuple[float, list[str]]:
    """
    Score 0..1: does the value move when the experiment demands it?
    Returns (score, notes).
    """
    notes: list[str] = []
    if not traj["moves"]:
        return 0.0, ["value never changed across scans — "
                     "could this be unrelated, or a frozen display copy?"]
    score = 0.4  # it moves at all: partial credit
    notes.append("value changed across scans")
    # Direction check: compare each delta against the LATER scan's direction.
    correct = 0
    checked = 0
    deltas = traj["deltas"]
    scan_list = sorted(scan_dirs)
    for idx, d in enumerate(deltas):
        if idx + 1 >= len(scan_list):
            break
        direction = scan_dirs.get(scan_list[idx + 1])
        if direction is None:
            continue
        checked += 1
        if direction == "down" and d < -1e-9:
            correct += 1
        elif direction == "up" and d > 1e-9:
            correct += 1
    if checked:
        frac = correct / checked
        score += 0.6 * frac
        notes.append(
            f"moved in the experiment's expected direction in "
            f"{correct}/{checked} directional scans"
        )
        if frac < 0.5:
            notes.append("warning: often moved opposite to the experiment — "
                         "could this be noise or a different variable?")
    else:
        notes.append("no directional scan labels to check movement against — "
                     "consider labelling scans (drain/recover/...) next session")
    return min(score, 1.0), notes


# ---------------------------------------------------------------------------
# Ranking
# ---------------------------------------------------------------------------

def rank_candidates(payload: dict) -> dict:
    """
    Rank scan-result candidates. Returns a dict with goal, corpus note, and
    ranked candidate list (best first). Advisory language throughout.
    """
    goal = payload.get("goal", "")
    _, category = classify_goal(goal)
    known = category is not None
    if not known:
        category = {
            "likely_types": [],
            "plausible_range": "unknown",
            "priors_confidence": "Low (no seeded priors)",
        }

    scans = {s.get("scan_number"): s for s in payload.get("scans", [])}
    scan_dirs = {n: _label_direction(s.get("label", "")) for n, s in scans.items()}

    by_address: dict[str, dict[int, object]] = defaultdict(dict)
    addr_type: dict[str, str] = {}
    for r in payload.get("results", []):
        addr = str(r.get("address"))
        by_address[addr][int(r.get("scan_number", 0))] = r.get("value")
        addr_type[addr] = str(r.get("value_type", "unknown"))

    ranked = []
    for addr, values_by_scan in by_address.items():
        vtype = addr_type.get(addr, "unknown")
        traj = _trajectory(values_by_scan)
        confirming = len(values_by_scan)
        rationale: list[str] = []
        score = 0.0
        flags: list[str] = []

        # 1. Type match against priors.
        if known and _type_matches(vtype, category["likely_types"]):
            score += 0.25
            rationale.append(
                f"value type '{vtype}' matches priors for this goal "
                f"({', '.join(category['likely_types'])})"
            )
        elif known:
            rationale.append(
                f"value type '{vtype}' does NOT match expected "
                f"({', '.join(category['likely_types'])}) — could this be "
                f"type confusion? What alternatives have you tried?"
            )
        else:
            rationale.append("no seeded priors for this goal — treating as hypothesis only")

        # 2. Range plausibility.
        in_range = _in_plausible_range(traj.get("first"), category["plausible_range"])
        if in_range:
            score += 0.15
            rationale.append(
                f"baseline value {traj['first']} sits inside the plausible range "
                f"({category['plausible_range']})"
            )
        elif in_range is False:
            rationale.append(
                f"baseline value {traj['first']} is outside the plausible range "
                f"({category['plausible_range']}) — worth a second look before trusting it"
            )

        # 3. Entropy / experiment tracking.
        ent, ent_notes = _entropy_score(traj, scan_dirs)
        score += 0.45 * ent
        rationale.extend(ent_notes)

        # 4. Display-copy heuristics.
        # Flag only when the value is UI-round, never moved, AND had at least
        # two scans in which to move — a single-scan candidate is merely
        # unconfirmed, not display-likely.
        display_likely = False
        if (_is_round_number(traj.get("first")) and not traj["moves"]
                and confirming >= 2):
            display_likely = True
            flags.append("display-likely")
            rationale.append(
                "round number that never moves — this smells like a UI display "
                "copy rather than the authoritative value. Ranked below "
                "moving candidates; how would you rule it out?"
            )
        elif _is_round_number(traj.get("first")):
            rationale.append(
                "round baseline number — not disqualifying on its own, but "
                "display copies often look like this; the authority test will tell"
            )

        # 5. Confirming-scan count (spec Section 2 uncertainty marker).
        if confirming >= MIN_CONFIRMING_SCANS:
            score += 0.15
            rationale.append(f"seen in {confirming} scans (meets the ≥3 confirming-scan bar)")
        else:
            rationale.append(
                f"seen in only {confirming} scan(s) — below the 3-confirming-scan "
                f"bar; treat any read of this candidate as tentative"
            )

        # Confidence assignment.
        if not known:
            confidence = "low"
            rationale.append(
                "CONFIDENCE LOW: no seeded priors for this goal (corpus bias — "
                "the corpus is ~78% Unreal-pattern NMS data). Hypothesis-only: "
                "what experiment would confirm or kill this candidate?"
            )
        elif display_likely or ent < 0.3 or confirming < MIN_CONFIRMING_SCANS:
            confidence = "low"
            rationale.append(
                "CONFIDENCE LOW — do not draft a profile from this candidate "
                "yet. What would raise it: more confirming scans, clean "
                "directional movement, a non-round baseline."
            )
        elif score >= 0.75:
            confidence = "high"
            rationale.append(
                "Candidate looks promising — but 'promising' is not 'confirmed'. "
                "Could the authority test (external stimulus) still fail?"
            )
        else:
            confidence = "med"
            rationale.append(
                "Plausible but not convincing yet — what single experiment "
                "would most efficiently confirm or eliminate it?"
            )

        ranked.append({
            "address": addr,
            "value_type": vtype,
            "confidence": confidence,
            "display_likely": display_likely,
            "confirming_scans": confirming,
            "score": round(score, 3),
            "rationale": rationale,
            "suggested_next": (
                "Consider the authority test on this candidate — write a test "
                "value yourself, then apply an in-game stimulus and watch for "
                "the real effect. A display copy will pass readback and fail there."
                if confidence in ("high", "med") else
                "Consider gathering more scans before the authority test — "
                "can you label each scan with what you did in-game (drain/recover/...)?"
            ),
        })

    # Authoritative-state candidates first; display-likely always sinks.
    ranked.sort(key=lambda c: (c["display_likely"], -c["score"]))

    return {
        "goal": goal,
        "corpus_note": (
            "Priors seeded from the NMS research corpus (critically narrow: "
            "two real AOBs; ~78% Unreal-pattern data). Below-threshold engine "
            "coverage degrades to hypothesis-only mode."
        ) if known else (
            "No seeded priors matched this goal — hypothesis-only mode. "
            "Rankings below are questions, not findings."
        ),
        "candidates": ranked,
        "advisory": (
            "Suggestions only. The copilot never asserts an address is correct — "
            "only your authority test (external stimulus) can do that."
        ),
    }


def render_ranking(result: dict) -> str:
    """Render a ranking as readable advisory text."""
    lines = [
        f"Candidate ranking — {result['goal']}",
        f"Corpus note: {result['corpus_note']}",
        "",
    ]
    if not result["candidates"]:
        return "\n".join(lines + ["No candidates found in the scan results."])
    for i, c in enumerate(result["candidates"], 1):
        flag = " [DISPLAY-LIKELY]" if c["display_likely"] else ""
        lines.append(
            f"{i}. {c['address']} ({c['value_type']}) — "
            f"confidence: {c['confidence'].upper()}{flag}"
        )
        for r in c["rationale"]:
            lines.append(f"   - {r}")
        lines.append(f"   Suggested next: {c['suggested_next']}")
        lines.append("")
    lines.append(result["advisory"])
    return "\n".join(lines)
