"""
GameGPT Stage 1 R&D Copilot — desktop GUI (gui.py)

Simple tkinter interface over the copilot modules. Stdlib only, no installs.
Run:  python gui.py

Tabs:
  Plan    — enter a cheat goal, get the experiment plan + known AOB patterns
  Rank    — load a scan-results JSON file, get ranked candidates
  Draft   — load a confirmed candidate JSON, draft a sealed profile
  Corpus  — browse/search the AOB pattern corpus

Advisory only. Never touches the game.
"""

from __future__ import annotations

import json
import tkinter as tk
from tkinter import filedialog, messagebox, scrolledtext, ttk
from pathlib import Path

from planner import build_experiment_plan, render_plan
from ranker import rank_candidates, render_ranking
from drafter import draft_profile, render_draft_summary, write_profile
from corpus_adapter import (
    find_relevant,
    render_corpus_hits,
    corpus_stats,
    load_corpus,
)


class CopilotGUI(tk.Tk):
    def __init__(self) -> None:
        super().__init__()
        self.title("GameGPT R&D Copilot")
        self.geometry("900x700")

        stats = corpus_stats()
        self.status_var = tk.StringVar(
            value=f"Corpus: {stats['total']} patterns "
                  f"({stats['quarantined']} quarantined) loaded"
        )

        self.notebook = ttk.Notebook(self)
        self.notebook.pack(fill="both", expand=True, padx=8, pady=8)

        self._build_plan_tab()
        self._build_rank_tab()
        self._build_draft_tab()
        self._build_corpus_tab()

        ttk.Label(self, textvariable=self.status_var,
                  relief="sunken", anchor="w").pack(
            fill="x", padx=8, pady=(0, 8))

    # -- helpers ---------------------------------------------------------
    def _output(self, parent) -> scrolledtext.ScrolledText:
        out = scrolledtext.ScrolledText(parent, wrap="word", height=20,
                                        font=("Consolas", 10))
        out.pack(fill="both", expand=True, padx=8, pady=8)
        return out

    def _show(self, widget: scrolledtext.ScrolledText, text: str) -> None:
        widget.delete("1.0", "end")
        widget.insert("1.0", text)

    # -- Plan tab --------------------------------------------------------
    def _build_plan_tab(self) -> None:
        tab = ttk.Frame(self.notebook)
        self.notebook.add(tab, text="Plan")

        top = ttk.Frame(tab)
        top.pack(fill="x", padx=8, pady=8)
        ttk.Label(top, text="Cheat goal:").pack(side="left")
        self.plan_goal = ttk.Entry(top, width=50)
        self.plan_goal.pack(side="left", padx=8)
        self.plan_goal.insert(0, "unlimited stamina")
        ttk.Button(top, text="Get Plan",
                   command=self._do_plan).pack(side="left")

        self.plan_quarantine = tk.BooleanVar(value=False)
        ttk.Checkbutton(top, text="include quarantined",
                        variable=self.plan_quarantine).pack(side="left",
                                                            padx=8)

        self.plan_out = self._output(tab)

    def _do_plan(self) -> None:
        goal = self.plan_goal.get().strip()
        if not goal:
            messagebox.showwarning("Missing goal", "Enter a cheat goal first.")
            return
        try:
            plan = build_experiment_plan(goal)
            text = render_plan(plan)
            text += "\n\n" + render_corpus_hits(
                find_relevant(goal,
                              include_quarantined=self.plan_quarantine.get()))
            self._show(self.plan_out, text)
            self.status_var.set(f"Plan ready for: {goal}")
        except Exception as e:  # noqa: BLE001
            messagebox.showerror("Plan failed", str(e))

    # -- Rank tab --------------------------------------------------------
    def _build_rank_tab(self) -> None:
        tab = ttk.Frame(self.notebook)
        self.notebook.add(tab, text="Rank")

        top = ttk.Frame(tab)
        top.pack(fill="x", padx=8, pady=8)
        ttk.Button(top, text="Load scan results JSON…",
                   command=self._do_rank).pack(side="left")
        ttk.Label(top, text="Goal (optional):").pack(side="left", padx=(16, 4))
        self.rank_goal = ttk.Entry(top, width=30)
        self.rank_goal.pack(side="left")

        self.rank_out = self._output(tab)

    def _do_rank(self) -> None:
        path = filedialog.askopenfilename(
            title="Scan results JSON",
            filetypes=[("JSON files", "*.json"), ("All files", "*.*")])
        if not path:
            return
        try:
            payload = json.loads(Path(path).read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as e:
            messagebox.showerror("Load failed", str(e))
            return
        goal = self.rank_goal.get().strip()
        if goal:
            payload["goal"] = goal
        if not payload.get("goal"):
            messagebox.showwarning(
                "Missing goal",
                "No cheat goal: enter one above or include \"goal\" in the JSON.")
            return
        try:
            result = rank_candidates(payload)
            self._show(self.rank_out, render_ranking(result))
            self.status_var.set(f"Ranked {Path(path).name}")
        except Exception as e:  # noqa: BLE001
            messagebox.showerror("Rank failed", str(e))

    # -- Draft tab -------------------------------------------------------
    def _build_draft_tab(self) -> None:
        tab = ttk.Frame(self.notebook)
        self.notebook.add(tab, text="Draft")

        top = ttk.Frame(tab)
        top.pack(fill="x", padx=8, pady=8)
        ttk.Button(top, text="Load candidate JSON…",
                   command=self._do_draft).pack(side="left")
        ttk.Label(top, text="Game build:").pack(side="left", padx=(16, 4))
        self.draft_build = ttk.Entry(top, width=25)
        self.draft_build.pack(side="left")
        self.draft_build.insert(0, "NMS 5.x")

        self.draft_out = self._output(tab)

    def _do_draft(self) -> None:
        path = filedialog.askopenfilename(
            title="Candidate JSON",
            filetypes=[("JSON files", "*.json"), ("All files", "*.*")])
        if not path:
            return
        try:
            candidate = json.loads(Path(path).read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as e:
            messagebox.showerror("Load failed", str(e))
            return
        goal = candidate.get("goal", "")
        build = self.draft_build.get().strip()
        if not build:
            messagebox.showwarning("Missing build",
                                   "Enter the exact game build string.")
            return
        try:
            profile = draft_profile(candidate, goal, build)
            out = f"profile-{profile['draft_id']}.json"
            write_profile(profile, out)
            text = render_draft_summary(profile)
            text += f"\n\nWrote {out}\nReminder: status is DRAFT until the " \
                    "verification checklist is completed."
            self._show(self.draft_out, text)
            self.status_var.set(f"Drafted {out}")
        except Exception as e:  # noqa: BLE001
            messagebox.showerror("Draft failed", str(e))

    # -- Corpus tab ------------------------------------------------------
    def _build_corpus_tab(self) -> None:
        tab = ttk.Frame(self.notebook)
        self.notebook.add(tab, text="Corpus")

        top = ttk.Frame(tab)
        top.pack(fill="x", padx=8, pady=8)
        ttk.Label(top, text="Search:").pack(side="left")
        self.corpus_q = ttk.Entry(top, width=40)
        self.corpus_q.pack(side="left", padx=8)
        self.corpus_q.bind("<Return>", lambda _e: self._do_corpus_search())
        ttk.Button(top, text="Search",
                   command=self._do_corpus_search).pack(side="left")
        self.corpus_quarantine = tk.BooleanVar(value=False)
        ttk.Checkbutton(top, text="include quarantined",
                        variable=self.corpus_quarantine).pack(side="left",
                                                              padx=8)

        self.corpus_out = self._output(tab)
        self._do_corpus_search()  # show all on open

    def _do_corpus_search(self) -> None:
        q = self.corpus_q.get().strip()
        corpus = load_corpus()
        if q:
            hits = find_relevant(q, corpus=corpus,
                                 include_quarantined=self.corpus_quarantine.get(),
                                 max_results=50)
            self._show(self.corpus_out, render_corpus_hits(hits))
        else:
            stats = corpus_stats(corpus)
            lines = [
                f"Corpus: {stats['total']} patterns, "
                f"{stats['quarantined']} quarantined.",
                "",
                "Categories:",
            ]
            for cat, n in sorted(stats["categories"].items()):
                lines.append(f"  {cat}: {n}")
            lines.append("\nType a search term above to find patterns.")
            self._show(self.corpus_out, "\n".join(lines))


def main() -> None:
    app = CopilotGUI()
    app.mainloop()


if __name__ == "__main__":
    main()
