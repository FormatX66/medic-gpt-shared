#!/usr/bin/env python3
"""
GameGPT Stage 1 R&D Copilot — CLI (copilot.py)

Advisory-only assistant for cheat-discovery research. Read-only: it ingests
structured scan results and suggests experiments, rankings, and profile
drafts. It never touches game memory, never performs writes, and never
asserts a finding as fact.

Usage:
    copilot.py plan <cheat_goal>
    copilot.py rank <scan_results.json> --goal <cheat_goal>
    copilot.py draft <candidate.json> --goal <cheat_goal> --build <build_string>
                                      [--out <profile.json>]

Spec: ~/workspace/gamegpt/specs/rd-copilot-stage1.md
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from planner import build_experiment_plan, render_plan
from ranker import rank_candidates, render_ranking
from drafter import draft_profile, render_draft_summary, write_profile
from corpus_adapter import find_relevant, render_corpus_hits


def cmd_plan(args: argparse.Namespace) -> int:
    plan = build_experiment_plan(args.cheat_goal)
    print(render_plan(plan))
    if not args.no_corpus:
        print()
        hits = find_relevant(
            args.cheat_goal,
            include_quarantined=args.include_quarantined,
        )
        print(render_corpus_hits(hits))
    return 0


def cmd_corpus(args: argparse.Namespace) -> int:
    hits = find_relevant(
        args.cheat_goal,
        include_quarantined=args.include_quarantined,
        max_results=args.max,
    )
    print(render_corpus_hits(hits))
    return 0


def cmd_rank(args: argparse.Namespace) -> int:
    try:
        payload = json.loads(Path(args.scan_results).read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as e:
        print(f"Could not read scan results: {e}", file=sys.stderr)
        return 1
    if args.goal:
        payload["goal"] = args.goal
    if not payload.get("goal"):
        print("No cheat goal: pass --goal or include \"goal\" in the JSON.",
              file=sys.stderr)
        return 1
    result = rank_candidates(payload)
    print(render_ranking(result))
    return 0


def cmd_draft(args: argparse.Namespace) -> int:
    try:
        candidate = json.loads(Path(args.candidate).read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as e:
        print(f"Could not read candidate file: {e}", file=sys.stderr)
        return 1
    goal = args.goal or candidate.get("goal")
    if not goal:
        print("No cheat goal: pass --goal or include \"goal\" in the candidate JSON.",
              file=sys.stderr)
        return 1
    profile = draft_profile(candidate, goal, args.build)
    out = args.out or f"profile-{profile['draft_id']}.json"
    write_profile(profile, out)
    print(render_draft_summary(profile))
    print(f"\nWrote {out}")
    print("Reminder: status is DRAFT. It becomes validated only after you "
          "complete the verification checklist in tooling.")
    return 0


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="copilot.py",
        description=(
            "GameGPT Stage 1 R&D Copilot — advisory-only cheat-discovery "
            "assistant. Suggests experiments, ranks candidates, drafts "
            "profiles. Never writes to the game."
        ),
    )
    sub = p.add_subparsers(dest="command", required=True)

    pp = sub.add_parser("plan", help="Print an experiment plan for a cheat goal.")
    pp.add_argument("cheat_goal", help='e.g. "unlimited stamina"')
    pp.add_argument("--no-corpus", action="store_true",
                    help="skip AOB corpus lookup")
    pp.add_argument("--include-quarantined", action="store_true",
                    help="include crash-quarantined corpus entries")
    pp.set_defaults(func=cmd_plan)

    pc = sub.add_parser("corpus", help="Look up known AOB patterns for a goal.")
    pc.add_argument("cheat_goal", help='e.g. "unlimited stamina"')
    pc.add_argument("--include-quarantined", action="store_true",
                    help="include crash-quarantined corpus entries")
    pc.add_argument("--max", type=int, default=10, help="max hits to show")
    pc.set_defaults(func=cmd_corpus)

    pr = sub.add_parser("rank", help="Rank scan-result candidates.")
    pr.add_argument("scan_results", help="JSON file of scan results")
    pr.add_argument("--goal", default=None, help="cheat goal (overrides JSON)")
    pr.set_defaults(func=cmd_rank)

    pd = sub.add_parser("draft", help="Draft a sealed profile JSON.")
    pd.add_argument("candidate", help="JSON file with the confirmed candidate")
    pd.add_argument("--goal", default=None, help="cheat goal (overrides JSON)")
    pd.add_argument("--build", required=True, help="exact game build string")
    pd.add_argument("--out", default=None, help="output path for the profile JSON")
    pd.set_defaults(func=cmd_draft)

    return p


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
