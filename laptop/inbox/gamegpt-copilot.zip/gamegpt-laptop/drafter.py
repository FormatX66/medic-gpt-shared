"""
GameGPT Stage 1 R&D Copilot — profile drafter (drafter.py)

Drafts a sealed profile JSON (v0.1.1 schema shape) from a human-confirmed
candidate plus session metadata, per spec Section 7.

The draft is ADVISORY and can never become `validated` on its own: it always
carries `status: "draft"` and the mandatory verification checklist as
`verification_pending`. Only the human review gate — completing every checklist
item in tooling — can promote it. The copilot never performs writes and never
suggests them; guarded steps describe what the HUMAN would do in Cheat Engine
during the authority test.

Expected candidate JSON:
{
  "address": "0x1A2B3C4D",
  "value_type": "float",
  "goal": "unlimited stamina",          # optional (CLI --goal overrides)
  "resolution_method": "aob_hook",      # optional; one of
                                        # save_edit | config_tuning | aob_hook |
                                        # pointer_chain | unknown
  "session": {
    "game": "No Man's Sky",
    "build": "5.12.3 (build 98765)",
    "module_base": "0x7FF600000000",
    "scans_performed": 4,
    "authority_test": "sprinted in-game; drain resumed from modified base",
    "notes": "free text"
  }
}
"""

from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone

# The mandatory verification checklist, spec Section 7. Enforced as a gate:
# the draft cannot become validated until the human completes every item
# in tooling. Emitted verbatim as `verification_pending`.
VERIFICATION_CHECKLIST = [
    "Authoritative address confirmed via EXTERNAL STIMULUS "
    "(in-game effect observed from the modified base; display-copy ruled out).",
    "Min / max / mid writes tested; game behaves sanely at each.",
    "±32 bytes of adjacent memory verified uncorrupted after writes.",
    "Assert predicates deliberately failed (wrong expected value) to prove "
    "the guard actually guards — no tautologies (`gte 0` on unsigned, "
    "`eq written_value`, `not-null` on primitives are rejected).",
    "Human documents WHY this address is authoritative and WHY each guard "
    "guards (predicate rationale).",
    "Every evidence reference resolves to a real file in the hashed session "
    "manifest — no synthetic identifiers.",
]

# Guarded write steps, spec Section 7: pre-read → assert predicate → write →
# readbacks. These describe HUMAN actions in Cheat Engine, never copilot actions.
GUARDED_STEPS_TEMPLATE = [
    {
        "order": 1,
        "step": "pre-read",
        "description": (
            "Human reads the current value at the candidate address and "
            "records it. Suggested question: does the value match what the "
            "HUD shows right now?"
        ),
    },
    {
        "order": 2,
        "step": "assert-predicate",
        "description": (
            "Human asserts a predicate on the pre-read value (e.g. within "
            "the plausible range, sane type). Suggested question: would a "
            "wrong expected value fail here — does the guard actually guard, "
            "or is it a tautology?"
        ),
    },
    {
        "order": 3,
        "step": "write",
        "description": (
            "Human writes the test value in Cheat Engine. The copilot never "
            "writes; it only drafted this step for review."
        ),
    },
    {
        "order": 4,
        "step": "immediate-readback",
        "description": (
            "Human re-reads the address immediately. Suggested question: "
            "did the write land, and is adjacent memory (±32 bytes) untouched?"
        ),
    },
    {
        "order": 5,
        "step": "independent-readback",
        "description": (
            "Human re-reads after an in-game state change (pause/unpause, "
            "menu round-trip). Suggested question: does the value persist, "
            "or was it a transient copy?"
        ),
    },
    {
        "order": 6,
        "step": "external-stimulus",
        "description": (
            "Human applies the in-game stimulus tied to the cheat goal and "
            "observes the real effect from the modified base. Suggested "
            "question: did the game react to YOUR value — the definitive "
            "display-copy test."
        ),
    },
]

# Conservative default cooldowns (spec Section 8: derived from observed
# update-loop frequency, ≥2× loop time; conservative when unknown).
DEFAULT_COOLDOWNS = {
    "min_ms": 100,
    "note": (
        "Conservative default. Suggested: measure the game's update-loop "
        "frequency and set cooldown ≥ 2× loop time."
    ),
}


def draft_profile(candidate: dict, cheat_goal: str, build_string: str) -> dict:
    """
    Draft a sealed-profile JSON from a confirmed candidate.

    The result always has status "draft" and the full verification checklist
    pending. Advisory language throughout; no write is performed or promised.
    """
    session = candidate.get("session", {}) or {}
    address = str(candidate.get("address", "UNKNOWN"))
    value_type = str(candidate.get("value_type", "unknown"))
    method = str(candidate.get("resolution_method", "unknown")).lower()
    if method not in ("save_edit", "config_tuning", "aob_hook",
                      "pointer_chain", "unknown"):
        method = "unknown"

    # Stable draft id from goal + address + build (traceability, not authority).
    draft_id = hashlib.sha256(
        f"{cheat_goal}|{address}|{build_string}".encode()
    ).hexdigest()[:16]

    guarded_steps = []
    for step in GUARDED_STEPS_TEMPLATE:
        guarded_steps.append({
            **step,
            "performed_by": "human",
            "status": "pending",
        })

    return {
        "schema": "gamegpt-profile/0.1.1",
        "draft_id": draft_id,
        "status": "draft",
        "cheat_goal": cheat_goal,
        "candidate": {
            "address": address,
            "value_type": value_type,
            "resolution_method": method,
        },
        "build_stamp": {
            "game": session.get("game", "unknown"),
            "build": build_string,
            "module_base": session.get("module_base", "unknown"),
        },
        "session_evidence": {
            "scans_performed": session.get("scans_performed", "unknown"),
            "authority_test": session.get(
                "authority_test",
                "NOT DOCUMENTED — the authority test is required before "
                "this draft can be reviewed. What in-game stimulus did you apply?",
            ),
            "notes": session.get("notes", ""),
        },
        "guarded_steps": guarded_steps,
        "cooldowns": DEFAULT_COOLDOWNS,
        "gates": {
            "note": (
                "Suggested: define when this cheat may fire (game state, "
                "mutual exclusions). Related profiles within 256 bytes "
                "default to mutually exclusive unless you override with cause."
            ),
            "mutual_exclusions": [],
        },
        "verification_pending": list(VERIFICATION_CHECKLIST),
        "lifecycle_gate": (
            "This draft CANNOT become 'validated' until a human completes "
            "every verification_pending item in tooling and documents the "
            "predicate rationale. Copilot involvement never upgrades status."
        ),
        "advisory": (
            "Drafted by the R&D copilot as a suggestion. Nothing here has "
            "been verified by the copilot; every step is yours to perform "
            "and yours to judge."
        ),
        "drafted_at": datetime.now(timezone.utc).isoformat(),
    }


def render_draft_summary(profile: dict) -> str:
    """Short human-readable summary of a drafted profile."""
    c = profile["candidate"]
    lines = [
        "Profile draft (status: DRAFT — not validated)",
        f"  draft_id:   {profile['draft_id']}",
        f"  cheat goal: {profile['cheat_goal']}",
        f"  address:    {c['address']} ({c['value_type']})",
        f"  method:     {c['resolution_method']}",
        f"  build:      {profile['build_stamp']['build']}",
        "",
        "Guarded steps (human performs each):",
    ]
    for s in profile["guarded_steps"]:
        lines.append(f"  {s['order']}. {s['step']}: {s['description']}")
    lines += [
        "",
        f"Verification checklist: {len(profile['verification_pending'])} items PENDING",
        "The draft cannot become validated until you complete every item.",
    ]
    return "\n".join(lines)


def write_profile(profile: dict, path: str) -> str:
    """Write the profile JSON to path. Returns the path."""
    with open(path, "w", encoding="utf-8") as f:
        json.dump(profile, f, indent=2)
    return path
