# GameGPT System — Laptop Deployment

The full GameGPT game companion system.

## Setup

1. Install dependencies:
   ```
   pip install -r requirements.txt
   ```

2. Launch:
   ```
   run-gamegpt.bat
   ```
   Or: `python -m gtp_games.launcher` (with PYTHONPATH set to this folder)

## Components

- `gtp_games/launcher.py` — main entry point (UI + process tracker + companion)
- `gtp_games/scanner.py` — memory scan engine
- `gtp_games/memory/` — Windows process memory backend
- `gtp_games/safety.py` — write safety policy
- `gtp_games/plugin_runtime.py` — plugin API (scan/read/write/attach)
- `gtp_games/assistant/openai_tools.py` — GPT plugin interface
- `gtp_games/mcp_server.py` — MCP server

## Tier 3 rules

- Game must be running for live tests.
- Each live test needs explicit human authorization.
- NMS writes: fresh pre-read, expected_current, immediate + independent readback.
- Never modify Skyrim values.
