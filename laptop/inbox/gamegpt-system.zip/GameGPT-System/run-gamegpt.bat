@echo off
cd /d "%~dp0"
set PYTHONPATH=%CD%
python -m gtp_games.launcher %*
pause
