from __future__ import annotations

import hashlib
import os
import re
from datetime import UTC, datetime
from pathlib import Path
from threading import RLock

from gtp_games.config import Settings
from gtp_games.errors import SafetyError
from gtp_games.game_identity import executable_build_identity
from gtp_games.models import (
    DiscoveryCandidate,
    GameProfileMonitorStatus,
    GameValueTable,
    GameValueTableEntry,
    GameValueTableExportResult,
    GameValueTableSelectionResult,
    LocatorKind,
    PortableGameValueTable,
    PortableGameValueTableEntry,
    ProcessSession,
    UnrealGasProfile,
    ValueType,
)

_TABLE_LOCK = RLock()


def game_key_for_session(session: ProcessSession) -> str:
    if session.game_key:
        selected = re.sub(r"[^a-z0-9]+", "-", session.game_key.casefold()).strip("-")
        if selected:
            return selected
    basename = os.path.basename(session.executable or session.process_name).casefold()
    normalized = re.sub(r"(?:-win64-shipping)?\.exe$", "", basename)
    return re.sub(r"[^a-z0-9]+", "-", normalized).strip("-") or f"pid-{session.pid}"


def game_value_table_path(settings: Settings, session: ProcessSession) -> Path:
    identity = executable_build_identity(session.executable) or "unknown-build"
    build_key = _build_key(identity)
    return (
        settings.game_profile_directory
        / "tables"
        / game_key_for_session(session)
        / f"{build_key}.gtp-table.json"
    )


def game_value_table_export_path(settings: Settings, session: ProcessSession) -> Path:
    identity = executable_build_identity(session.executable) or "unknown-build"
    return (
        settings.game_table_export_directory
        / game_key_for_session(session)
        / f"{_build_key(identity)}.gtp-table.json"
    )


def ensure_game_value_table(
    settings: Settings,
    session: ProcessSession,
) -> GameValueTable:
    with _TABLE_LOCK:
        table = _load_or_create(settings, session)
        _write_table(table)
        _write_portable_export(settings, session, table)
        return table.model_copy(deep=True)


def export_game_value_table(
    settings: Settings,
    session: ProcessSession,
) -> GameValueTableExportResult:
    with _TABLE_LOCK:
        table = _load_or_create(settings, session)
        return _write_portable_export(settings, session, table)


def select_portable_game_value_table(
    settings: Settings,
    session: ProcessSession,
    source_path: str,
) -> GameValueTableSelectionResult:
    """Load a user-selected portable table as non-write-ready discovery guidance."""

    with _TABLE_LOCK:
        path = Path(source_path).expanduser().resolve()
        if not path.is_file() or not path.name.casefold().endswith(".gtp-table.json"):
            raise SafetyError("choose an existing portable .gtp-table.json file")
        try:
            source = PortableGameValueTable.model_validate_json(path.read_text(encoding="utf-8"))
        except (OSError, ValueError) as exc:
            raise SafetyError(f"the selected portable table is invalid: {exc}") from exc
        if source.schema_version != "gtp-portable-game-value-table/v1":
            raise SafetyError("the selected table uses an unsupported portable schema")
        if (
            source.contains_raw_addresses
            or source.contains_executable_scripts
            or source.contains_machine_paths
        ):
            raise SafetyError("the selected table does not satisfy portable-table safety rules")
        if any(
            entry.locator
            and (
                entry.locator.kind is LocatorKind.RAW_ADDRESS
                or entry.locator.address is not None
            )
            for entry in [*source.confirmed_features, *source.candidate_features]
        ):
            raise SafetyError("portable tables cannot contain raw memory addresses")

        session_game_key = game_key_for_session(session)
        game_match = _game_identity(source.game_key) == _game_identity(session_game_key)
        if not game_match:
            process_match = _game_identity(source.process_name) == _game_identity(
                session.process_name
            )
            if not process_match:
                raise SafetyError("the selected table belongs to a different game")
            game_match = True

        current_build = executable_build_identity(session.executable)
        build_match = bool(
            current_build
            and source.game_build_identity
            and current_build == source.game_build_identity
        )
        status = (
            "exact_build_needs_runtime_validation"
            if build_match
            else "other_build_needs_runtime_validation"
        )
        table = _load_or_create(settings, session)
        confirmed_ids = {item.id for item in table.confirmed_features}
        candidates = {item.id: item for item in table.candidate_features}
        source_id = hashlib.sha256(source.model_dump_json().encode()).hexdigest()[:24]

        imported_confirmed = 0
        imported_candidates = 0
        for portable, came_from_confirmed in (
            *((item, True) for item in source.confirmed_features),
            *((item, False) for item in source.candidate_features),
        ):
            locator_id = _locator_id(
                table.game_key,
                portable.object_path,
                portable.field_offset,
                portable.value_type.value,
            )
            if locator_id in confirmed_ids:
                continue
            confidence_cap = 0.8 if build_match else 0.55
            entry = GameValueTableEntry(
                id=locator_id,
                name=portable.name,
                status=(
                    "selected_confirmed_needs_runtime_validation"
                    if came_from_confirmed
                    else "selected_candidate_needs_runtime_validation"
                ),
                object_path=portable.object_path,
                field_offset=portable.field_offset,
                value_type=portable.value_type,
                likely_max_offset=portable.likely_max_offset,
                suggested_features=portable.suggested_features,
                category=portable.category,
                relevance=portable.relevance,
                confidence=min(portable.confidence, confidence_cap),
                source_kind="selected_portable_table",
                source_id=source_id,
                locator=portable.locator,
                validation_rule=portable.validation_rule,
                validated_events=portable.validated_events,
                validated_launches=portable.validated_launches,
                validated_process_starts=portable.validated_process_starts,
                source_correlated=portable.source_correlated,
                stability_score=min(portable.stability_score, confidence_cap),
                write_test_status=portable.write_test_status,
                evidence=[
                    "Loaded from a user-selected portable GTP table.",
                    (
                        "Executable build fingerprint matches; live object-path validation "
                        "is still required."
                        if build_match
                        else "Game identity matches, but this is another build; offsets must "
                        "be rediscovered or validated."
                    ),
                    "This selection does not grant or prepare memory writes.",
                ],
            )
            existing = candidates.get(locator_id)
            if existing is None or entry.confidence >= existing.confidence:
                candidates[locator_id] = entry
            if came_from_confirmed:
                imported_confirmed += 1
            else:
                imported_candidates += 1

        table.candidate_features = sorted(
            candidates.values(),
            key=lambda item: (-item.confidence, item.name.casefold(), item.field_offset),
        )[:200]
        table.selected_source_table = str(path)
        table.selected_source_build_identity = source.game_build_identity
        table.selected_source_status = status
        table.updated_at = datetime.now(UTC)
        note = (
            "A portable table was selected as read-only discovery guidance; all entries require "
            "live validation before they can become actionable features."
        )
        if note not in table.notes:
            table.notes.append(note)
        _write_table(table)
        _write_portable_export(settings, session, table)
        return GameValueTableSelectionResult(
            selected_path=str(path),
            target_table_path=table.saved_path,
            game_key=session_game_key,
            source_build_identity=source.game_build_identity,
            current_build_identity=current_build,
            game_match=game_match,
            build_match=build_match,
            status=status,
            imported_confirmed_as_candidates=imported_confirmed,
            imported_candidates=imported_candidates,
            notes=[
                "The selected table is data only.",
                "Its entries remain non-write-ready until this game session validates them.",
            ],
        )


def load_game_value_table(
    settings: Settings,
    session: ProcessSession,
) -> GameValueTable:
    with _TABLE_LOCK:
        return _load_or_create(settings, session).model_copy(deep=True)


def quarantine_legacy_behavioral_discoveries(
    settings: Settings,
    session: ProcessSession,
    target_names: set[str],
    validation_marker: str,
) -> GameValueTable:
    """Demote behavioral entries that predate explicit action-window validation."""

    selected_names = {name.casefold() for name in target_names}
    with _TABLE_LOCK:
        table = _load_or_create(settings, session)
        candidates = {item.id: item for item in table.candidate_features}
        confirmed = []
        changed = False

        def needs_quarantine(entry: GameValueTableEntry) -> bool:
            if entry.name.casefold() not in selected_names:
                return False
            rule = entry.validation_rule
            return rule is None or validation_marker not in rule.notes

        def quarantined(entry: GameValueTableEntry) -> GameValueTableEntry:
            evidence = [
                *entry.evidence,
                (
                    "Legacy behavioral correlation was invalidated because it was not "
                    "captured inside an explicitly labeled gameplay action window."
                ),
            ][-20:]
            return entry.model_copy(
                update={
                    "status": "candidate_explicit_behavior_required",
                    "confidence": min(entry.confidence, 0.45),
                    "source_correlated": False,
                    "validated_events": 0,
                    "evidence": evidence,
                },
                deep=True,
            )

        for entry in table.confirmed_features:
            if needs_quarantine(entry):
                candidates[entry.id] = quarantined(entry)
                changed = True
            else:
                confirmed.append(entry)

        for entry_id, entry in list(candidates.items()):
            if needs_quarantine(entry):
                candidates[entry_id] = quarantined(entry)
                changed = True

        if not changed:
            return table.model_copy(deep=True)

        table.confirmed_features = sorted(
            confirmed,
            key=lambda entry: (entry.name.casefold(), entry.object_path),
        )
        table.candidate_features = sorted(
            candidates.values(),
            key=lambda entry: (-entry.confidence, entry.name.casefold(), entry.object_path),
        )[:200]
        note = (
            "Legacy movement/jump confirmations were demoted until explicit gameplay "
            "action windows validate them again."
        )
        if note not in table.notes:
            table.notes.append(note)
        table.updated_at = datetime.now(UTC)
        _write_table(table)
        _write_portable_export(settings, session, table)
        return table.model_copy(deep=True)


def register_confirmed_profile(
    settings: Settings,
    session: ProcessSession,
    profile: UnrealGasProfile,
    *,
    current_value: int | float | None = None,
    maximum_value: int | float | None = None,
) -> GameValueTable:
    with _TABLE_LOCK:
        table = _load_or_create(settings, session)
        locator_id = _locator_id(
            table.game_key,
            profile.object_path,
            profile.field_offset,
            profile.value_type.value,
        )
        entry = GameValueTableEntry(
            id=locator_id,
            name=profile.name,
            status="confirmed",
            object_path=profile.object_path,
            field_offset=profile.field_offset,
            value_type=profile.value_type,
            likely_max_offset=profile.likely_max_offset,
            profile_id=profile.id,
            current_value=current_value,
            maximum_value=maximum_value,
            suggested_features=[profile.name],
            category="player_resource",
            relevance="useful",
            confidence=0.95,
            source_kind="confirmed_local_profile",
            source_id=profile.id,
            evidence=[
                "Saved from a live-validated GWorld-rooted object path.",
                "Kept separate from unresolved profiling candidates.",
            ],
        )
        confirmed = {item.id: item for item in table.confirmed_features}
        confirmed[entry.id] = entry
        table.confirmed_features = sorted(
            confirmed.values(),
            key=lambda item: (item.name.casefold(), item.object_path, item.field_offset),
        )
        table.candidate_features = [
            item for item in table.candidate_features if item.id != entry.id
        ]
        table.updated_at = datetime.now(UTC)
        _write_table(table)
        _write_portable_export(settings, session, table)
        return table.model_copy(deep=True)


def register_profile_monitor_ledger(
    settings: Settings,
    session: ProcessSession,
    status: GameProfileMonitorStatus,
) -> GameValueTable:
    with _TABLE_LOCK:
        table = _load_or_create(settings, session)
        if status.sample_count <= 0:
            return table.model_copy(deep=True)
        confirmed_ids = {item.id for item in table.confirmed_features}
        candidates = {item.id: item for item in table.candidate_features}
        for candidate in status.candidates:
            locator_id = _locator_id(
                table.game_key,
                candidate.object_path,
                candidate.field_offset,
                candidate.value_type.value,
            )
            if locator_id in confirmed_ids:
                continue
            name = (
                candidate.suggested_features[0]
                if candidate.suggested_features
                else "Unclassified gameplay value"
            )
            entry = GameValueTableEntry(
                id=locator_id,
                name=name,
                status="candidate",
                object_path=candidate.object_path,
                field_offset=candidate.field_offset,
                value_type=candidate.value_type,
                likely_max_offset=(
                    candidate.likely_max_address - candidate.object_address
                    if candidate.likely_max_address is not None
                    else None
                ),
                baseline_value=candidate.baseline_value,
                current_value=candidate.current_value,
                minimum_value=candidate.minimum_value,
                maximum_value=candidate.maximum_value,
                suggested_features=candidate.suggested_features,
                category=candidate.category,
                relevance=candidate.relevance,
                confidence=candidate.confidence,
                source_kind="full_game_profile_monitor",
                source_id=status.id,
                evidence=candidate.evidence[:12],
            )
            existing = candidates.get(locator_id)
            if existing is None or entry.confidence >= existing.confidence:
                candidates[locator_id] = entry
        table.candidate_features = sorted(
            candidates.values(),
            key=lambda item: (
                {"useful": 0, "secondary": 1, "unknown": 2}.get(item.relevance, 3),
                -item.confidence,
                item.name.casefold(),
                item.object_path,
                item.field_offset,
            ),
        )[:200]
        if status.saved_path and status.saved_path not in table.source_ledgers:
            table.source_ledgers.append(status.saved_path)
            table.source_ledgers = table.source_ledgers[-20:]
        table.updated_at = datetime.now(UTC)
        _write_table(table)
        _write_portable_export(settings, session, table)
        return table.model_copy(deep=True)


def register_discovery_candidates(
    settings: Settings,
    session: ProcessSession,
    discovered: list[DiscoveryCandidate],
    *,
    replace_target: str | None = None,
) -> GameValueTable:
    """Merge autonomous read-only evidence and promote only validated stable locators."""

    with _TABLE_LOCK:
        table = _load_or_create(settings, session)
        confirmed = {item.id: item for item in table.confirmed_features}
        candidates = {item.id: item for item in table.candidate_features}
        current_locator_ids: set[str] = set()
        for item in discovered:
            locator_text = _locator_text(item)
            locator_offset = (
                item.locator.module_offset
                if item.locator.module_offset is not None
                else item.locator.aob_offset
            )
            locator_id = _locator_id(
                table.game_key,
                locator_text,
                locator_offset,
                item.value_type.value,
            )
            current_locator_ids.add(locator_id)
            high_confidence = _is_high_confidence_discovery(item)
            display_name = item.reference_name or item.target
            entry = GameValueTableEntry(
                id=locator_id,
                name=display_name,
                status=(
                    "confirmed"
                    if high_confidence
                    else "locked_read_only"
                    if item.locked_for_run
                    else "candidate"
                ),
                object_path=locator_text,
                field_offset=max(0, locator_offset),
                value_type=item.value_type,
                current_value=item.current_value,
                suggested_features=list(dict.fromkeys([display_name, item.target])),
                category="autonomous_discovery",
                relevance="useful",
                confidence=item.confidence,
                source_kind="autonomous_read_only_discovery",
                source_id=item.id,
                locator=item.locator,
                validation_rule=item.validation_rule,
                validated_events=item.validated_events,
                validated_launches=item.validated_launches,
                validated_process_starts=item.validated_process_starts,
                source_correlated=item.source_correlated,
                stability_score=item.confidence,
                write_test_status=item.write_test_status,
                evidence=item.evidence[:20],
            )
            if high_confidence:
                previous_entries = [
                    previous
                    for previous in [
                        confirmed.get(locator_id) or candidates.get(locator_id)
                    ]
                    if previous is not None
                ]
                alias_ids = []
                for existing_id, existing in {**candidates, **confirmed}.items():
                    if existing_id != locator_id and _is_integer_type_alias(existing, entry):
                        alias_ids.append(existing_id)
                        previous_entries.append(existing)
                for previous in previous_entries:
                    entry = entry.model_copy(
                        update={
                            "confidence": max(entry.confidence, previous.confidence),
                            "validated_events": max(
                                entry.validated_events,
                                previous.validated_events,
                            ),
                            "validated_launches": max(
                                entry.validated_launches,
                                previous.validated_launches,
                            ),
                            "validated_process_starts": list(
                                dict.fromkeys(
                                    [
                                        *previous.validated_process_starts,
                                        *entry.validated_process_starts,
                                    ]
                                )
                            )[-20:],
                            "source_correlated": (
                                entry.source_correlated or previous.source_correlated
                            ),
                            "write_test_status": (
                                "confirmed"
                                if "confirmed"
                                in {entry.write_test_status, previous.write_test_status}
                                else entry.write_test_status
                            ),
                            "evidence": list(
                                dict.fromkeys([*previous.evidence, *entry.evidence])
                            )[-20:],
                        },
                        deep=True,
                    )
                for alias_id in alias_ids:
                    confirmed.pop(alias_id, None)
                    candidates.pop(alias_id, None)
                confirmed[locator_id] = entry
                candidates.pop(locator_id, None)
            elif locator_id not in confirmed:
                previous = candidates.get(locator_id)
                if previous is None:
                    candidates[locator_id] = entry
                else:
                    stronger = entry if entry.confidence >= previous.confidence else previous
                    candidates[locator_id] = stronger.model_copy(
                        update={
                            "confidence": max(entry.confidence, previous.confidence),
                            "validated_events": max(
                                entry.validated_events,
                                previous.validated_events,
                            ),
                            "validated_launches": max(
                                entry.validated_launches,
                                previous.validated_launches,
                            ),
                            "validated_process_starts": list(
                                dict.fromkeys(
                                    [
                                        *previous.validated_process_starts,
                                        *entry.validated_process_starts,
                                    ]
                                )
                            )[-20:],
                            "source_correlated": (
                                entry.source_correlated or previous.source_correlated
                            ),
                            "write_test_status": (
                                "confirmed"
                                if "confirmed"
                                in {entry.write_test_status, previous.write_test_status}
                                else stronger.write_test_status
                            ),
                            "evidence": list(
                                dict.fromkeys([*previous.evidence, *entry.evidence])
                            )[-20:],
                        },
                        deep=True,
                    )
        if replace_target is not None:
            target_key = replace_target.casefold()
            candidates = {
                entry_id: entry
                for entry_id, entry in candidates.items()
                if entry.source_kind
                not in {"autonomous_read_only_discovery", "selected_portable_table"}
                or not (
                    entry.name.casefold() == target_key
                    or target_key
                    in {name.casefold() for name in entry.suggested_features}
                )
                or entry_id in current_locator_ids
            }
        table.confirmed_features = sorted(
            confirmed.values(),
            key=lambda entry: (entry.name.casefold(), entry.object_path),
        )
        table.candidate_features = sorted(
            candidates.values(),
            key=lambda entry: (-entry.confidence, entry.name.casefold(), entry.object_path),
        )[:200]
        table.updated_at = datetime.now(UTC)
        _write_table(table)
        _write_portable_export(settings, session, table)
        return table.model_copy(deep=True)


def _load_or_create(settings: Settings, session: ProcessSession) -> GameValueTable:
    path = game_value_table_path(settings, session)
    if path.is_file():
        try:
            table = GameValueTable.model_validate_json(path.read_text(encoding="utf-8"))
            current_build = executable_build_identity(session.executable)
            identity_matches = (
                table.game_key == game_key_for_session(session)
                and table.process_name.casefold() == session.process_name.casefold()
                and table.game_build_identity == current_build
            )
            if identity_matches:
                resolved_path = str(path.resolve())
                if str(Path(table.saved_path).resolve()) != resolved_path:
                    table.saved_path = resolved_path
                    table.updated_at = datetime.now(UTC)
                    note = (
                        "Relocated this same-build native table with its companion folder; "
                        "all locator evidence was preserved."
                    )
                    if note not in table.notes:
                        table.notes.append(note)
                    _write_table(table)
                return _merge_same_build_alias_tables(settings, session, table)
        except (OSError, ValueError):
            pass
    table = GameValueTable(
        game_key=game_key_for_session(session),
        process_name=session.process_name,
        executable=session.executable,
        game_build_identity=executable_build_identity(session.executable),
        saved_path=str(path.resolve()),
        notes=[
            "Confirmed features and unresolved candidates are intentionally separate.",
            "This table contains data only; it never embeds or executes table scripts.",
        ],
    )
    return _merge_same_build_alias_tables(settings, session, table)


def _merge_same_build_alias_tables(
    settings: Settings,
    session: ProcessSession,
    table: GameValueTable,
) -> GameValueTable:
    """Merge same-executable/build alias ledgers without removing their source files."""

    current_path = Path(table.saved_path).resolve()
    table_root = settings.game_profile_directory / "tables"
    try:
        possible_aliases = sorted(table_root.glob(f"*/{current_path.name}"))
    except OSError:
        return table
    confirmed = {entry.id: entry for entry in table.confirmed_features}
    candidates = {entry.id: entry for entry in table.candidate_features}
    merged_keys: list[str] = []
    changed = False
    for alias_path in possible_aliases:
        try:
            resolved_alias = alias_path.resolve()
            if resolved_alias == current_path:
                continue
            alias = GameValueTable.model_validate_json(
                resolved_alias.read_text(encoding="utf-8")
            )
        except (OSError, ValueError):
            continue
        if (
            alias.game_key == table.game_key
            or alias.process_name.casefold() != session.process_name.casefold()
            or alias.game_build_identity != table.game_build_identity
        ):
            continue
        for source in alias.confirmed_features:
            entry = _entry_for_game_key(table.game_key, source)
            previous = confirmed.get(entry.id)
            if previous is None or _entry_strength(entry) > _entry_strength(previous):
                confirmed[entry.id] = entry
                changed = True
            if candidates.pop(entry.id, None) is not None:
                changed = True
        for source in alias.candidate_features:
            entry = _entry_for_game_key(table.game_key, source)
            if entry.id in confirmed:
                continue
            previous = candidates.get(entry.id)
            if previous is None or _entry_strength(entry) > _entry_strength(previous):
                candidates[entry.id] = entry
                changed = True
        merged_keys.append(alias.game_key)
        alias_source = str(resolved_alias)
        if alias_source not in table.source_ledgers:
            table.source_ledgers.append(alias_source)
            changed = True
    if not merged_keys:
        return table
    table.confirmed_features = sorted(
        confirmed.values(), key=lambda entry: (entry.name.casefold(), entry.object_path)
    )
    table.candidate_features = sorted(
        candidates.values(),
        key=lambda entry: (-entry.confidence, entry.name.casefold(), entry.object_path),
    )[:200]
    table.source_ledgers = table.source_ledgers[-20:]
    note = (
        "Merged preserved same-build evidence from game-key alias(es): "
        + ", ".join(sorted(set(merged_keys)))
        + ". Source ledgers were retained."
    )
    if note not in table.notes:
        table.notes.append(note)
        changed = True
    if not changed:
        return table
    table.updated_at = datetime.now(UTC)
    _write_table(table)
    return table


def _entry_for_game_key(game_key: str, source: GameValueTableEntry) -> GameValueTableEntry:
    entry = source.model_copy(deep=True)
    entry.id = _locator_id(
        game_key,
        entry.object_path,
        entry.field_offset,
        entry.value_type.value,
    )
    return entry


def _entry_strength(entry: GameValueTableEntry) -> tuple[int, int, int, float, float]:
    return (
        1 if entry.status == "confirmed" else 0,
        1 if entry.write_test_status == "confirmed" else 0,
        1 if entry.locator and entry.locator.kind is not LocatorKind.RAW_ADDRESS else 0,
        entry.confidence,
        entry.updated_at.timestamp(),
    )


def _write_table(table: GameValueTable) -> None:
    path = Path(table.saved_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(".tmp")
    temporary.write_text(table.model_dump_json(indent=2), encoding="utf-8")
    temporary.replace(path)


def _write_portable_export(
    settings: Settings,
    session: ProcessSession,
    table: GameValueTable,
) -> GameValueTableExportResult:
    path = game_value_table_export_path(settings, session).resolve()
    exported = PortableGameValueTable(
        game_key=table.game_key,
        process_name=table.process_name,
        game_build_identity=table.game_build_identity,
        confirmed_features=[
            _portable_entry(item)
            for item in table.confirmed_features
            if _portable_safe_entry(item)
        ],
        candidate_features=[
            _portable_entry(item)
            for item in table.candidate_features
            if _portable_safe_entry(item)
        ],
        notes=[
            "Portable data-only GTP table; importing it never grants write permission.",
            "Confirmed entries must be revalidated locally before set or hold actions.",
        ],
    )
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(".tmp")
    temporary.write_text(
        exported.model_dump_json(indent=2, exclude_none=True),
        encoding="utf-8",
    )
    temporary.replace(path)
    return GameValueTableExportResult(
        exported_path=str(path),
        table=exported,
    )


def _portable_entry(item: GameValueTableEntry) -> PortableGameValueTableEntry:
    return PortableGameValueTableEntry(
        id=item.id,
        name=item.name,
        status=item.status,
        object_path=item.object_path,
        field_offset=item.field_offset,
        value_type=item.value_type,
        likely_max_offset=item.likely_max_offset,
        suggested_features=item.suggested_features,
        category=item.category,
        relevance=item.relevance,
        confidence=item.confidence,
        locator=item.locator,
        validation_rule=item.validation_rule,
        validated_events=item.validated_events,
        validated_launches=item.validated_launches,
        validated_process_starts=item.validated_process_starts,
        source_correlated=item.source_correlated,
        stability_score=item.stability_score,
        write_test_status=item.write_test_status,
    )


def _portable_safe_entry(item: GameValueTableEntry) -> bool:
    locator = item.locator
    return not locator or (
        locator.kind is not LocatorKind.RAW_ADDRESS and locator.address is None
    )


def _locator_text(item: DiscoveryCandidate) -> str:
    locator = item.locator
    if locator.kind is LocatorKind.POINTER_CHAIN:
        offsets = ",".join(f"0x{offset:X}" for offset in locator.pointer_offsets)
        return f"pointer:{locator.module}+0x{locator.module_offset or 0:X}[{offsets}]"
    if locator.kind is LocatorKind.MODULE_OFFSET:
        return f"module:{locator.module}+0x{locator.module_offset or 0:X}"
    if locator.kind is LocatorKind.AOB:
        return f"aob:{locator.module or '$process'}:{locator.aob_pattern}"
    if locator.kind is LocatorKind.AOB_POINTER:
        offsets = ",".join(f"0x{offset:X}" for offset in locator.pointer_offsets)
        return (
            f"aob-pointer:{locator.module or '$process'}:{locator.aob_pattern}"
            f"+0x{locator.aob_offset:X}[{offsets}]"
        )
    return f"raw:0x{locator.address or 0:X}"


def _is_high_confidence_discovery(item: DiscoveryCandidate) -> bool:
    rule = item.validation_rule
    if item.confidence < 0.85:
        return False
    if item.validated_events < rule.minimum_change_events:
        return False
    if item.validated_launches < rule.minimum_launches:
        return False
    if rule.require_source_correlation and not item.source_correlated:
        return False
    if rule.require_non_raw_locator and item.locator.kind is LocatorKind.RAW_ADDRESS:
        return False
    if (
        item.locator.kind in {LocatorKind.AOB, LocatorKind.AOB_POINTER}
        and rule.require_unique_aob
        and item.locator.match_count != 1
    ):
        return False
    return True


def _is_integer_type_alias(
    existing: GameValueTableEntry,
    incoming: GameValueTableEntry,
) -> bool:
    integer_widths = {
        ValueType.I8: 8,
        ValueType.U8: 8,
        ValueType.I16: 16,
        ValueType.U16: 16,
        ValueType.I32: 32,
        ValueType.U32: 32,
        ValueType.I64: 64,
        ValueType.U64: 64,
    }
    return (
        existing.name.casefold() == incoming.name.casefold()
        and existing.object_path == incoming.object_path
        and existing.field_offset == incoming.field_offset
        and existing.value_type != incoming.value_type
        and integer_widths.get(existing.value_type)
        == integer_widths.get(incoming.value_type)
        and integer_widths.get(incoming.value_type) is not None
    )


def _build_key(identity: str) -> str:
    build_key = re.sub(r"[^a-zA-Z0-9._-]+", "-", identity).strip("-")
    if len(build_key) > 48:
        build_key = build_key[-48:]
    return build_key or "unknown-build"


def _game_identity(value: str) -> str:
    return re.sub(r"[^a-z0-9]+", "", value.casefold())


def _locator_id(game_key: str, object_path: str, offset: int, value_type: str) -> str:
    payload = f"{game_key}\0{object_path}\0{offset:X}\0{value_type}".encode()
    return hashlib.sha256(payload).hexdigest()[:24]
