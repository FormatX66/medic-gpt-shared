from __future__ import annotations

from pathlib import Path
from typing import Literal

from dotenv import find_dotenv, load_dotenv
from pydantic import Field, SecretStr, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

_local_env = find_dotenv(".env.local", usecwd=True)
if _local_env:
    load_dotenv(_local_env, override=False)


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_prefix="GTP_",
        case_sensitive=False,
        extra="ignore",
    )

    backend: Literal["auto", "simulated", "windows"] = "auto"
    assistant_provider: Literal["rules", "openai"] = "rules"
    openai_model: str = "gpt-5.6-luna"
    openai_api_key: SecretStr | None = Field(
        default=None,
        validation_alias="OPENAI_API_KEY",
    )
    github_token: SecretStr | None = Field(
        default=None,
        validation_alias="GITHUB_TOKEN",
    )

    allow_writes: bool = False
    allowed_processes: str = "gtp-simulated-game"
    write_intent_ttl_seconds: int = 60
    max_hold_seconds: int = 600
    max_active_holds: int = 4
    mcp_host: str = "127.0.0.1"
    mcp_port: int = 8000

    # Unknown-value scans retain a smaller bounded snapshot. Exact scans can safely
    # cover more of a modern game's writable address space without retaining it.
    max_scan_bytes: int = 32 * 1024 * 1024
    max_exact_scan_bytes: int = 1024 * 1024 * 1024
    max_scan_region_bytes: int = 64 * 1024 * 1024
    max_scan_results: int = 50_000
    scan_chunk_bytes: int = 1024 * 1024
    max_watch_seconds: int = 30
    max_damage_monitor_seconds: int = 900
    max_cheat_table_bytes: int = 10 * 1024 * 1024
    max_unreal_code_scan_bytes: int = 512 * 1024 * 1024
    max_unreal_objects: int = 512
    max_unreal_object_bytes: int = 4096
    max_unreal_fields: int = 250_000
    auto_profile_on_first_connection: bool = True
    auto_web_discovery_on_mount: bool = True
    web_discovery_timeout_seconds: int = 20
    web_discovery_cache_hours: int = 168
    max_web_discovery_sources: int = 24
    max_web_response_bytes: int = 2 * 1024 * 1024
    game_profile_directory: Path = Path("data/game_profiles")
    game_table_export_directory: Path = Path("data/exports")
    game_table_registry_directory: Path | None = None
    game_table_registry_remote: str = ""
    game_table_registry_timeout_seconds: int = 20
    auto_load_registry_tables: bool = True
    web_discovery_cache_directory: Path = Path("data/web_cache")
    scan_cache_directory: Path = Path("data/scan_cache")
    audit_log_path: Path | None = Path("data/audit.jsonl")
    chat_learnings_path: Path = Path("data/chat_learned_values.json")
    inventory_observations_path: Path = Path("data/inventory_observations.json")
    command_overlay_directory: Path = Path("data/command_overlay")
    auto_start_command_overlay: bool = False
    gpt_voice_hotkey: str = "auto"

    @field_validator("write_intent_ttl_seconds")
    @classmethod
    def validate_ttl(cls, value: int) -> int:
        if not 10 <= value <= 600:
            raise ValueError("write intent TTL must be between 10 and 600 seconds")
        return value

    @field_validator(
        "max_scan_bytes",
        "max_exact_scan_bytes",
        "max_scan_region_bytes",
        "max_scan_results",
        "scan_chunk_bytes",
        "max_watch_seconds",
        "max_damage_monitor_seconds",
        "max_cheat_table_bytes",
        "max_unreal_code_scan_bytes",
        "max_unreal_objects",
        "max_unreal_object_bytes",
        "max_unreal_fields",
        "max_hold_seconds",
        "max_active_holds",
        "web_discovery_timeout_seconds",
        "web_discovery_cache_hours",
        "max_web_discovery_sources",
        "max_web_response_bytes",
        "game_table_registry_timeout_seconds",
    )
    @classmethod
    def positive_limits(cls, value: int) -> int:
        if value <= 0:
            raise ValueError("scan limits must be positive")
        return value

    @field_validator("mcp_port")
    @classmethod
    def valid_port(cls, value: int) -> int:
        if not 1 <= value <= 65535:
            raise ValueError("MCP port must be between 1 and 65535")
        return value

    @field_validator("audit_log_path", mode="before")
    @classmethod
    def empty_audit_path_disables_persistence(cls, value: object) -> object:
        return None if value in {None, ""} else value

    @field_validator("game_table_registry_directory", mode="before")
    @classmethod
    def empty_registry_path_disables_registry(cls, value: object) -> object:
        return None if value in {None, ""} else value

    @property
    def allowed_process_patterns(self) -> tuple[str, ...]:
        return tuple(part.strip() for part in self.allowed_processes.split(",") if part.strip())
