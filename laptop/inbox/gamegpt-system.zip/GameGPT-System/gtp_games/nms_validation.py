"""Timing-safe state machine for a future user-assisted NMS promotion run."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import StrEnum


class ValidationState(StrEnum):
    GAME_OFF = "game_off"
    LAUNCH_REQUESTED = "launch_requested"
    PROCESS_DETECTED = "process_detected"
    ATTACHED_GUARDED_WRITE_ENABLED = "attached_guarded_write_enabled"
    LOCATOR_RESOLVED = "locator_resolved"
    READY = "ready"
    ARMED = "armed"
    ACT = "act"
    HIT = "hit"
    NO_HIT = "no_hit"
    APPLY_PENDING = "apply_pending"
    APPLIED_AND_VERIFIED = "applied_and_verified"
    RESTORED_AND_VERIFIED = "restored_and_verified"
    RESTART_REVALIDATED = "restart_revalidated"
    PROMOTED = "promoted"
    QUARANTINED = "quarantined"


@dataclass(frozen=True)
class TimingReceipt:
    state: ValidationState
    monotonic_time: float
    message: str
    process_identity: str | None


@dataclass
class NmsValidationSession:
    window_seconds: float = 20.0
    state: ValidationState = ValidationState.GAME_OFF
    process_identity: str | None = None
    prior_process_identity: str | None = None
    arm_time: float | None = None
    first_activity_time: float | None = None
    write_dispatch_time: float | None = None
    readback_time: float | None = None
    user_confirmation_time: float | None = None
    observer_active: bool = False
    act_recorded: bool = False
    receipts: list[TimingReceipt] = field(default_factory=list)

    def _record(self, now: float, message: str) -> TimingReceipt:
        receipt = TimingReceipt(self.state, now, message, self.process_identity)
        self.receipts.append(receipt)
        return receipt

    def request_launch(self, now: float) -> TimingReceipt:
        self._require(ValidationState.GAME_OFF)
        self.process_identity = None
        self.arm_time = None
        self.observer_active = False
        self.state = ValidationState.LAUNCH_REQUESTED
        return self._record(now, "fresh launch requested; prior locators discarded")

    def detect_process(self, identity: str, now: float) -> TimingReceipt:
        self._require(ValidationState.LAUNCH_REQUESTED)
        if not identity:
            raise ValueError("exact process identity is required")
        self.process_identity = identity
        self.state = ValidationState.PROCESS_DETECTED
        return self._record(now, "exact executable, PID, and start identity captured")

    def attach_guarded_write(self, now: float) -> TimingReceipt:
        self._require(ValidationState.PROCESS_DETECTED)
        self.state = ValidationState.ATTACHED_GUARDED_WRITE_ENABLED
        return self._record(now, "guarded write workflow attached; preflight can still reject")

    def resolve_locator(self, *, unique: bool, preconditions: bool, now: float) -> TimingReceipt:
        self._require(ValidationState.ATTACHED_GUARDED_WRITE_ENABLED)
        if not unique or not preconditions:
            return self.quarantine(now, "locator uniqueness or baseline failed")
        self.state = ValidationState.LOCATOR_RESOLVED
        return self._record(now, "current non-raw locator resolved")

    def ready(self, now: float) -> TimingReceipt:
        self._require(ValidationState.LOCATOR_RESOLVED)
        self.state = ValidationState.READY
        return self._record(now, "user action displayed; timer has not started")

    def arm(self, now: float) -> TimingReceipt:
        self._require(ValidationState.READY)
        self.state = ValidationState.ARMED
        self.arm_time = now
        self.observer_active = True
        self.act_recorded = False
        return self._record(now, f"observer armed for {self.window_seconds:.1f} seconds")

    def observe_activity(self, now: float) -> TimingReceipt:
        if self.state != ValidationState.ARMED or not self.observer_active:
            raise RuntimeError("activity is accepted only while visibly armed")
        if self.arm_time is None or now > self.arm_time + self.window_seconds:
            return self.timeout(now)
        if self.act_recorded:
            raise RuntimeError("duplicate ACT is rejected")
        self.act_recorded = True
        self.first_activity_time = now
        self.state = ValidationState.ACT
        return self._record(now, "user action observed inside the armed window")

    def finish_observation(self, *, hit: bool, now: float) -> TimingReceipt:
        self._require(ValidationState.ACT)
        self.observer_active = False
        self.state = ValidationState.HIT if hit else ValidationState.NO_HIT
        return self._record(
            now,
            "candidate activity hit" if hit else "no hit; preserve timing evidence",
        )

    def timeout(self, now: float) -> TimingReceipt:
        if self.state != ValidationState.ARMED:
            raise RuntimeError("no armed observation to time out")
        self.observer_active = False
        self.state = ValidationState.NO_HIT
        return self._record(now, "window expired; timeout is timing evidence, not disproof")

    def apply_pending(self, now: float) -> TimingReceipt:
        self._require(ValidationState.HIT)
        self.state = ValidationState.APPLY_PENDING
        return self._record(now, "separate reversible-write approval required")

    def applied(self, *, write_time: float, readback_time: float) -> TimingReceipt:
        self._require(ValidationState.APPLY_PENDING)
        if readback_time < write_time:
            raise ValueError("readback cannot precede dispatch")
        self.write_dispatch_time = write_time
        self.readback_time = readback_time
        self.state = ValidationState.APPLIED_AND_VERIFIED
        return self._record(readback_time, "guarded write and readback verified")

    def confirm_and_restore(self, *, confirmation_time: float, now: float) -> TimingReceipt:
        self._require(ValidationState.APPLIED_AND_VERIFIED)
        self.user_confirmation_time = confirmation_time
        self.state = ValidationState.RESTORED_AND_VERIFIED
        return self._record(now, "original and in-game behavior restored")

    def restart_revalidated(self, new_identity: str, now: float) -> TimingReceipt:
        self._require(ValidationState.RESTORED_AND_VERIFIED)
        if not new_identity or new_identity == self.process_identity:
            raise ValueError("restart requires a distinct fresh process identity")
        self.prior_process_identity = self.process_identity
        self.process_identity = new_identity
        self.state = ValidationState.RESTART_REVALIDATED
        return self._record(now, "locator reacquired in a new process without old address")

    def promote(self, now: float) -> TimingReceipt:
        self._require(ValidationState.RESTART_REVALIDATED)
        self.state = ValidationState.PROMOTED
        return self._record(now, "promotion gates complete")

    def cancel(self, now: float, reason: str) -> TimingReceipt:
        self.observer_active = False
        return self.quarantine(now, reason)

    def process_changed(self, new_identity: str, now: float) -> TimingReceipt:
        if self.process_identity and new_identity != self.process_identity:
            return self.cancel(now, "stale session: process changed")
        return self._record(now, "process identity unchanged")

    def pause_or_mute(self, now: float) -> TimingReceipt:
        if self.state == ValidationState.ARMED:
            return self.cancel(now, "armed observation cancelled by mute or wait")
        return self._record(now, "voice state changed outside observation window")

    def quarantine(self, now: float, reason: str) -> TimingReceipt:
        self.observer_active = False
        self.state = ValidationState.QUARANTINED
        return self._record(now, reason)

    def _require(self, expected: ValidationState) -> None:
        if self.state != expected:
            raise RuntimeError(f"expected {expected}, found {self.state}")
