from __future__ import annotations

import math
import struct

from gtp_games.errors import GTPError
from gtp_games.models import ValueType

_FORMATS: dict[ValueType, str] = {
    ValueType.I8: "<b",
    ValueType.U8: "<B",
    ValueType.I16: "<h",
    ValueType.U16: "<H",
    ValueType.I32: "<i",
    ValueType.U32: "<I",
    ValueType.I64: "<q",
    ValueType.U64: "<Q",
    ValueType.F32: "<f",
    ValueType.F64: "<d",
}


def value_size(value_type: ValueType) -> int:
    return struct.calcsize(_FORMATS[value_type])


def encode_value(value_type: ValueType, value: int | float) -> bytes:
    try:
        if value_type in {ValueType.F32, ValueType.F64}:
            numeric: int | float = float(value)
            if not math.isfinite(numeric):
                raise ValueError("non-finite floating-point values are not supported")
        else:
            if isinstance(value, float) and not value.is_integer():
                raise ValueError("integer value type requires a whole number")
            numeric = int(value)
        return struct.pack(_FORMATS[value_type], numeric)
    except (OverflowError, struct.error, TypeError, ValueError) as exc:
        raise GTPError(f"invalid {value_type} value: {value}") from exc


def decode_value(value_type: ValueType, data: bytes) -> int | float:
    expected = value_size(value_type)
    if len(data) != expected:
        raise GTPError(f"expected {expected} bytes for {value_type}, received {len(data)}")
    return struct.unpack(_FORMATS[value_type], data)[0]


def iter_values(value_type: ValueType, data: bytes):
    """Yield decoded scalar values without allocating a Python list."""

    width = value_size(value_type)
    usable = len(data) - (len(data) % width)
    return (item[0] for item in struct.iter_unpack(_FORMATS[value_type], data[:usable]))


def values_equal(value_type: ValueType, left: int | float, right: int | float) -> bool:
    if value_type in {ValueType.F32, ValueType.F64}:
        return math.isclose(float(left), float(right), rel_tol=1e-6, abs_tol=1e-6)
    return int(left) == int(right)
