from __future__ import annotations

import hashlib
import os
import re
from datetime import UTC, datetime
from pathlib import Path

from gtp_games.models import GameBuildFingerprint

_SAMPLE_BYTES = 128 * 1024


def executable_build_identity(executable: str | None) -> str | None:
    """Fingerprint a game build cheaply without hashing a multi-gigabyte binary."""

    if not executable:
        return None
    try:
        size = os.path.getsize(executable)
        with open(executable, "rb") as stream:
            first = stream.read(_SAMPLE_BYTES)
            if size > _SAMPLE_BYTES:
                stream.seek(max(0, size - _SAMPLE_BYTES))
                last = stream.read(_SAMPLE_BYTES)
            else:
                last = b""
    except OSError:
        return None
    digest = hashlib.sha256()
    digest.update(size.to_bytes(8, "little"))
    digest.update(first)
    digest.update(last)
    return f"sample-sha256:{digest.hexdigest()}"


def executable_build_fingerprint(executable: str | None) -> GameBuildFingerprint | None:
    """Return an exact local build fingerprint plus store identity when available."""

    if not executable:
        return None
    path = Path(executable)
    try:
        stat = path.stat()
        digest = hashlib.sha256()
        with path.open("rb") as stream:
            while chunk := stream.read(1024 * 1024):
                digest.update(chunk)
    except OSError:
        return None
    sample_identity = executable_build_identity(str(path))
    if sample_identity is None:
        return None
    store, store_app_id, store_build_id = _steam_build_reference(path)
    return GameBuildFingerprint(
        executable_name=path.name,
        size_bytes=stat.st_size,
        modified_at=datetime.fromtimestamp(stat.st_mtime, UTC),
        sample_identity=sample_identity,
        sha256=digest.hexdigest(),
        store=store,
        store_app_id=store_app_id,
        store_build_id=store_build_id,
    )


def _steam_build_reference(executable: Path) -> tuple[str | None, str | None, str | None]:
    try:
        resolved = executable.resolve()
    except OSError:
        return None, None, None
    install_root = next(
        (
            parent
            for parent in resolved.parents
            if parent.parent.name.casefold() == "common"
            and parent.parent.parent.name.casefold() == "steamapps"
        ),
        None,
    )
    if install_root is None:
        return None, None, None
    manifest_root = install_root.parent.parent
    try:
        manifests = sorted(manifest_root.glob("appmanifest_*.acf"))
    except OSError:
        return "steam", None, None
    for manifest in manifests:
        try:
            text = manifest.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        install_dir = _vdf_value(text, "installdir")
        if not install_dir or install_dir.casefold() != install_root.name.casefold():
            continue
        return "steam", _vdf_value(text, "appid"), _vdf_value(text, "buildid")
    return "steam", None, None


def _vdf_value(text: str, key: str) -> str | None:
    match = re.search(rf'"{re.escape(key)}"\s+"([^"]*)"', text, flags=re.IGNORECASE)
    return match.group(1) if match else None
