from __future__ import annotations

import os
import re
from dataclasses import dataclass
from enum import StrEnum

from gtp_games.models import ProcessInfo


class ProcessState(StrEnum):
    RUNNING = "running"
    RESTARTED = "restarted"
    DISAPPEARED = "disappeared"


@dataclass(frozen=True)
class ProcessRow:
    process: ProcessInfo
    state: ProcessState
    previous_pid: int | None = None

    @property
    def status(self) -> str:
        if not self.process.attachable:
            return "Blocked"
        if self.state is ProcessState.RESTARTED:
            return f"Restarted (was PID {self.previous_pid})"
        if self.state is ProcessState.DISAPPEARED:
            return "Disappeared"
        return "Likely game" if self.process.likely_game else "Available"


class ProcessTracker:
    """Compare process snapshots without assuming a stable executable name."""

    def __init__(self) -> None:
        self._previous: list[ProcessInfo] = []

    def refresh(self, current: list[ProcessInfo]) -> list[ProcessRow]:
        previous_by_pid = {process.pid: process for process in self._previous}
        current_by_pid = {process.pid: process for process in current}
        matched_previous: set[int] = set()
        matched_current: set[int] = set()
        rows: list[ProcessRow] = []

        for pid in sorted(previous_by_pid.keys() & current_by_pid.keys()):
            old = previous_by_pid[pid]
            new = current_by_pid[pid]
            restarted = not _same_incarnation(old, new)
            rows.append(
                ProcessRow(
                    process=new,
                    state=ProcessState.RESTARTED if restarted else ProcessState.RUNNING,
                    previous_pid=pid if restarted else None,
                )
            )
            matched_previous.add(pid)
            matched_current.add(pid)

        old_unmatched = [item for item in self._previous if item.pid not in matched_previous]
        new_unmatched = [item for item in current if item.pid not in matched_current]
        pairs = self._restart_pairs(old_unmatched, new_unmatched)
        for old, new in pairs:
            rows.append(
                ProcessRow(
                    process=new,
                    state=ProcessState.RESTARTED,
                    previous_pid=old.pid,
                )
            )
            matched_previous.add(old.pid)
            matched_current.add(new.pid)

        rows.extend(
            ProcessRow(process=process, state=ProcessState.RUNNING)
            for process in current
            if process.pid not in matched_current
        )
        rows.extend(
            ProcessRow(process=process, state=ProcessState.DISAPPEARED)
            for process in self._previous
            if process.pid not in matched_previous
        )

        self._previous = list(current)
        return rows

    @staticmethod
    def _restart_pairs(
        old_processes: list[ProcessInfo],
        new_processes: list[ProcessInfo],
    ) -> list[tuple[ProcessInfo, ProcessInfo]]:
        old_directories = _directory_counts(old_processes)
        new_directories = _directory_counts(new_processes)
        scored: list[tuple[int, int, int]] = []
        for old_index, old in enumerate(old_processes):
            for new_index, new in enumerate(new_processes):
                score = _identity_score(old, new, old_directories, new_directories)
                if score:
                    scored.append((score, old_index, new_index))

        used_old: set[int] = set()
        used_new: set[int] = set()
        pairs: list[tuple[ProcessInfo, ProcessInfo]] = []
        for _, old_index, new_index in sorted(scored, reverse=True):
            if old_index in used_old or new_index in used_new:
                continue
            used_old.add(old_index)
            used_new.add(new_index)
            pairs.append((old_processes[old_index], new_processes[new_index]))
        return pairs


def filter_and_sort_rows(
    rows: list[ProcessRow],
    *,
    query: str = "",
    process_filter: str = "all",
    sort_key: str = "name",
    descending: bool = False,
) -> list[ProcessRow]:
    normalized_query = query.strip().casefold()
    visible: list[ProcessRow] = []
    for row in rows:
        if process_filter == "likely" and (
            not row.process.likely_game
            or not row.process.attachable
            or row.state is ProcessState.DISAPPEARED
        ):
            continue
        if process_filter == "attachable" and (
            not row.process.attachable or row.state is ProcessState.DISAPPEARED
        ):
            continue
        if process_filter == "running" and row.state is ProcessState.DISAPPEARED:
            continue
        if process_filter == "changes" and row.state is ProcessState.RUNNING:
            continue
        searchable = " ".join(
            (
                row.process.name,
                str(row.process.pid),
                row.process.executable or "",
                row.status,
                row.process.blocked_reason or "",
                " ".join(row.process.game_reasons),
                str(row.process.gpu_percent or 0),
                str(row.process.memory_bytes or 0),
            )
        ).casefold()
        if normalized_query and normalized_query not in searchable:
            continue
        visible.append(row)

    key_functions = {
        "name": lambda row: (row.process.name.casefold(), row.process.pid),
        "pid": lambda row: (row.process.pid,),
        "path": lambda row: ((row.process.executable or "").casefold(), row.process.pid),
        "status": lambda row: (row.status.casefold(), row.process.name.casefold()),
        "gpu": lambda row: (row.process.gpu_percent or -1, row.process.pid),
        "memory": lambda row: (row.process.memory_bytes or -1, row.process.pid),
        "score": lambda row: (row.process.game_score, row.process.pid),
    }
    if sort_key not in key_functions:
        raise ValueError(f"unsupported process sort key: {sort_key}")
    return sorted(visible, key=key_functions[sort_key], reverse=descending)


def _same_incarnation(old: ProcessInfo, new: ProcessInfo) -> bool:
    if old.started_at is not None and new.started_at is not None:
        return abs(old.started_at - new.started_at) < 1.0
    return True


def _identity_score(
    old: ProcessInfo,
    new: ProcessInfo,
    old_directories: dict[str, int],
    new_directories: dict[str, int],
) -> int:
    old_path = _normalized_path(old.executable)
    new_path = _normalized_path(new.executable)
    if old_path and old_path == new_path:
        return 100
    if old.name.casefold() == new.name.casefold():
        return 90
    old_variant = _variant_name(old.name)
    if old_variant and old_variant == _variant_name(new.name):
        return 70
    old_directory = _normalized_directory(old.executable)
    new_directory = _normalized_directory(new.executable)
    if (
        old_directory
        and old_directory == new_directory
        and old_directories.get(old_directory) == 1
        and new_directories.get(new_directory) == 1
    ):
        return 50
    return 0


def _directory_counts(processes: list[ProcessInfo]) -> dict[str, int]:
    counts: dict[str, int] = {}
    for process in processes:
        directory = _normalized_directory(process.executable)
        if directory:
            counts[directory] = counts.get(directory, 0) + 1
    return counts


def _normalized_path(path: str | None) -> str:
    return os.path.normcase(os.path.normpath(path)) if path else ""


def _normalized_directory(path: str | None) -> str:
    normalized = _normalized_path(path)
    return os.path.dirname(normalized) if normalized else ""


def _variant_name(name: str) -> str:
    stem, _ = os.path.splitext(name.casefold())
    return re.sub(r"[\W_]*\d+[\W_]*$", "", stem)
