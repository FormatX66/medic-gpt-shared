from __future__ import annotations

from pydantic import BaseModel, Field

from gtp_games import __version__

CONTROL_API = "gamegpt.control"
CONTROL_PROTOCOL_VERSIONS = ("1.0",)
CANONICAL_ROLE = "gamegpt-companion"


class ControlNegotiation(BaseModel):
    control_api: str = CONTROL_API
    client_versions: list[str] = Field(default_factory=list)
    server_versions: list[str] = Field(default_factory=lambda: list(CONTROL_PROTOCOL_VERSIONS))
    selected_version: str | None = None
    compatible: bool
    product_version: str = __version__
    instance_id: str
    canonical_role: str = CANONICAL_ROLE
    reason: str


def negotiate_control(client_versions: list[str], *, instance_id: str) -> ControlNegotiation:
    normalized = [str(item).strip() for item in client_versions if str(item).strip()]
    selected = next(
        (version for version in CONTROL_PROTOCOL_VERSIONS if version in normalized),
        None,
    )
    return ControlNegotiation(
        client_versions=normalized,
        selected_version=selected,
        compatible=selected is not None,
        instance_id=instance_id,
        reason=(
            f"negotiated {selected}"
            if selected is not None
            else "no mutually supported control protocol version"
        ),
    )
