from __future__ import annotations

from mcp.server.fastmcp import FastMCP
from mcp.server.fastmcp import server as fastmcp_server_module
from mcp.types import ToolAnnotations

from gtp_games.chat_learnings import LearnedGameValue
from gtp_games.command_overlay import (
    GameCommandOverlayController,
    GameOverlayCommandResult,
    GameOverlayControlResult,
    GameOverlayMessageResult,
)
from gtp_games.config import Settings
from gtp_games.control import CONTROL_PROTOCOL_VERSIONS, ControlNegotiation
from gtp_games.game_accelerators import GameAcceleratorPack
from gtp_games.game_table_registry import GameTableRegistryStatus
from gtp_games.instruction_values import (
    InstructionValueObserverStatus,
    InstructionValueRecipe,
)
from gtp_games.inventory_observer import InventoryObserverStatus, InventorySlotObservation
from gtp_games.models import (
    CheatTableResult,
    CheatTableSourceBuild,
    Comparison,
    HealthBarResult,
    InventoryScreenResult,
    RollbackResult,
    SavedInventoryLiveResolution,
    SavedInventoryResult,
    ValueType,
    WebCheatDiscoveryResult,
    WriteResult,
)
from gtp_games.plugin_runtime import (
    AttachedSessionResult,
    DetachedSessionResult,
    LearnedGameValuesResult,
    PluginRuntime,
    PluginStatus,
    ProcessListResult,
    RawMemoryReadResult,
    ScanResult,
)
from gtp_games.service import ApplicationService

fastmcp_server_module.Settings.model_rebuild(_types_namespace=vars(fastmcp_server_module))

INSTRUCTIONS = (
    "ChatGPT is the GTP Games interface and decides the memory workflow conversationally. "
    "This local plugin is only a headless RAM bridge for personal offline games. Choose one "
    "returned game process and attach to it. When an on-screen value is known, start an exact "
    "scan. Otherwise start an unknown scan, ask the user to cause one clear in-game change, "
    "then refine with changed, unchanged, increased, decreased, or an exact new value. Inspect "
    "the remaining candidates, read them directly, and write only when the user asks to test or "
    "set a value. Immediately after attaching, load learned game values before starting a new "
    "scan. Same-process raw observations can be re-read; observations from a prior launch or "
    "build are scan guidance and must be revalidated. Keep every correlated candidate because "
    "one game value may have several correct mirrors. Remember a narrowed scan after it is "
    "identified, recording only addresses actually verified by a write as write-verified. "
    "Verified values also attempt to save non-raw pointer, module, or signature-pointer "
    "locators. Exact-build tables "
    "from the configured local registry load automatically on attach; publishing to its private "
    "remote is always an explicit command. "
    "For a supported inventory build, call start_moved_inventory_observer before asking for or "
    "automating one stack move. It returns only after the hardware observer is truly armed. "
    "Then call get_moved_inventory_observer for the result. The observer never executes "
    "imported CT code, patches game instructions, or writes game memory. "
    "Translate public or local CT/source hints into data-only instruction recipes; never "
    "execute imported scripts. Recipes must match the exact executable build and a unique "
    "AOB before the read-only structure observer can arm. "
    "For No Man's Sky inventory, call read_saved_inventory before screen capture or scanning; "
    "it returns item IDs, amounts, maximums, container groups, and grid coordinates from the "
    "newest local save without requiring the inventory menu to be open. Save evidence can guide "
    "a later live correlation but never proves a RAM offset by itself. Then call "
    "resolve_saved_inventory_stack to use the remembered same-process allocation and exact "
    "neighbor structure before considering a broad scan. "
    "The optional Ctrl+Shift+G overlay is only a command surface. Start it when requested or "
    "when automatic overlay startup is enabled. While the user asks GPT to keep listening, call "
    "wait_for_game_command in bounded intervals, acknowledge the previous command on the next "
    "wait, carry out each local-user command within this same safety scope, and publish a short "
    "result back to the overlay. Its GPT Voice button opens native Codex Voice. Enable writes "
    "only for that selected game. Every write must stay inside a "
    "readable, writable, non-executable region of the allowlisted process and is verified by "
    "immediate readback. Never target protected, anti-cheat, DRM, online, competitive, system, "
    "or security processes."
)

READ_ONLY = ToolAnnotations(
    readOnlyHint=True,
    destructiveHint=False,
    idempotentHint=False,
    openWorldHint=False,
)
STATEFUL_READ = ToolAnnotations(
    readOnlyHint=False,
    destructiveHint=False,
    idempotentHint=False,
    openWorldHint=False,
)
DIRECT_WRITE = ToolAnnotations(
    readOnlyHint=False,
    destructiveHint=True,
    idempotentHint=False,
    openWorldHint=False,
)


def create_raw_mcp_server(
    settings: Settings | None = None,
    *,
    application: ApplicationService | None = None,
) -> tuple[FastMCP, PluginRuntime]:
    active_settings = settings or Settings()
    runtime = PluginRuntime(active_settings, application=application)
    overlay = GameCommandOverlayController(
        active_settings.command_overlay_directory,
        gpt_voice_hotkey=active_settings.gpt_voice_hotkey,
    )
    server = FastMCP(
        name="GTP Games Raw RAM",
        instructions=INSTRUCTIONS,
        host=active_settings.mcp_host,
        port=active_settings.mcp_port,
        streamable_http_path="/mcp",
        json_response=True,
        stateless_http=True,
    )

    @server.tool(
        title="Check raw RAM companion",
        description="Report whether the local companion and game-memory writes are available.",
        annotations=READ_ONLY,
        structured_output=True,
    )
    def get_raw_memory_status() -> PluginStatus:
        return runtime.status()

    @server.tool(
        title="Negotiate the GameGPT control protocol",
        description="Select a mutually supported canonical control protocol version.",
        annotations=READ_ONLY,
        structured_output=True,
    )
    def negotiate_gamegpt_control(
        client_versions: list[str] | None = None,
    ) -> ControlNegotiation:
        return runtime.negotiate_control(
            client_versions if client_versions is not None else list(CONTROL_PROTOCOL_VERSIONS)
        )

    @server.tool(
        title="List local game processes",
        description="List eligible local processes and the currently selected game session.",
        annotations=READ_ONLY,
        structured_output=True,
    )
    def list_game_processes() -> ProcessListResult:
        return runtime.list_processes()

    @server.tool(
        title="Attach to one game",
        description=(
            "Attach to the selected local game. Set write_enabled true when the user wants to "
            "edit its memory and the process is in the companion allowlist."
        ),
        annotations=STATEFUL_READ,
        structured_output=True,
    )
    def attach_game_process(pid: int, write_enabled: bool = False) -> AttachedSessionResult:
        attached = runtime.attach(pid, write_enabled=write_enabled, start_catalog_discovery=False)
        if active_settings.auto_start_command_overlay:
            status = overlay.start()
            if status.running:
                overlay.bridge.set_message(
                    f"Attached to {attached.process_name}. GPT is ready.",
                    state="ready",
                )
        return attached

    @server.tool(
        title="Detach from the game",
        description="Close the selected local game-memory session.",
        annotations=STATEFUL_READ,
        structured_output=True,
    )
    def detach_game_process(session_id: str) -> DetachedSessionResult:
        return runtime.detach(session_id)

    @server.tool(
        title="Scan for a visible value",
        description=(
            "Start a bounded exact scan for a value the user can currently see in the selected "
            "game. ChatGPT should choose the likely type and refine after the value changes."
        ),
        annotations=STATEFUL_READ,
        structured_output=True,
    )
    def start_exact_value_scan(
        session_id: str,
        value: int | float,
        value_type: ValueType = ValueType.I32,
    ) -> ScanResult:
        return runtime.start_scan(session_id, value, value_type)

    @server.tool(
        title="Scan for an unknown value",
        description=(
            "Capture a bounded baseline when the current value is not displayed. ChatGPT must "
            "then ask for one clear game event and refine the same scan from that observation."
        ),
        annotations=STATEFUL_READ,
        structured_output=True,
    )
    def start_unknown_value_scan(
        session_id: str,
        value_type: ValueType = ValueType.I32,
        normalized: bool = False,
    ) -> ScanResult:
        return runtime.start_unknown_scan(session_id, value_type, normalized=normalized)

    @server.tool(
        title="Refine a value scan",
        description=(
            "Filter an existing scan after one observed game change. Supply value only for an "
            "exact comparison; omit it for changed, unchanged, increased, or decreased."
        ),
        annotations=STATEFUL_READ,
        structured_output=True,
    )
    def refine_value_scan(
        scan_id: str,
        comparison: Comparison,
        value: int | float | None = None,
    ) -> ScanResult:
        return runtime.refine_scan(scan_id, comparison, value)

    @server.tool(
        title="Inspect scan candidates",
        description=(
            "Read the remaining addresses and current values so ChatGPT can decide the next "
            "refinement or a user-requested verification write."
        ),
        annotations=READ_ONLY,
        structured_output=True,
    )
    def get_scan_candidates(scan_id: str, limit: int = 20) -> ScanResult:
        if not 0 <= limit <= 200:
            raise ValueError("limit must be between 0 and 200")
        return runtime.scan_candidates(scan_id, limit=limit)

    @server.tool(
        title="Load learned game values",
        description=(
            "Load same-build saved value observations and stable game-table features before "
            "scanning. Raw addresses from another process launch are guidance only and are "
            "explicitly marked as requiring revalidation."
        ),
        annotations=READ_ONLY,
        structured_output=True,
    )
    def get_learned_game_values(session_id: str) -> LearnedGameValuesResult:
        return runtime.learned_game_values(session_id)

    @server.tool(
        title="Mount game accelerator evidence",
        description=(
            "Immediately combine exact-build local recipes, portable locators, and read-only "
            "save evidence for the selected game. Matching values are staged as restart-safe "
            "candidates. This never executes imported code, writes game memory, or waits on "
            "an online search."
        ),
        annotations=STATEFUL_READ,
        structured_output=True,
    )
    def mount_game_accelerator_pack(session_id: str) -> GameAcceleratorPack:
        return runtime.game_accelerator_pack(session_id)

    @server.tool(
        title="Refresh public game accelerators",
        description=(
            "Explicitly run a bounded public-source search for the selected game and cache only "
            "metadata, feature hints, and direct CT/source links. No downloaded code or table "
            "script is executed, and this refresh never runs in the attach path."
        ),
        annotations=STATEFUL_READ,
        structured_output=True,
    )
    def refresh_public_game_sources(session_id: str) -> WebCheatDiscoveryResult:
        return runtime.discover_public_game_sources(session_id)

    @server.tool(
        title="Inspect inert Cheat Engine reference",
        description=(
            "Statically parse a local or public HTTPS Cheat Engine table for value hints, AOB "
            "signatures, module offsets, and structures. Auto Assembler, Lua, injection logic, "
            "and table UI are never executed or loaded."
        ),
        annotations=STATEFUL_READ,
        structured_output=True,
    )
    def inspect_cheat_table_reference(
        session_id: str,
        source: str,
        query: str = "",
        limit: int = 200,
        source_build: CheatTableSourceBuild | None = None,
    ) -> CheatTableResult:
        return runtime.inspect_cheat_table(
            session_id,
            source,
            query=query,
            limit=limit,
            source_build=source_build,
        )

    @server.tool(
        title="Observe current game HUD",
        description=(
            "Capture the selected foreground game window once, detect visible numeric text and "
            "HUD bars locally, then discard the pixels. Screens from other apps are refused."
        ),
        annotations=READ_ONLY,
        structured_output=True,
    )
    def observe_game_hud(session_id: str) -> HealthBarResult:
        return runtime.detect_health_bars(session_id)

    @server.tool(
        title="Read visible inventory selection",
        description=(
            "Capture the selected foreground game inventory once and read the visible selected "
            "item label plus current/max stack text locally. Pixels are discarded and no input "
            "or game-memory write occurs."
        ),
        annotations=READ_ONLY,
        structured_output=True,
    )
    def read_inventory_screen(session_id: str) -> InventoryScreenResult:
        return runtime.read_inventory_screen(session_id)

    @server.tool(
        title="Read saved inventory structure",
        description=(
            "Read typed inventory slots from the newest local No Man's Sky save. Returns item "
            "identity, amount, maximum, container group, cargo/technology classification, and "
            "grid coordinates without requiring a process session, capturing the screen, or "
            "reading/writing game memory."
        ),
        annotations=READ_ONLY,
        structured_output=True,
    )
    def read_saved_inventory(
        session_id: str | None = None,
        limit: int = 250,
    ) -> SavedInventoryResult:
        return runtime.read_saved_inventory(session_id, limit=limit)

    @server.tool(
        title="Resolve one saved inventory stack in live RAM",
        description=(
            "Resolve one exact No Man's Sky saved stack in the current process without writing "
            "game memory. The fast path scans only a remembered same-process allocation and "
            "validates the 0x30-byte item record plus neighboring saved slot identities. Raw "
            "addresses remain current-launch only. Set full_scan true only to seed a new process "
            "when no allocation hint exists."
        ),
        annotations=STATEFUL_READ,
        structured_output=True,
    )
    def resolve_saved_inventory_stack(
        session_id: str,
        item_id: str,
        container_name: str | None = "Inventory",
        stack_size_group: str | None = "Personal",
        full_scan: bool = False,
        limit: int = 20,
    ) -> SavedInventoryLiveResolution:
        return runtime.resolve_saved_inventory_stack(
            session_id,
            item_id,
            container_name=container_name,
            stack_size_group=stack_size_group,
            full_scan=full_scan,
            limit=limit,
        )

    @server.tool(
        title="Observe one moved inventory stack",
        description=(
            "Open a short read-only learning window for a validated exact-build inventory "
            "instruction. Ask the user to move one item stack during the window. The companion "
            "uses a temporary hardware execution breakpoint, never patches game code or writes "
            "game memory, and returns the live count address plus stable item identity."
        ),
        annotations=STATEFUL_READ,
        structured_output=True,
    )
    def observe_moved_inventory_slot(
        session_id: str,
        timeout_seconds: float = 20,
        recipe_name: str | None = None,
    ) -> InventorySlotObservation:
        return runtime.observe_moved_inventory_slot(
            session_id,
            timeout_seconds=timeout_seconds,
            recipe_name=recipe_name,
        )

    @server.tool(
        title="Arm inventory move learning",
        description=(
            "Validate the exact build and unique inventory signature, start a background "
            "hardware observer, and return only after it is genuinely armed. Perform one "
            "inventory move only after this tool returns. No game-memory write or code patch."
        ),
        annotations=STATEFUL_READ,
        structured_output=True,
    )
    def start_moved_inventory_observer(
        session_id: str,
        timeout_seconds: float = 20,
        recipe_name: str | None = None,
    ) -> InventoryObserverStatus:
        return runtime.start_moved_inventory_observer(
            session_id,
            timeout_seconds=timeout_seconds,
            recipe_name=recipe_name,
        )

    @server.tool(
        title="Get inventory move learning result",
        description=(
            "Return or briefly wait for one armed inventory observer result. A successful "
            "result includes the stable item identity and current-launch count/max addresses."
        ),
        annotations=READ_ONLY,
        structured_output=True,
    )
    def get_moved_inventory_observer(
        session_id: str,
        observer_token: str,
        wait_seconds: float = 0,
    ) -> InventoryObserverStatus:
        return runtime.moved_inventory_observer_status(
            session_id,
            observer_token,
            wait_seconds=wait_seconds,
        )

    @server.tool(
        title="Cancel inventory move learning",
        description=(
            "Cancel one active inventory observer, restore its debug registers, and detach."
        ),
        annotations=STATEFUL_READ,
        structured_output=True,
    )
    def cancel_moved_inventory_observer(
        session_id: str,
        observer_token: str,
    ) -> InventoryObserverStatus:
        return runtime.cancel_moved_inventory_observer(session_id, observer_token)

    @server.tool(
        title="Arm translated structure learning",
        description=(
            "Arm a short read-only hardware observation from a data-only translated CT or "
            "source recipe. The exact executable build and unique AOB must match. It captures "
            "one x64 register and reads typed structure fields without executing scripts, "
            "patching code, or writing game memory."
        ),
        annotations=STATEFUL_READ,
        structured_output=True,
    )
    def start_instruction_value_observer(
        session_id: str,
        recipe: InstructionValueRecipe,
        timeout_seconds: float = 20,
    ) -> InstructionValueObserverStatus:
        return runtime.start_instruction_value_observer(
            session_id,
            recipe,
            timeout_seconds=timeout_seconds,
        )

    @server.tool(
        title="Get translated structure learning result",
        description=(
            "Return or briefly wait for a translated instruction observer result, including "
            "current-launch field addresses, values, and source provenance."
        ),
        annotations=READ_ONLY,
        structured_output=True,
    )
    def get_instruction_value_observer(
        session_id: str,
        observer_token: str,
        wait_seconds: float = 0,
    ) -> InstructionValueObserverStatus:
        return runtime.instruction_value_observer_status(
            session_id,
            observer_token,
            wait_seconds=wait_seconds,
        )

    @server.tool(
        title="Cancel translated structure learning",
        description=(
            "Cancel one translated instruction observer, restore debug registers, and detach."
        ),
        annotations=STATEFUL_READ,
        structured_output=True,
    )
    def cancel_instruction_value_observer(
        session_id: str,
        observer_token: str,
    ) -> InstructionValueObserverStatus:
        return runtime.cancel_instruction_value_observer(session_id, observer_token)

    @server.tool(
        title="Sync portable game tables",
        description=(
            "Inspect, pull, stage, or explicitly publish data-only exact-build game tables in "
            "the configured private registry. Attach auto-loads from the local checkout and "
            "never waits on the network. Raw addresses and imported executable scripts are "
            "rejected. Publishing does not write game memory."
        ),
        annotations=STATEFUL_READ,
        structured_output=True,
    )
    def sync_game_table_registry(
        action: str = "status",
        session_id: str | None = None,
    ) -> GameTableRegistryStatus:
        return runtime.sync_game_table_registry(action, session_id=session_id)

    @server.tool(
        title="Remember a narrowed value scan",
        description=(
            "Persist every candidate from an untruncated scan of at most 20 results. Supply "
            "verified_addresses only for candidates already confirmed by a write/readback test."
        ),
        annotations=STATEFUL_READ,
        structured_output=True,
    )
    def remember_value_scan(
        session_id: str,
        scan_id: str,
        label: str,
        verification: str = "exact_match",
        verified_addresses: list[int] | None = None,
    ) -> LearnedGameValue:
        return runtime.remember_scan_candidates(
            session_id,
            scan_id,
            label,
            verification=verification,
            verified_addresses=verified_addresses,
        )

    @server.tool(
        title="Control the in-game GPT command overlay",
        description=(
            "Start, inspect, or stop the small always-on-top Windows command box. Ctrl+Shift+G "
            "toggles it and GPT Voice opens native Codex Voice. Stopping is cooperative and never "
            "terminates an unverified process."
        ),
        annotations=STATEFUL_READ,
        structured_output=True,
    )
    def control_game_command_overlay(action: str = "status") -> GameOverlayControlResult:
        if action not in {"start", "status", "stop"}:
            raise ValueError("action must be start, status, or stop")
        return overlay.control(action)

    @server.tool(
        title="Wait for one in-game GPT command",
        description=(
            "Wait up to 30 seconds for a local keyboard or voice command from the overlay. Pass "
            "the prior command ID as acknowledge_id only after acting on it."
        ),
        annotations=STATEFUL_READ,
        structured_output=True,
    )
    def wait_for_game_command(
        timeout_seconds: float = 20,
        acknowledge_id: str | None = None,
    ) -> GameOverlayCommandResult:
        return overlay.bridge.wait(
            timeout_seconds=timeout_seconds,
            acknowledge_id=acknowledge_id,
        )

    @server.tool(
        title="Update the in-game GPT overlay",
        description="Show a short GPT progress or result message in the in-game command overlay.",
        annotations=STATEFUL_READ,
        structured_output=True,
    )
    def set_game_command_overlay_message(
        message: str,
        state: str = "ready",
    ) -> GameOverlayMessageResult:
        return overlay.bridge.set_message(message, state=state)

    @server.tool(
        title="Read one RAM value",
        description=(
            "Read a typed scalar at a decimal memory address in the selected game. Supported "
            "types are i8, u8, i16, u16, i32, u32, i64, u64, f32, and f64."
        ),
        annotations=READ_ONLY,
        structured_output=True,
    )
    def read_game_memory(
        session_id: str,
        address: int,
        value_type: ValueType = ValueType.I32,
    ) -> RawMemoryReadResult:
        return runtime.read_memory_value(session_id, address, value_type)

    @server.tool(
        title="Write one RAM value",
        description=(
            "Write a typed scalar at a decimal address in the selected write-enabled game and "
            "return the previous value plus verified readback. expected_current is optional; "
            "when supplied, a mismatch stops the write."
        ),
        annotations=DIRECT_WRITE,
        structured_output=True,
    )
    def write_game_memory(
        session_id: str,
        address: int,
        value_type: ValueType,
        new_value: int | float,
        expected_current: int | float | None = None,
        operation_id: str | None = None,
    ) -> WriteResult:
        return runtime.write_memory_value(
            session_id,
            address,
            value_type,
            new_value,
            expected_current=expected_current,
            operation_id=operation_id,
        )

    @server.tool(
        title="Roll back one verified RAM write",
        description=(
            "Restore the original value using a receipt token. The rollback is refused if the "
            "process or current value changed after the verified write."
        ),
        annotations=DIRECT_WRITE,
        structured_output=True,
    )
    def rollback_game_memory_write(rollback_token: str) -> RollbackResult:
        return runtime.rollback_memory_write(rollback_token)

    return server, runtime


def run() -> None:
    server, runtime = create_raw_mcp_server()
    try:
        server.run(transport="streamable-http")
    finally:
        runtime.close()


def run_stdio() -> None:
    server, runtime = create_raw_mcp_server()
    try:
        server.run(transport="stdio")
    finally:
        runtime.close()
