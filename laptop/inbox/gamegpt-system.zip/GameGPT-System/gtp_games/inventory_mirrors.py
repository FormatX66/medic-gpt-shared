from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class CompleteInventoryMirror:
    """One saved-order inventory sequence that appears complete at a live base."""

    owner_key: str
    base_address: int
    record_signatures: tuple[str, ...]


def cross_owner_prefix_rejections(
    mirrors: list[CompleteInventoryMirror],
) -> dict[tuple[str, int], str]:
    """Reject shorter complete claims that are prefixes of another owner at one base.

    A two-record inventory can otherwise appear complete when its two records happen
    to match the start of a longer, independently complete inventory. The longer
    owner retains the base; only the shorter cross-owner claim is rejected.
    """

    rejected: dict[tuple[str, int], str] = {}
    for shorter in mirrors:
        if not shorter.record_signatures:
            continue
        for longer in mirrors:
            if (
                shorter.owner_key == longer.owner_key
                or shorter.base_address != longer.base_address
                or len(shorter.record_signatures) >= len(longer.record_signatures)
            ):
                continue
            if (
                longer.record_signatures[: len(shorter.record_signatures)]
                != shorter.record_signatures
            ):
                continue
            rejected[(shorter.owner_key, shorter.base_address)] = (
                f"cross-owner prefix of {longer.owner_key} "
                f"({len(shorter.record_signatures)} of {len(longer.record_signatures)} records)"
            )
            break
    return rejected
