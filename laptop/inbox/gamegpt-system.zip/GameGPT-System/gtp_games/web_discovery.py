from __future__ import annotations

import json
import os
import re
import time
from datetime import UTC, datetime, timedelta
from html.parser import HTMLParser
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.parse import parse_qs, quote, unquote, urlencode, urlsplit
from urllib.request import Request, build_opener

from gtp_games.cheat_tables import _SafeRedirectHandler, _validate_public_https_url
from gtp_games.config import Settings
from gtp_games.models import WebCheatDiscoveryResult, WebCheatSource

_RESULT_HOSTS = {
    "cheatengine.org",
    "fearlessrevolution.com",
    "github.com",
    "nexusmods.com",
    "raw.githubusercontent.com",
    "steamcommunity.com",
}
_CODE_SUFFIXES = {".c", ".cc", ".cpp", ".cs", ".h", ".hpp", ".json", ".md", ".py", ".txt"}
_RELEVANT_PATH = re.compile(
    r"cheat|trainer|memory|offset|pointer|health|stamina|mana|currency|inventory|player",
    re.IGNORECASE,
)
_RELEVANT_FORUM_TITLE = re.compile(
    r"cheat|trainer|table|mod|health|stamina|mana|money|currency|inventory|"
    r"blueprint|resource|movement|jump|ammo|experience|\bxp\b",
    re.IGNORECASE,
)
_FEATURE_PATTERNS: dict[str, re.Pattern[str]] = {
    "Health / god mode": re.compile(r"\bhealth\b|\bhp\b|god.?mode|invincib", re.I),
    "Stamina": re.compile(r"\bstamina\b|endurance", re.I),
    "Mana / energy": re.compile(r"\bmana\b|player.?energy", re.I),
    "Money / currency": re.compile(
        r"\bmoney\b|\bgold\b|currency|credits|units|nanites|quicksilver", re.I
    ),
    "Ammo / reload": re.compile(r"\bammo\b|ammunition|no.?reload|magazine", re.I),
    "Inventory / capacity": re.compile(r"inventory|capacity|stack.?size|slots", re.I),
    "Experience / skill points": re.compile(r"experience|\bxp\b|skill.?points", re.I),
    "Movement speed": re.compile(r"movement.?speed|walk.?speed|run.?speed|sprint", re.I),
    "Jump / jetpack": re.compile(r"jump.?height|jetpack|boost", re.I),
    "Cooldown / charge": re.compile(r"cooldown|instant.?charge|no.?overheat", re.I),
    "Life support / hazard": re.compile(r"life.?support|hazard|oxygen|shield", re.I),
    "Crafting / resources": re.compile(r"craft|resource|materials?|free.?build", re.I),
}


class WebCheatDiscovery:
    """Find public advisory sources without executing or persisting their code."""

    def __init__(self, settings: Settings) -> None:
        self.settings = settings
        self._deadline = 0.0
        self._notes: list[str] = []

    def discover(
        self,
        *,
        game_name: str,
        game_key: str,
        game_build_identity: str | None,
    ) -> WebCheatDiscoveryResult:
        cached = self._load_cache(game_key, game_build_identity)
        if cached is not None:
            cached.status = "cached"
            return cached

        self._deadline = time.monotonic() + self.settings.web_discovery_timeout_seconds
        self._notes = []
        sources: dict[str, WebCheatSource] = {}
        queries = [
            f'GitHub: "{game_name}" cheat / trainer repositories and .CT files',
            f'site:fearlessrevolution.com "{game_name}" cheat table',
            f'site:nexusmods.com "{game_name}" cheats gameplay',
            f'Steam Community: "{game_name}" cheat discussions',
        ]
        self._discover_github(game_name, sources)
        for query in queries[1:3]:
            if self._expired() or len(sources) >= self.settings.max_web_discovery_sources:
                break
            self._discover_search_results(query, sources)
        if not self._expired() and len(sources) < self.settings.max_web_discovery_sources:
            self._discover_steam_forums(game_name, sources)

        result = WebCheatDiscoveryResult(
            game_name=game_name,
            game_key=game_key,
            game_build_identity=game_build_identity,
            status="ready" if sources else "no_sources_found",
            sources=list(sources.values())[: self.settings.max_web_discovery_sources],
            queries=queries,
            notes=[
                "Public sources were indexed as untrusted metadata only.",
                "No downloaded script or repository code was executed.",
                *self._notes[:18],
            ],
        )
        if result.sources:
            result.cache_path = str(self._write_cache(result))
        return result

    def _discover_github(
        self,
        game_name: str,
        sources: dict[str, WebCheatSource],
    ) -> None:
        search_name = " ".join(re.sub(r"[^a-zA-Z0-9]+", " ", game_name).split())
        compact_name = re.sub(r"[^a-zA-Z0-9]+", "", game_name)
        repositories: list[dict] = []
        seen_repositories: set[str] = set()
        for query in (f'"{search_name}" cheat', f"{compact_name} trainer"):
            endpoint = "https://api.github.com/search/repositories?" + urlencode(
                {"q": query, "sort": "stars", "order": "desc", "per_page": 5}
            )
            try:
                payload = self._get_json(endpoint)
            except Exception as exc:  # noqa: BLE001 - network failures become catalog notes
                self._notes.append(f"A GitHub repository search did not complete: {exc}")
                continue
            items = payload.get("items", []) if isinstance(payload, dict) else []
            for item in items:
                if not isinstance(item, dict):
                    continue
                full_name = str(item.get("full_name") or "").casefold()
                if full_name and full_name not in seen_repositories:
                    repositories.append(item)
                    seen_repositories.add(full_name)
            if self._expired():
                return
        if self.settings.github_token is not None and not self._expired():
            self._discover_github_code_tables(compact_name, sources)
        code_reads = 0
        for repository_index, repository in enumerate(repositories[:6]):
            if self._expired() or len(sources) >= self.settings.max_web_discovery_sources:
                return
            if not isinstance(repository, dict):
                continue
            full_name = str(repository.get("full_name") or "").strip()
            html_url = str(repository.get("html_url") or "").strip()
            default_branch = str(repository.get("default_branch") or "main").strip()
            description = str(repository.get("description") or "").strip()
            if not full_name or not html_url:
                continue
            self._add_source(
                sources,
                WebCheatSource(
                    title=full_name,
                    url=html_url,
                    source_kind="github_repository",
                    host="github.com",
                    feature_hints=_feature_hints(f"{full_name} {description}"),
                    evidence=[
                        "Public GitHub repository metadata; repository code was not executed."
                    ],
                ),
            )
            if len(sources) >= self.settings.max_web_discovery_sources:
                return
            if repository_index >= 3:
                continue
            tree_url = (
                f"https://api.github.com/repos/{full_name}/git/trees/"
                f"{quote(default_branch, safe='')}?recursive=1"
            )
            try:
                tree_payload = self._get_json(tree_url)
            except Exception as exc:  # noqa: BLE001 - one repository must not stop discovery
                self._notes.append(f"Could not inspect the file list for {full_name}: {exc}")
                continue
            entries = tree_payload.get("tree", []) if isinstance(tree_payload, dict) else []
            ranked = sorted(
                (
                    entry
                    for entry in entries
                    if isinstance(entry, dict)
                    and entry.get("type") == "blob"
                    and int(entry.get("size") or 0) <= 512 * 1024
                    and _interesting_path(str(entry.get("path") or ""))
                ),
                key=lambda entry: _path_rank(str(entry.get("path") or "")),
            )[:10]
            for entry in ranked:
                if self._expired() or len(sources) >= self.settings.max_web_discovery_sources:
                    return
                path = str(entry.get("path") or "")
                suffix = Path(path).suffix.casefold()
                raw_url = (
                    f"https://raw.githubusercontent.com/{full_name}/"
                    f"{quote(default_branch, safe='')}/{quote(path, safe='/')}"
                )
                hints = _feature_hints(path)
                if suffix in _CODE_SUFFIXES and code_reads < 3:
                    try:
                        text = self._get_text(raw_url, max_bytes=256 * 1024)
                    except Exception:
                        text = ""
                    code_reads += 1
                    hints = list(dict.fromkeys([*hints, *_feature_hints(text)]))
                direct_table = suffix == ".ct"
                display_url = (
                    raw_url
                    if direct_table
                    else f"https://github.com/{full_name}/blob/"
                    f"{quote(default_branch, safe='')}/{quote(path, safe='/')}"
                )
                self._add_source(
                    sources,
                    WebCheatSource(
                        title=f"{full_name}: {path}",
                        url=display_url,
                        source_kind=("cheat_engine_table" if direct_table else "github_code"),
                        host=("raw.githubusercontent.com" if direct_table else "github.com"),
                        direct_table=direct_table,
                        feature_hints=hints,
                        evidence=[
                            "Public repository file inspected as text/metadata only.",
                            "No repository code or table script was executed.",
                        ],
                    ),
                )

    def _discover_github_code_tables(
        self,
        compact_name: str,
        sources: dict[str, WebCheatSource],
    ) -> None:
        endpoint = "https://api.github.com/search/code?" + urlencode(
            {"q": f"{compact_name} extension:ct", "per_page": 10}
        )
        try:
            payload = self._get_json(endpoint)
        except Exception as exc:  # noqa: BLE001 - optional authenticated search
            self._notes.append(f"GitHub table-file search did not complete: {exc}")
            return
        items = payload.get("items", []) if isinstance(payload, dict) else []
        for item in items[:10]:
            if not isinstance(item, dict):
                continue
            path = str(item.get("path") or "")
            repository = item.get("repository")
            if Path(path).suffix.casefold() != ".ct" or not isinstance(repository, dict):
                continue
            full_name = str(repository.get("full_name") or "").strip()
            default_branch = str(repository.get("default_branch") or "main").strip()
            if not full_name:
                continue
            raw_url = (
                f"https://raw.githubusercontent.com/{full_name}/"
                f"{quote(default_branch, safe='')}/{quote(path, safe='/')}"
            )
            self._add_source(
                sources,
                WebCheatSource(
                    title=f"{full_name}: {path}",
                    url=raw_url,
                    source_kind="cheat_engine_table",
                    host="raw.githubusercontent.com",
                    direct_table=True,
                    feature_hints=_feature_hints(path),
                    evidence=[
                        "Authenticated GitHub file search found this public .CT file.",
                        "The table was treated as inert data and was not executed.",
                    ],
                ),
            )

    def _discover_search_results(
        self,
        query: str,
        sources: dict[str, WebCheatSource],
    ) -> None:
        endpoint = "https://html.duckduckgo.com/html/?" + urlencode({"q": query})
        try:
            html = self._get_text(endpoint, max_bytes=512 * 1024)
        except Exception as exc:  # noqa: BLE001 - search outage is non-fatal
            self._notes.append(f"A forum/mod search did not complete: {exc}")
            return
        parser = _DuckDuckGoResultsParser()
        parser.feed(html)
        for title, url in parser.results[:8]:
            normalized = _unwrap_search_url(url)
            if not _allowed_result_url(normalized):
                continue
            host = (urlsplit(normalized).hostname or "").casefold()
            self._add_source(
                sources,
                WebCheatSource(
                    title=title,
                    url=normalized,
                    source_kind=_source_kind(host),
                    host=host,
                    direct_table=normalized.casefold().endswith(".ct"),
                    feature_hints=_feature_hints(title),
                    evidence=["Public search-result metadata; the linked page was not executed."],
                ),
            )
            if len(sources) >= self.settings.max_web_discovery_sources:
                return

        if not parser.results and "anomaly" in html.casefold():
            self._notes.append(
                "A public forum/mod search was rate-limited; mounting continued safely."
            )

    def _discover_steam_forums(
        self,
        game_name: str,
        sources: dict[str, WebCheatSource],
    ) -> None:
        query = f'"{game_name}" cheat'
        endpoint = "https://steamcommunity.com/discussions/forum/search/?" + urlencode({"q": query})
        try:
            html = self._get_text(endpoint, max_bytes=768 * 1024)
        except Exception as exc:  # noqa: BLE001 - forum outage is non-fatal
            self._notes.append(f"Steam Community search did not complete: {exc}")
            return
        parser = _SteamForumResultsParser()
        parser.feed(html)
        game_terms = {
            term.casefold() for term in re.findall(r"[a-zA-Z0-9]+", game_name) if len(term) >= 3
        }
        for title, url in parser.results[:12]:
            title_terms = set(re.findall(r"[a-zA-Z0-9]+", title.casefold()))
            if game_terms and not (game_terms & title_terms):
                continue
            if not _RELEVANT_FORUM_TITLE.search(title):
                continue
            if not _allowed_result_url(url):
                continue
            self._add_source(
                sources,
                WebCheatSource(
                    title=title,
                    url=url,
                    source_kind="community_forum",
                    host="steamcommunity.com",
                    feature_hints=_feature_hints(title),
                    evidence=[
                        "Public Steam Community discussion metadata only.",
                        "No linked download, script, or code was executed.",
                    ],
                ),
            )
            if len(sources) >= self.settings.max_web_discovery_sources:
                return

    def _add_source(
        self,
        sources: dict[str, WebCheatSource],
        source: WebCheatSource,
    ) -> None:
        sources.setdefault(source.url, source)

    def _get_json(self, url: str) -> object:
        return json.loads(self._get_text(url, max_bytes=self.settings.max_web_response_bytes))

    def _get_text(self, url: str, *, max_bytes: int) -> str:
        if self._expired():
            raise TimeoutError("web discovery time budget expired")
        _validate_public_https_url(url)
        headers = {
            "Accept-Encoding": "identity",
            "User-Agent": "GTP-Games-ReadOnly-Web-Discovery/0.9.1",
        }
        host = (urlsplit(url).hostname or "").casefold()
        if host == "api.github.com":
            headers.update(
                {
                    "Accept": "application/vnd.github+json",
                    "X-GitHub-Api-Version": "2022-11-28",
                }
            )
            if self.settings.github_token is not None:
                headers["Authorization"] = f"Bearer {self.settings.github_token.get_secret_value()}"
        else:
            headers["Accept"] = "text/html,text/plain,application/json"
        request = Request(url, headers=headers)
        timeout = max(1.0, min(8.0, self._deadline - time.monotonic()))
        try:
            with build_opener(_SafeRedirectHandler()).open(request, timeout=timeout) as response:
                final_url = response.geturl()
                _validate_public_https_url(final_url)
                declared = response.headers.get("Content-Length")
                if declared and int(declared) > max_bytes:
                    raise ValueError("response exceeds the discovery byte limit")
                raw = response.read(max_bytes + 1)
        except (HTTPError, URLError, OSError, ValueError) as exc:
            raise RuntimeError("public source request failed") from exc
        if len(raw) > max_bytes:
            raise RuntimeError("public source response exceeds the discovery byte limit")
        return raw.decode("utf-8", errors="replace")

    def _cache_path(self, game_key: str, identity: str | None) -> Path:
        build = re.sub(r"[^a-zA-Z0-9._-]+", "-", identity or "unknown-build")[-80:]
        game = re.sub(r"[^a-z0-9-]+", "-", game_key.casefold()).strip("-")
        return self.settings.web_discovery_cache_directory / game / f"{build}.web.json"

    def _load_cache(
        self,
        game_key: str,
        identity: str | None,
    ) -> WebCheatDiscoveryResult | None:
        path = self._cache_path(game_key, identity)
        try:
            age = datetime.now(UTC) - datetime.fromtimestamp(path.stat().st_mtime, UTC)
            if age > timedelta(hours=self.settings.web_discovery_cache_hours):
                return None
            result = WebCheatDiscoveryResult.model_validate_json(path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return None
        if result.game_key != game_key or result.game_build_identity != identity:
            return None
        result.cache_path = str(path.resolve())
        return result

    def _write_cache(self, result: WebCheatDiscoveryResult) -> Path:
        path = self._cache_path(result.game_key, result.game_build_identity).resolve()
        path.parent.mkdir(parents=True, exist_ok=True)
        temporary = path.with_suffix(".tmp")
        temporary.write_text(result.model_dump_json(indent=2), encoding="utf-8")
        os.replace(temporary, path)
        return path

    def _expired(self) -> bool:
        return time.monotonic() >= self._deadline


class _DuckDuckGoResultsParser(HTMLParser):
    def __init__(self) -> None:
        super().__init__()
        self.results: list[tuple[str, str]] = []
        self._href: str | None = None
        self._title: list[str] = []

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        if tag.casefold() != "a":
            return
        attributes = dict(attrs)
        classes = (attributes.get("class") or "").split()
        if "result__a" in classes and attributes.get("href"):
            self._href = str(attributes["href"])
            self._title = []

    def handle_data(self, data: str) -> None:
        if self._href is not None:
            self._title.append(data)

    def handle_endtag(self, tag: str) -> None:
        if tag.casefold() == "a" and self._href is not None:
            title = " ".join("".join(self._title).split())
            if title:
                self.results.append((title, self._href))
            self._href = None
            self._title = []


class _SteamForumResultsParser(HTMLParser):
    def __init__(self) -> None:
        super().__init__()
        self.results: list[tuple[str, str]] = []
        self._pending_href: str | None = None
        self._in_title = False
        self._title: list[str] = []

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        attributes = dict(attrs)
        classes = (attributes.get("class") or "").split()
        if tag.casefold() == "a" and "forum_topic_overlay" in classes:
            href = attributes.get("href")
            if href:
                self._pending_href = str(href)
        if tag.casefold() == "div" and "forum_topic_name" in classes:
            self._in_title = True
            self._title = []

    def handle_data(self, data: str) -> None:
        if self._in_title:
            self._title.append(data)

    def handle_endtag(self, tag: str) -> None:
        if tag.casefold() != "div" or not self._in_title:
            return
        title = " ".join("".join(self._title).split())
        if title and self._pending_href:
            self.results.append((title, self._pending_href))
        self._pending_href = None
        self._in_title = False
        self._title = []


def _interesting_path(path: str) -> bool:
    suffix = Path(path).suffix.casefold()
    return (
        suffix == ".ct"
        or Path(path).name.casefold().startswith("readme")
        or (suffix in _CODE_SUFFIXES and bool(_RELEVANT_PATH.search(path)))
    )


def _path_rank(path: str) -> tuple[int, int, str]:
    suffix = Path(path).suffix.casefold()
    priority = 0 if suffix == ".ct" else 1 if "readme" in Path(path).name.casefold() else 2
    return (priority, len(Path(path).parts), path.casefold())


def _feature_hints(text: str) -> list[str]:
    bounded = text[: 256 * 1024]
    return [name for name, pattern in _FEATURE_PATTERNS.items() if pattern.search(bounded)]


def _unwrap_search_url(url: str) -> str:
    if url.startswith("//"):
        url = "https:" + url
    parsed = urlsplit(url)
    if parsed.hostname and parsed.hostname.casefold().endswith("duckduckgo.com"):
        target = parse_qs(parsed.query).get("uddg", [""])[0]
        if target:
            return unquote(target)
    return url


def _allowed_result_url(url: str) -> bool:
    parsed = urlsplit(url)
    if parsed.scheme.casefold() != "https" or not parsed.hostname:
        return False
    host = parsed.hostname.casefold()
    return any(host == allowed or host.endswith(f".{allowed}") for allowed in _RESULT_HOSTS)


def _source_kind(host: str) -> str:
    if host.endswith("github.com"):
        return "github_code"
    if host.endswith("fearlessrevolution.com") or host.endswith("cheatengine.org"):
        return "game_forum"
    if host.endswith("nexusmods.com"):
        return "mod_forum"
    if host.endswith("steamcommunity.com"):
        return "community_forum"
    return "public_web"
