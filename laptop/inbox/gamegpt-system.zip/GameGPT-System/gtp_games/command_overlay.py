from __future__ import annotations

import argparse
import ctypes
import ctypes.wintypes
import json
import os
import subprocess
import sys
import threading
import time
from datetime import UTC, datetime
from pathlib import Path
from typing import Literal
from uuid import uuid4

import psutil
from pydantic import BaseModel, Field

HOTKEY_LABEL = "Ctrl+Shift+G"
DEFAULT_GPT_VOICE_HOTKEY = "Ctrl+1"
AUTO_GPT_VOICE_HOTKEY = "auto"
MAX_COMMAND_LENGTH = 2000
MAX_STATUS_LENGTH = 240
COLLAPSED_WIDTH = 236
COLLAPSED_HEIGHT = 38
EXPANDED_HEIGHT = 112
VOICE_LAUNCH_GUARD_SECONDS = 12.0


class GameOverlayCommand(BaseModel):
    id: str
    text: str
    source: Literal["keyboard", "voice"] = "keyboard"
    created_at: datetime = Field(default_factory=lambda: datetime.now(UTC))


class GameOverlayCommandResult(BaseModel):
    command: GameOverlayCommand | None = None
    timed_out: bool = False
    pending_count: int = Field(default=0, ge=0)


class GameOverlayControlResult(BaseModel):
    status: str
    running: bool
    pid: int | None = None
    hwnd: int | None = None
    hotkey: str = HOTKEY_LABEL
    hotkey_registered: bool = False
    voice_input: str = f"Codex GPT Voice ({DEFAULT_GPT_VOICE_HOTKEY})"
    mode: Literal["collapsed", "expanded", "unknown"] = "unknown"
    width: int | None = None
    height: int | None = None
    command_path: str
    message: str = ""


class GameOverlayMessageResult(BaseModel):
    state: str
    message: str
    updated_at: datetime


class GameCommandBridge:
    """Small durable queue joining the in-game overlay to a conversational MCP turn."""

    def __init__(self, directory: Path) -> None:
        self.directory = directory.expanduser().resolve()
        self.commands_path = self.directory / "commands.jsonl"
        self.acknowledged_path = self.directory / "acknowledged.json"
        self.message_path = self.directory / "message.json"
        self.runtime_path = self.directory / "runtime.json"
        self.stop_path = self.directory / "stop.json"
        self._lock = threading.RLock()

    def submit(
        self,
        text: str,
        *,
        source: Literal["keyboard", "voice"] = "keyboard",
    ) -> GameOverlayCommand:
        normalized = " ".join(text.split()).strip()
        if not normalized:
            raise ValueError("game command must not be empty")
        if len(normalized) > MAX_COMMAND_LENGTH:
            raise ValueError(f"game command must be at most {MAX_COMMAND_LENGTH} characters")
        command = GameOverlayCommand(id=uuid4().hex, text=normalized, source=source)
        with self._lock:
            self.directory.mkdir(parents=True, exist_ok=True)
            with self.commands_path.open("a", encoding="utf-8", newline="\n") as stream:
                stream.write(command.model_dump_json() + "\n")
        return command

    def pending(self, *, limit: int = 20) -> list[GameOverlayCommand]:
        acknowledged = self._acknowledged()
        commands: list[GameOverlayCommand] = []
        with self._lock:
            try:
                lines = self.commands_path.read_text(encoding="utf-8").splitlines()
            except OSError:
                return []
        for line in lines[-2000:]:
            try:
                command = GameOverlayCommand.model_validate_json(line)
            except ValueError:
                continue
            if command.id not in acknowledged:
                commands.append(command)
            if len(commands) >= limit:
                break
        return commands

    def acknowledge(self, command_id: str) -> None:
        if not command_id:
            return
        with self._lock:
            acknowledged = self._acknowledged()
            acknowledged.add(command_id)
            self.directory.mkdir(parents=True, exist_ok=True)
            self._write_json(
                self.acknowledged_path,
                {"acknowledged": sorted(acknowledged)[-2000:]},
            )

    def wait(
        self,
        *,
        timeout_seconds: float,
        acknowledge_id: str | None = None,
    ) -> GameOverlayCommandResult:
        if not 0 <= timeout_seconds <= 30:
            raise ValueError("timeout_seconds must be between 0 and 30")
        if acknowledge_id:
            self.acknowledge(acknowledge_id)
        deadline = time.monotonic() + timeout_seconds
        while True:
            pending = self.pending()
            if pending:
                return GameOverlayCommandResult(
                    command=pending[0],
                    pending_count=len(pending),
                )
            if time.monotonic() >= deadline:
                return GameOverlayCommandResult(timed_out=True)
            time.sleep(0.1)

    def set_message(self, message: str, *, state: str = "ready") -> GameOverlayMessageResult:
        normalized = " ".join(message.split()).strip()[:MAX_STATUS_LENGTH]
        result = GameOverlayMessageResult(
            state=state[:40] or "ready",
            message=normalized,
            updated_at=datetime.now(UTC),
        )
        with self._lock:
            self.directory.mkdir(parents=True, exist_ok=True)
            self._write_json(self.message_path, result.model_dump(mode="json"))
        return result

    def message(self) -> GameOverlayMessageResult:
        try:
            return GameOverlayMessageResult.model_validate_json(
                self.message_path.read_text(encoding="utf-8")
            )
        except (OSError, ValueError):
            return GameOverlayMessageResult(
                state="ready",
                message=f"Ready. Press {HOTKEY_LABEL} to command GPT.",
                updated_at=datetime.now(UTC),
            )

    def runtime(self) -> dict[str, object]:
        try:
            payload = json.loads(self.runtime_path.read_text(encoding="utf-8"))
            return payload if isinstance(payload, dict) else {}
        except (OSError, ValueError):
            return {}

    def write_runtime(self, payload: dict[str, object]) -> None:
        self.directory.mkdir(parents=True, exist_ok=True)
        self._write_json(self.runtime_path, payload)

    def request_stop(self, token: str) -> None:
        self.directory.mkdir(parents=True, exist_ok=True)
        self._write_json(self.stop_path, {"token": token})

    def stop_requested(self, token: str) -> bool:
        try:
            payload = json.loads(self.stop_path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return False
        return isinstance(payload, dict) and payload.get("token") == token

    def clear_stop(self) -> None:
        self.stop_path.unlink(missing_ok=True)

    def _acknowledged(self) -> set[str]:
        try:
            payload = json.loads(self.acknowledged_path.read_text(encoding="utf-8"))
            values = payload.get("acknowledged", []) if isinstance(payload, dict) else []
            return {str(item) for item in values}
        except (OSError, ValueError):
            return set()

    @staticmethod
    def _write_json(path: Path, payload: object) -> None:
        temporary = path.with_suffix(path.suffix + ".tmp")
        temporary.write_text(json.dumps(payload, indent=2), encoding="utf-8")
        temporary.replace(path)


class GameCommandOverlayController:
    def __init__(
        self,
        directory: Path,
        *,
        gpt_voice_hotkey: str = AUTO_GPT_VOICE_HOTKEY,
    ) -> None:
        self.bridge = GameCommandBridge(directory)
        self.gpt_voice_hotkey = _resolve_gpt_voice_hotkey(gpt_voice_hotkey)

    def control(self, action: Literal["start", "status", "stop"]) -> GameOverlayControlResult:
        if action == "start":
            return self.start()
        if action == "stop":
            return self.stop()
        return self.status()

    def start(self) -> GameOverlayControlResult:
        current = self.status()
        if current.running:
            return current
        if sys.platform != "win32":
            return self._result("unavailable_on_this_platform", False)

        token = uuid4().hex
        self.bridge.clear_stop()
        executable = Path(sys.executable)
        pythonw = executable.with_name("pythonw.exe")
        if pythonw.is_file():
            executable = pythonw
        creation_flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        subprocess.Popen(
            [
                str(executable),
                "-m",
                "gtp_games.command_overlay",
                "--directory",
                str(self.bridge.directory),
                "--token",
                token,
                "--voice-hotkey",
                self.gpt_voice_hotkey,
            ],
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            close_fds=True,
            creationflags=creation_flags,
        )
        deadline = time.monotonic() + 12
        while time.monotonic() < deadline:
            runtime = self.bridge.runtime()
            if runtime.get("token") == token and _overlay_process_matches(runtime):
                return self.status()
            time.sleep(0.1)
        return self._result("start_pending", False, message="Overlay launch did not report ready.")

    def stop(self) -> GameOverlayControlResult:
        runtime = self.bridge.runtime()
        token = str(runtime.get("token", ""))
        if not token or not _overlay_process_matches(runtime):
            return self._result("stopped", False)
        self.bridge.request_stop(token)
        deadline = time.monotonic() + 3
        while time.monotonic() < deadline:
            if not _overlay_process_matches(runtime):
                return self._result("stopped", False)
            time.sleep(0.1)
        return self._result("stop_requested", True, runtime=runtime)

    def status(self) -> GameOverlayControlResult:
        runtime = self.bridge.runtime()
        running = _overlay_process_matches(runtime)
        message = self.bridge.message().message
        return self._result(
            "running" if running else "stopped",
            running,
            runtime=runtime,
            message=message,
        )

    def _result(
        self,
        status: str,
        running: bool,
        *,
        runtime: dict[str, object] | None = None,
        message: str = "",
    ) -> GameOverlayControlResult:
        payload = runtime or {}
        return GameOverlayControlResult(
            status=status,
            running=running,
            pid=_optional_int(payload.get("pid")),
            hwnd=_optional_int(payload.get("hwnd")),
            hotkey_registered=bool(payload.get("hotkey_registered", False)),
            voice_input=f"Codex GPT Voice ({self.gpt_voice_hotkey})",
            mode=(
                str(payload.get("mode"))
                if payload.get("mode") in {"collapsed", "expanded"}
                else "unknown"
            ),
            width=_optional_int(payload.get("width")),
            height=_optional_int(payload.get("height")),
            command_path=str(self.bridge.commands_path),
            message=message,
        )


def _optional_int(value: object) -> int | None:
    return int(value) if isinstance(value, int | float) else None


def _overlay_process_matches(runtime: dict[str, object]) -> bool:
    pid = _optional_int(runtime.get("pid"))
    token = runtime.get("token")
    if pid is None or not isinstance(token, str) or not token:
        return False
    try:
        process = psutil.Process(pid)
        command = " ".join(process.cmdline()).casefold()
        return process.is_running() and "gtp_games.command_overlay" in command
    except (psutil.Error, OSError):
        return False


def _enable_dpi_awareness() -> None:
    if sys.platform != "win32":
        return
    try:
        ctypes.windll.shcore.SetProcessDpiAwareness(2)
    except (AttributeError, OSError):
        try:
            ctypes.windll.user32.SetProcessDPIAware()
        except (AttributeError, OSError):
            pass


def _parse_hotkey(chord: str) -> tuple[int, ...]:
    modifiers = {
        "ctrl": 0x11,
        "control": 0x11,
        "shift": 0x10,
        "alt": 0x12,
        "win": 0x5B,
        "windows": 0x5B,
    }
    aliases = {"space": 0x20, "enter": 0x0D, "tab": 0x09}
    parts = [part.strip().casefold() for part in chord.split("+") if part.strip()]
    if len(parts) < 2:
        raise ValueError("GPT Voice hotkey must include a modifier and a key")
    virtual_keys: list[int] = []
    for part in parts[:-1]:
        try:
            virtual_keys.append(modifiers[part])
        except KeyError as exc:
            raise ValueError(f"unsupported GPT Voice modifier: {part}") from exc
    key = parts[-1]
    if len(key) == 1 and key.isascii() and key.isalnum():
        virtual_keys.append(ord(key.upper()))
    elif key in aliases:
        virtual_keys.append(aliases[key])
    elif key.startswith("f") and key[1:].isdigit() and 1 <= int(key[1:]) <= 24:
        virtual_keys.append(0x70 + int(key[1:]) - 1)
    else:
        raise ValueError(f"unsupported GPT Voice key: {key}")
    return tuple(virtual_keys)


def _resolve_gpt_voice_hotkey(
    configured: str,
    *,
    codex_home: Path | None = None,
) -> str:
    normalized = configured.strip()
    if normalized and normalized.casefold() != AUTO_GPT_VOICE_HOTKEY:
        _parse_hotkey(normalized)
        return normalized

    root = codex_home
    if root is None:
        configured_home = os.environ.get("CODEX_HOME", "").strip()
        root = Path(configured_home) if configured_home else Path.home() / ".codex"
    try:
        payload = json.loads((root / "keybindings.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return DEFAULT_GPT_VOICE_HOTKEY
    if not isinstance(payload, list):
        return DEFAULT_GPT_VOICE_HOTKEY
    for binding in reversed(payload):
        if not isinstance(binding, dict) or binding.get("command") != "realtimeVoice":
            continue
        key = binding.get("key")
        if not isinstance(key, str) or not key.strip():
            continue
        try:
            _parse_hotkey(key)
        except ValueError:
            continue
        return key.strip()
    return DEFAULT_GPT_VOICE_HOTKEY


def _send_hotkey(chord: str) -> None:
    user32 = ctypes.windll.user32
    key_up = 0x0002
    virtual_keys = _parse_hotkey(chord)
    for virtual_key in virtual_keys:
        user32.keybd_event(virtual_key, 0, 0, 0)
    for virtual_key in reversed(virtual_keys):
        user32.keybd_event(virtual_key, 0, key_up, 0)


def run_overlay(
    directory: Path,
    token: str,
    *,
    gpt_voice_hotkey: str = AUTO_GPT_VOICE_HOTKEY,
) -> None:
    if sys.platform != "win32":
        raise RuntimeError("the command overlay requires Windows")
    import tkinter as tk

    _enable_dpi_awareness()
    gpt_voice_hotkey = _resolve_gpt_voice_hotkey(gpt_voice_hotkey)
    bridge = GameCommandBridge(directory)
    root = tk.Tk()
    root.title("GTP Games Command Overlay")
    root.overrideredirect(True)
    root.resizable(False, False)
    root.attributes("-topmost", True)
    root.attributes("-alpha", 0.9)
    root.configure(background="#38C7EE")
    try:
        root.attributes("-toolwindow", True)
    except tk.TclError:
        pass

    expanded_width = min(520, max(360, root.winfo_screenwidth() - 40))
    position = {
        "x": max(0, root.winfo_screenwidth() - COLLAPSED_WIDTH - 24),
        "y": 24,
    }
    mode = {"value": "collapsed"}
    current_size = {"width": COLLAPSED_WIDTH, "height": COLLAPSED_HEIGHT}
    command_value = tk.StringVar()
    status_value = tk.StringVar(value=bridge.message().message)
    compact_status_value = tk.StringVar(value="READY")
    status_hold_until = {"value": 0.0}
    voice_guard_until = {"value": 0.0}
    hotkey_state = {"registered": False}
    drag_offset = {"x": 0, "y": 0}

    collapsed_frame = tk.Frame(root, background="#101827", padx=6, pady=4)
    expanded_frame = tk.Frame(root, background="#101827", padx=10, pady=7)

    def publish_runtime() -> None:
        root.update_idletasks()
        client_hwnd = root.winfo_id()
        try:
            native_hwnd = ctypes.windll.user32.GetAncestor(client_hwnd, 2) or client_hwnd
        except (AttributeError, OSError):
            native_hwnd = client_hwnd
        bridge.write_runtime(
            {
                "token": token,
                "pid": os.getpid(),
                "hwnd": native_hwnd,
                "mode": mode["value"],
                "width": root.winfo_width(),
                "height": root.winfo_height(),
                "topmost": True,
                "hotkey": HOTKEY_LABEL,
                "hotkey_registered": hotkey_state["registered"],
                "gpt_voice_hotkey": gpt_voice_hotkey,
                "started_at": datetime.now(UTC).isoformat(),
            }
        )

    def apply_geometry(width: int, height: int) -> None:
        current_size.update(width=width, height=height)
        max_x = max(0, root.winfo_screenwidth() - width)
        position["x"] = min(max(0, position["x"]), max_x)
        root.geometry(f"{width}x{height}+{position['x']}+{position['y']}")

    def show_collapsed(*, publish: bool = True) -> None:
        expanded_frame.pack_forget()
        collapsed_frame.pack(fill="both", expand=True, padx=2, pady=2)
        mode["value"] = "collapsed"
        root.attributes("-alpha", 0.9)
        apply_geometry(COLLAPSED_WIDTH, COLLAPSED_HEIGHT)
        root.lift()
        root.attributes("-topmost", True)
        if publish:
            publish_runtime()

    def show_expanded() -> None:
        collapsed_frame.pack_forget()
        expanded_frame.pack(fill="both", expand=True, padx=2, pady=2)
        mode["value"] = "expanded"
        root.attributes("-alpha", 0.97)
        apply_geometry(expanded_width, EXPANDED_HEIGHT)
        root.lift()
        root.attributes("-topmost", True)
        entry.focus_force()
        publish_runtime()

    def begin_drag(event) -> None:
        drag_offset["x"] = int(event.x_root) - position["x"]
        drag_offset["y"] = int(event.y_root) - position["y"]

    def drag_window(event) -> None:
        position["x"] = int(event.x_root) - drag_offset["x"]
        position["y"] = max(0, int(event.y_root) - drag_offset["y"])
        apply_geometry(current_size["width"], current_size["height"])

    def submit() -> None:
        text = command_value.get()
        if not text.strip():
            return
        try:
            bridge.submit(text, source="keyboard")
        except ValueError as exc:
            status_value.set(str(exc))
            return
        command_value.set("")
        status_value.set("Sent to GPT. Waiting for the task to respond…")
        compact_status_value.set("SENT")
        status_hold_until["value"] = time.monotonic() + 2.5
        root.after(650, show_collapsed)

    def start_voice() -> None:
        try:
            _parse_hotkey(gpt_voice_hotkey)
        except ValueError as exc:
            status_value.set(str(exc))
            return
        now = time.monotonic()
        if now < voice_guard_until["value"]:
            status_value.set("GPT Voice is already starting. Speak when Codex opens.")
            compact_status_value.set("VOICE STARTING")
            show_collapsed()
            return
        voice_guard_until["value"] = now + VOICE_LAUNCH_GUARD_SECONDS
        status_value.set(f"Opening Codex GPT Voice with {gpt_voice_hotkey}…")
        compact_status_value.set("VOICE STARTING")
        status_hold_until["value"] = time.monotonic() + 2.5
        show_collapsed()

        def launch_voice() -> None:
            try:
                _send_hotkey(gpt_voice_hotkey)
                compact_status_value.set("VOICE OPEN")
            except (AttributeError, OSError, RuntimeError) as exc:
                status_value.set(f"Could not start GPT Voice: {exc}")
                compact_status_value.set("VOICE ERROR")
                voice_guard_until["value"] = 0.0
                status_hold_until["value"] = time.monotonic() + 5

        root.after(120, launch_voice)

    def toggle() -> None:
        if mode["value"] == "expanded":
            show_collapsed()
        else:
            show_expanded()

    button_style = {
        "background": "#1C2A40",
        "foreground": "#E7F7FF",
        "activebackground": "#29415F",
        "activeforeground": "#FFFFFF",
        "borderwidth": 0,
        "padx": 9,
        "pady": 2,
        "font": ("Segoe UI", 8, "bold"),
    }

    compact_handle = tk.Label(
        collapsed_frame,
        text="GTP",
        background="#101827",
        foreground="#8BE9FD",
        font=("Segoe UI", 9, "bold"),
        cursor="fleur",
    )
    compact_handle.pack(side="left", padx=(2, 5))
    tk.Label(
        collapsed_frame,
        textvariable=compact_status_value,
        background="#101827",
        foreground="#AABBD1",
        font=("Segoe UI", 7, "bold"),
    ).pack(side="left", fill="x", expand=True)
    tk.Button(
        collapsed_frame,
        text="VOICE",
        command=start_voice,
        **button_style,
    ).pack(side="right", padx=(4, 0))
    tk.Button(
        collapsed_frame,
        text="OPEN",
        command=show_expanded,
        **button_style,
    ).pack(side="right")

    header = tk.Frame(expanded_frame, background="#101827")
    header.pack(fill="x")
    header_handle = tk.Label(
        header,
        text=f"GTP GAMES   •   {HOTKEY_LABEL}",
        background="#101827",
        foreground="#8BE9FD",
        font=("Segoe UI", 9, "bold"),
        cursor="fleur",
    )
    header_handle.pack(side="left")
    tk.Button(
        header,
        text="MINIMIZE",
        command=show_collapsed,
        **button_style,
    ).pack(side="right")
    entry = tk.Entry(
        expanded_frame,
        textvariable=command_value,
        background="#17243A",
        foreground="#FFFFFF",
        insertbackground="#FFFFFF",
        relief="flat",
        font=("Segoe UI", 10),
    )
    entry.pack(fill="x", pady=(6, 5), ipady=3)
    footer = tk.Frame(expanded_frame, background="#101827")
    footer.pack(fill="x")
    tk.Label(
        footer,
        textvariable=status_value,
        background="#101827",
        foreground="#AABBD1",
        anchor="w",
        font=("Segoe UI", 8),
    ).pack(side="left", fill="x", expand=True)
    tk.Button(
        footer,
        text=f"GPT VOICE  {gpt_voice_hotkey}",
        command=start_voice,
        **button_style,
    ).pack(side="right", padx=(6, 0))
    tk.Button(footer, text="SEND", command=submit, **button_style).pack(side="right")

    root.bind("<Return>", lambda _event: submit())
    root.bind("<Escape>", lambda _event: show_collapsed())
    root.protocol("WM_DELETE_WINDOW", show_collapsed)
    for handle in (compact_handle, header_handle):
        handle.bind("<ButtonPress-1>", begin_drag)
        handle.bind("<B1-Motion>", drag_window)

    def hotkey_loop() -> None:
        user32 = ctypes.windll.user32
        modifiers = 0x0002 | 0x0004 | 0x4000
        hotkey_state["registered"] = bool(user32.RegisterHotKey(None, 1, modifiers, ord("G")))
        root.after(0, publish_runtime)
        message = ctypes.wintypes.MSG()
        while user32.GetMessageW(ctypes.byref(message), None, 0, 0) > 0:
            if message.message == 0x0312 and message.wParam == 1:
                root.after(0, toggle)
        if hotkey_state["registered"]:
            user32.UnregisterHotKey(None, 1)

    def poll() -> None:
        if bridge.stop_requested(token):
            root.destroy()
            return
        message = bridge.message()
        if (
            message.message
            and command_value.get() == ""
            and time.monotonic() >= status_hold_until["value"]
        ):
            status_value.set(message.message)
        root.after(350, poll)

    show_collapsed(publish=False)
    threading.Thread(target=hotkey_loop, daemon=True, name="gtp-overlay-hotkey").start()
    root.after(100, publish_runtime)
    root.after(350, poll)
    root.mainloop()


def main() -> None:
    parser = argparse.ArgumentParser(description="GTP Games in-game GPT command overlay")
    parser.add_argument("--directory", type=Path, required=True)
    parser.add_argument("--token", required=True)
    parser.add_argument("--voice-hotkey", default=AUTO_GPT_VOICE_HOTKEY)
    args = parser.parse_args()
    run_overlay(args.directory, args.token, gpt_voice_hotkey=args.voice_hotkey)


if __name__ == "__main__":
    main()
