from __future__ import annotations

import argparse
import json
import queue
import sys
import threading
import time
import traceback
import webbrowser
from collections.abc import Callable
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from gtp_games.companion import (
    CompanionController,
    CompanionStatus,
    default_config_path,
    load_launcher_config,
)
from gtp_games.game_identity import executable_build_identity
from gtp_games.game_library import (
    DiscoveredGame,
    GameLibrarySnapshot,
    GameTableChoice,
)
from gtp_games.integrated import responsive_layout
from gtp_games.integrated_ui import IntegratedPanel
from gtp_games.overlay import overlay_is_topmost
from gtp_games.process_tracker import (
    ProcessRow,
    ProcessState,
    ProcessTracker,
    filter_and_sort_rows,
)

LIKELY_GAME_FOLLOW_UP_MS = 3000
PROCESS_START_TOLERANCE_SECONDS = 1.0
AUTO_MOUNT_POLL_MS = 3000
AUTO_MOUNT_TIMEOUT_SECONDS = 120
PROCESS_REFRESH_TIMEOUT_MS = 12_000
PROCESS_REFRESH_TICK_MS = 500
LEARNING_CATALOG_REFRESH_MS = 2_000
SCREEN_LEARNING_INTERVAL_MS = 2_000
SCREEN_LEARNING_BURST_SAMPLES = 8
SCREEN_LEARNING_REST_MS = 4_000
AUTO_TRACE_OBSERVATION_MS = 1_200
INTEGER_VALUE_TYPES = {"i8", "u8", "i16", "u16", "i32", "u32", "i64", "u64"}
CORE_CHEAT_TARGETS = (
    "Units",
    "Nanites",
    "Quicksilver",
    "health",
    "shield",
    "hazard protection",
    "life support",
    "stamina",
    "jetpack",
    "movement speed",
    "jump height",
    "inventory item quantity",
    "inventory capacity",
    "launch thrusters",
    "pulse/hyperdrive",
    "weapon heat/ammo",
    "scanner",
)
VISIBLE_VALUE_TARGETS = (
    "Units",
    "Nanites",
    "Quicksilver",
    "inventory item quantity",
    "inventory capacity",
    "weapon heat/ammo",
)
BEHAVIOR_ACTION_LABELS = {
    "movement speed": "stand still, then walk and sprint in a clear straight line",
    "jump height": "stand still, then perform one ordinary jump on level ground",
}


def _values_match(left: Any, right: Any) -> bool:
    try:
        left_value = float(left)
        right_value = float(right)
        normalized_tolerance = 0.015 if max(abs(left_value), abs(right_value)) <= 1.01 else 0
        return abs(left_value - right_value) <= max(
            0.0005,
            abs(right_value) * 0.00001,
            normalized_tolerance,
        )
    except (TypeError, ValueError):
        return False


def _meter_scan_representations(
    process_name: str,
    target_name: str,
    observation: dict[str, Any],
) -> list[dict[str, Any]]:
    """Return bounded live representations for one stable foreground HUD meter."""

    normalized = float(observation["value"])
    percent = float(observation.get("percent", normalized * 100.0))
    representations = [
        {
            "target": target_name,
            "value": normalized,
            "value_type": "f32",
            "screen_scale": 1.0,
        },
        {
            "target": f"{target_name} percent",
            "value": int(round(percent)),
            "value_type": "i32",
            "screen_scale": 100.0,
        },
    ]
    if process_name.casefold() == "nms.exe" and target_name.casefold() == "shield":
        # The imported NMS CT is reference-only, but its suit-shield script shows an
        # integer 50-point representation.  Scan that value; never execute the script.
        representations.append(
            {
                "target": "shield charge points",
                "value": int(round(percent * 0.5)),
                "value_type": "i32",
                "screen_scale": 50.0,
            }
        )
    return representations


def _find_screen_value(
    result: dict[str, Any],
    target_name: str,
    anchor: dict[str, Any] | None = None,
) -> dict[str, Any] | None:
    candidates = [
        item
        for item in result.get("visible_values") or []
        if isinstance(item, dict)
        and str(item.get("target") or "").casefold() == target_name.casefold()
    ]
    bar_candidates = []
    for item in result.get("detections") or []:
        if not isinstance(item, dict) or not item.get("hud_target"):
            continue
        filled_width = float(item.get("filled_width") or item.get("width") or 1)
        container_width = float(item.get("width") or 1)
        if anchor is not None:
            container_width = max(container_width, float(anchor.get("width") or 1))
        bar_candidates.append(
            {
                **item,
                "target": item.get("hud_target"),
                "scan_value": round(filled_width / max(1.0, container_width), 4),
                "current_value": round(
                    filled_width * 100.0 / max(1.0, container_width), 1
                ),
            }
        )
    candidates.extend(
        item
        for item in bar_candidates
        if str(item.get("target") or "").casefold() == target_name.casefold()
    )
    if not candidates and anchor:
        # A save-derived target can share a stable on-screen number whose OCR label is
        # generic. The location anchor is retained across the tiny trace change, while
        # the OCR-generated target name may not match the save field name.
        candidates = [
            item for item in result.get("visible_values") or [] if isinstance(item, dict)
        ] + bar_candidates
    if not candidates:
        return None
    if not anchor:
        return max(candidates, key=lambda item: float(item.get("confidence") or 0))
    anchor_x = float(anchor.get("x") or 0) + float(anchor.get("width") or 1) / 2
    anchor_y = float(anchor.get("y") or 0) + float(anchor.get("height") or 1) / 2

    def distance(item: dict[str, Any]) -> float:
        center_x = float(item.get("x") or 0) + float(item.get("width") or 1) / 2
        center_y = float(item.get("y") or 0) + float(item.get("height") or 1) / 2
        return abs(center_x - anchor_x) + abs(center_y - anchor_y)

    closest = min(candidates, key=distance)
    tolerance = max(
        64.0,
        float(anchor.get("width") or 1) * 1.5 + float(anchor.get("height") or 1) * 2,
    )
    if distance(closest) > tolerance:
        return None
    if anchor and anchor.get("screen_scale") is not None:
        scale = float(anchor["screen_scale"])
        normalized = float(closest.get("scan_value") or 0.0)
        closest = {
            **closest,
            "scan_value": (
                round(normalized * scale, 6)
                if str(anchor.get("value_type") or "").casefold() in {"f32", "f64"}
                else int(round(normalized * scale))
            ),
        }
    return closest


def _automatic_trace_baseline(
    baselines: dict[str, dict[str, Any]],
    target_name: str,
    exact_value: Any,
) -> dict[str, Any] | None:
    """Find one stable visible baseline for a locked target without guessing."""

    direct = baselines.get(target_name.casefold())
    if direct is not None and _values_match(direct.get("value"), exact_value):
        return dict(direct)
    matching = [
        dict(item)
        for item in baselines.values()
        if _values_match(item.get("value"), exact_value)
    ]
    anchors = {
        (
            int(item.get("x") or 0),
            int(item.get("y") or 0),
            int(item.get("width") or 0),
            int(item.get("height") or 0),
        )
        for item in matching
    }
    return matching[0] if len(anchors) == 1 else None


def _automatic_trace_value(value_type: str, original: Any, position: int) -> int | float:
    kind = value_type.casefold()
    if kind in {"f32", "f64"}:
        value = float(original)
        if not 0.0 <= value <= 1.0:
            raise ValueError("a normalized meter trace must start between 0 and 1")
        delta = 0.04 + position * 0.02
        if value - delta >= 0.02:
            return round(value - delta, 6)
        if value + delta <= 0.98:
            return round(value + delta, 6)
        raise ValueError("the meter has no room for a reversible visible trace")
    if kind not in INTEGER_VALUE_TYPES:
        raise ValueError("automatic traces support integer values and normalized meters")
    value = int(original)
    delta = position * 2 + 1
    limits = {
        "i8": (-128, 127),
        "u8": (0, 255),
        "i16": (-32_768, 32_767),
        "u16": (0, 65_535),
        "i32": (-2_147_483_648, 2_147_483_647),
        "u32": (0, 4_294_967_295),
        "i64": (-9_223_372_036_854_775_808, 9_223_372_036_854_775_807),
        "u64": (0, 18_446_744_073_709_551_615),
    }
    minimum, maximum = limits[kind]
    if value + delta <= maximum:
        return value + delta
    if value - delta >= minimum:
        return value - delta
    raise ValueError("the displayed value has no room for a reversible trace")


def _catalog_core_ready(catalog: dict[str, Any]) -> bool:
    """The local catalog is usable before optional public references finish."""

    completed = int(catalog.get("mount_steps_completed", 0))
    total = max(1, int(catalog.get("mount_steps_total", 3)))
    return completed >= total or (
        str(catalog.get("status") or "").casefold() == "ready"
        and completed >= min(2, total)
    )


class CompanionApp:
    def __init__(
        self,
        root,
        *,
        config_path: Path | None = None,
        start_workers: bool = True,
    ) -> None:
        import tkinter as tk
        from tkinter import ttk

        self.tk = tk
        self.ttk = ttk
        self.root = root
        self.config_path = config_path or default_config_path()
        self.config = load_launcher_config(self.config_path)
        self.controller = CompanionController(self.config, config_path=self.config_path)
        self._busy = False
        self._status_busy = False
        self._process_refresh_busy = False
        self._process_refresh_after: str | None = None
        self._process_refresh_generation = 0
        self._process_refresh_started_at: float | None = None
        self._process_refresh_tick_after: str | None = None
        self._process_refresh_timeout_after: str | None = None
        self._automatic_follow_up_used = False
        self._tracker = ProcessTracker()
        self._process_rows: list[ProcessRow] = []
        self._row_by_item: dict[str, ProcessRow] = {}
        self._compact_row_by_label: dict[str, ProcessRow] = {}
        self._library_snapshot = GameLibrarySnapshot(games=[], scanned_sources=[], warnings=[])
        self._game_by_item: dict[str, DiscoveredGame] = {}
        self._game_item_by_id: dict[str, str] = {}
        self._table_by_label: dict[str, GameTableChoice] = {}
        self._syncing_game_process_selection = False
        self._pending_auto_mount_game_id: str | None = None
        self._automatic_read_only_mount_attempted = False
        self._auto_mount_in_progress = False
        self._auto_mount_deadline = 0.0
        self._auto_mount_after: str | None = None
        self._sort_key = "score"
        self._sort_descending = True
        self._active_session: dict[str, Any] | None = None
        self._ui_callbacks: queue.Queue[Callable[[], None]] = queue.Queue()
        self._mount_started_at: float | None = None
        self._mount_process_name = ""
        self._mount_write_enabled = False
        self._mount_stage = ""
        self._mount_progress_after: str | None = None
        self._mount_catalog_poll_busy = False
        self._mount_catalog_poll_failures = 0
        self._catalog_refresh_after: str | None = None
        self._catalog_refresh_busy = False
        self._catalog_refresh_failures = 0
        self._catalog_refresh_session_id: str | None = None
        self._discovery_window = None
        self._discovery_tree = None
        self._discovery_listbox = None
        self._discovery_status_var = None
        self._discovery_prompt_var = None
        self._discovery_target_var = None
        self._discovery_value_var = None
        self._discovery_behavior_target_var = None
        self._save_compare_var = None
        self._discovery_run_id: str | None = None
        self._discovery_poll_after: str | None = None
        self._discovery_poll_busy = False
        self._initial_discovery_session_ids: set[str] = set()
        self._screen_learning_after: str | None = None
        self._screen_learning_busy = False
        self._screen_learning_samples_remaining = 0
        self._screen_learning_failures = 0
        self._screen_learning_pause_message: str | None = None
        self._screen_observed_values: dict[str, float] = {}
        self._screen_visible_baselines: dict[str, dict[str, Any]] = {}
        self._screen_temporal_started: set[str] = set()
        self._screen_temporal_pending: set[str] = set()
        self._automatic_trace_busy = False
        self._automatic_trace_attempts: set[tuple[str, str, int, tuple[str, ...]]] = set()
        self._automatic_trace_target: dict[str, Any] | None = None
        self._automatic_trace_baseline: dict[str, Any] | None = None
        self._automatic_trace_candidates: list[str] = []
        self._automatic_trace_candidate_position = 0
        self._automatic_trace_matches = 0
        self._automatic_trace_intent_id: str | None = None
        self._responsive_after: str | None = None
        self._last_layout_mode = ""
        self._advanced_visible = False
        self._enable_global_hotkeys = start_workers

        root.title("GTP Games Companion")
        root.geometry("1180x820")
        root.minsize(880, 640)
        root.configure(background="#0b1220")
        root.protocol("WM_DELETE_WINDOW", root.destroy)
        root.report_callback_exception = self._report_callback_exception

        style = ttk.Style(root)
        if "clam" in style.theme_names():
            style.theme_use("clam")
        style.configure("TFrame", background="#0b1220")
        style.configure("TLabel", background="#0b1220", foreground="#e5e7eb")
        style.configure("TLabelframe", background="#0b1220", foreground="#9ca3af")
        style.configure(
            "TLabelframe.Label",
            background="#0b1220",
            foreground="#9ca3af",
            font=("Segoe UI", 9, "bold"),
        )
        style.configure("Title.TLabel", font=("Segoe UI Semibold", 17), foreground="#f8fafc")
        style.configure("Heading.TLabel", font=("Segoe UI Semibold", 11))
        style.configure("Status.TLabel", font=("Segoe UI Semibold", 10), foreground="#f8fafc")
        style.configure(
            "ReadOnly.TLabel",
            font=("Segoe UI Semibold", 9),
            foreground="#6ee7b7",
            background="#172033",
            padding=(8, 4),
        )
        style.configure("Card.TFrame", background="#172033", relief="flat")
        style.configure("Card.TLabel", background="#172033", foreground="#e5e7eb")
        style.configure("Muted.TLabel", foreground="#94a3b8")
        style.configure(
            "Primary.TButton",
            font=("Segoe UI Semibold", 10),
            foreground="#ffffff",
            background="#6757d9",
            padding=(14, 7),
        )
        style.map("Primary.TButton", background=[("active", "#7c6ee6")])
        style.configure("TButton", padding=(9, 5))
        style.map(
            "TButton",
            foreground=[("disabled", "#94a3b8")],
            background=[("disabled", "#253047")],
        )
        style.map(
            "Primary.TButton",
            foreground=[("disabled", "#cbd5e1")],
            background=[("disabled", "#334155"), ("active", "#7c6ee6")],
        )
        style.configure("Danger.TButton", foreground="#fecaca", background="#3f1d2b")
        style.configure(
            "Treeview",
            rowheight=28,
            background="#111827",
            fieldbackground="#111827",
            foreground="#e5e7eb",
            borderwidth=0,
        )
        style.map("Treeview", background=[("selected", "#3f3a78")])
        style.configure(
            "Treeview.Heading",
            font=("Segoe UI Semibold", 9),
            background="#1f2937",
            foreground="#cbd5e1",
            relief="flat",
        )
        style.configure("Compact.TNotebook", background="#0b1220", borderwidth=0)
        style.layout("Compact.TNotebook.Tab", [])

        self.status_var = tk.StringVar(value="Checking connection...")
        self.companion_var = tk.StringVar(value="Companion: checking")
        self.tunnel_var = tk.StringVar(value="ChatGPT connection: checking")
        self.mode_var = tk.StringVar(
            value=("Mode: Value editing enabled" if self.config.allow_writes else "Mode: Read-only")
        )
        self.scan_var = tk.StringVar(value="Scan: idle")
        self.compact_game_var = tk.StringVar(value="No running game detected")
        self.compact_build_var = tk.StringVar(value="Build: waiting for a running game")
        self.search_var = tk.StringVar()
        self.filter_var = tk.StringVar(value="Likely games")
        self.selection_var = tk.StringVar(value="Select a running process to see its path.")
        self.game_selection_var = tk.StringVar(
            value="Choose an installed, recent, or currently running game."
        )
        self.table_var = tk.StringVar(value="No saved table — discover a new one")
        self.table_detail_var = tk.StringVar(
            value="A new build-specific table will be created after attachment."
        )
        self.session_var = tk.StringVar(value="Not attached")
        self.write_var = tk.BooleanVar(value=self.config.allow_writes)
        self.attach_mode_hint_var = tk.StringVar(
            value=(
                "Value editing is enabled for the selected offline game."
                if self.config.allow_writes
                else (
                    "Read-only attachment. Controlled writes require the separate checkbox below."
                )
            )
        )
        self.message_var = tk.StringVar(value="")

        self._build_layout()
        self.root.bind("<Configure>", self._window_resized, add="+")
        self.search_var.trace_add("write", self._render_process_rows)
        self.filter_var.trace_add("write", self._render_process_rows)
        if start_workers:
            self.root.after(50, self._drain_ui_callbacks)
            self._refresh_games(refresh_reason="startup")
            self.root.after(100, self._poll_status)

    def _build_layout(self) -> None:
        ttk = self.ttk

        outer = ttk.Frame(self.root, padding=12)
        outer.pack(fill="both", expand=True)

        header = ttk.Frame(outer)
        header.pack(fill="x")
        ttk.Label(header, text="GPT Gaming", style="Title.TLabel").pack(side="left")
        self.mode_badge = ttk.Label(
            header,
            text="●  READ ONLY" if not self.config.allow_writes else "●  VALUE EDITING",
            style="ReadOnly.TLabel",
        )
        self.mode_badge.pack(side="right")
        self.header_description = ttk.Label(
            outer,
            textvariable=self.status_var,
            style="Muted.TLabel",
            wraplength=620,
        )
        self.header_description.pack(anchor="w", pady=(2, 9))

        compact_card = ttk.Frame(outer, style="Card.TFrame", padding=10)
        compact_card.pack(fill="x")
        picker_row = ttk.Frame(compact_card, style="Card.TFrame")
        self.compact_picker_row = picker_row
        picker_row.pack(fill="x")
        self.compact_game_label = ttk.Label(picker_row, text="Game", style="Card.TLabel")
        self.compact_game_label.grid(row=0, column=0, sticky="w")
        self.compact_game_combo = ttk.Combobox(
            picker_row,
            textvariable=self.compact_game_var,
            values=("No running game detected",),
            state="disabled",
            width=38,
        )
        self.compact_game_combo.grid(row=0, column=1, sticky="ew", padx=(9, 8))
        self.compact_game_combo.bind("<<ComboboxSelected>>", self._compact_game_selected)
        self.compact_refresh_button = ttk.Button(
            picker_row,
            text="Refresh",
            command=lambda: self._refresh_games(refresh_reason="manual"),
        )
        self.compact_refresh_button.grid(row=0, column=2, sticky="e")
        picker_row.columnconfigure(1, weight=1)
        info_row = ttk.Frame(compact_card, style="Card.TFrame")
        self.compact_info_row = info_row
        info_row.pack(fill="x", pady=(7, 0))
        self.compact_build_label = ttk.Label(
            info_row,
            textvariable=self.compact_build_var,
            style="Card.TLabel",
        )
        self.compact_build_label.grid(row=0, column=0, sticky="w")
        self.compact_session_label = ttk.Label(
            info_row,
            textvariable=self.session_var,
            style="Card.TLabel",
        )
        self.compact_session_label.grid(row=0, column=1, sticky="e")
        info_row.columnconfigure(0, weight=1)
        ttk.Label(
            compact_card,
            textvariable=self.scan_var,
            style="Card.TLabel",
            wraplength=620,
        ).pack(anchor="w", pady=(3, 0))

        self.main_notebook = ttk.Notebook(outer, style="Compact.TNotebook", height=590)
        self.main_notebook.pack(fill="both", expand=True, pady=(8, 0))
        connect_tab = ttk.Frame(self.main_notebook)
        capabilities_tab = ttk.Frame(self.main_notebook)
        script_tab = ttk.Frame(self.main_notebook)
        history_tab = ttk.Frame(self.main_notebook)
        connection_tab = ttk.Frame(self.main_notebook)
        self.capabilities_tab = capabilities_tab
        self.connect_tab = connect_tab
        self.script_tab = script_tab
        self.history_tab = history_tab
        self.connection_tab = connection_tab
        self.main_notebook.add(capabilities_tab, text="Controls")
        self.main_notebook.add(connect_tab, text="Games")
        self.main_notebook.add(script_tab, text="Script Lab")
        self.main_notebook.add(history_tab, text="History & Restore")
        self.main_notebook.add(connection_tab, text="Connection")
        self.main_notebook.select(capabilities_tab)

        library_card = ttk.LabelFrame(connect_tab, text="My games", padding=12)
        library_card.pack(fill="x", pady=(10, 0))
        self.library_description = ttk.Label(
            library_card,
            text=(
                "Games are discovered locally from Steam, Epic, GOG, recent GTP sessions, "
                "saved tables, and currently running game windows."
            ),
            wraplength=1000,
        )

        self.game_tree = ttk.Treeview(
            library_card,
            columns=("game", "played", "launcher", "tables", "status"),
            show="headings",
            selectmode="browse",
            height=3,
        )
        self.game_tree.heading("game", text="Game")
        self.game_tree.heading("played", text="Last played")
        self.game_tree.heading("launcher", text="Launcher")
        self.game_tree.heading("tables", text="Cheat tables")
        self.game_tree.heading("status", text="Status")
        self.game_tree.column("game", width=330, minwidth=200)
        self.game_tree.column("played", width=150, minwidth=120, stretch=False)
        self.game_tree.column("launcher", width=150, minwidth=110, stretch=False)
        self.game_tree.column("tables", width=100, minwidth=90, stretch=False, anchor="center")
        self.game_tree.column("status", width=145, minwidth=120, stretch=False)
        self.game_tree.pack(fill="x", pady=(9, 0))
        self.game_tree.bind("<<TreeviewSelect>>", self._game_selected)

        game_action_row = ttk.Frame(library_card)
        game_action_row.pack(fill="x", pady=(7, 0))
        ttk.Label(game_action_row, textvariable=self.game_selection_var).pack(side="left")
        self.launch_game_button = ttk.Button(
            game_action_row,
            text="Launch selected game",
            command=self._launch_selected_game,
            state="disabled",
        )
        self.launch_game_button.pack(side="right")

        table_row = ttk.Frame(library_card)
        table_row.pack(fill="x", pady=(7, 0))
        ttk.Label(table_row, text="Cheat table").pack(side="left")
        self.table_combo = ttk.Combobox(
            table_row,
            textvariable=self.table_var,
            values=("No saved table — discover a new one",),
            state="readonly",
            width=78,
        )
        self.table_combo.pack(side="left", padx=(8, 0), fill="x", expand=True)
        self.table_combo.bind("<<ComboboxSelected>>", self._table_selected)
        self.table_detail_label = ttk.Label(
            library_card,
            textvariable=self.table_detail_var,
            wraplength=1000,
            foreground="#565d66",
        )

        game_card = ttk.LabelFrame(connect_tab, text="Running processes", padding=12)
        game_card.pack(fill="both", expand=True, pady=(10, 0))
        self.process_description = ttk.Label(
            game_card,
            text=(
                "Likely games are ranked from live GPU and RAM use. Search by name, PID, "
                "or path; double-click a row to attach in the displayed mode."
            ),
            wraplength=980,
        )

        process_controls = ttk.Frame(game_card)
        process_controls.pack(fill="x", pady=(10, 8))
        ttk.Label(process_controls, text="Search").pack(side="left")
        ttk.Entry(process_controls, textvariable=self.search_var, width=32).pack(
            side="left", padx=(8, 14)
        )
        ttk.Label(process_controls, text="Filter").pack(side="left")
        ttk.Combobox(
            process_controls,
            textvariable=self.filter_var,
            values=("Likely games", "All processes", "Attachable", "Running", "Changes"),
            state="readonly",
            width=16,
        ).pack(side="left", padx=(8, 14))
        self.refresh_button = ttk.Button(
            process_controls,
            text="Refresh games",
            command=lambda: self._refresh_games(refresh_reason="manual"),
        )
        self.refresh_button.pack(side="right")

        table_frame = ttk.Frame(game_card)
        table_frame.pack(fill="both", expand=True)
        self.process_tree = ttk.Treeview(
            table_frame,
            columns=("name", "pid", "gpu", "memory", "score", "path", "status"),
            show="headings",
            selectmode="browse",
            height=3,
        )
        self.process_tree.heading(
            "name", text="Process / executable", command=lambda: self._sort_processes("name")
        )
        self.process_tree.heading("pid", text="PID", command=lambda: self._sort_processes("pid"))
        self.process_tree.heading("gpu", text="GPU", command=lambda: self._sort_processes("gpu"))
        self.process_tree.heading(
            "memory", text="RAM", command=lambda: self._sort_processes("memory")
        )
        self.process_tree.heading(
            "score", text="Game %", command=lambda: self._sort_processes("score")
        )
        self.process_tree.heading(
            "path", text="Path (when available)", command=lambda: self._sort_processes("path")
        )
        self.process_tree.heading(
            "status", text="Status", command=lambda: self._sort_processes("status")
        )
        self.process_tree.column("name", width=175, minwidth=130, stretch=False)
        self.process_tree.column("pid", width=65, minwidth=55, stretch=False, anchor="e")
        self.process_tree.column("gpu", width=65, minwidth=55, stretch=False, anchor="e")
        self.process_tree.column("memory", width=80, minwidth=65, stretch=False, anchor="e")
        self.process_tree.column("score", width=75, minwidth=65, stretch=False, anchor="e")
        self.process_tree.column("path", width=405, minwidth=180)
        self.process_tree.column("status", width=140, minwidth=110, stretch=False)
        process_scrollbar = ttk.Scrollbar(
            table_frame,
            orient="vertical",
            command=self.process_tree.yview,
        )
        self.process_tree.configure(yscrollcommand=process_scrollbar.set)
        self.process_tree.pack(side="left", fill="both", expand=True)
        process_scrollbar.pack(side="right", fill="y")
        self.process_tree.tag_configure("disappeared", foreground="#737b85")
        self.process_tree.tag_configure("restarted", foreground="#8a5400")
        self.process_tree.tag_configure("blocked", foreground="#8b2635")
        self.process_tree.tag_configure("likely", foreground="#17643a")
        self.process_tree.bind("<<TreeviewSelect>>", self._process_selected)
        self.process_tree.bind("<Double-1>", self._attach_selected)

        attach_row = ttk.Frame(game_card)
        attach_row.pack(fill="x", pady=(10, 0))
        self.detach_button = ttk.Button(
            attach_row,
            text="Detach",
            command=self._detach_selected,
            state="disabled",
        )
        self.detach_button.pack(side="right", padx=(8, 0))
        self.export_button = ttk.Button(
            attach_row,
            text="Export game table",
            command=self._export_selected_table,
            state="disabled",
        )
        self.export_button.pack(side="right", padx=(8, 0))
        self.learn_button = ttk.Button(
            attach_row,
            text="Learn cheat options",
            command=self._open_discovery_window,
            state="disabled",
        )
        self.learn_button.pack(side="right", padx=(8, 0))
        self.attach_button = ttk.Button(
            attach_row,
            text=("Attach with full value writes" if self.write_var.get() else "Attach read-only"),
            command=self._attach_selected,
            state="disabled",
        )
        self.attach_button.pack(side="right")
        ttk.Label(game_card, textvariable=self.session_var, style="Heading.TLabel").pack(
            anchor="w", pady=(8, 0)
        )

        self.write_check = ttk.Checkbutton(
            game_card,
            text="Enable value editing for the selected offline game",
            variable=self.write_var,
            command=self._write_mode_changed,
        )
        self.write_check.pack(anchor="w", pady=(8, 0))
        self.write_description = ttk.Label(
            game_card,
            text=(
                "This stays enabled for the selected offline game. Choose a found value, "
                "enter the replacement, and press Apply value; the app verifies the write "
                "and automatically restores a candidate you report as incorrect."
            ),
            wraplength=980,
        )
        table_frame.pack_forget()
        table_frame.pack(fill="both", expand=True)

        self.integrated_panel = IntegratedPanel(
            root=self.root,
            tk=self.tk,
            ttk=self.ttk,
            capabilities_parent=capabilities_tab,
            script_parent=script_tab,
            history_parent=history_tab,
            controller=self.controller,
            data_directory=self.config_path.parent / "integrated",
            run_background=self._run_background,
            get_active_session=lambda: self._active_session,
            get_discovery_run_id=lambda: self._discovery_run_id,
            open_discovery=self._open_discovery_window,
            show_script_lab=lambda: self._show_advanced_page(self.script_tab),
            set_status=self.message_var.set,
            enable_global_hotkeys=self._enable_global_hotkeys,
        )

        ttk.Label(
            connection_tab,
            text="Connection and service",
            style="Heading.TLabel",
        ).pack(anchor="w", padx=12, pady=(12, 2))
        ttk.Label(
            connection_tab,
            text=(
                "Service and tunnel controls live here. Main-screen value changes "
                "still require a verified locator and confirmation."
            ),
            style="Muted.TLabel",
        ).pack(anchor="w", padx=12)
        action_row = ttk.Frame(connection_tab, padding=(12, 10, 12, 0))
        action_row.pack(fill="x", pady=(10, 0))
        self.start_button = ttk.Button(
            action_row,
            text="Start GTP Games",
            command=self._start,
        )
        self.start_button.pack(side="left")
        self.stop_button = ttk.Button(
            action_row,
            text="Stop everything",
            style="Danger.TButton",
            command=self._stop,
        )
        self.stop_button.pack(side="left", padx=(10, 0))
        ttk.Button(
            action_row,
            text="Open ChatGPT",
            command=lambda: webbrowser.open("https://chatgpt.com/"),
        ).pack(side="right")

        secondary_row = ttk.Frame(connection_tab, padding=(12, 4, 12, 0))
        secondary_row.pack(fill="x", pady=(8, 0))
        ttk.Button(
            secondary_row,
            text="Connection settings",
            command=self._open_connection_settings,
        ).pack(side="left")
        ttk.Label(secondary_row, textvariable=self.companion_var).pack(side="left", padx=(12, 0))
        ttk.Label(secondary_row, textvariable=self.tunnel_var).pack(side="left", padx=(12, 0))

        self.advanced_nav = ttk.Frame(outer)
        self.advanced_nav.pack(fill="x", pady=(7, 0), side="bottom")
        self.advanced_button = ttk.Button(
            self.advanced_nav,
            text="▸ Advanced",
            command=self._toggle_advanced,
        )
        self.advanced_button.pack(side="left")
        self.games_nav_button = ttk.Button(
            self.advanced_nav,
            text="Games & tables",
            command=lambda: self._show_advanced_page(self.connect_tab),
        )
        self.scripts_nav_button = ttk.Button(
            self.advanced_nav,
            text="Script Lab",
            command=lambda: self._show_advanced_page(self.script_tab),
        )
        self.history_nav_button = ttk.Button(
            self.advanced_nav,
            text="History & restore",
            command=lambda: self._show_advanced_page(self.history_tab),
        )
        self.connection_nav_button = ttk.Button(
            self.advanced_nav,
            text="Connection",
            command=lambda: self._show_advanced_page(self.connection_tab),
        )

        self.message_label = ttk.Label(
            outer,
            textvariable=self.message_var,
            wraplength=620,
            style="Muted.TLabel",
        )
        self.message_label.pack(fill="x", pady=(5, 0), side="bottom")

    def _toggle_advanced(self) -> None:
        if self._advanced_visible:
            self._show_controls()
            return
        self._show_advanced_page(self.connect_tab)

    def _show_advanced_page(self, page) -> None:
        self._advanced_visible = True
        self.main_notebook.select(page)
        self.main_notebook.configure(height=590)
        self.advanced_button.configure(text="‹ Controls")
        for button in (
            self.games_nav_button,
            self.scripts_nav_button,
            self.history_nav_button,
            self.connection_nav_button,
        ):
            if not button.winfo_manager():
                button.pack(side="left", padx=(6, 0))
        width = max(self.root.winfo_width(), 1080)
        height = max(self.root.winfo_height(), 760)
        self.root.geometry(f"{width}x{height}")

    def _show_controls(self) -> None:
        self._advanced_visible = False
        self.main_notebook.select(self.capabilities_tab)
        self.main_notebook.configure(height=590)
        self.advanced_button.configure(text="▸ Advanced")
        for button in (
            self.games_nav_button,
            self.scripts_nav_button,
            self.history_nav_button,
            self.connection_nav_button,
        ):
            button.pack_forget()
        width = max(self.root.winfo_width(), 1080)
        height = max(self.root.winfo_height(), 720)
        self.root.geometry(f"{width}x{height}")

    def _window_resized(self, event=None) -> None:
        if event is not None and event.widget is not self.root:
            return
        if self._responsive_after is not None:
            self.root.after_cancel(self._responsive_after)
        self._responsive_after = self.root.after(80, self._apply_responsive_layout)

    def _apply_responsive_layout(self) -> None:
        self._responsive_after = None
        scale = max(float(self.root.tk.call("tk", "scaling")) * 72 / 96, 0.5)
        policy = responsive_layout(
            max(1, self.root.winfo_width()),
            max(1, self.root.winfo_height()),
            scale,
        )
        self._apply_layout_policy(policy)

    def _apply_layout_policy(self, policy) -> None:
        self.game_tree.configure(height=policy.game_rows)
        self.process_tree.configure(height=policy.process_rows)
        self.integrated_panel.apply_layout_policy(policy)
        self._layout_compact_header(compact=policy.mode == "compact")
        for label in (
            self.header_description,
            self.library_description,
            self.process_description,
            self.write_description,
            self.message_label,
        ):
            label.configure(wraplength=policy.wraplength)
        if policy.mode != self._last_layout_mode:
            self.ttk.Style(self.root).configure(
                "Title.TLabel",
                font=("Segoe UI Semibold", min(policy.title_size, 18)),
            )
            self._last_layout_mode = policy.mode

    def _layout_compact_header(self, *, compact: bool) -> None:
        self.compact_build_label.grid_forget()
        self.compact_session_label.grid_forget()
        if compact:
            self.compact_build_label.grid(row=0, column=0, sticky="w")
            self.compact_session_label.grid(row=1, column=0, sticky="w", pady=(3, 0))
        else:
            self.compact_build_label.grid(row=0, column=0, sticky="w")
            self.compact_session_label.grid(row=0, column=1, sticky="e")

    def _refresh_games(self, *, refresh_reason: str = "manual") -> None:
        if self._process_refresh_busy:
            elapsed = (
                time.monotonic() - self._process_refresh_started_at
                if self._process_refresh_started_at is not None
                else 0.0
            )
            self.message_var.set(f"Game refresh is already loading ({elapsed:.1f}s).")
            return
        if self._process_refresh_after is not None:
            self.root.after_cancel(self._process_refresh_after)
            self._process_refresh_after = None
        if refresh_reason == "manual":
            self._automatic_follow_up_used = True
        self._process_refresh_generation += 1
        refresh_generation = self._process_refresh_generation
        self._process_refresh_busy = True
        self._process_refresh_started_at = time.monotonic()
        self.refresh_button.configure(state="disabled", text="Refreshing...")
        if hasattr(self, "compact_refresh_button"):
            self.compact_refresh_button.configure(state="disabled", text="...")
        self.message_var.set("Looking for running games — 0.0s")
        self._schedule_process_refresh_tick(refresh_generation)
        self._process_refresh_timeout_after = self.root.after(
            PROCESS_REFRESH_TIMEOUT_MS,
            lambda: self._process_refresh_timed_out(refresh_generation),
        )

        def work() -> tuple[list, GameLibrarySnapshot] | Exception:
            try:
                processes = self.controller.list_game_processes()
                return processes, self.controller.discover_game_library(processes)
            except Exception as exc:  # noqa: BLE001 - shown in the companion status area
                return exc

        def done(result: tuple[list, GameLibrarySnapshot] | Exception) -> None:
            if refresh_generation != self._process_refresh_generation:
                return
            self._cancel_process_refresh_timers()
            self._process_refresh_busy = False
            self._process_refresh_started_at = None
            self.refresh_button.configure(state="normal", text="Refresh games")
            if hasattr(self, "compact_refresh_button"):
                self.compact_refresh_button.configure(state="normal", text="Refresh")
            if isinstance(result, Exception):
                self.message_var.set(f"Process refresh failed: {result}. Use Refresh to try again.")
                return
            processes, library = result
            processes = _promote_mountable_game_processes(
                processes,
                library,
                configured_process=self.config.game_process,
            )
            self._library_snapshot = library
            self._process_rows = self._tracker.refresh(processes)
            self._reconcile_active_session(processes)
            self._render_process_rows()
            self._render_game_rows()
            running_count = sum(
                row.state is not ProcessState.DISAPPEARED for row in self._process_rows
            )
            changes = sum(row.state is not ProcessState.RUNNING for row in self._process_rows)
            likely_count = sum(
                row.process.likely_game
                and row.process.attachable
                and row.state is not ProcessState.DISAPPEARED
                for row in self._process_rows
            )
            message = (
                f"Found {len(library.games)} known game(s) and {likely_count} likely running "
                f"game(s) out of {running_count} visible processes"
                + (f"; {changes} changed." if changes else ".")
            )
            if likely_count == 0:
                message = "No running game found. Start one, then select Refresh."
            elif self._active_session is None:
                message = "Choose a running game above to attach read-only and begin discovery."
            if self._should_schedule_follow_up(refresh_reason, likely_count):
                self._automatic_follow_up_used = True
                message += " Confirming the likely game once more."
                self._schedule_likely_game_follow_up()
            elif refresh_reason == "likely-game-follow-up":
                message += " Automatic checks finished; use Refresh for later changes."
            self.message_var.set(message)
            self._handle_auto_mount_after_refresh()
            self._handle_configured_auto_mount()
            if (
                self._active_session is None
                and likely_count
                and not self._auto_mount_in_progress
            ):
                self.integrated_panel.set_learning_status(
                    "Learning guide: choose a running game; saved controls load immediately."
                )

        self._run_background(work, done, lock_buttons=False)

    def _schedule_process_refresh_tick(self, refresh_generation: int) -> None:
        def tick() -> None:
            self._process_refresh_tick_after = None
            if (
                not self._process_refresh_busy
                or refresh_generation != self._process_refresh_generation
            ):
                return
            elapsed = time.monotonic() - (self._process_refresh_started_at or time.monotonic())
            self.refresh_button.configure(text=f"Refreshing... {elapsed:.1f}s")
            self.message_var.set(f"Looking for running games — {elapsed:.1f}s")
            self._process_refresh_tick_after = self.root.after(
                PROCESS_REFRESH_TICK_MS,
                tick,
            )

        self._process_refresh_tick_after = self.root.after(PROCESS_REFRESH_TICK_MS, tick)

    def _process_refresh_timed_out(self, refresh_generation: int) -> None:
        if not self._process_refresh_busy or refresh_generation != self._process_refresh_generation:
            return
        elapsed = time.monotonic() - (self._process_refresh_started_at or time.monotonic())
        self._cancel_process_refresh_timers()
        self._process_refresh_generation += 1
        self._process_refresh_busy = False
        self._process_refresh_started_at = None
        self.refresh_button.configure(state="normal", text="Refresh games")
        if hasattr(self, "compact_refresh_button"):
            self.compact_refresh_button.configure(state="normal", text="Refresh")
        self.message_var.set(
            f"Game refresh stopped after {elapsed:.1f}s. The window is responsive; "
            "use Refresh games to try again."
        )

    def _cancel_process_refresh_timers(self) -> None:
        for attribute in ("_process_refresh_tick_after", "_process_refresh_timeout_after"):
            callback_id = getattr(self, attribute, None)
            if callback_id is not None:
                try:
                    self.root.after_cancel(callback_id)
                except Exception:  # noqa: BLE001 - the callback may already be executing
                    pass
                setattr(self, attribute, None)

    def _render_game_rows(self) -> None:
        selected = self._selected_game()
        selected_id = selected.id if selected else self.config.selected_game_id
        self.game_tree.delete(*self.game_tree.get_children())
        self._game_by_item.clear()
        self._game_item_by_id.clear()
        chosen: str | None = None
        first: str | None = None
        for index, game in enumerate(self._library_snapshot.games):
            item_id = f"game-{index}"
            self.game_tree.insert(
                "",
                "end",
                iid=item_id,
                values=(
                    game.name,
                    _format_last_played(game),
                    game.launcher,
                    len(game.tables),
                    game.status,
                ),
            )
            self._game_by_item[item_id] = game
            self._game_item_by_id[game.id] = item_id
            first = first or item_id
            if game.id == selected_id:
                chosen = item_id
        chosen = (
            chosen
            or next(
                (
                    self._game_item_by_id[game.id]
                    for game in self._library_snapshot.games
                    if game.running_pids
                ),
                None,
            )
            or first
        )
        if chosen:
            self.game_tree.selection_set(chosen)
            self.game_tree.see(chosen)
            self._game_selected()
        else:
            self.game_selection_var.set("No games found yet. Start a game, then use Refresh games.")
            self.launch_game_button.configure(state="disabled")
            self._update_table_choices(None)

    def _selected_game(self) -> DiscoveredGame | None:
        selected = self.game_tree.selection() if hasattr(self, "game_tree") else ()
        return self._game_by_item.get(selected[0]) if selected else None

    def _game_selected(self, _event=None) -> None:
        game = self._selected_game()
        if game is None:
            self.launch_game_button.configure(state="disabled")
            self._update_table_choices(None)
            return
        self.config.selected_game_id = game.id
        self.game_selection_var.set(
            f"{game.name} — {game.launcher} — {game.status}"
            + (f" — {game.install_path}" if game.install_path else "")
        )
        self.launch_game_button.configure(
            state=(
                "normal"
                if game.launch_target and self._active_session is None and not self._busy
                else "disabled"
            )
        )
        self._update_table_choices(game)
        if self._syncing_game_process_selection:
            return
        matching_item = next(
            (
                item_id
                for item_id, row in self._row_by_item.items()
                if row.process.pid in game.running_pids
                and row.state is not ProcessState.DISAPPEARED
            ),
            None,
        )
        if matching_item:
            if self.process_tree.selection() == (matching_item,):
                return
            self._syncing_game_process_selection = True
            try:
                self.process_tree.selection_set(matching_item)
                self.process_tree.see(matching_item)
                self._process_selected()
            finally:
                self._syncing_game_process_selection = False

    def _update_table_choices(self, game: DiscoveredGame | None) -> None:
        empty_label = "No saved table — discover a new one"
        self._table_by_label.clear()
        if game is None or not game.tables:
            self.table_combo.configure(values=(empty_label,))
            self.table_var.set(empty_label)
            self.table_detail_var.set(
                "A new build-specific table will be created after attachment."
            )
            self.config.selected_table_path = ""
            return

        row = self._selected_process_row()
        current_build = None
        if row is not None and row.process.pid in game.running_pids:
            current_build = executable_build_identity(row.process.executable)
        labels: list[str] = [empty_label]
        exact_label: str | None = None
        configured_label: str | None = None
        for index, table in enumerate(game.tables, start=1):
            exact = bool(current_build and table.game_build_identity == current_build)
            build_name = _short_build_identity(table.game_build_identity)
            prefix = "Recommended — current build" if exact else f"Saved build {build_name}"
            label = (
                f"{prefix} — {table.confirmed_count} confirmed, {table.candidate_count} candidates"
            )
            if label in self._table_by_label:
                label = f"{label} ({index})"
            labels.append(label)
            self._table_by_label[label] = table
            if exact and exact_label is None:
                exact_label = label
            if table.path == self.config.selected_table_path:
                configured_label = label
        chosen = configured_label or exact_label or labels[1]
        self.table_combo.configure(values=tuple(labels))
        self.table_var.set(chosen)
        self._table_selected()

    def _selected_table(self) -> GameTableChoice | None:
        return self._table_by_label.get(self.table_var.get())

    def _table_selected(self, _event=None) -> None:
        table = self._selected_table()
        self.config.selected_table_path = table.path if table else ""
        if table is None:
            self.table_detail_var.set(
                "A new build-specific table will be created after attachment."
            )
            return
        row = self._selected_process_row()
        current_build = executable_build_identity(row.process.executable) if row else None
        exact = bool(current_build and current_build == table.game_build_identity)
        self.table_detail_var.set(
            "Current build match. The table will still be validated live before any value "
            "can become actionable."
            if exact
            else "Another or unknown build. It will guide read-only rediscovery; saved offsets "
            "will not be trusted as write-ready."
        )

    def _launch_selected_game(self) -> None:
        game = self._selected_game()
        if game is None or not game.launch_target:
            return
        self.message_var.set(f"Opening {game.name} from {game.launcher}...")
        self._run_background(
            lambda: self.controller.launch_game(str(game.launch_target)),
            lambda _result: self._launch_finished(game),
        )

    def _launch_finished(self, game: DiscoveredGame) -> None:
        self._record_game_played(game)
        auto_mode = "with full value writes" if self.write_var.get() else "read-only"
        self.message_var.set(f"{game.name} was opened. Waiting to auto-mount {auto_mode}...")
        self._pending_auto_mount_game_id = game.id
        self._auto_mount_deadline = time.monotonic() + AUTO_MOUNT_TIMEOUT_SECONDS
        self._schedule_auto_mount_refresh()

    def _schedule_auto_mount_refresh(self) -> None:
        if self._auto_mount_after is not None:
            return

        def refresh_for_mount() -> None:
            self._auto_mount_after = None
            self._refresh_games(refresh_reason="launcher-auto-mount")

        self._auto_mount_after = self.root.after(AUTO_MOUNT_POLL_MS, refresh_for_mount)

    def _handle_auto_mount_after_refresh(self) -> None:
        game_id = self._pending_auto_mount_game_id
        if game_id is None:
            return
        if self._active_session is not None:
            self._pending_auto_mount_game_id = None
            return
        game = next(
            (item for item in self._library_snapshot.games if item.id == game_id),
            None,
        )
        matching_item = None
        if game is not None:
            matching_row = _find_auto_mount_process(game, self._process_rows)
            matching_item = next(
                (
                    item_id
                    for item_id, row in self._row_by_item.items()
                    if row.process.pid in game.running_pids
                    and row.process.attachable
                    and row.state is not ProcessState.DISAPPEARED
                ),
                None,
            )
            if matching_row is not None and matching_item is None:
                self.filter_var.set("Attachable")
                self._render_process_rows()
                matching_item = next(
                    (
                        item_id
                        for item_id, row in self._row_by_item.items()
                        if row.process.pid == matching_row.process.pid
                    ),
                    None,
                )
        if game is not None and matching_item is not None:
            game_item = self._game_item_by_id.get(game.id)
            if game_item:
                self.game_tree.selection_set(game_item)
                self.game_tree.see(game_item)
                self._game_selected()
            self.process_tree.selection_set(matching_item)
            self.process_tree.see(matching_item)
            self._process_selected()
            self._pending_auto_mount_game_id = None
            self._auto_mount_in_progress = True
            self.write_var.set(True)
            self.mode_var.set("Mode: Value editing enabled")
            self._refresh_attach_mode_text()
            self.message_var.set(
                f"{game.name} loaded. Auto-mounting with value editing enabled..."
            )
            self.root.after(0, self._attach_selected)
            return
        if time.monotonic() >= self._auto_mount_deadline:
            self._pending_auto_mount_game_id = None
            self.message_var.set(
                "The launched game did not expose an attachable process within two minutes. "
                "Use Refresh games after reaching gameplay."
            )
            return
        self._schedule_auto_mount_refresh()

    def _handle_configured_auto_mount(self) -> None:
        if (
            self._automatic_read_only_mount_attempted
            or self._auto_mount_in_progress
            or self._pending_auto_mount_game_id is not None
            or self._active_session is not None
        ):
            return
        row = _select_safe_auto_mount_process(
            self._process_rows,
            configured_process=self.config.game_process,
        )
        if row is None:
            return
        self._automatic_read_only_mount_attempted = True
        matching_item = next(
            (
                item_id
                for item_id, candidate in self._row_by_item.items()
                if self._row_identity(candidate) == self._row_identity(row)
            ),
            None,
        )
        if matching_item is None:
            self.filter_var.set("Attachable")
            self._render_process_rows()
            matching_item = next(
                (
                    item_id
                    for item_id, candidate in self._row_by_item.items()
                    if self._row_identity(candidate) == self._row_identity(row)
                ),
                None,
            )
        if matching_item is None:
            return
        game = next(
            (item for item in self._library_snapshot.games if row.process.pid in item.running_pids),
            None,
        )
        if game is not None:
            game_item = self._game_item_by_id.get(game.id)
            if game_item:
                self.game_tree.selection_set(game_item)
                self.game_tree.see(game_item)
                self._game_selected()
        self.process_tree.selection_set(matching_item)
        self.process_tree.see(matching_item)
        self._process_selected()
        self._auto_mount_in_progress = True
        self.write_var.set(True)
        self.mode_var.set("Mode: Value editing enabled")
        self._refresh_attach_mode_text()
        self.message_var.set(
            f"Found {row.process.name}. Auto-mounting with value editing enabled and "
            "starting learning..."
        )
        self.root.after(0, self._attach_selected)

    def _record_game_played(self, game: DiscoveredGame) -> None:
        now = datetime.now(UTC)
        game.last_played_at = now
        self.config.game_history[game.id] = now.isoformat()
        self.controller.save()
        item_id = self._game_item_by_id.get(game.id)
        if item_id and self.game_tree.exists(item_id):
            values = list(self.game_tree.item(item_id, "values"))
            values[1] = _format_last_played(game)
            self.game_tree.item(item_id, values=values)

    def _should_schedule_follow_up(self, refresh_reason: str, likely_count: int) -> bool:
        return (
            refresh_reason == "startup" and likely_count > 0 and not self._automatic_follow_up_used
        )

    def _schedule_likely_game_follow_up(self) -> None:
        def refresh_once() -> None:
            self._process_refresh_after = None
            self._refresh_games(refresh_reason="likely-game-follow-up")

        self._process_refresh_after = self.root.after(
            LIKELY_GAME_FOLLOW_UP_MS,
            refresh_once,
        )

    def _render_process_rows(self, *_args) -> None:
        if not hasattr(self, "process_tree"):
            return
        selected = self._selected_process_row()
        selected_identity = self._row_identity(selected)
        filter_key = {
            "Likely games": "likely",
            "All processes": "all",
            "Attachable": "attachable",
            "Running": "running",
            "Changes": "changes",
        }.get(self.filter_var.get(), "all")
        visible = filter_and_sort_rows(
            self._process_rows,
            query=self.search_var.get(),
            process_filter=filter_key,
            sort_key=self._sort_key,
            descending=self._sort_descending,
        )

        self.process_tree.delete(*self.process_tree.get_children())
        self._row_by_item.clear()
        reselect: str | None = None
        configured: str | None = None
        for index, row in enumerate(visible):
            item_id = f"process-{index}"
            tag = ""
            if not row.process.attachable:
                tag = "blocked"
            elif row.state is ProcessState.DISAPPEARED:
                tag = "disappeared"
            elif row.state is ProcessState.RESTARTED:
                tag = "restarted"
            elif row.process.likely_game:
                tag = "likely"
            self.process_tree.insert(
                "",
                "end",
                iid=item_id,
                values=(
                    row.process.name,
                    row.process.pid,
                    (
                        f"{row.process.gpu_percent:.1f}%"
                        if row.process.gpu_percent is not None
                        else "Unavailable"
                    ),
                    _format_memory(row.process.memory_bytes),
                    f"{row.process.game_score}%",
                    row.process.executable or "Unavailable",
                    row.status,
                ),
                tags=(tag,) if tag else (),
            )
            self._row_by_item[item_id] = row
            if selected_identity == self._row_identity(row):
                reselect = item_id
            elif (
                selected_identity is None
                and self.config.game_process
                and row.process.name.casefold() == self.config.game_process.casefold()
                and row.state is not ProcessState.DISAPPEARED
            ):
                configured = item_id
        chosen = reselect or configured
        if chosen:
            self.process_tree.selection_set(chosen)
            self.process_tree.see(chosen)
            self._process_selected()
        else:
            self.selection_var.set("Select a running process to see its path.")
            self.attach_button.configure(state="disabled")
        self._render_compact_game_picker()

    def _render_compact_game_picker(self) -> None:
        selected = self._selected_process_row()
        selected_identity = self._row_identity(selected)
        self._compact_row_by_label.clear()
        live_rows = [
            row
            for row in self._process_rows
            if row.process.attachable
            and row.process.likely_game
            and row.state is not ProcessState.DISAPPEARED
        ]
        labels: list[str] = []
        chosen: str | None = None
        for row in live_rows:
            game = next(
                (
                    item
                    for item in self._library_snapshot.games
                    if row.process.pid in item.running_pids
                ),
                None,
            )
            name = game.name if game is not None else Path(row.process.name).stem
            label = f"{name}  ·  {row.process.name}"
            if label in self._compact_row_by_label:
                label = f"{label}  ·  PID {row.process.pid}"
            labels.append(label)
            self._compact_row_by_label[label] = row
            if selected_identity == self._row_identity(row):
                chosen = label

        if not labels:
            self.compact_game_combo.configure(
                values=("No running game detected",),
                state="disabled",
            )
            self.compact_game_var.set("No running game detected")
            self.compact_build_var.set("Build: waiting for a running game")
            return

        self.compact_game_combo.configure(values=tuple(labels), state="readonly")
        chosen = chosen or labels[0]
        self.compact_game_var.set(chosen)
        self._update_compact_build(self._compact_row_by_label[chosen])

    def _compact_game_selected(self, _event=None) -> None:
        row = self._compact_row_by_label.get(self.compact_game_var.get())
        if row is None:
            return
        matching_item = next(
            (
                item_id
                for item_id, candidate in self._row_by_item.items()
                if self._row_identity(candidate) == self._row_identity(row)
            ),
            None,
        )
        if matching_item is None:
            self.message_var.set("Refresh the running-game list, then choose the game again.")
            return
        self.process_tree.selection_set(matching_item)
        self.process_tree.see(matching_item)
        self._process_selected()
        self._update_compact_build(row)
        if self._active_session is not None:
            if int(self._active_session.get("pid", -1)) == row.process.pid:
                mode = (
                    "with value editing"
                    if bool(self._active_session.get("write_enabled"))
                    else "read-only"
                )
                self.message_var.set(f"{row.process.name} is already attached {mode}.")
            else:
                self.message_var.set("Detach the current game before choosing another one.")
            return
        self.write_var.set(True)
        self._refresh_attach_mode_text()
        self.message_var.set(
            f"Attaching {row.process.name}, loading saved controls, and starting learning..."
        )
        self.root.after(0, self._attach_selected)

    def _update_compact_build(self, row: ProcessRow | None) -> None:
        if row is None or not row.process.executable:
            self.compact_build_var.set("Build: unknown")
            return
        identity = executable_build_identity(row.process.executable)
        self.compact_build_var.set(f"Build: {_short_build_identity(identity)}")

    def _sort_processes(self, key: str) -> None:
        if self._sort_key == key:
            self._sort_descending = not self._sort_descending
        else:
            self._sort_key = key
            self._sort_descending = key in {"gpu", "memory", "score"}
        self._render_process_rows()

    def _selected_process_row(self) -> ProcessRow | None:
        selected = self.process_tree.selection() if hasattr(self, "process_tree") else ()
        return self._row_by_item.get(selected[0]) if selected else None

    def _process_selected(self, _event=None) -> None:
        row = self._selected_process_row()
        if row is None:
            self.attach_button.configure(state="disabled")
            if hasattr(self, "compact_build_var"):
                self._update_compact_build(None)
            return
        if hasattr(self, "compact_build_var"):
            self._update_compact_build(row)
        if hasattr(self, "_compact_row_by_label"):
            for label, candidate in self._compact_row_by_label.items():
                if self._row_identity(candidate) == self._row_identity(row):
                    self.compact_game_var.set(label)
                    break
        gpu = (
            f"{row.process.gpu_percent:.1f}%"
            if row.process.gpu_percent is not None
            else "unavailable"
        )
        reasons = ", ".join(row.process.game_reasons[:3]) or "no strong game signals"
        detail = row.process.blocked_reason or row.process.executable or "Path unavailable"
        self.selection_var.set(
            f"{row.process.name} - PID {row.process.pid} - GPU {gpu}, "
            f"RAM {_format_memory(row.process.memory_bytes)}, game score "
            f"{row.process.game_score}% ({reasons}) - {detail}"
        )
        can_attach = row.process.attachable and row.state is not ProcessState.DISAPPEARED
        self.attach_button.configure(state="normal" if can_attach else "disabled")
        if not self._syncing_game_process_selection:
            matching_game = next(
                (
                    game
                    for game in self._library_snapshot.games
                    if row.process.pid in game.running_pids
                ),
                None,
            )
            if matching_game:
                item_id = self._game_item_by_id.get(matching_game.id)
                if item_id and self.game_tree.selection() != (item_id,):
                    self._syncing_game_process_selection = True
                    try:
                        self.game_tree.selection_set(item_id)
                        self.game_tree.see(item_id)
                        self._game_selected()
                    finally:
                        self._syncing_game_process_selection = False

    def _selected_process_name(self) -> str:
        row = self._selected_process_row()
        if row is None or row.state is ProcessState.DISAPPEARED:
            return ""
        return row.process.name

    def _attach_selected(self, _event=None) -> None:
        row = self._selected_process_row()
        if row is None or not row.process.attachable or row.state is ProcessState.DISAPPEARED:
            return
        if row.process.likely_game:
            self.write_var.set(True)
            self._refresh_attach_mode_text()
        try:
            self._sync_config_from_controls()
        except ValueError as exc:
            self.message_var.set(str(exc))
            return
        write_enabled = bool(self.write_var.get())
        self._start_mount_progress(row.process.name, write_enabled=write_enabled)
        game = self._selected_game()
        table = self._selected_table()
        def start_and_attach() -> dict[str, Any]:
            self.controller.ensure_runtime()
            return self.controller.attach_process(
                row.process.pid,
                write_enabled=write_enabled,
                game_key=game.game_key if game else None,
                game_name=game.name if game else None,
                table_path=table.path if table else None,
            )

        self._run_background(start_and_attach, self._attach_finished)

    def _attach_finished(self, session: dict[str, Any]) -> None:
        self._auto_mount_in_progress = False
        self._active_session = session
        self._screen_observed_values.clear()
        self._screen_visible_baselines.clear()
        self._screen_temporal_started.clear()
        self._screen_temporal_pending.clear()
        self._automatic_trace_attempts.clear()
        self._reset_automatic_trace_state()
        self.integrated_panel.clear_screen_observations()
        session_mode = "value editing" if bool(session.get("write_enabled")) else "read-only"
        self.session_var.set(
            f"Attached: {session['process_name']} (PID {session['pid']}) - {session_mode}"
        )
        self.detach_button.configure(state="normal")
        self.export_button.configure(state="normal")
        self.learn_button.configure(state="normal")
        self.table_combo.configure(state="disabled")
        self.launch_game_button.configure(state="disabled")
        game = self._selected_game()
        if game is not None:
            self._record_game_played(game)
        self._mount_stage = "Step 2/3 — checking local tables, profiles, and game engine"
        self._poll_mount_catalog()
        self._start_initial_read_only_discovery(session)

    def _start_initial_read_only_discovery(self, session: dict[str, Any]) -> None:
        session_id = str(session.get("session_id") or "")
        process_name = str(session.get("process_name") or "")
        if (
            not session_id
            or session_id in self._initial_discovery_session_ids
        ):
            return
        self._initial_discovery_session_ids.add(session_id)
        self._run_background(
            lambda: self.controller.start_autonomous_discovery(
                session_id=session_id,
                process_name=process_name,
            ),
            self._initial_read_only_discovery_started,
            lock_buttons=False,
        )

    def _initial_read_only_discovery_started(self, result: dict[str, Any]) -> None:
        self._discovery_run_id = str(result.get("id") or "") or None
        target_count = len(result.get("target_order") or [])
        self.integrated_panel.capability_status_var.set(
            f"Automatic RAM discovery and learning is running across {target_count} "
            "targets; "
            "100% candidates lock for this run."
        )
        self.integrated_panel.set_learning_status(
            "Learning guide: saved targets are checked first. Keep the game visible while GTP "
            "reads bars and numbers, narrows RAM matches, and verifies small reversible traces."
        )
        active_session = getattr(self, "_active_session", None)
        if active_session is not None:
            session_id = str(active_session.get("session_id") or "")
            if session_id:
                self._start_background_catalog_refresh(session_id)
            self._schedule_discovery_poll()
            self._start_screen_learning_bursts()

    def _start_screen_learning_bursts(self) -> None:
        self._cancel_screen_learning_bursts()
        if self._active_session is None:
            return
        self._screen_learning_samples_remaining = SCREEN_LEARNING_BURST_SAMPLES
        self._screen_learning_failures = 0
        self._screen_learning_after = self.root.after(750, self._capture_screen_learning_sample)

    def _capture_screen_learning_sample(self) -> None:
        self._screen_learning_after = None
        if (
            self._active_session is None
            or not self._discovery_run_id
            or self._screen_learning_busy
        ):
            return
        self._screen_learning_busy = True
        session_id = str(self._active_session.get("session_id") or "")

        def worker() -> None:
            try:
                result = self.controller.estimate_health_bars(session_id, limit=8)
                self._post_ui(lambda: self._screen_learning_sample_finished(result))
            except Exception as exc:  # noqa: BLE001 - minimized games simply pause screen learning
                self._post_ui(lambda error=exc: self._screen_learning_sample_failed(error))

        threading.Thread(target=worker, daemon=True).start()

    def _screen_learning_sample_finished(self, result: dict[str, Any]) -> None:
        self._screen_learning_busy = False
        self._screen_learning_failures = 0
        capture_status = str(result.get("capture_status") or "captured")
        if capture_status != "captured":
            message = str(
                result.get("message")
                or "Bring the selected game to the front to continue HUD learning."
            )
            self._screen_learning_pause_message = message
            self.integrated_panel.set_learning_status(f"Learning guide: {message}")
            if capture_status == "inventory":
                self.integrated_panel.capture_inventory_learning_sample("automatic")
            self._schedule_next_screen_learning_sample()
            return
        self._screen_learning_pause_message = None
        if not hasattr(self, "_screen_temporal_started"):
            self._screen_temporal_started = set()
        if not hasattr(self, "_screen_temporal_pending"):
            self._screen_temporal_pending = set()
        stable = self.integrated_panel.add_screen_observations(result)
        best_by_target: dict[str, dict[str, Any]] = {}
        for observation in stable:
            target = str(observation.get("target") or "")
            previous = best_by_target.get(target)
            if previous is None or float(observation.get("confidence") or 0) > float(
                previous.get("confidence") or 0
            ):
                best_by_target[target] = observation
        exact_updates: list[tuple[str, int | float]] = []
        temporal_updates: list[tuple[str, str, int | float]] = []
        process_name = str((self._active_session or {}).get("process_name") or "")
        for target, observation in best_by_target.items():
            representations = (
                _meter_scan_representations(process_name, target, observation)
                if bool(observation.get("normalized"))
                else [
                    {
                        "target": target,
                        "value": observation["value"],
                        "value_type": observation.get("value_type", "i32"),
                    }
                ]
            )
            for representation in representations:
                represented_target = str(representation["target"])
                value = representation["value"]
                self._screen_visible_baselines[represented_target.casefold()] = {
                    **observation,
                    **representation,
                }
                if bool(observation.get("normalized")):
                    temporal_key = represented_target.casefold()
                    comparison = str(observation.get("comparison") or "baseline")
                    if temporal_key not in self._screen_temporal_started:
                        comparison = "baseline"
                    if (
                        comparison in {"baseline", "increased", "decreased"}
                        and temporal_key not in self._screen_temporal_pending
                    ):
                        self._screen_temporal_pending.add(temporal_key)
                        temporal_updates.append((represented_target, comparison, value))
                    continue
                prior = self._screen_observed_values.get(represented_target)
                if prior is not None and abs(float(prior) - float(value)) < 0.005:
                    continue
                self._screen_observed_values[represented_target] = float(value)
                exact_updates.append((represented_target, value))
        if (exact_updates or temporal_updates) and self._discovery_run_id:
            run_id = self._discovery_run_id

            def apply_updates() -> dict[str, Any]:
                status: dict[str, Any] = {}
                try:
                    for target, comparison, value in temporal_updates:
                        status = self.controller.record_autonomous_discovery_screen_comparison(
                            run_id,
                            target,
                            comparison,
                            value,
                        )
                    for target, value in exact_updates:
                        status = self.controller.set_autonomous_discovery_value(
                            run_id,
                            target,
                            value,
                            source="screen",
                        )
                except Exception as exc:  # noqa: BLE001 - retain the next screenshot opportunity
                    return {"error": str(exc), "status": status}
                return {"status": status}

            self._run_background(
                apply_updates,
                lambda payload: self._screen_discovery_values_applied(
                    payload,
                    temporal_updates,
                ),
                lock_buttons=False,
            )
        self._schedule_next_screen_learning_sample()

    def _screen_discovery_values_applied(
        self,
        payload: dict[str, Any],
        temporal_updates: list[tuple[str, str, int | float]] | None = None,
    ) -> None:
        updates = temporal_updates or []
        for target, _comparison, _value in updates:
            getattr(self, "_screen_temporal_pending", set()).discard(target.casefold())
        error = str(payload.get("error") or "")
        status = payload.get("status") if "status" in payload else payload
        if error:
            self.integrated_panel.set_learning_status(
                f"Learning guide: screenshot correlation paused: {error}"
            )
            return
        for target, _comparison, _value in updates:
            if not hasattr(self, "_screen_temporal_started"):
                self._screen_temporal_started = set()
            self._screen_temporal_started.add(target.casefold())
        if status:
            self._render_discovery_status(status)

    def _screen_learning_sample_failed(self, error: Exception) -> None:
        self._screen_learning_busy = False
        self._screen_learning_failures += 1
        self._screen_learning_pause_message = (
            f"HUD observation is waiting: {error}. No screenshot value was accepted."
        )
        self.integrated_panel.set_learning_status(
            f"Learning guide: {self._screen_learning_pause_message}"
        )
        self._schedule_next_screen_learning_sample()

    def _schedule_next_screen_learning_sample(self) -> None:
        if self._active_session is None or not self._discovery_run_id:
            return
        self._screen_learning_samples_remaining -= 1
        if self._screen_learning_samples_remaining > 0:
            delay = SCREEN_LEARNING_INTERVAL_MS
        else:
            self._screen_learning_samples_remaining = SCREEN_LEARNING_BURST_SAMPLES
            delay = SCREEN_LEARNING_REST_MS
        self._screen_learning_after = self.root.after(delay, self._capture_screen_learning_sample)

    def _cancel_screen_learning_bursts(self) -> None:
        self._screen_learning_busy = False
        self._screen_learning_samples_remaining = 0
        if self._screen_learning_after is not None:
            self.root.after_cancel(self._screen_learning_after)
            self._screen_learning_after = None

    def _start_mount_progress(self, process_name: str, *, write_enabled: bool = False) -> None:
        self._cancel_background_catalog_refresh()
        if self._mount_progress_after is not None:
            self.root.after_cancel(self._mount_progress_after)
        self._mount_started_at = time.monotonic()
        self._mount_process_name = process_name
        self._mount_write_enabled = write_enabled
        session_mode = "value-editing" if write_enabled else "read-only"
        self._mount_stage = f"Step 1/3 — opening the {session_mode} game session"
        self._mount_catalog_poll_failures = 0
        self._mount_catalog_poll_busy = False
        self._update_mount_progress()

    def _update_mount_progress(self) -> None:
        if self._mount_started_at is None:
            self._mount_progress_after = None
            return
        elapsed = time.monotonic() - self._mount_started_at
        self.message_var.set(
            f"Mounting {self._mount_process_name}: {elapsed:.1f}s — {self._mount_stage}"
        )
        self._mount_progress_after = self.root.after(250, self._update_mount_progress)

    def _poll_mount_catalog(self) -> None:
        if self._active_session is None or self._mount_catalog_poll_busy:
            return
        self._mount_catalog_poll_busy = True
        session_id = str(self._active_session["session_id"])

        def worker() -> None:
            try:
                catalog = self.controller.game_cheat_catalog(session_id)
                self._post_ui(lambda: self._mount_catalog_updated(catalog))
            except Exception as exc:  # noqa: BLE001 - slow catalog must not break attachment
                self._post_ui(lambda error=exc: self._mount_catalog_poll_failed(error))

        threading.Thread(target=worker, daemon=True).start()

    def _mount_catalog_updated(self, catalog: dict[str, Any]) -> None:
        if self._mount_started_at is None:
            return
        self._mount_catalog_poll_busy = False
        completed = int(catalog.get("mount_steps_completed", 0))
        total = max(1, int(catalog.get("mount_steps_total", 3)))
        stage = str(catalog.get("mount_stage") or "Building the game cheat library")
        source_count = len(catalog.get("web_sources") or [])
        feature_count = len(catalog.get("features") or [])
        self.integrated_panel.update_catalog(
            catalog,
            write_enabled=bool(self._active_session and self._active_session.get("write_enabled")),
        )
        self._mount_stage = (
            f"Step {min(completed + 1, total)}/{total} — {stage}; "
            f"{source_count} sources, {feature_count} candidate features"
        )
        if _catalog_core_ready(catalog):
            session_id = str(
                self._active_session.get("session_id") if self._active_session else ""
            )
            self._finish_mount_progress(catalog)
            if completed < total and session_id:
                self._start_background_catalog_refresh(session_id)
            return
        self.root.after(750, self._poll_mount_catalog)

    def _mount_catalog_poll_failed(self, _error: Exception) -> None:
        if self._mount_started_at is None:
            return
        self._mount_catalog_poll_busy = False
        self._mount_catalog_poll_failures += 1
        if self._mount_catalog_poll_failures >= 5:
            self._finish_mount_progress(None)
            return
        self._mount_stage = "Catalog is still loading; checking again"
        self.root.after(1000, self._poll_mount_catalog)

    def _finish_mount_progress(self, catalog: dict[str, Any] | None) -> None:
        elapsed = (
            time.monotonic() - self._mount_started_at if self._mount_started_at is not None else 0.0
        )
        self._mount_started_at = None
        if self._mount_progress_after is not None:
            self.root.after_cancel(self._mount_progress_after)
            self._mount_progress_after = None
        session_mode = "with value editing" if self._mount_write_enabled else "read-only"
        if catalog is None:
            self.message_var.set(
                f"Mounted {session_mode} in {elapsed:.1f}s. The cheat library continues loading "
                "in the background."
            )
            return
        useful = int(catalog.get("useful_feature_count", 0))
        secondary = int(catalog.get("secondary_feature_count", 0))
        ignored = int(catalog.get("ignored_feature_count", 0))
        self.message_var.set(
            f"Mounted {session_mode} in {elapsed:.1f}s — {useful} useful, {secondary} optional "
            f"movement/tuning, {ignored} engine/noise values ignored."
            + (
                " Public references are still loading in the background."
                if int(catalog.get("mount_steps_completed", 0))
                < max(1, int(catalog.get("mount_steps_total", 3)))
                else ""
            )
        )

    def _start_background_catalog_refresh(self, session_id: str) -> None:
        self._cancel_background_catalog_refresh()
        self._catalog_refresh_session_id = session_id
        self._catalog_refresh_failures = 0
        self._catalog_refresh_after = self.root.after(750, self._poll_background_catalog)

    def _poll_background_catalog(self) -> None:
        self._catalog_refresh_after = None
        session_id = self._catalog_refresh_session_id
        active_session_id = str(
            self._active_session.get("session_id") if self._active_session else ""
        )
        if not session_id or session_id != active_session_id:
            self._cancel_background_catalog_refresh()
            return
        if self._catalog_refresh_busy:
            return
        self._catalog_refresh_busy = True

        def worker() -> None:
            try:
                catalog = self.controller.game_cheat_catalog(session_id)
                self._post_ui(
                    lambda: self._background_catalog_updated(session_id, catalog)
                )
            except Exception as exc:  # noqa: BLE001 - optional refresh is best effort
                self._post_ui(
                    lambda error=exc: self._background_catalog_poll_failed(
                        session_id,
                        error,
                    )
                )

        threading.Thread(target=worker, daemon=True).start()

    def _background_catalog_updated(
        self,
        session_id: str,
        catalog: dict[str, Any],
    ) -> None:
        if session_id != self._catalog_refresh_session_id:
            return
        self._catalog_refresh_busy = False
        self.integrated_panel.update_catalog(
            catalog,
            write_enabled=bool(self._active_session and self._active_session.get("write_enabled")),
        )
        completed = int(catalog.get("mount_steps_completed", 0))
        total = max(1, int(catalog.get("mount_steps_total", 3)))
        if completed >= total and not self._discovery_run_id:
            self._cancel_background_catalog_refresh()
            return
        delay = LEARNING_CATALOG_REFRESH_MS if self._discovery_run_id else 750
        self._catalog_refresh_after = self.root.after(delay, self._poll_background_catalog)

    def _background_catalog_poll_failed(
        self,
        session_id: str,
        _error: Exception,
    ) -> None:
        if session_id != self._catalog_refresh_session_id:
            return
        self._catalog_refresh_busy = False
        self._catalog_refresh_failures += 1
        if self._catalog_refresh_failures >= 5:
            self._cancel_background_catalog_refresh()
            return
        self._catalog_refresh_after = self.root.after(1000, self._poll_background_catalog)

    def _cancel_background_catalog_refresh(self) -> None:
        self._catalog_refresh_session_id = None
        self._catalog_refresh_busy = False
        if self._catalog_refresh_after is not None:
            self.root.after_cancel(self._catalog_refresh_after)
            self._catalog_refresh_after = None

    def _cancel_mount_progress(self) -> None:
        self._mount_started_at = None
        self._mount_catalog_poll_busy = False
        if self._mount_progress_after is not None:
            self.root.after_cancel(self._mount_progress_after)
            self._mount_progress_after = None

    def _export_selected_table(self) -> None:
        if self._active_session is None:
            return
        session_id = str(self._active_session["session_id"])
        self.message_var.set("Exporting the selected game's portable table...")
        self._run_background(
            lambda: self.controller.export_game_value_table(session_id),
            self._export_table_finished,
        )

    def _export_table_finished(self, result: dict[str, Any]) -> None:
        self.message_var.set(f"Portable game table exported: {result['exported_path']}")

    def _open_discovery_window(self) -> None:
        from tkinter import messagebox

        if self._active_session is None:
            messagebox.showinfo(
                "Learn cheat options",
                "Attach the running offline game first.",
                parent=self.root,
            )
            return
        if self._discovery_window is not None and self._discovery_window.winfo_exists():
            self._discovery_window.deiconify()
            self._discovery_window.lift()
            return

        window = self.tk.Toplevel(self.root)
        window.title("Learn cheat options")
        window.geometry("980x810")
        window.minsize(820, 600)
        window.transient(self.root)
        window.protocol("WM_DELETE_WINDOW", self._close_discovery_window)
        self._discovery_window = window

        frame = self.ttk.Frame(window, padding=16)
        frame.pack(fill="both", expand=True)
        self.ttk.Label(
            frame,
            text="Build this game's reusable cheat table",
            style="Heading.TLabel",
        ).pack(anchor="w")
        self.ttk.Label(
            frame,
            text=(
                "Choose what to learn. Discovery reads the local offline game, compares live "
                "play events, keeps synchronized copies together, and saves only candidates "
                "that can be revalidated after a restart. Learning never writes memory."
            ),
            wraplength=920,
        ).pack(anchor="w", pady=(4, 10))

        selection = self.ttk.LabelFrame(frame, text="Cheats to learn", padding=10)
        selection.pack(fill="x")
        listbox = self.tk.Listbox(
            selection,
            selectmode="extended",
            exportselection=False,
            height=6,
        )
        for target in CORE_CHEAT_TARGETS:
            listbox.insert("end", target)
        listbox.selection_set(0, "end")
        listbox.pack(side="left", fill="x", expand=True)
        self._discovery_listbox = listbox

        selection_buttons = self.ttk.Frame(selection)
        selection_buttons.pack(side="right", padx=(12, 0), anchor="n")
        self.ttk.Button(
            selection_buttons,
            text="Select all",
            command=lambda: listbox.selection_set(0, "end"),
        ).pack(fill="x")
        self.ttk.Button(
            selection_buttons,
            text="Clear",
            command=lambda: listbox.selection_clear(0, "end"),
        ).pack(fill="x", pady=(6, 0))

        controls = self.ttk.Frame(frame)
        controls.pack(fill="x", pady=(10, 0))
        self.ttk.Button(
            controls,
            text="Start learning",
            command=self._start_cheat_learning,
        ).pack(side="left")
        self.ttk.Button(
            controls,
            text="Stop and save progress",
            command=self._stop_cheat_learning,
        ).pack(side="left", padx=(8, 0))

        self._discovery_status_var = self.tk.StringVar(value="Ready to build a read-only baseline.")
        self._discovery_prompt_var = self.tk.StringVar(
            value="The next action will appear here while learning."
        )
        self.ttk.Label(
            frame,
            textvariable=self._discovery_status_var,
            style="Status.TLabel",
        ).pack(anchor="w", pady=(12, 0))
        self.ttk.Label(
            frame,
            textvariable=self._discovery_prompt_var,
            wraplength=920,
            foreground="#17643a",
        ).pack(anchor="w", pady=(4, 8))

        table_frame = self.ttk.Frame(frame)
        table_frame.pack(fill="both", expand=True)
        tree = self.ttk.Treeview(
            table_frame,
            columns=("target", "state", "candidates", "confidence", "next"),
            show="headings",
            height=12,
        )
        tree.heading("target", text="Cheat option")
        tree.heading("state", text="Learning state")
        tree.heading("candidates", text="Candidates")
        tree.heading("confidence", text="Best confidence")
        tree.heading("next", text="What happens next")
        tree.column("target", width=180, minwidth=130, stretch=False)
        tree.column("state", width=120, minwidth=100, stretch=False)
        tree.column("candidates", width=90, minwidth=80, stretch=False, anchor="e")
        tree.column("confidence", width=105, minwidth=95, stretch=False, anchor="e")
        tree.column("next", width=410, minwidth=240)
        tree.pack(side="left", fill="both", expand=True)
        scrollbar = self.ttk.Scrollbar(table_frame, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side="right", fill="y")
        self._discovery_tree = tree

        visible = self.ttk.LabelFrame(frame, text="Visible value (when requested)", padding=10)
        visible.pack(fill="x", pady=(10, 0))
        self._discovery_target_var = self.tk.StringVar(value=VISIBLE_VALUE_TARGETS[0])
        self._discovery_value_var = self.tk.StringVar()
        self.ttk.Combobox(
            visible,
            textvariable=self._discovery_target_var,
            values=VISIBLE_VALUE_TARGETS,
            state="readonly",
            width=28,
        ).pack(side="left")
        self.ttk.Entry(
            visible,
            textvariable=self._discovery_value_var,
            width=18,
        ).pack(side="left", padx=(8, 0))
        self.ttk.Button(
            visible,
            text="Use current displayed value",
            command=self._set_discovery_visible_value,
        ).pack(side="left", padx=(8, 0))
        self.ttk.Label(
            visible,
            text="Example: Units 15460 or an inventory stack count 154",
            foreground="#565d66",
        ).pack(side="left", padx=(12, 0))

        behavior = self.ttk.LabelFrame(
            frame,
            text="Guided movement check (prevents false matches)",
            padding=10,
        )
        behavior.pack(fill="x", pady=(10, 0))
        self._discovery_behavior_target_var = self.tk.StringVar(
            value=next(iter(BEHAVIOR_ACTION_LABELS))
        )
        self.ttk.Combobox(
            behavior,
            textvariable=self._discovery_behavior_target_var,
            values=tuple(BEHAVIOR_ACTION_LABELS),
            state="readonly",
            width=24,
        ).pack(side="left")
        self.ttk.Button(
            behavior,
            text="1. Capture rest baseline",
            command=lambda: self._capture_discovery_behavior("begin"),
        ).pack(side="left", padx=(8, 0))
        self.ttk.Button(
            behavior,
            text="2. Finish after action",
            command=lambda: self._capture_discovery_behavior("complete"),
        ).pack(side="left", padx=(8, 0))
        self.ttk.Button(
            behavior,
            text="Cancel",
            command=lambda: self._capture_discovery_behavior("cancel"),
        ).pack(side="left", padx=(8, 0))
        self.ttk.Label(
            frame,
            text=(
                "Start while resting, return to the game and perform only the selected action, "
                "then finish. Background/menu changes never count as proof."
            ),
            foreground="#565d66",
            wraplength=920,
        ).pack(anchor="w", pady=(4, 0))

        save_compare = self.ttk.LabelFrame(
            frame,
            text="Save comparison (No Man's Sky)",
            padding=10,
        )
        save_compare.pack(fill="x", pady=(10, 0))
        self._save_compare_var = self.tk.StringVar(
            value="Compare the two newest local saves to label currency and inventory deltas."
        )
        self.ttk.Button(
            save_compare,
            text="Compare newest saves",
            command=self._compare_newest_nms_saves,
        ).pack(side="left")
        self.ttk.Label(
            save_compare,
            textvariable=self._save_compare_var,
            wraplength=700,
            foreground="#565d66",
        ).pack(side="left", padx=(12, 0))

        if self._discovery_run_id:
            self._poll_discovery_status()

    def _close_discovery_window(self) -> None:
        if self._discovery_poll_after is not None:
            self.root.after_cancel(self._discovery_poll_after)
            self._discovery_poll_after = None
        if self._discovery_window is not None:
            self._discovery_window.destroy()
        self._discovery_window = None
        self._discovery_tree = None
        self._discovery_listbox = None
        self._save_compare_var = None

    def _compare_newest_nms_saves(self) -> None:
        if self._save_compare_var is not None:
            self._save_compare_var.set("Reading and comparing local saves without changing them...")
        self._run_background(
            self.controller.compare_nms_saves,
            self._nms_save_compare_finished,
            lock_buttons=False,
        )

    def _nms_save_compare_finished(self, report: dict[str, Any]) -> None:
        if self._save_compare_var is None:
            return
        older = str((report.get("older") or {}).get("filename") or "older save")
        newer = str((report.get("newer") or {}).get("filename") or "newer save")
        deltas = report.get("currency_changes") or {}
        delta_text = ", ".join(f"{name} {int(value):+d}" for name, value in deltas.items())
        suffix = f" Currency: {delta_text}." if delta_text else ""
        self._save_compare_var.set(
            f"{older} → {newer}: {int(report.get('total_changed_fields', 0))} changed fields."
            f"{suffix} Ranked deltas are ready for live-scan correlation."
        )

    def _start_cheat_learning(self) -> None:
        if self._active_session is None or self._discovery_listbox is None:
            return
        selected = [
            str(self._discovery_listbox.get(index))
            for index in self._discovery_listbox.curselection()
        ]
        if not selected:
            if self._discovery_status_var is not None:
                self._discovery_status_var.set("Choose at least one cheat option to learn.")
            return
        session_id = str(self._active_session["session_id"])
        process_name = str(self._active_session.get("process_name") or "NMS.exe")
        if self._discovery_status_var is not None:
            self._discovery_status_var.set("Starting learning and building read-only baselines...")
        self._run_background(
            lambda: self.controller.start_autonomous_discovery(
                session_id=session_id,
                process_name=process_name,
                target_order=selected,
            ),
            self._cheat_learning_started,
        )

    def _cheat_learning_started(self, status: dict[str, Any]) -> None:
        self._discovery_run_id = str(status["id"])
        if self._active_session is not None and status.get("session_id"):
            self._active_session["session_id"] = status["session_id"]
            write_enabled = bool(
                status.get("write_enabled", self._active_session.get("write_enabled"))
            )
            self._active_session["write_enabled"] = write_enabled
            if status.get("pid"):
                self._active_session["pid"] = status["pid"]
            mode = "write-enabled learning" if write_enabled else "read-only learning"
            self.session_var.set(
                f"Attached: {self._active_session['process_name']} "
                f"(PID {self._active_session['pid']}) - {mode}"
            )
        if self._active_session and self._active_session.get("write_enabled"):
            self.message_var.set(
                "Cheat learning is running. Candidate tests and value changes remain "
                "individually reviewed."
            )
        else:
            self.message_var.set("Cheat learning is running read-only in the background.")
        self._render_discovery_status(status)
        self._schedule_discovery_poll()

    def _schedule_discovery_poll(self) -> None:
        if not self._discovery_run_id or self._active_session is None:
            return
        if self._discovery_poll_after is not None:
            self.root.after_cancel(self._discovery_poll_after)
        self._discovery_poll_after = self.root.after(1500, self._poll_discovery_status)

    def _poll_discovery_status(self) -> None:
        self._discovery_poll_after = None
        if not self._discovery_run_id or self._discovery_poll_busy:
            return
        self._discovery_poll_busy = True
        run_id = self._discovery_run_id

        def worker() -> None:
            try:
                status = self.controller.autonomous_discovery_status(run_id)
                self._post_ui(lambda: self._discovery_poll_finished(status))
            except Exception as exc:  # noqa: BLE001 - status retry stays inside this window
                self._post_ui(lambda error=exc: self._discovery_poll_failed(error))

        threading.Thread(target=worker, daemon=True).start()

    def _discovery_poll_finished(self, status: dict[str, Any]) -> None:
        self._discovery_poll_busy = False
        state = str(status.get("state") or "")
        session_changed = self._sync_discovery_session(status)
        if state == "waiting_for_process":
            self._screen_learning_pause_message = (
                "The selected game is closed. Learning will resume after it reopens."
            )
            self._cancel_screen_learning_bursts()
        elif session_changed:
            self._screen_learning_pause_message = None
            self._start_screen_learning_bursts()
        self._render_discovery_status(status)
        if state not in {"stopped", "completed"}:
            self._schedule_discovery_poll()
        else:
            self._discovery_run_id = None
            self._cancel_screen_learning_bursts()

    def _sync_discovery_session(self, status: dict[str, Any]) -> bool:
        """Follow a supervised learner onto the game's current process incarnation."""

        if self._active_session is None:
            return False
        session_id = str(status.get("session_id") or "")
        if not session_id:
            return False
        pid = int(status.get("pid") or self._active_session.get("pid") or 0)
        changed = (
            session_id != str(self._active_session.get("session_id") or "")
            or pid != int(self._active_session.get("pid") or 0)
        )
        self._active_session["session_id"] = session_id
        self._active_session["pid"] = pid
        write_enabled = bool(
            status.get("write_enabled", self._active_session.get("write_enabled", False))
        )
        self._active_session["write_enabled"] = write_enabled
        mode = "write-enabled learning" if write_enabled else "read-only learning"
        self.session_var.set(
            f"Attached: {self._active_session['process_name']} (PID {pid}) - {mode}"
        )
        return changed

    def _discovery_poll_failed(self, error: Exception) -> None:
        self._discovery_poll_busy = False
        if self._discovery_status_var is not None:
            self._discovery_status_var.set(f"Learning status is temporarily unavailable: {error}")
        self._schedule_discovery_poll()

    def _render_discovery_status(self, status: dict[str, Any]) -> None:
        tree = (
            self._discovery_tree
            if self._discovery_tree is not None and self._discovery_tree.winfo_exists()
            else None
        )
        if tree is not None:
            tree.delete(*tree.get_children())
        active_name = str(status.get("active_target") or "")
        active_prompt = ""
        confirmed = 0
        locked = 0
        for index, target in enumerate(status.get("targets") or []):
            candidates = target.get("candidates") or []
            best = max((float(item.get("confidence", 0)) for item in candidates), default=0.0)
            state = str(target.get("state") or "queued").replace("_", " ")
            if state == "confirmed":
                confirmed += 1
            elif state == "locked":
                locked += 1
            exact_missing = (
                bool(target.get("requires_visible_value")) and target.get("exact_value") is None
            )
            if target.get("requires_behavior_capture"):
                capture_state = str(target.get("behavior_capture_state") or "")
                next_action = (
                    "Perform only the selected action, then click Finish after action."
                    if capture_state == "armed"
                    else "Use the guided action check below; background changes are ignored."
                )
            else:
                target_name = str(target.get("name") or "the value")
                if exact_missing:
                    next_action = "Enter the currently displayed value below."
                elif int(target.get("candidate_count") or 0) > 0:
                    if target_name.casefold() in {"health", "shield", "stamina", "jetpack"}:
                        next_action = (
                            f"Keep {target_name} visible, make it drop or refill once, then pause."
                        )
                    elif target_name.casefold() in {"units", "nanites", "quicksilver"}:
                        next_action = (
                            f"Spend or earn a small amount of {target_name}, then leave the new "
                            "total visible."
                        )
                    else:
                        next_action = (
                            f"Change {target_name} once in the game, then enter or show its new "
                            "value."
                        )
                else:
                    next_action = str(
                        target.get("experiment_prompt") or "Keep playing normally for comparison."
                    )
            if target.get("name") == active_name:
                active_prompt = next_action
            if tree is not None:
                tree.insert(
                    "",
                    "end",
                    iid=f"discovery-{index}",
                    values=(
                        target.get("name", ""),
                        state,
                        int(target.get("candidate_count", 0)),
                        f"{best:.0%}" if candidates else "—",
                        next_action,
                    ),
                )
        self.integrated_panel.set_confirmed_learning_targets(
            [
                str(target.get("name") or "")
                for target in status.get("targets") or []
                if str(target.get("state") or "").casefold() == "confirmed"
                or any(
                    str(candidate.get("write_test_status") or "").casefold() == "confirmed"
                    for candidate in target.get("candidates") or []
                )
            ]
        )
        run_state = str(status.get("state") or "running")
        pause_message = getattr(self, "_screen_learning_pause_message", None)
        if self._discovery_status_var is not None:
            state_label = run_state.replace("_", " ").title()
            if run_state == "waiting_for_process":
                state_label = "Waiting for the selected game"
            elif pause_message:
                state_label = "RAM learner active; HUD observation waiting"
            self._discovery_status_var.set(
                f"{state_label} — {int(status.get('cycle_count', 0))} real target passes; "
                f"{locked} locked this run, {confirmed} restart-verified."
            )
        if run_state == "waiting_for_process":
            prompt = "Learning is paused until the selected game reopens."
        elif pause_message:
            prompt = pause_message
        elif active_name:
            prompt = f"Now learning {active_name}: {active_prompt}"
        else:
            prompt = "Learning is waiting for the next real value or guided-action change."
        if self._discovery_prompt_var is not None:
            self._discovery_prompt_var.set(prompt)
        self.integrated_panel.set_learning_status(f"Learning guide: {prompt}")
        self._maybe_start_automatic_trace(status)
        if not getattr(self, "_automatic_trace_busy", False) and hasattr(
            self.integrated_panel, "maybe_start_inventory_matrix"
        ):
            self.integrated_panel.maybe_start_inventory_matrix(status)

    def _maybe_start_automatic_trace(self, status: dict[str, Any]) -> None:
        session = self._active_session or {}
        if self._automatic_trace_busy or not bool(session.get("write_enabled")):
            return
        run_id = str(status.get("id") or self._discovery_run_id or "")
        if not run_id:
            return
        for target in status.get("targets") or []:
            target_name = str(target.get("name") or "")
            value_type = str(target.get("value_type") or "").casefold()
            if (
                str(target.get("state") or "").casefold() == "confirmed"
                or value_type not in {*INTEGER_VALUE_TYPES, "f32", "f64"}
            ):
                continue
            ready = [
                str(candidate.get("id") or "")
                for candidate in target.get("candidates") or []
                if str(candidate.get("write_test_status") or "") == "ready"
                and str(candidate.get("id") or "")
            ]
            if not 1 <= len(ready) <= 5:
                continue
            baseline = _automatic_trace_baseline(
                self._screen_visible_baselines,
                target_name,
                target.get("exact_value"),
            )
            if baseline is None:
                continue
            attempt = (
                run_id,
                target_name.casefold(),
                int(target.get("generation") or 0),
                tuple(sorted(ready)),
            )
            if attempt in self._automatic_trace_attempts:
                continue
            self._automatic_trace_attempts.add(attempt)
            self._automatic_trace_busy = True
            self._automatic_trace_target = dict(target)
            self._automatic_trace_target["run_id"] = run_id
            self._automatic_trace_baseline = dict(baseline)
            self._automatic_trace_candidates = ready
            self._automatic_trace_candidate_position = 0
            self._automatic_trace_matches = 0
            self._cancel_screen_learning_bursts()
            self.integrated_panel.set_learning_status(
                f"Learning guide: verifying {target_name} automatically across "
                f"{len(ready)} reversible candidate trace(s)."
            )
            self._capture_automatic_trace_baseline()
            return

    def _capture_automatic_trace_baseline(self) -> None:
        session_id = str((self._active_session or {}).get("session_id") or "")

        def capture() -> dict[str, Any]:
            try:
                return self.controller.estimate_health_bars(session_id, limit=8)
            except Exception as exc:  # noqa: BLE001 - no trace write has occurred
                return {"capture_status": "unavailable", "message": str(exc)}

        self._run_background(
            capture,
            self._automatic_trace_baseline_captured,
            lock_buttons=False,
        )

    def _automatic_trace_baseline_captured(self, result: dict[str, Any]) -> None:
        target = self._automatic_trace_target or {}
        expected = self._automatic_trace_baseline or {}
        current = _find_screen_value(result, str(target.get("name") or ""), expected)
        if (
            str(result.get("capture_status") or "captured") != "captured"
            or current is None
            or not _values_match(current.get("scan_value"), expected.get("value"))
        ):
            self._finish_automatic_trace(
                "Automatic trace paused before writing because the visible baseline moved."
            )
            return
        self._automatic_trace_baseline = {
            **expected,
            **current,
            "value": current.get("scan_value"),
        }
        self._prepare_next_automatic_trace_candidate()

    def _prepare_next_automatic_trace_candidate(self) -> None:
        if self._automatic_trace_candidate_position >= len(self._automatic_trace_candidates):
            total = len(self._automatic_trace_candidates)
            self._finish_automatic_trace(
                f"Automatic trace restored all {total} test change(s) and verified "
                f"{self._automatic_trace_matches} matching candidate(s)."
            )
            return
        target = self._automatic_trace_target or {}
        baseline = self._automatic_trace_baseline or {}
        position = self._automatic_trace_candidate_position
        candidate_id = self._automatic_trace_candidates[position]
        original = baseline.get("value")
        try:
            test_value = _automatic_trace_value(
                str(target.get("value_type") or "i32"),
                original,
                position,
            )
        except ValueError as exc:
            self._finish_automatic_trace(f"Automatic trace stopped before writing: {exc}")
            return
        target["test_value"] = test_value
        target["candidate_id"] = candidate_id

        def prepare() -> dict[str, Any]:
            try:
                return self.controller.prepare_discovery_candidate_test(
                    str(target.get("run_id") or ""),
                    str(target.get("name") or ""),
                    candidate_id,
                    test_value,
                )
            except Exception as exc:  # noqa: BLE001 - preparation performs no write
                return {"error": str(exc)}

        self._run_background(
            prepare,
            self._automatic_trace_candidate_prepared,
            lock_buttons=False,
        )

    def _automatic_trace_candidate_prepared(self, prepared: dict[str, Any]) -> None:
        if prepared.get("error"):
            self._finish_automatic_trace(
                f"Automatic trace stopped before writing: {prepared['error']}"
            )
            return
        intent_id = str(prepared.get("intent_id") or "")
        if not intent_id:
            self._finish_automatic_trace("Automatic trace could not prepare the next candidate.")
            return
        self._automatic_trace_intent_id = intent_id

        def apply() -> dict[str, Any]:
            try:
                return self.controller.apply_prepared_write(intent_id)
            except Exception as exc:  # noqa: BLE001 - backend compare/readback remains authoritative
                return {"error": str(exc)}

        self._run_background(
            apply,
            self._automatic_trace_candidate_applied,
            lock_buttons=False,
        )

    def _automatic_trace_candidate_applied(self, result: dict[str, Any]) -> None:
        if result.get("error"):
            self._finish_automatic_trace(f"Automatic trace write stopped: {result['error']}")
            return
        self.root.after(AUTO_TRACE_OBSERVATION_MS, self._capture_automatic_trace_result)

    def _capture_automatic_trace_result(self) -> None:
        session_id = str((self._active_session or {}).get("session_id") or "")

        def capture() -> dict[str, Any]:
            try:
                return self.controller.estimate_health_bars(session_id, limit=8)
            except Exception as exc:  # noqa: BLE001 - finalizer will restore the test value
                return {"capture_status": "unavailable", "message": str(exc)}

        self._run_background(
            capture,
            self._automatic_trace_result_captured,
            lock_buttons=False,
        )

    def _automatic_trace_result_captured(self, result: dict[str, Any]) -> None:
        target = self._automatic_trace_target or {}
        baseline = self._automatic_trace_baseline or {}
        observed = _find_screen_value(result, str(target.get("name") or ""), baseline)
        matched = bool(
            str(result.get("capture_status") or "captured") == "captured"
            and observed is not None
            and _values_match(observed.get("scan_value"), target.get("test_value"))
        )
        intent_id = self._automatic_trace_intent_id or ""

        def finalize() -> dict[str, Any]:
            try:
                return self.controller.finalize_discovery_candidate_test(
                    intent_id,
                    matched,
                    restore_after_test=True,
                    verification_source="screen",
                )
            except Exception as exc:  # noqa: BLE001 - make any restore uncertainty visible
                return {"error": str(exc)}

        self._run_background(
            finalize,
            self._automatic_trace_candidate_finalized,
            lock_buttons=False,
        )

    def _automatic_trace_candidate_finalized(self, result: dict[str, Any]) -> None:
        if result.get("error"):
            self._finish_automatic_trace(
                f"Automatic trace restore needs attention: {result['error']}"
            )
            return
        if bool(result.get("matched_in_game")):
            self._automatic_trace_matches += 1
        self._automatic_trace_intent_id = None
        self._automatic_trace_candidate_position += 1
        status = result.get("status") or {}
        if status:
            self._render_discovery_status(status)
        if self._automatic_trace_candidate_position < len(self._automatic_trace_candidates):
            self._capture_automatic_trace_baseline()
        else:
            self._prepare_next_automatic_trace_candidate()

    def _finish_automatic_trace(self, message: str) -> None:
        self._reset_automatic_trace_state()
        self.integrated_panel.set_learning_status(f"Learning guide: {message}")
        if self._active_session is not None and self._discovery_run_id:
            self._start_screen_learning_bursts()

    def _reset_automatic_trace_state(self) -> None:
        self._automatic_trace_busy = False
        self._automatic_trace_target = None
        self._automatic_trace_baseline = None
        self._automatic_trace_candidates = []
        self._automatic_trace_candidate_position = 0
        self._automatic_trace_matches = 0
        self._automatic_trace_intent_id = None

    def _set_discovery_visible_value(self) -> None:
        if (
            not self._discovery_run_id
            or self._discovery_target_var is None
            or self._discovery_value_var is None
        ):
            return
        raw = self._discovery_value_var.get().strip().replace(",", "")
        try:
            decimal_value = any(token in raw for token in (".", "e", "E"))
            value: int | float = float(raw) if decimal_value else int(raw)
        except ValueError:
            if self._discovery_status_var is not None:
                self._discovery_status_var.set("Enter a number exactly as the game displays it.")
            return
        run_id = self._discovery_run_id
        target = self._discovery_target_var.get()
        self._run_background(
            lambda: self.controller.set_autonomous_discovery_value(run_id, target, value),
            self._discovery_value_saved,
            lock_buttons=False,
        )

    def _discovery_value_saved(self, status: dict[str, Any]) -> None:
        if self._discovery_value_var is not None:
            self._discovery_value_var.set("")
        self._render_discovery_status(status)
        self._schedule_discovery_poll()

    def _capture_discovery_behavior(self, phase: str) -> None:
        if not self._discovery_run_id or self._discovery_behavior_target_var is None:
            return
        run_id = self._discovery_run_id
        target = self._discovery_behavior_target_var.get()
        label = BEHAVIOR_ACTION_LABELS.get(target, target)
        if self._discovery_status_var is not None:
            self._discovery_status_var.set(
                "Building a resting baseline..."
                if phase == "begin"
                else "Comparing the labeled action window..."
            )
        self._run_background(
            lambda: self.controller.capture_autonomous_discovery_behavior(
                run_id,
                target,
                phase,
                label,
            ),
            self._discovery_behavior_saved,
            lock_buttons=False,
        )

    def _discovery_behavior_saved(self, status: dict[str, Any]) -> None:
        self._render_discovery_status(status)
        self._schedule_discovery_poll()

    def _stop_cheat_learning(self) -> None:
        if not self._discovery_run_id:
            return
        run_id = self._discovery_run_id
        self._run_background(
            lambda: self.controller.stop_autonomous_discovery(run_id),
            self._cheat_learning_stopped,
            lock_buttons=False,
        )

    def _cheat_learning_stopped(self, status: dict[str, Any]) -> None:
        self._render_discovery_status(status)
        self.message_var.set("Cheat-learning progress was saved to this game's table.")

    def _detach_selected(self) -> None:
        if self._active_session is None:
            return
        session_id = str(self._active_session["session_id"])
        self.message_var.set("Detaching...")
        self._run_background(
            lambda: self.controller.detach_session(session_id),
            self._detach_finished,
        )

    def _detach_finished(self, _result: dict[str, Any]) -> None:
        self._cancel_mount_progress()
        self._cancel_background_catalog_refresh()
        self._cancel_screen_learning_bursts()
        self._reset_automatic_trace_state()
        self.integrated_panel.clear_screen_observations()
        self._discovery_run_id = None
        self._active_session = None
        self.session_var.set("Not attached")
        self.detach_button.configure(state="disabled")
        self.export_button.configure(state="disabled")
        self.learn_button.configure(state="disabled")
        self.table_combo.configure(state="readonly")
        self._game_selected()
        self.message_var.set("Detached safely.")

    def _reconcile_active_session(self, processes: list) -> None:
        active = self._active_session
        if active is None:
            return
        matching = next((item for item in processes if item.pid == active["pid"]), None)
        active_started = active.get("process_started_at")
        same_incarnation = matching is not None and (
            active_started is None
            or matching.started_at is None
            or _start_times_match(active_started, matching.started_at)
        )
        if same_incarnation:
            return

        restarted = next(
            (
                row
                for row in self._process_rows
                if row.state is ProcessState.RESTARTED and row.previous_pid == active["pid"]
            ),
            None,
        )
        self._cancel_mount_progress()
        self._cancel_background_catalog_refresh()
        self._reset_automatic_trace_state()
        self._active_session = None
        self.detach_button.configure(state="disabled")
        self.export_button.configure(state="disabled")
        self.learn_button.configure(state="disabled")
        self.table_combo.configure(state="readonly")
        if restarted:
            self.session_var.set(
                f"{active['process_name']} restarted as PID {restarted.process.pid}; "
                "click the new row to reattach."
            )
        else:
            self.session_var.set(
                f"{active['process_name']} (PID {active['pid']}) disappeared; detached safely."
            )
        threading.Thread(
            target=self._detach_stale_session,
            args=(str(active["session_id"]),),
            daemon=True,
        ).start()

    def _detach_stale_session(self, session_id: str) -> None:
        try:
            self.controller.detach_session(session_id)
        except Exception:
            pass

    @staticmethod
    def _row_identity(row: ProcessRow | None) -> tuple | None:
        if row is None:
            return None
        # PID is stable for a running incarnation and lets the selection survive
        # small timestamp-estimation changes in live Windows performance counters.
        return (row.process.pid,)

    def _write_mode_changed(self) -> None:
        from tkinter import messagebox

        if not self.write_var.get():
            self.mode_var.set("Mode: Read-only")
            self._refresh_attach_mode_text()
            return
        if not self._selected_process_name():
            messagebox.showwarning(
                "Choose an offline game",
                "Select a running offline game before enabling value editing.",
                parent=self.root,
            )
            self.write_var.set(False)
            self._refresh_attach_mode_text()
            return
        self.mode_var.set(
            "Mode: Value editing enabled" if self.write_var.get() else "Mode: Read-only"
        )
        self._refresh_attach_mode_text()

    def _refresh_attach_mode_text(self) -> None:
        if self.write_var.get():
            self.mode_badge.configure(text="●  VALUE EDITING")
            self.attach_mode_hint_var.set(
                "Value editing is enabled for the selected offline game; Apply writes now."
            )
            self.attach_button.configure(text="Attach with full value writes")
            return
        self.mode_badge.configure(text="●  READ ONLY")
        self.attach_mode_hint_var.set(
            "Read-only attachment. Controlled writes require the separate checkbox below."
        )
        self.attach_button.configure(text="Attach read-only")

    def _sync_config_from_controls(self) -> None:
        self.config.game_process = self._selected_process_name()
        self.config.allow_writes = bool(self.write_var.get())
        self.config.validate()

    def _start(self) -> None:
        from tkinter import messagebox

        try:
            self._sync_config_from_controls()
        except ValueError as exc:
            messagebox.showwarning("Cannot start", str(exc), parent=self.root)
            return
        self.message_var.set("Starting the private companion...")
        self._run_background(self.controller.start, self._start_finished)

    def _start_finished(self, status: CompanionStatus) -> None:
        self._apply_status(status)
        self.message_var.set("Ready. In ChatGPT, mention @GTP Games.")

    def _stop(self) -> None:
        from tkinter import messagebox

        approved = messagebox.askyesno(
            "Stop GTP Games?",
            "This disconnects ChatGPT and closes every GTP Games process session.",
            parent=self.root,
        )
        if not approved:
            return
        self.message_var.set("Stopping GTP Games...")
        self._run_background(self.controller.stop, self._stop_finished)

    def _stop_finished(self, status: CompanionStatus) -> None:
        self._cancel_background_catalog_refresh()
        self._cancel_screen_learning_bursts()
        self.integrated_panel.clear_screen_observations()
        self._discovery_run_id = None
        self._active_session = None
        self.session_var.set("Not attached")
        self.detach_button.configure(state="disabled")
        self.export_button.configure(state="disabled")
        self.learn_button.configure(state="disabled")
        self.table_combo.configure(state="readonly")
        self._apply_status(status)
        self.message_var.set("Stopped safely.")

    def _poll_status(self) -> None:
        if not self._status_busy and not self._busy:
            self._status_busy = True

            def worker() -> None:
                try:
                    status = self.controller.status()
                    self._post_ui(lambda: self._status_finished(status))
                except Exception as exc:  # noqa: BLE001 - convert background failures to UI text
                    self._post_ui(
                        lambda error=exc: self._background_error(error, status_only=True),
                    )

            threading.Thread(target=worker, daemon=True).start()
        self.root.after(1800, self._poll_status)

    def _status_finished(self, status: CompanionStatus) -> None:
        self._status_busy = False
        self._apply_status(status)

    def _apply_status(self, status: CompanionStatus) -> None:
        self.status_var.set(status.detail)
        self.companion_var.set(
            f"Companion: Running (PID {status.companion_pid})"
            if status.companion_running
            else "Companion: Stopped"
        )
        self.tunnel_var.set(
            "ChatGPT connection: Ready"
            if status.tunnel_ready
            else (
                "ChatGPT connection: Starting"
                if status.tunnel_running
                else "ChatGPT connection: Offline"
            )
        )
        self.mode_var.set(
            "Mode: Value editing enabled" if status.writes_enabled else "Mode: Read-only"
        )
        self.scan_var.set(
            _format_scan_activity(status.scan_activity)
            if self._active_session is not None
            else "Scan: waiting for a running game"
        )
        if not status.companion_running and self._active_session is not None:
            self._cancel_background_catalog_refresh()
            self._cancel_screen_learning_bursts()
            self.integrated_panel.clear_screen_observations()
            self._discovery_run_id = None
            self._active_session = None
            self.session_var.set("Companion stopped; no process is attached.")
            self.detach_button.configure(state="disabled")
            self.export_button.configure(state="disabled")
            self.learn_button.configure(state="disabled")
            self.table_combo.configure(state="readonly")

    def _run_background(
        self,
        work: Callable,
        on_success: Callable,
        *,
        lock_buttons: bool = True,
    ) -> None:
        if lock_buttons and self._busy:
            return
        if lock_buttons:
            self._busy = True
            self._set_buttons_enabled(False)

        def worker() -> None:
            try:
                result = work()
                self._post_ui(lambda: finish(result))
            except Exception as exc:  # noqa: BLE001 - convert background failures to UI text
                self._post_ui(lambda error=exc: self._background_error(error))

        def finish(result) -> None:
            try:
                if lock_buttons:
                    self._busy = False
                    self._set_buttons_enabled(True)
                on_success(result)
            except Exception as exc:  # noqa: BLE001 - keep the window alive and log UI faults
                self._background_error(exc)

        threading.Thread(target=worker, daemon=True).start()

    def _post_ui(self, callback: Callable[[], None]) -> None:
        """Queue a UI callback without entering Tcl from a worker thread."""

        self._ui_callbacks.put(callback)

    def _drain_ui_callbacks(self) -> None:
        """Run completed worker callbacks only from Tk's owning thread."""

        for _ in range(100):
            try:
                callback = self._ui_callbacks.get_nowait()
            except queue.Empty:
                break
            try:
                callback()
            except Exception:  # noqa: BLE001 - route through Tk's configured crash boundary
                error_type, error, error_traceback = sys.exc_info()
                if error_type is not None and error is not None:
                    self._report_callback_exception(
                        error_type,
                        error,
                        error_traceback,
                    )
        self.root.after(50, self._drain_ui_callbacks)

    def _background_error(self, error: Exception, *, status_only: bool = False) -> None:
        from tkinter import messagebox

        self._busy = False
        self._status_busy = False
        if self._active_session is None:
            self._auto_mount_in_progress = False
        if self._mount_started_at is not None and self._active_session is None:
            self._cancel_mount_progress()
        self._set_buttons_enabled(True)
        self.message_var.set(str(error))
        self._append_error_log("Background operation failed", error)
        if not status_only:
            messagebox.showerror("GTP Games", str(error), parent=self.root)

    def _report_callback_exception(self, error_type, error, error_traceback) -> None:
        from tkinter import messagebox

        rendered = "".join(traceback.format_exception(error_type, error, error_traceback))
        self._append_error_log("Windows callback failed", error, rendered=rendered)
        try:
            self._busy = False
            self._cancel_process_refresh_timers()
            self._process_refresh_generation += 1
            self._process_refresh_busy = False
            self._process_refresh_started_at = None
            self.refresh_button.configure(state="normal", text="Refresh games")
            self._set_buttons_enabled(True)
            self.message_var.set(
                "Refresh could not finish. The window was kept open and details were logged."
            )
            messagebox.showerror(
                "GTP Games refresh error",
                (
                    "GTP Games kept the window open after a refresh error. Details were "
                    "saved to:\n\n"
                    f"{self.config_path.parent / 'companion-errors.log'}"
                ),
                parent=self.root,
            )
        except Exception:
            pass

    def _append_error_log(
        self,
        heading: str,
        error: Exception,
        *,
        rendered: str | None = None,
    ) -> None:
        path = self.config_path.parent / "companion-errors.log"
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            with path.open("a", encoding="utf-8") as stream:
                stream.write(f"[{datetime.now(UTC).isoformat()}] {heading}: {error}\n")
                if rendered:
                    stream.write(rendered)
                stream.write("\n")
        except OSError:
            pass

    def _set_buttons_enabled(self, enabled: bool) -> None:
        state = "normal" if enabled else "disabled"
        self.start_button.configure(state=state)
        self.stop_button.configure(state=state)
        if enabled:
            self._process_selected()
            self.detach_button.configure(
                state="normal" if self._active_session is not None else "disabled"
            )
            self.export_button.configure(
                state="normal" if self._active_session is not None else "disabled"
            )
            self.learn_button.configure(
                state="normal" if self._active_session is not None else "disabled"
            )
            self.table_combo.configure(
                state="disabled" if self._active_session is not None else "readonly"
            )
            self._game_selected()
        else:
            self.attach_button.configure(state="disabled")
            self.detach_button.configure(state="disabled")
            self.export_button.configure(state="disabled")
            self.learn_button.configure(state="disabled")
            self.launch_game_button.configure(state="disabled")

    def _open_connection_settings(self) -> None:
        from tkinter import filedialog, messagebox

        window = self.tk.Toplevel(self.root)
        window.title("GTP Games connection settings")
        window.geometry("650x440")
        window.transient(self.root)
        window.grab_set()

        frame = self.ttk.Frame(window, padding=20)
        frame.pack(fill="both", expand=True)
        self.ttk.Label(
            frame,
            text="Private connection settings",
            style="Heading.TLabel",
        ).grid(row=0, column=0, columnspan=3, sticky="w", pady=(0, 12))

        fields = [
            ("Tunnel client program", "tunnel_client_path"),
            ("Tunnel profile folder", "tunnel_profile_dir"),
            ("Profile name", "tunnel_profile"),
            ("Connection name", "tunnel_alias"),
            ("Tunnel ID", "tunnel_id"),
            ("OpenAI organization ID", "organization_id"),
        ]
        variables: dict[str, object] = {}
        for row, (label, attribute) in enumerate(fields, start=1):
            variable = self.tk.StringVar(value=getattr(self.config, attribute))
            variables[attribute] = variable
            self.ttk.Label(frame, text=label).grid(row=row, column=0, sticky="w", pady=5)
            self.ttk.Entry(frame, textvariable=variable, width=58).grid(
                row=row, column=1, sticky="ew", padx=(10, 6), pady=5
            )

        def choose_program() -> None:
            path = filedialog.askopenfilename(
                parent=window,
                title="Choose tunnel-client.exe",
                filetypes=[("Tunnel client", "tunnel-client.exe"), ("Programs", "*.exe")],
            )
            if path:
                variables["tunnel_client_path"].set(path)

        def choose_profile_dir() -> None:
            path = filedialog.askdirectory(parent=window, title="Choose tunnel profile folder")
            if path:
                variables["tunnel_profile_dir"].set(path)

        self.ttk.Button(frame, text="Browse", command=choose_program).grid(row=1, column=2, pady=5)
        self.ttk.Button(frame, text="Browse", command=choose_profile_dir).grid(
            row=2, column=2, pady=5
        )
        frame.columnconfigure(1, weight=1)

        def save() -> None:
            for attribute, variable in variables.items():
                setattr(self.config, attribute, variable.get().strip())
            try:
                self.controller.save()
            except (OSError, ValueError) as exc:
                messagebox.showerror("Could not save", str(exc), parent=window)
                return
            window.destroy()
            self.message_var.set("Connection settings saved.")

        buttons = self.ttk.Frame(frame)
        buttons.grid(row=len(fields) + 1, column=0, columnspan=3, sticky="e", pady=(18, 0))
        self.ttk.Button(buttons, text="Cancel", command=window.destroy).pack(side="right")
        self.ttk.Button(buttons, text="Save", command=save).pack(side="right", padx=(0, 8))


def _format_memory(memory_bytes: int | None) -> str:
    if memory_bytes is None:
        return "Unavailable"
    memory_mb = memory_bytes / (1024 * 1024)
    if memory_mb >= 1024:
        return f"{memory_mb / 1024:.1f} GB"
    return f"{memory_mb:.0f} MB"


def _format_scan_activity(activity: dict[str, Any] | None) -> str:
    if not activity:
        return "Scan: idle"
    state = str(activity.get("state") or "idle")
    operation = str(activity.get("operation") or "Memory scan")
    candidates = int(activity.get("result_count") or 0)
    if state == "loading":
        processed = int(activity.get("processed_bytes") or 0)
        total = int(activity.get("total_bytes") or 0)
        completed_regions = int(activity.get("processed_regions") or 0)
        total_regions = int(activity.get("total_regions") or 0)
        percent = min(100.0, (processed / total * 100.0) if total else 0.0)
        return (
            f"Scan: loading {percent:.0f}% — {operation} — "
            f"{completed_regions}/{total_regions} regions — "
            f"{_format_memory(processed)} / {_format_memory(total)} — "
            f"{candidates:,} candidates; caching"
        )
    if state == "completed":
        cached = " — cached" if activity.get("cache_backed") else ""
        return f"Scan: ready — {operation} — {candidates:,} candidates{cached}"
    if state == "failed":
        return f"Scan: failed — {activity.get('error') or operation}"
    return f"Scan: {state} — {operation}"


def _format_last_played(game: DiscoveredGame) -> str:
    if game.running_pids:
        return "Now"
    if game.last_played_at is None:
        return "Not recorded"
    return game.last_played_at.astimezone().strftime("%b %d, %Y %I:%M %p")


def _short_build_identity(identity: str | None) -> str:
    if not identity:
        return "unknown"
    digest = identity.rsplit(":", 1)[-1]
    return digest[:10]


def _start_times_match(first: float, second: float) -> bool:
    """Allow for small timestamp estimation jitter in Windows counters."""

    return abs(first - second) < PROCESS_START_TOLERANCE_SECONDS


def _find_auto_mount_process(
    game: DiscoveredGame,
    rows: list[ProcessRow],
) -> ProcessRow | None:
    """Choose only a live, attachable process already matched to the launched game."""

    return next(
        (
            row
            for row in rows
            if row.process.pid in game.running_pids
            and row.process.attachable
            and row.state is not ProcessState.DISAPPEARED
        ),
        None,
    )


def _select_safe_auto_mount_process(
    rows: list[ProcessRow],
    *,
    configured_process: str,
) -> ProcessRow | None:
    """Select only one unambiguous configured or sole likely running game."""

    available = [
        row
        for row in rows
        if row.process.attachable
        and row.process.likely_game
        and row.state is not ProcessState.DISAPPEARED
    ]
    configured = {
        name.strip().casefold()
        for name in configured_process.split(",")
        if name.strip()
    }
    preferred = [row for row in available if row.process.name.casefold() in configured]
    if len(preferred) == 1:
        return preferred[0]
    if not preferred and len(available) == 1:
        return available[0]
    return None


def _promote_mountable_game_processes(
    processes: list,
    library: GameLibrarySnapshot,
    *,
    configured_process: str = "",
) -> list:
    """Keep known running games visible when live GPU/RAM samples are unavailable."""

    catalog_pids = {pid for game in library.games for pid in game.running_pids}
    configured_name = configured_process.strip().casefold()
    promoted = []
    for process in processes:
        catalog_match = process.pid in catalog_pids
        configured_match = bool(configured_name and process.name.casefold() == configured_name)
        if process.attachable and (catalog_match or configured_match):
            reason = (
                "matched installed/running game" if catalog_match else "selected game executable"
            )
            reasons = list(dict.fromkeys([*process.game_reasons, reason]))
            process = process.model_copy(
                update={
                    "likely_game": True,
                    "game_score": max(70, process.game_score),
                    "game_reasons": reasons,
                }
            )
        promoted.append(process)
    return promoted


def configure_windows_dpi_awareness() -> bool:
    if sys.platform != "win32":
        return False
    try:
        import ctypes

        user32 = ctypes.windll.user32
        if user32.SetProcessDpiAwarenessContext(ctypes.c_void_p(-4)):
            return True
    except (AttributeError, OSError):
        pass
    try:
        import ctypes

        ctypes.windll.shcore.SetProcessDpiAwareness(2)
        return True
    except (AttributeError, OSError):
        return False


def run_desktop(config_path: Path | None = None) -> None:
    if sys.platform != "win32":
        raise SystemExit("The GTP Games desktop companion requires Windows.")
    configure_windows_dpi_awareness()
    import tkinter as tk

    root = tk.Tk()
    CompanionApp(root, config_path=config_path)
    root.mainloop()


def smoke_desktop_layout(config_path: Path | None = None) -> dict[str, Any]:
    if sys.platform != "win32":
        raise SystemExit("The GTP Games desktop companion requires Windows.")
    configure_windows_dpi_awareness()
    import tkinter as tk

    root = tk.Tk()
    root.withdraw()
    try:
        app = CompanionApp(root, config_path=config_path, start_workers=False)
        app._active_session = {
            "session_id": "ui-smoke-session",
            "process_name": "SmokeGame.exe",
            "pid": 0,
            "write_enabled": True,
        }
        app.integrated_panel.update_catalog(
            {
                "id": "ui-smoke-catalog",
                "session_id": "ui-smoke-session",
                "process_name": "SmokeGame.exe",
                "game_key": "ui-smoke-game",
                "status": "ready",
                "features": [
                    {
                        "id": "ui-smoke-health",
                        "name": "Health",
                        "description": "Synthetic live quick-edit candidate",
                        "status": "locked_read_only",
                        "source_kind": "mounted_game_value_table",
                        "current_value": 80,
                        "confidence": 0.9,
                        "discovery_run_id": "ui-smoke-run",
                        "discovery_candidate_ids": ["ui-smoke-candidate"],
                    }
                ],
            },
            write_enabled=True,
        )
        app.integrated_panel.capability_tree.selection_set("capability-0")
        app.integrated_panel._selection_changed()
        app.integrated_panel.update_catalog(
            {
                "id": "ui-smoke-catalog",
                "session_id": "ui-smoke-session",
                "process_name": "SmokeGame.exe",
                "game_key": "ui-smoke-game",
                "status": "ready",
                "features": [
                    {
                        "id": "ui-smoke-health",
                        "name": "Health",
                        "description": "Synthetic live quick-edit candidate",
                        "status": "locked_read_only",
                        "source_kind": "mounted_game_value_table",
                        "current_value": 80,
                        "confidence": 0.9,
                        "discovery_run_id": "ui-smoke-run",
                        "discovery_candidate_ids": ["ui-smoke-candidate"],
                    }
                ],
            },
            write_enabled=True,
        )
        app.integrated_panel.state.overlay_visible = True
        app.integrated_panel.render_overlay()
        root.update_idletasks()
        overlay_text = " ".join(
            str(child.cget("text"))
            for child in app.integrated_panel.overlay_frame.winfo_children()
            if "text" in child.keys()
        )
        refreshed_values = app.integrated_panel.capability_tree.item(
            "capability-0", "values"
        )
        modes: list[str] = []
        compact_editor_before_results = False
        compact_secondary_actions_visible = False
        compact_sections_visible = False
        for width, height in ((560, 480), (1000, 700), (1500, 1000)):
            policy = responsive_layout(width, height, dpi_scale=1.0)
            app._apply_layout_policy(policy)
            modes.append(app._last_layout_mode)
            if policy.mode == "compact":
                packed = app.integrated_panel.capability_tree_frame.master.pack_slaves()
                detail = app.integrated_panel.capability_detail_frame
                results = app.integrated_panel.capability_tree_frame
                compact_editor_before_results = (
                    detail in packed
                    and results in packed
                    and packed.index(detail) < packed.index(results)
                    and bool(app.integrated_panel.capability_editor_frame.winfo_manager())
                )
                compact_secondary_actions_visible = bool(
                    app.integrated_panel.capability_actions_frame.winfo_manager()
                )
                compact_sections_visible = all(
                    bool(widget.winfo_manager())
                    for widget in (
                        app.integrated_panel.hunt_help_label,
                        app.integrated_panel.quick_section,
                        app.integrated_panel.capability_detail_label,
                        app.integrated_panel.capability_actions_frame,
                        app.integrated_panel.capability_page_scrollbar,
                    )
                )
        return {
            "ui": "ready",
            "primary_surface": "compact-controls",
            "advanced_default": app._advanced_visible,
            "advanced_pages": len(app.main_notebook.tabs()) - 1,
            "running_game_picker": hasattr(app, "compact_game_combo"),
            "direct_target_picker": hasattr(app.integrated_panel, "hunt_target_combo"),
            "multi_use_input": hasattr(app.integrated_panel, "command_var"),
            "capability_rows": hasattr(app.integrated_panel, "capability_tree"),
            "inline_value_editor": hasattr(app.integrated_panel, "edit_value_entry"),
            "game_overlay_button": hasattr(app.integrated_panel, "overlay_button"),
            "global_overlay_hotkey": app.integrated_panel.state.overlay_hotkey == "<F8>",
            "read_only_overlay_window": (
                app.integrated_panel.overlay_window is not None
                and "LEARNING OVERLAY" in overlay_text
            ),
            "overlay_learning_controls": (
                "AUTO LEARNING ON" in overlay_text and "Ctrl+F11 rescan" in overlay_text
            ),
            "overlay_topmost": overlay_is_topmost(
                int(app.integrated_panel.overlay_window.winfo_id())
            ),
            "inventory_learning_buttons": all(
                hasattr(app.integrated_panel, name)
                for name in (
                    "inventory_observe_button",
                    "inventory_changed_button",
                    "inventory_matrix_button",
                    "rescan_values_button",
                    "inventory_guide_button",
                )
            ),
            "inventory_learning_hotkeys": app.integrated_panel.learning_hotkeys
            == {
                "baseline": "<F9>",
                "changed": "<F10>",
                "rescan": "<Control-F11>",
            },
            "overlay_auto_rows": [
                row.name for row in app.integrated_panel._overlay_rows()
            ],
            "capability_refresh_rows": len(app.integrated_panel.rows),
            "capability_refresh_action": refreshed_values[3],
            "quick_edit_button_label": app.integrated_panel.edit_value_button.cget("text"),
            "quick_edit_button_enabled": (
                str(app.integrated_panel.edit_value_button.cget("state")) == "normal"
            ),
            "default_window_width": root.winfo_width(),
            "default_window_height": root.winfo_height(),
            "value_workspace_rows": int(app.integrated_panel.capability_tree.cget("height")),
            "selection_survives_refresh": (
                app.integrated_panel.capability_tree.selection() == ("capability-0",)
            ),
            "compact_editor_before_results": compact_editor_before_results,
            "compact_secondary_actions_visible": compact_secondary_actions_visible,
            "compact_sections_visible": compact_sections_visible,
            "layout_modes": modes,
            "dpi_awareness_requested": True,
            "screen_learning_interval_ms": SCREEN_LEARNING_INTERVAL_MS,
            "screen_learning_burst_samples": SCREEN_LEARNING_BURST_SAMPLES,
            "screen_learning_rest_ms": SCREEN_LEARNING_REST_MS,
            "screen_learning_uses_temporal_direction": True,
            "memory_write_performed": False,
        }
    finally:
        root.destroy()


def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(description="GTP Games Windows companion")
    parser.add_argument("--serve", action="store_true", help=argparse.SUPPRESS)
    parser.add_argument("--ui-smoke", action="store_true", help=argparse.SUPPRESS)
    parser.add_argument("--inventory-ocr-smoke", type=Path, help=argparse.SUPPRESS)
    parser.add_argument("--smoke-output", type=Path, help=argparse.SUPPRESS)
    parser.add_argument("--config", type=Path, help="launcher configuration path")
    args = parser.parse_args(argv)
    if args.inventory_ocr_smoke is not None:
        from gtp_games.inventory_capture import smoke_inventory_image

        payload = json.dumps(smoke_inventory_image(args.inventory_ocr_smoke), sort_keys=True)
        if args.smoke_output is not None:
            args.smoke_output.parent.mkdir(parents=True, exist_ok=True)
            args.smoke_output.write_text(payload, encoding="utf-8")
        else:
            print(payload)
        return
    if args.serve:
        from gtp_games.mcp_server import run

        run()
        return
    if args.ui_smoke:
        payload = json.dumps(smoke_desktop_layout(args.config), sort_keys=True)
        if args.smoke_output is not None:
            args.smoke_output.parent.mkdir(parents=True, exist_ok=True)
            args.smoke_output.write_text(payload, encoding="utf-8")
        else:
            print(payload)
        return
    run_desktop(args.config)


if __name__ == "__main__":
    main()
