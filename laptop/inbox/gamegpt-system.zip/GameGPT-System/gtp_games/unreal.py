from __future__ import annotations

import bisect
import ctypes
import heapq
import math
import re
import struct
import sys
import time
from collections.abc import Iterable
from dataclasses import dataclass, field
from datetime import UTC, datetime
from threading import Event, RLock, Thread
from uuid import uuid4

from gtp_games.codec import decode_value, value_size, values_equal
from gtp_games.config import Settings
from gtp_games.errors import BackendError, NotFoundError, ScanLimitError
from gtp_games.game_identity import executable_build_identity
from gtp_games.game_tables import (
    register_confirmed_profile,
    register_profile_monitor_ledger,
)
from gtp_games.memory.base import MemoryBackend
from gtp_games.models import (
    Comparison,
    GameProfileCandidate,
    GameProfileMonitorStatus,
    MemoryRegion,
    MemoryRegionKind,
    ProcessSession,
    UnrealDiscoveryResult,
    UnrealGasCandidate,
    UnrealGasCandidateGroup,
    UnrealGasMonitorStatus,
    UnrealGasProfile,
    UnrealGasProfileValue,
    UnrealGasScanSummary,
    UnrealGasTemporalCandidate,
    UnrealGasTemporalResult,
    UnrealGasWatchResult,
    UnrealGasWatchSample,
    UnrealGlobalCandidate,
    ValueType,
)


@dataclass(frozen=True)
class _Pattern:
    name: str
    text: str
    instruction_offset: int = 0
    displacement_offset: int = 3
    instruction_size: int = 7
    priority: int = 100

    def compile(self) -> tuple[bytes, bytes, bytes, int]:
        values: list[int] = []
        mask: list[int] = []
        for token in self.text.split():
            if token == "??":
                values.append(0)
                mask.append(0)
            else:
                values.append(int(token, 16))
                mask.append(0xFF)
        best_start = 0
        best_length = 0
        current_start = 0
        current_length = 0
        for index, fixed in enumerate(mask + [0]):
            if fixed:
                if current_length == 0:
                    current_start = index
                current_length += 1
            else:
                if current_length > best_length:
                    best_start, best_length = current_start, current_length
                current_length = 0
        return (
            bytes(values),
            bytes(mask),
            bytes(values[best_start : best_start + best_length]),
            best_start,
        )


# Conservative read-site signatures derived from public Unreal Engine x64 code shapes.
# Names match the MIT-licensed UE5CEDumper signature catalogue for auditability, but
# GTP performs its own external ReadProcessMemory scan and never loads or executes it.
_GWORLD_PATTERNS = (
    _Pattern(
        "GWLD_GH_3",
        "E8 ?? ?? ?? ?? 80 7C 24 ?? 00 75 ?? 48 8B 3D ?? ?? ?? ?? "
        "48 8B 5C 24 ?? 48 8B C7 48 8B 7C 24",
        instruction_offset=12,
        priority=10,
    ),
    _Pattern(
        "GWLD_GH_1",
        "89 7C 24 ?? 55 48 8B EC 48 83 EC ?? 48 8B 05 ?? ?? ?? ?? "
        "48 8B D9 48 8D 4D 10 48 8B 50 18 48",
        instruction_offset=12,
        priority=20,
    ),
    _Pattern(
        "GWLD_GH_2",
        "48 8B 40 30 48 85 C0 75 ?? 48 8B 05 ?? ?? ?? ?? C3 48 89 5C 24 10 56 48 83 EC 20 48",
        instruction_offset=9,
        priority=30,
    ),
    _Pattern(
        "GWLD_G427_1",
        "48 8B 1D ?? ?? ?? ?? 48 85 DB 74 ?? ?? ?? 01 33 D2 48 8B CB",
        priority=40,
    ),
    _Pattern(
        "GWLD_G427_2",
        "48 8B 3D ?? ?? ?? ?? 48 8B 5C 24 ?? 48 8B C7 48",
        priority=50,
    ),
    _Pattern(
        "GWLD_G427_3",
        "49 8B ?? ?? ?? ?? ?? 4C 8B C6 48 8B 05 ?? ?? ?? ?? 48 8B D7",
        instruction_offset=10,
        priority=60,
    ),
    _Pattern(
        "GWLD_G427_4",
        "48 8B ?? ?? ?? ?? ?? 4C 8B C6 48 8B 05 ?? ?? ?? ?? 48 8B D7",
        instruction_offset=10,
        priority=70,
    ),
    _Pattern(
        "GWLD_G42_3",
        "48 8B 40 30 48 85 C0 75 ?? 48 8B 05 ?? ?? ?? ?? C3",
        instruction_offset=9,
        priority=80,
    ),
    _Pattern(
        "GWLD_G42_2",
        "48 8B 1D ?? ?? ?? ?? 48 85 DB 74 ?? 41 B0 01",
        priority=90,
    ),
)


# FNamePool read-site shapes for UE4.23+ builds. These are a deliberately small,
# high-specificity subset of the public MIT-licensed UE5CEDumper catalogue. GTP scans
# them externally and only reads the resulting pool; it never calls game functions.
_GNAME_PATTERNS = (
    _Pattern(
        "GNAM_DI427_2",
        "48 8D 0D ?? ?? ?? ?? E8 ?? ?? ?? ?? ?? 8B ?? C6 05 ?? ?? ?? ?? 01 "
        "48 8B 44 24 ?? 48 C1 E8 20 03 C0 ?? 03 ?? ?? 10",
        priority=10,
    ),
    _Pattern(
        "GNAM_DI427_1",
        "48 8D 0D ?? ?? ?? ?? E8 ?? ?? ?? ?? ?? 8B ?? C6 05 ?? ?? ?? ?? 01 "
        "48 8B 44 24 ?? 48 C1 E8 20",
        priority=20,
    ),
    _Pattern(
        "GNAM_GH_1",
        "89 74 24 18 57 48 83 EC 20 C1 EA 03 48 8D 2D ?? ?? ?? ?? FF CA "
        "8B D9 48 BF CD CC CC CC CC CC",
        instruction_offset=12,
        priority=30,
    ),
    _Pattern(
        "GNAM_SAT425_2",
        "48 8D 05 ?? ?? ?? ?? 8B 40 08 FF C0 C1 E0 11 48 83 C4 28 C3",
        priority=40,
    ),
)


class _MemoryMap:
    def __init__(self, regions: list[MemoryRegion]) -> None:
        self.regions = sorted(regions, key=lambda item: item.base_address)
        self.bases = [item.base_address for item in self.regions]
        self.executable = [
            item
            for item in self.regions
            if item.committed and item.readable and item.executable and not item.guarded
        ]

    def region(self, address: int, size: int = 1) -> MemoryRegion | None:
        index = bisect.bisect_right(self.bases, address) - 1
        if index < 0:
            return None
        region = self.regions[index]
        return region if region.contains(address, size) else None

    def readable(self, address: int, size: int = 1) -> bool:
        region = self.region(address, size)
        return bool(region and region.committed and region.readable and not region.guarded)

    def executable_address(self, address: int) -> bool:
        region = self.region(address)
        return bool(region and region.executable and region.readable and not region.guarded)


@dataclass(frozen=True)
class _FNamePool:
    address: int
    module_offset: int
    pattern: str
    chunks_offset: int
    header_offset: int
    stride: int
    length_shift: int
    length_mask: int
    block_offset_bits: int = 16

    def read_name(
        self,
        backend: MemoryBackend,
        session: ProcessSession,
        comparison_index: int,
        number: int = 0,
    ) -> str:
        if comparison_index < 0:
            return ""
        block_index = comparison_index >> self.block_offset_bits
        block_mask = (1 << self.block_offset_bits) - 1
        block_offset = (comparison_index & block_mask) * self.stride
        try:
            block = struct.unpack(
                "<Q",
                backend.read(
                    session.backend_handle,
                    self.address + self.chunks_offset + block_index * 8,
                    8,
                ),
            )[0]
            if block < 0x10000:
                return ""
            entry = block + block_offset
            header = struct.unpack(
                "<H",
                backend.read(
                    session.backend_handle,
                    entry + self.header_offset,
                    2,
                ),
            )[0]
            length = (header >> self.length_shift) & self.length_mask
            if not 0 < length <= 256:
                return ""
            wide = bool(header & 1)
            raw = backend.read(
                session.backend_handle,
                entry + self.header_offset + 2,
                length * (2 if wide else 1),
            )
            value = raw.decode("utf-16-le" if wide else "utf-8", errors="strict")
        except (BackendError, UnicodeDecodeError, struct.error):
            return ""
        if not value or any(ord(character) < 0x20 for character in value):
            return ""
        return f"{value}_{number - 1}" if 0 < number < 1_000_000 else value


def _locate_fname_pool(
    backend: MemoryBackend,
    session: ProcessSession,
    settings: Settings,
    regions: list[MemoryRegion],
) -> _FNamePool | None:
    module_regions = [
        region for region in regions if region.main_module and region.kind is MemoryRegionKind.IMAGE
    ]
    if not module_regions:
        return None
    module_base = min(region.allocation_base or region.base_address for region in module_regions)
    code_regions = [
        region
        for region in module_regions
        if region.committed and region.readable and region.executable and not region.guarded
    ]
    compiled = [(pattern, *pattern.compile()) for pattern in _GNAME_PATTERNS]
    max_pattern = max(len(item[1]) for item in compiled)
    chunk_size = max(settings.scan_chunk_bytes, 64 * 1024)
    scanned_bytes = 0
    matches: dict[int, list[tuple[_Pattern, tuple[int, int, int, int, int]]]] = {}

    for region in code_regions:
        position = region.base_address
        while position < region.end_address:
            remaining_budget = settings.max_unreal_code_scan_bytes - scanned_bytes
            if remaining_budget <= 0:
                break
            requested = min(chunk_size, region.end_address - position, remaining_budget)
            overlap = min(max_pattern - 1, region.end_address - position - requested)
            try:
                data = backend.read(
                    session.backend_handle,
                    position,
                    requested + overlap,
                )
            except BackendError:
                position += requested
                scanned_bytes += requested
                continue
            scanned_bytes += requested
            for pattern, values, mask, anchor, anchor_offset in compiled:
                search_from = 0
                while True:
                    anchor_at = data.find(anchor, search_from)
                    if anchor_at < 0:
                        break
                    search_from = anchor_at + 1
                    match_offset = anchor_at - anchor_offset
                    if match_offset < 0 or match_offset + len(values) > len(data):
                        continue
                    window = data[match_offset : match_offset + len(values)]
                    if any(
                        fixed and actual != expected
                        for actual, expected, fixed in zip(
                            window,
                            values,
                            mask,
                            strict=True,
                        )
                    ):
                        continue
                    instruction = position + match_offset + pattern.instruction_offset
                    try:
                        displacement = struct.unpack(
                            "<i",
                            backend.read(
                                session.backend_handle,
                                instruction + pattern.displacement_offset,
                                4,
                            ),
                        )[0]
                    except (BackendError, struct.error):
                        continue
                    pool_address = instruction + pattern.instruction_size + displacement
                    layout = _validate_fname_pool(backend, session, pool_address)
                    if layout is not None:
                        matches.setdefault(pool_address, []).append((pattern, layout))
            position += requested
        if scanned_bytes >= settings.max_unreal_code_scan_bytes:
            break

    if not matches:
        return None
    ranked = sorted(
        matches.items(),
        key=lambda item: (
            -len(item[1]),
            min(match[0].priority for match in item[1]),
            item[0],
        ),
    )
    if len(ranked) > 1 and len(ranked[0][1]) == len(ranked[1][1]):
        return None
    address, evidence = ranked[0]
    pattern, layout = min(evidence, key=lambda item: item[0].priority)
    chunks_offset, header_offset, stride, length_shift, length_mask = layout
    return _FNamePool(
        address=address,
        module_offset=address - module_base,
        pattern=pattern.name,
        chunks_offset=chunks_offset,
        header_offset=header_offset,
        stride=stride,
        length_shift=length_shift,
        length_mask=length_mask,
    )


def _validate_fname_pool(
    backend: MemoryBackend,
    session: ProcessSession,
    address: int,
) -> tuple[int, int, int, int, int] | None:
    for chunks_offset in (0x10, 0, 8, 0x20, 0x40):
        try:
            block = struct.unpack(
                "<Q",
                backend.read(session.backend_handle, address + chunks_offset, 8),
            )[0]
            if block < 0x10000:
                continue
            data = backend.read(session.backend_handle, block, 16)
        except (BackendError, struct.error):
            continue
        for header_offset in (0, 4):
            if data[header_offset + 2 : header_offset + 6] != b"None":
                continue
            header = struct.unpack_from("<H", data, header_offset)[0]
            for length_shift, length_mask in ((6, 0x3FF), (1, 0x7FF)):
                if (header >> length_shift) & length_mask == 4:
                    stride = 2 if header_offset == 0 else 4
                    return (
                        chunks_offset,
                        header_offset,
                        stride,
                        length_shift,
                        length_mask,
                    )
    return None


def _uobject_names(
    backend: MemoryBackend,
    session: ProcessSession,
    pool: _FNamePool | None,
    address: int,
) -> tuple[str, str]:
    if pool is None:
        return "", ""
    try:
        header = backend.read(session.backend_handle, address, 0x20)
        class_address = struct.unpack_from("<Q", header, 0x10)[0]
        comparison_index, number = struct.unpack_from("<ii", header, 0x18)
        class_name_data = backend.read(session.backend_handle, class_address + 0x18, 8)
        class_index, class_number = struct.unpack("<ii", class_name_data)
    except (BackendError, struct.error):
        return "", ""
    return (
        pool.read_name(backend, session, comparison_index, number),
        pool.read_name(backend, session, class_index, class_number),
    )


def locate_gworld(
    backend: MemoryBackend,
    session: ProcessSession,
    settings: Settings,
    *,
    regions: list[MemoryRegion] | None = None,
) -> UnrealDiscoveryResult:
    all_regions = regions if regions is not None else backend.regions(session.backend_handle)
    memory = _MemoryMap(all_regions)
    module_regions = [
        region
        for region in all_regions
        if region.main_module and region.kind is MemoryRegionKind.IMAGE
    ]
    if not module_regions:
        raise ScanLimitError("the selected process has no readable main-module image")
    module_base = min(region.allocation_base or region.base_address for region in module_regions)
    module_end = max(region.end_address for region in module_regions)
    code_regions = [
        region
        for region in module_regions
        if region.committed and region.readable and region.executable and not region.guarded
    ]
    code_regions.sort(key=lambda item: (item.writable, item.base_address))
    compiled = [(pattern, *pattern.compile()) for pattern in _GWORLD_PATTERNS]
    max_pattern = max(len(item[1]) for item in compiled)
    scanned_bytes = 0
    scope_truncated = False
    candidates: list[UnrealGlobalCandidate] = []
    seen: set[tuple[str, int]] = set()
    chunk_size = max(settings.scan_chunk_bytes, 64 * 1024)

    for region in code_regions:
        position = region.base_address
        while position < region.end_address:
            remaining_budget = settings.max_unreal_code_scan_bytes - scanned_bytes
            if remaining_budget <= 0:
                scope_truncated = True
                break
            requested = min(chunk_size, region.end_address - position, remaining_budget)
            overlap = min(max_pattern - 1, region.end_address - (position + requested))
            try:
                data = backend.read(session.backend_handle, position, requested + overlap)
            except BackendError:
                position += requested
                scanned_bytes += requested
                continue
            scanned_bytes += requested
            for pattern, values, mask, anchor, anchor_offset in compiled:
                search_from = 0
                while True:
                    anchor_at = data.find(anchor, search_from)
                    if anchor_at < 0:
                        break
                    match_offset = anchor_at - anchor_offset
                    search_from = anchor_at + 1
                    if match_offset < 0 or match_offset + len(values) > len(data):
                        continue
                    window = data[match_offset : match_offset + len(values)]
                    if any(
                        fixed and byte != expected
                        for byte, expected, fixed in zip(window, values, mask, strict=True)
                    ):
                        continue
                    match_address = position + match_offset
                    instruction = match_address + pattern.instruction_offset
                    key = (pattern.name, instruction)
                    if key in seen:
                        continue
                    seen.add(key)
                    try:
                        displacement = struct.unpack(
                            "<i",
                            backend.read(
                                session.backend_handle,
                                instruction + pattern.displacement_offset,
                                4,
                            ),
                        )[0]
                    except (BackendError, struct.error):
                        continue
                    slot = instruction + pattern.instruction_size + displacement
                    candidates.append(
                        _validate_gworld_candidate(
                            backend,
                            session,
                            memory,
                            pattern,
                            match_address,
                            slot,
                            module_base,
                            module_end,
                        )
                    )
            position += requested
        if scope_truncated:
            break

    candidates.sort(
        key=lambda item: (
            -item.confidence,
            _pattern_priority(item.pattern),
            item.slot_address,
        )
    )
    valid_groups: dict[int, list[UnrealGlobalCandidate]] = {}
    for item in candidates:
        if item.valid:
            valid_groups.setdefault(item.slot_address, []).append(item)
    selected = None
    ambiguous = False
    if len(valid_groups) == 1:
        selected = next(iter(valid_groups.values()))[0]
    elif valid_groups:
        ranked_groups = sorted(
            valid_groups.values(),
            key=lambda group: (-len(group), _pattern_priority(group[0].pattern)),
        )
        if len(ranked_groups[0]) >= 2 and (
            len(ranked_groups) == 1 or len(ranked_groups[0]) > len(ranked_groups[1])
        ):
            selected = ranked_groups[0][0]
        else:
            ambiguous = True
    warnings: list[str] = []
    if selected is None:
        warnings.append(
            "GWorld was not validated; this build may need a signed game profile or "
            "updated read-site signature."
        )
    if scope_truncated:
        warnings.append("The live executable-code scope reached GTP_MAX_UNREAL_CODE_SCAN_BYTES.")
    if ambiguous:
        warnings.append("Multiple equally plausible GWorld slots were found; none was selected.")
    return UnrealDiscoveryResult(
        session_id=session.id,
        main_module_base=module_base,
        main_module_size=module_end - module_base,
        gworld_module_offset=(selected.slot_address - module_base) if selected else None,
        gworld_slot=selected.slot_address if selected else None,
        world_address=selected.world_address if selected else None,
        selected_pattern=selected.pattern if selected else None,
        scanned_bytes=scanned_bytes,
        scope_truncated=scope_truncated,
        candidates=candidates[:50],
        warnings=warnings,
    )


def _pattern_priority(name: str) -> int:
    return next((item.priority for item in _GWORLD_PATTERNS if item.name == name), 1000)


def _validate_gworld_candidate(
    backend: MemoryBackend,
    session: ProcessSession,
    memory: _MemoryMap,
    pattern: _Pattern,
    match_address: int,
    slot: int,
    module_base: int,
    module_end: int,
) -> UnrealGlobalCandidate:
    reasons: list[str] = []
    score = 0.0
    slot_region = memory.region(slot, 8)
    if slot_region is None or not slot_region.readable or slot_region.guarded:
        reasons.append("resolved slot is not readable")
        return UnrealGlobalCandidate(
            pattern=pattern.name,
            match_address=match_address,
            slot_address=max(slot, 0),
            reasons=reasons,
        )
    if module_base <= slot < module_end and slot_region.main_module:
        score += 0.2
        reasons.append("slot is inside the main game image")
    else:
        reasons.append("slot is outside the main game image")
    if not slot_region.executable:
        score += 0.1
        reasons.append("slot is in data, not executable code")
    try:
        world = struct.unpack("<Q", backend.read(session.backend_handle, slot, 8))[0]
    except (BackendError, struct.error):
        reasons.append("could not read the GWorld slot")
        world = 0
    if world == 0:
        reasons.append("GWorld is currently null")
    elif _plausible_uobject(backend, session, memory, world):
        score += 0.7
        reasons.append("target has a plausible live UObject layout and executable vtable")
    else:
        reasons.append("target failed conservative UObject validation")
    valid = score >= 0.9 and world != 0
    return UnrealGlobalCandidate(
        pattern=pattern.name,
        match_address=match_address,
        slot_address=slot,
        world_address=world or None,
        valid=valid,
        confidence=min(score, 1.0),
        reasons=reasons,
    )


def _plausible_uobject(
    backend: MemoryBackend,
    session: ProcessSession,
    memory: _MemoryMap,
    address: int,
) -> bool:
    if address < 0x10000 or address % 8 or not memory.readable(address, 0x28):
        return False
    try:
        header = backend.read(session.backend_handle, address, 0x28)
        vtable, internal_index, class_address, outer = struct.unpack_from("<QxxxxiQ8xQ", header)
        if not 0 <= internal_index <= 10_000_000:
            return False
        if not memory.readable(vtable, 8) or not memory.readable(class_address, 0x18):
            return False
        first_virtual = struct.unpack("<Q", backend.read(session.backend_handle, vtable, 8))[0]
        class_vtable = struct.unpack("<Q", backend.read(session.backend_handle, class_address, 8))[
            0
        ]
        class_first_virtual = struct.unpack(
            "<Q", backend.read(session.backend_handle, class_vtable, 8)
        )[0]
        if not memory.executable_address(first_virtual):
            return False
        if not memory.executable_address(class_first_virtual):
            return False
        return outer == 0 or (outer % 8 == 0 and memory.readable(outer, 8))
    except (BackendError, struct.error):
        return False


@dataclass(order=True)
class _ObjectNode:
    priority: int
    sequence: int
    address: int = field(compare=False)
    path: str = field(compare=False)
    depth: int = field(compare=False)
    object_name: str = field(default="", compare=False)
    class_name: str = field(default="", compare=False)


@dataclass
class _FieldState:
    address: int
    object_address: int
    object_path: str
    offset: int
    value_type: ValueType
    previous: int | float
    observations: list[int | float] = field(default_factory=list)
    active: bool = True
    decreased: int = 0
    increased: int = 0
    unchanged: int = 0
    changed: int = 0
    advisory_score: int = 0
    advisory_evidence: list[str] = field(default_factory=list)
    object_name: str = ""
    class_name: str = ""


@dataclass
class _GasRecord:
    id: str
    session_id: str
    gworld: UnrealDiscoveryResult
    fields: dict[tuple[int, ValueType], _FieldState]
    object_count: int
    scanned_bytes: int
    truncated: bool
    player_pawn_address: int | None = None
    player_pawn_path: str | None = None
    generation: int = 0
    comparison: Comparison = Comparison.UNCHANGED
    stage: str = "baseline"


@dataclass(frozen=True)
class _TemporalMatch:
    candidate: UnrealGasTemporalCandidate
    shape: tuple[float, ...]


@dataclass
class _ActiveTemporalTrace:
    state: _FieldState
    values: list[int | float]
    started_sample: int


@dataclass
class _DamageMonitor:
    id: str
    scan_id: str
    session_id: str
    interval_ms: int
    duration_seconds: int
    group_limit: int
    foreground_only: bool
    started_at: datetime = field(default_factory=lambda: datetime.now(UTC))
    state: str = "running"
    sample_count: int = 0
    paused_sample_count: int = 0
    waiting_for_game: bool = False
    sampled_field_count: int = 0
    matches: dict[tuple[int, ValueType], _TemporalMatch] = field(default_factory=dict)
    event_counts: dict[tuple[int, ValueType], int] = field(default_factory=dict)
    warnings: list[str] = field(default_factory=list)
    finished_at: datetime | None = None
    stop_event: Event = field(default_factory=Event)
    thread: Thread | None = None


@dataclass
class _ProfileStats:
    baseline: int | float
    current: int | float
    minimum: int | float
    maximum: int | float
    changed: int = 0
    increased: int = 0
    decreased: int = 0
    unchanged: int = 0
    distinct_values: set[int | float] = field(default_factory=set)


@dataclass
class _GameProfileMonitor:
    id: str
    scan_id: str
    session_id: str
    interval_ms: int
    duration_seconds: int
    candidate_limit: int
    foreground_only: bool
    object_count: int
    session: ProcessSession
    started_at: datetime = field(default_factory=lambda: datetime.now(UTC))
    state: str = "running"
    sample_count: int = 0
    paused_sample_count: int = 0
    waiting_for_game: bool = False
    sampled_field_count: int = 0
    stats: dict[tuple[int, ValueType], _ProfileStats] = field(default_factory=dict)
    warnings: list[str] = field(default_factory=list)
    finished_at: datetime | None = None
    saved_path: str | None = None
    stop_event: Event = field(default_factory=Event)
    thread: Thread | None = None


class UnrealGasEngine:
    """Bounded external Unreal object-graph and behavior scanner.

    It deliberately does not inject code or call engine functions. When reflection names are
    unavailable, damage/heal snapshots supply the evidence and object paths remain rooted at
    the restart-stable GWorld slot.
    """

    def __init__(self, backend: MemoryBackend, settings: Settings) -> None:
        self.backend = backend
        self.settings = settings
        self._records: dict[str, _GasRecord] = {}
        self._discoveries: dict[str, UnrealDiscoveryResult] = {}
        self._name_pools: dict[str, _FNamePool] = {}
        self._monitors: dict[str, _DamageMonitor] = {}
        self._profile_monitors: dict[str, _GameProfileMonitor] = {}
        self._lock = RLock()

    def locate(self, session: ProcessSession) -> UnrealDiscoveryResult:
        result = locate_gworld(self.backend, session, self.settings)
        with self._lock:
            self._discoveries[session.id] = result
        return result

    def start(
        self,
        session: ProcessSession,
        value_types: list[ValueType] | None = None,
    ) -> UnrealGasScanSummary:
        types = value_types or [ValueType.F32, ValueType.F64, ValueType.I32, ValueType.I16]
        allowed = {ValueType.F32, ValueType.F64, ValueType.I32, ValueType.I16}
        if not types or any(item not in allowed for item in types):
            raise ScanLimitError("Unreal/GAS scans support i16, i32, f32, and f64")
        regions = self.backend.regions(session.backend_handle)
        memory = _MemoryMap(regions)
        with self._lock:
            gworld = self._discoveries.get(session.id)
        if gworld is None or not self._discovery_is_live(session, memory, gworld):
            gworld = locate_gworld(
                self.backend,
                session,
                self.settings,
                regions=regions,
            )
            with self._lock:
                self._discoveries[session.id] = gworld
        if gworld.world_address is None:
            raise ScanLimitError(
                "GWorld could not be validated for this build; no GAS snapshot was taken"
            )
        nodes = self._walk_objects(session, memory, gworld.world_address)
        with self._lock:
            name_pool = self._name_pools.get(session.id)
        if name_pool is None:
            name_pool = _locate_fname_pool(
                self.backend,
                session,
                self.settings,
                regions,
            )
            if name_pool is not None:
                with self._lock:
                    self._name_pools[session.id] = name_pool
        if name_pool is not None:
            for node in nodes:
                node.object_name, node.class_name = _uobject_names(
                    self.backend,
                    session,
                    name_pool,
                    node.address,
                )
        fields: dict[tuple[int, ValueType], _FieldState] = {}
        scanned_bytes = 0
        truncated = False
        for node in nodes:
            region = memory.region(node.address)
            if region is None:
                continue
            length = min(
                self.settings.max_unreal_object_bytes,
                region.end_address - node.address,
            )
            if length < 16:
                continue
            try:
                data = self.backend.read(session.backend_handle, node.address, length)
            except BackendError:
                continue
            scanned_bytes += len(data)
            for value_type in types:
                width = value_size(value_type)
                for offset in range(0x28, len(data) - width + 1, width):
                    value = decode_value(value_type, data[offset : offset + width])
                    if not _plausible_stat_value(value_type, value):
                        continue
                    key = (node.address + offset, value_type)
                    if key in fields:
                        continue
                    fields[key] = _FieldState(
                        address=key[0],
                        object_address=node.address,
                        object_path=node.path,
                        offset=offset,
                        value_type=value_type,
                        previous=value,
                        observations=[value],
                        object_name=node.object_name,
                        class_name=node.class_name,
                    )
                    if len(fields) >= self.settings.max_unreal_fields:
                        truncated = True
                        break
                if truncated:
                    break
            if truncated:
                break
        player_pawn = _locate_player_pawn(
            self.backend,
            session,
            memory,
            gworld.world_address,
            name_pool,
        ) or _guess_player_pawn(nodes)
        record = _GasRecord(
            id=uuid4().hex,
            session_id=session.id,
            gworld=gworld,
            fields=fields,
            object_count=len(nodes),
            scanned_bytes=scanned_bytes,
            truncated=truncated,
            player_pawn_address=player_pawn.address if player_pawn else None,
            player_pawn_path=player_pawn.path if player_pawn else None,
        )
        with self._lock:
            self._records[record.id] = record
        return self.summary(record.id)

    def refine(
        self,
        scan_id: str,
        session: ProcessSession,
        comparison: Comparison,
        value: int | float | None = None,
    ) -> UnrealGasScanSummary:
        if comparison is Comparison.EXACT and value is None:
            raise ScanLimitError("an exact Unreal/GAS refinement requires a value")
        with self._lock:
            record = self._get(scan_id)
            if record.session_id != session.id:
                raise NotFoundError("Unreal/GAS scan does not belong to this session")
            for state in record.fields.values():
                width = value_size(state.value_type)
                try:
                    current = decode_value(
                        state.value_type,
                        self.backend.read(session.backend_handle, state.address, width),
                    )
                except BackendError:
                    state.active = False
                    continue
                previous = state.previous
                state.observations.append(current)
                is_equal = values_equal(state.value_type, current, previous)
                if is_equal:
                    state.unchanged += 1
                else:
                    state.changed += 1
                    if current < previous:
                        state.decreased += 1
                    elif current > previous:
                        state.increased += 1
                if state.active:
                    state.active = _comparison_matches(
                        state.value_type,
                        previous,
                        current,
                        comparison,
                        value,
                    )
                state.previous = current
            record.comparison = comparison
            record.generation += 1
        return self.summary(scan_id)

    def start_table_guided(
        self,
        scan_id: str,
        session: ProcessSession,
        *,
        pawn_pointer_offset: int = 0xD30,
        pointer_radius: int = 0x100,
        health_offset: int = 0x1A4,
        max_health_offset: int = 0xE18,
        nested_state_offset: int = 0x150,
        replica_percent_offset: int = 0x12C,
    ) -> UnrealGasScanSummary:
        """Relocate an old table layout around the confirmed live player pawn.

        Every supplied offset is advisory. The scan validates live UObject pointers in a
        bounded neighborhood and records only plausible f32 fields from those objects.
        """

        if not 0x28 <= pawn_pointer_offset <= 0x10000:
            raise ScanLimitError("pawn_pointer_offset must be between 0x28 and 0x10000")
        if not 0 <= pointer_radius <= 0x1000:
            raise ScanLimitError("pointer_radius must be between 0 and 0x1000")
        advisory_offsets = {
            health_offset,
            max_health_offset,
            nested_state_offset,
            replica_percent_offset,
        }
        if any(not 0 <= offset <= 0x10000 for offset in advisory_offsets):
            raise ScanLimitError("table field offsets must be between 0 and 0x10000")

        with self._lock:
            source = self._get(scan_id)
            if source.session_id != session.id:
                raise NotFoundError("Unreal/GAS scan does not belong to this session")
            pawn_address = source.player_pawn_address
            pawn_path = source.player_pawn_path
            name_pool = self._name_pools.get(session.id)
        if pawn_address is None or pawn_path is None:
            raise ScanLimitError("the source scan did not identify a live player pawn")

        memory = _MemoryMap(self.backend.regions(session.backend_handle))
        pawn_region = memory.region(pawn_address)
        if pawn_region is None:
            raise ScanLimitError("the live player pawn is no longer readable")
        start_offset = max(0x28, pawn_pointer_offset - pointer_radius)
        end_offset = min(
            pawn_region.end_address - pawn_address,
            pawn_pointer_offset + pointer_radius + 8,
        )
        if end_offset <= start_offset:
            raise ScanLimitError("the table-guided pawn pointer window is empty")
        try:
            pawn_data = self.backend.read(
                session.backend_handle,
                pawn_address + start_offset,
                end_offset - start_offset,
            )
        except BackendError as exc:
            raise ScanLimitError("the table-guided pawn pointer window could not be read") from exc

        nodes: list[tuple[_ObjectNode, int, list[str]]] = []
        seen: set[int] = set()
        first_offset = (start_offset + 7) & ~7
        for pointer_offset in range(first_offset, end_offset - 7, 8):
            local = pointer_offset - start_offset
            target = struct.unpack_from("<Q", pawn_data, local)[0]
            if target in seen or not _plausible_uobject(
                self.backend,
                session,
                memory,
                target,
            ):
                continue
            seen.add(target)
            distance = abs(pointer_offset - pawn_pointer_offset)
            relocation_score = max(0, 60 - distance // 4)
            object_name, class_name = _uobject_names(
                self.backend,
                session,
                name_pool,
                target,
            )
            name_score, name_evidence = _table_object_advisory(
                object_name,
                class_name,
            )
            evidence = [
                "live UObject relocated near the table's pawn state-pointer offset",
                f"pawn pointer moved from advisory +0x{pawn_pointer_offset:X} "
                f"to validated +0x{pointer_offset:X}",
            ]
            evidence.extend(name_evidence)
            nodes.append(
                (
                    _ObjectNode(
                        0,
                        len(nodes),
                        target,
                        f"{pawn_path}->+0x{pointer_offset:X}",
                        1,
                        object_name,
                        class_name,
                    ),
                    relocation_score + name_score,
                    evidence,
                )
            )

        primary_nodes = list(nodes)
        for parent, parent_score, parent_evidence in primary_nodes:
            region = memory.region(parent.address)
            if region is None:
                continue
            child_start = max(0x28, nested_state_offset - 0x80)
            child_end = min(
                region.end_address - parent.address,
                nested_state_offset + 0x88,
            )
            if child_end <= child_start:
                continue
            try:
                data = self.backend.read(
                    session.backend_handle,
                    parent.address + child_start,
                    child_end - child_start,
                )
            except BackendError:
                continue
            first_child = (child_start + 7) & ~7
            for child_offset in range(first_child, child_end - 7, 8):
                target = struct.unpack_from("<Q", data, child_offset - child_start)[0]
                if target in seen or not _plausible_uobject(
                    self.backend,
                    session,
                    memory,
                    target,
                ):
                    continue
                seen.add(target)
                distance = abs(child_offset - nested_state_offset)
                object_name, class_name = _uobject_names(
                    self.backend,
                    session,
                    name_pool,
                    target,
                )
                name_score, name_evidence = _table_object_advisory(
                    object_name,
                    class_name,
                )
                evidence = list(parent_evidence)
                evidence.append(
                    "validated a nested UObject near the table's ObjectStateData offset"
                )
                evidence.extend(name_evidence)
                nodes.append(
                    (
                        _ObjectNode(
                            0,
                            len(nodes),
                            target,
                            f"{parent.path}->+0x{child_offset:X}",
                            2,
                            object_name,
                            class_name,
                        ),
                        max(0, min(parent_score, 60) - distance // 4) + 20 + name_score,
                        evidence,
                    )
                )
                if len(nodes) >= 32:
                    break
            if len(nodes) >= 32:
                break

        fields: dict[tuple[int, ValueType], _FieldState] = {}
        scanned_bytes = 0
        truncated = False
        for node, node_score, node_evidence in nodes:
            region = memory.region(node.address)
            if region is None:
                continue
            length = min(
                self.settings.max_unreal_object_bytes,
                region.end_address - node.address,
            )
            if length < 0x30:
                continue
            try:
                data = self.backend.read(session.backend_handle, node.address, length)
            except BackendError:
                continue
            scanned_bytes += len(data)
            for offset in range(0x28, len(data) - 4 + 1, 4):
                value = decode_value(ValueType.F32, data[offset : offset + 4])
                if not _plausible_stat_value(ValueType.F32, value):
                    continue
                advisory_score, field_evidence = _table_field_advisory(
                    offset,
                    health_offset=health_offset,
                    max_health_offset=max_health_offset,
                    replica_percent_offset=replica_percent_offset,
                    nested=node.depth >= 2,
                )
                key = (node.address + offset, ValueType.F32)
                fields[key] = _FieldState(
                    address=key[0],
                    object_address=node.address,
                    object_path=node.path,
                    offset=offset,
                    value_type=ValueType.F32,
                    previous=value,
                    observations=[value],
                    advisory_score=node_score + advisory_score,
                    advisory_evidence=node_evidence + field_evidence,
                    object_name=node.object_name,
                    class_name=node.class_name,
                )
                if len(fields) >= self.settings.max_unreal_fields:
                    truncated = True
                    break
            if truncated:
                break

        if not fields:
            raise ScanLimitError(
                "no plausible f32 fields were found near the relocated table objects"
            )
        record = _GasRecord(
            id=uuid4().hex,
            session_id=session.id,
            gworld=source.gworld,
            fields=fields,
            object_count=len(nodes),
            scanned_bytes=scanned_bytes,
            truncated=truncated,
            player_pawn_address=pawn_address,
            player_pawn_path=pawn_path,
            stage="table_guided",
        )
        with self._lock:
            self._records[record.id] = record
        return self.summary(record.id)

    def summary(self, scan_id: str, *, limit: int = 20) -> UnrealGasScanSummary:
        with self._lock:
            record = self._get(scan_id)
            active = [item for item in record.fields.values() if item.active]
            active.sort(key=lambda item: (-_field_score(item), item.address, item.value_type.value))
            candidates = [self._candidate(record, item) for item in active[: max(0, limit)]]
            stage = record.stage if record.generation == 0 else "refined"
            if record.stage == "baseline" and 0 < len(active) <= 50:
                stage = "candidate_review"
            return UnrealGasScanSummary(
                id=record.id,
                session_id=record.session_id,
                stage=stage,
                comparison=record.comparison,
                generation=record.generation,
                result_count=len(active),
                object_count=record.object_count,
                field_count=len(record.fields),
                scanned_bytes=record.scanned_bytes,
                truncated=record.truncated,
                player_pawn_address=record.player_pawn_address,
                player_pawn_path=record.player_pawn_path,
                gworld=record.gworld,
                candidates=candidates,
            )

    def watch(
        self,
        scan_id: str,
        session: ProcessSession,
        *,
        sample_count: int,
        interval_ms: int,
        limit: int,
    ) -> UnrealGasWatchResult:
        if not 1 <= sample_count <= 30:
            raise ScanLimitError("sample_count must be between 1 and 30")
        if not 100 <= interval_ms <= 5000:
            raise ScanLimitError("interval_ms must be between 100 and 5000")
        duration = (sample_count - 1) * interval_ms / 1000
        if duration > self.settings.max_watch_seconds:
            raise ScanLimitError(
                f"watch duration exceeds GTP_MAX_WATCH_SECONDS ({self.settings.max_watch_seconds})"
            )
        with self._lock:
            record = self._get(scan_id)
            if record.session_id != session.id:
                raise NotFoundError("Unreal/GAS scan does not belong to this session")
            active = [item for item in record.fields.values() if item.active]
            active.sort(key=lambda item: (-_field_score(item), item.address))
            selected = active[: max(0, limit)]
        samples: list[UnrealGasWatchSample] = []
        for sample_index in range(sample_count):
            candidates: list[UnrealGasCandidate] = []
            for state in selected:
                candidate = self._candidate(record, state)
                try:
                    current = decode_value(
                        state.value_type,
                        self.backend.read(
                            session.backend_handle,
                            state.address,
                            value_size(state.value_type),
                        ),
                    )
                except BackendError:
                    continue
                candidate = candidate.model_copy(update={"value": current})
                candidates.append(candidate)
            samples.append(UnrealGasWatchSample(candidates=candidates))
            if sample_index + 1 < sample_count:
                time.sleep(interval_ms / 1000)
        return UnrealGasWatchResult(
            scan_id=scan_id,
            session_id=session.id,
            samples=samples,
        )

    def capture_damage_refill(
        self,
        scan_id: str,
        session: ProcessSession,
        *,
        sample_count: int = 30,
        interval_ms: int = 500,
        group_limit: int = 10,
    ) -> UnrealGasTemporalResult:
        """Capture a damage-and-regeneration curve across the whole field pool.

        Object buffers are read once per sample and decoded locally. This avoids the prompt
        timing race in point-in-time refinements and keeps synchronized gameplay, GAS, UI,
        and replication copies together instead of forcing the result to one address.
        """

        if not 5 <= sample_count <= 60:
            raise ScanLimitError("sample_count must be between 5 and 60")
        if not 100 <= interval_ms <= 2000:
            raise ScanLimitError("interval_ms must be between 100 and 2000")
        if not 1 <= group_limit <= 20:
            raise ScanLimitError("group_limit must be between 1 and 20")
        duration = (sample_count - 1) * interval_ms / 1000
        if duration > self.settings.max_watch_seconds:
            raise ScanLimitError(
                "temporal capture exceeds GTP_MAX_WATCH_SECONDS "
                f"({self.settings.max_watch_seconds})"
            )

        with self._lock:
            record = self._get(scan_id)
            if record.session_id != session.id:
                raise NotFoundError("Unreal/GAS scan does not belong to this session")
            states = list(record.fields.values())

        started = time.monotonic()
        snapshots: list[dict[tuple[int, ValueType], int | float]] = []
        for sample_index in range(sample_count):
            snapshots.append(self._read_field_snapshot(record, session, states))
            if sample_index + 1 < sample_count:
                target = started + ((sample_index + 1) * interval_ms / 1000)
                time.sleep(max(0.0, target - time.monotonic()))

        matches: list[_TemporalMatch] = []
        sampled_field_count = 0
        for state in states:
            key = (state.address, state.value_type)
            values = [snapshot.get(key) for snapshot in snapshots]
            if any(value is None for value in values):
                continue
            sampled_field_count += 1
            match = _temporal_match(state, [value for value in values if value is not None])
            if match is not None:
                matches.append(match)

        groups = _group_temporal_matches(matches, limit=group_limit)
        warnings: list[str] = []
        if not groups:
            warnings.append(
                "No sharp damage drop followed by multi-step recovery was captured. "
                "Start a fresh baseline at full health and take damage during the window."
            )
        return UnrealGasTemporalResult(
            scan_id=scan_id,
            session_id=session.id,
            sample_count=sample_count,
            interval_ms=interval_ms,
            captured_seconds=time.monotonic() - started,
            sampled_field_count=sampled_field_count,
            matched_field_count=len(matches),
            group_count=len(groups),
            groups=groups,
            warnings=warnings,
        )

    def start_damage_monitor(
        self,
        scan_id: str,
        session: ProcessSession,
        *,
        interval_ms: int = 500,
        duration_seconds: int = 300,
        group_limit: int = 10,
    ) -> UnrealGasMonitorStatus:
        if not 100 <= interval_ms <= 2000:
            raise ScanLimitError("interval_ms must be between 100 and 2000")
        if not 1 <= duration_seconds <= self.settings.max_damage_monitor_seconds:
            raise ScanLimitError(
                f"duration_seconds must be between 1 and {self.settings.max_damage_monitor_seconds}"
            )
        if not 1 <= group_limit <= 20:
            raise ScanLimitError("group_limit must be between 1 and 20")
        with self._lock:
            record = self._get(scan_id)
            if record.session_id != session.id:
                raise NotFoundError("Unreal/GAS scan does not belong to this session")
            if any(
                item.scan_id == scan_id and item.state == "running"
                for item in self._monitors.values()
            ):
                raise ScanLimitError("a background damage monitor is already running")
            monitor = _DamageMonitor(
                id=uuid4().hex,
                scan_id=scan_id,
                session_id=session.id,
                interval_ms=interval_ms,
                duration_seconds=duration_seconds,
                group_limit=group_limit,
                foreground_only=session.backend_name == "windows",
            )
            states = list(record.fields.values())
            thread = Thread(
                target=self._run_damage_monitor,
                args=(monitor, record, session, states),
                name=f"gtp-damage-monitor-{monitor.id[:8]}",
                daemon=True,
            )
            monitor.thread = thread
            self._monitors[monitor.id] = monitor
        thread.start()
        return self.damage_monitor_status(monitor.id)

    def damage_monitor_status(self, monitor_id: str) -> UnrealGasMonitorStatus:
        with self._lock:
            monitor = self._monitors.get(monitor_id)
            if monitor is None:
                raise NotFoundError(f"damage monitor {monitor_id} was not found")
            matches: list[_TemporalMatch] = []
            for key, match in monitor.matches.items():
                event_count = monitor.event_counts.get(key, 1)
                evidence = list(match.candidate.evidence)
                if event_count > 1:
                    evidence.append(f"repeated across {event_count} separate events")
                matches.append(
                    _TemporalMatch(
                        candidate=match.candidate.model_copy(
                            update={
                                "event_count": event_count,
                                "score": match.candidate.score + min(event_count - 1, 4) * 20,
                                "evidence": evidence,
                            }
                        ),
                        shape=match.shape,
                    )
                )
            groups = _group_temporal_matches(
                matches,
                limit=monitor.group_limit,
            )
            warnings = list(monitor.warnings)
            if monitor.state != "running" and not groups and not warnings:
                warnings.append(
                    "No natural damage-and-refill event was detected before the monitor ended."
                )
            return UnrealGasMonitorStatus(
                id=monitor.id,
                scan_id=monitor.scan_id,
                session_id=monitor.session_id,
                state=monitor.state,
                interval_ms=monitor.interval_ms,
                duration_seconds=monitor.duration_seconds,
                sample_count=monitor.sample_count,
                paused_sample_count=monitor.paused_sample_count,
                waiting_for_game=monitor.waiting_for_game,
                foreground_only=monitor.foreground_only,
                sampled_field_count=monitor.sampled_field_count,
                matched_field_count=len(monitor.matches),
                group_count=len(groups),
                started_at=monitor.started_at,
                finished_at=monitor.finished_at,
                groups=groups,
                warnings=warnings,
            )

    def stop_damage_monitor(self, monitor_id: str) -> UnrealGasMonitorStatus:
        with self._lock:
            monitor = self._monitors.get(monitor_id)
            if monitor is None:
                raise NotFoundError(f"damage monitor {monitor_id} was not found")
            monitor.stop_event.set()
            thread = monitor.thread
        if thread is not None and thread.is_alive():
            thread.join(timeout=max(2.0, monitor.interval_ms / 1000 * 3))
        return self.damage_monitor_status(monitor_id)

    def start_game_profile_monitor(
        self,
        scan_id: str,
        session: ProcessSession,
        *,
        interval_ms: int = 1000,
        duration_seconds: int = 900,
        candidate_limit: int = 50,
    ) -> GameProfileMonitorStatus:
        if not 250 <= interval_ms <= 5000:
            raise ScanLimitError("interval_ms must be between 250 and 5000")
        if not 1 <= duration_seconds <= self.settings.max_damage_monitor_seconds:
            raise ScanLimitError(
                f"duration_seconds must be between 1 and {self.settings.max_damage_monitor_seconds}"
            )
        if not 10 <= candidate_limit <= 200:
            raise ScanLimitError("candidate_limit must be between 10 and 200")
        with self._lock:
            record = self._get(scan_id)
            if record.session_id != session.id:
                raise NotFoundError("Unreal scan does not belong to this session")
            if any(
                item.session_id == session.id and item.state == "running"
                for item in self._profile_monitors.values()
            ):
                raise ScanLimitError("a full-game profile monitor is already running")
            monitor = _GameProfileMonitor(
                id=uuid4().hex,
                scan_id=scan_id,
                session_id=session.id,
                interval_ms=interval_ms,
                duration_seconds=duration_seconds,
                candidate_limit=candidate_limit,
                foreground_only=session.backend_name == "windows",
                object_count=record.object_count,
                session=session,
            )
            states = list(record.fields.values())
            thread = Thread(
                target=self._run_game_profile_monitor,
                args=(monitor, record, session, states),
                name=f"gtp-game-profile-{monitor.id[:8]}",
                daemon=True,
            )
            monitor.thread = thread
            self._profile_monitors[monitor.id] = monitor
        thread.start()
        return self.game_profile_monitor_status(monitor.id)

    def game_profile_monitor_status(self, monitor_id: str) -> GameProfileMonitorStatus:
        with self._lock:
            monitor = self._profile_monitors.get(monitor_id)
            if monitor is None:
                raise NotFoundError(f"game profile monitor {monitor_id} was not found")
            record = self._get(monitor.scan_id)
            candidates = _rank_profile_candidates(
                record,
                monitor.stats,
                sample_count=monitor.sample_count,
                limit=monitor.candidate_limit,
            )
            changed_count = sum(1 for item in monitor.stats.values() if item.changed)
            useful_count = sum(item.relevance == "useful" for item in candidates)
            secondary_count = sum(item.relevance == "secondary" for item in candidates)
            unknown_count = sum(item.relevance == "unknown" for item in candidates)
            ignored_count = _ignored_profile_field_count(
                record,
                monitor.stats,
                monitor.sample_count,
            )
            warnings = list(monitor.warnings)
            if monitor.state != "running" and not candidates and not warnings:
                warnings.append(
                    "No useful changing or named fields were observed before profiling ended."
                )
            return GameProfileMonitorStatus(
                id=monitor.id,
                scan_id=monitor.scan_id,
                session_id=monitor.session_id,
                state=monitor.state,
                interval_ms=monitor.interval_ms,
                duration_seconds=monitor.duration_seconds,
                sample_count=monitor.sample_count,
                paused_sample_count=monitor.paused_sample_count,
                waiting_for_game=monitor.waiting_for_game,
                foreground_only=monitor.foreground_only,
                object_count=monitor.object_count,
                sampled_field_count=monitor.sampled_field_count,
                changed_field_count=changed_count,
                candidate_count=len(candidates),
                useful_candidate_count=useful_count,
                secondary_candidate_count=secondary_count,
                unknown_candidate_count=unknown_count,
                ignored_engine_field_count=ignored_count,
                started_at=monitor.started_at,
                finished_at=monitor.finished_at,
                saved_path=monitor.saved_path,
                candidates=candidates,
                warnings=warnings,
            )

    def stop_game_profile_monitor(self, monitor_id: str) -> GameProfileMonitorStatus:
        with self._lock:
            monitor = self._profile_monitors.get(monitor_id)
            if monitor is None:
                raise NotFoundError(f"game profile monitor {monitor_id} was not found")
            monitor.stop_event.set()
            thread = monitor.thread
        if thread is not None and thread.is_alive():
            thread.join(timeout=max(2.0, monitor.interval_ms / 1000 * 3))
        if monitor.saved_path is None:
            self._persist_game_profile_monitor(monitor.id)
        return self.game_profile_monitor_status(monitor_id)

    def stop_session_monitors(self, session_id: str) -> None:
        with self._lock:
            monitor_ids = [
                item.id
                for item in self._monitors.values()
                if item.session_id == session_id and item.state == "running"
            ]
            profile_monitor_ids = [
                item.id
                for item in self._profile_monitors.values()
                if item.session_id == session_id and item.state == "running"
            ]
        for monitor_id in monitor_ids:
            self.stop_damage_monitor(monitor_id)
        for monitor_id in profile_monitor_ids:
            self.stop_game_profile_monitor(monitor_id)

    def _run_game_profile_monitor(
        self,
        monitor: _GameProfileMonitor,
        record: _GasRecord,
        session: ProcessSession,
        states: list[_FieldState],
    ) -> None:
        state_by_key = {(state.address, state.value_type): state for state in states}
        try:
            previous: dict[tuple[int, ValueType], int | float] = {}
            target_samples = max(
                1,
                math.ceil(monitor.duration_seconds * 1000 / monitor.interval_ms),
            )
            while not monitor.stop_event.is_set() and monitor.sample_count < target_samples:
                if monitor.foreground_only and not _process_is_foreground(session.pid):
                    previous = {}
                    with self._lock:
                        monitor.waiting_for_game = True
                        monitor.paused_sample_count += 1
                    if monitor.stop_event.wait(monitor.interval_ms / 1000):
                        break
                    continue

                current = self._read_field_snapshot(record, session, states)
                if current:
                    with self._lock:
                        monitor.waiting_for_game = False
                        monitor.sample_count += 1
                        monitor.sampled_field_count = max(
                            monitor.sampled_field_count,
                            len(current),
                        )
                        for key, value in current.items():
                            state = state_by_key.get(key)
                            if state is None or not _plausible_stat_value(state.value_type, value):
                                continue
                            stats = monitor.stats.get(key)
                            if stats is None:
                                stats = _ProfileStats(
                                    baseline=value,
                                    current=value,
                                    minimum=value,
                                    maximum=value,
                                    distinct_values={value},
                                )
                                monitor.stats[key] = stats
                                continue
                            prior = previous.get(key, stats.current)
                            if values_equal(state.value_type, prior, value):
                                stats.unchanged += 1
                            else:
                                stats.changed += 1
                                if value > prior:
                                    stats.increased += 1
                                elif value < prior:
                                    stats.decreased += 1
                            stats.current = value
                            stats.minimum = min(stats.minimum, value)
                            stats.maximum = max(stats.maximum, value)
                            if len(stats.distinct_values) < 64:
                                stats.distinct_values.add(value)
                    previous = current
                    if monitor.sample_count % 30 == 0:
                        self._persist_game_profile_monitor(monitor.id)
                if monitor.stop_event.wait(monitor.interval_ms / 1000):
                    break
            with self._lock:
                monitor.state = "stopped" if monitor.stop_event.is_set() else "completed"
                monitor.waiting_for_game = False
                monitor.finished_at = datetime.now(UTC)
            self._persist_game_profile_monitor(monitor.id)
        except Exception as exc:  # noqa: BLE001 - retained as bounded monitor status
            with self._lock:
                monitor.state = "failed"
                monitor.waiting_for_game = False
                monitor.finished_at = datetime.now(UTC)
                monitor.warnings.append(f"Full-game profile monitor failed: {exc}")
            self._persist_game_profile_monitor(monitor.id)

    def _persist_game_profile_monitor(self, monitor_id: str) -> None:
        with self._lock:
            monitor = self._profile_monitors.get(monitor_id)
            if monitor is None:
                return
            directory = self.settings.game_profile_directory / "discoveries"
            path = directory / f"{monitor.id}.json"
            monitor.saved_path = str(path.resolve())
            status = self.game_profile_monitor_status(monitor_id)
        try:
            directory.mkdir(parents=True, exist_ok=True)
            temporary = path.with_suffix(".tmp")
            temporary.write_text(status.model_dump_json(indent=2), encoding="utf-8")
            temporary.replace(path)
            register_profile_monitor_ledger(
                self.settings,
                monitor.session,
                status,
            )
        except OSError as exc:
            with self._lock:
                warning = f"Could not save the local candidate ledger: {exc}"
                if warning not in monitor.warnings:
                    monitor.warnings.append(warning)

    def _run_damage_monitor(
        self,
        monitor: _DamageMonitor,
        record: _GasRecord,
        session: ProcessSession,
        states: list[_FieldState],
    ) -> None:
        state_by_key = {(state.address, state.value_type): state for state in states}
        active: dict[tuple[int, ValueType], _ActiveTemporalTrace] = {}
        stable_counts: dict[tuple[int, ValueType], int] = {}
        maximum_event_samples = max(5, min(60, round(20_000 / monitor.interval_ms)))
        try:
            previous: dict[tuple[int, ValueType], int | float] = {}
            deadline = time.monotonic() + monitor.duration_seconds
            while not monitor.stop_event.wait(monitor.interval_ms / 1000):
                if time.monotonic() >= deadline:
                    break
                if monitor.foreground_only and not _process_is_foreground(session.pid):
                    previous = {}
                    active.clear()
                    stable_counts.clear()
                    with self._lock:
                        monitor.waiting_for_game = True
                        monitor.paused_sample_count += 1
                    continue

                if not previous:
                    previous = self._read_field_snapshot(record, session, states)
                    if not previous:
                        continue
                    with self._lock:
                        monitor.waiting_for_game = False
                        monitor.sample_count += 1
                        monitor.sampled_field_count = max(
                            monitor.sampled_field_count,
                            len(previous),
                        )
                    continue

                with self._lock:
                    monitor.waiting_for_game = False
                current = self._read_field_snapshot(record, session, states)
                if not current:
                    continue

                for key, trace in list(active.items()):
                    current_value = current.get(key)
                    if current_value is None:
                        active.pop(key, None)
                        continue
                    trace.values.append(current_value)
                    recovered = _recovered_to_baseline(trace.state, trace.values)
                    if len(trace.values) >= maximum_event_samples or (
                        len(trace.values) >= 5 and recovered
                    ):
                        match = _temporal_match(
                            trace.state,
                            trace.values,
                            event_start_sample=trace.started_sample,
                        )
                        if match is not None:
                            with self._lock:
                                monitor.event_counts[key] = monitor.event_counts.get(key, 0) + 1
                                existing = monitor.matches.get(key)
                                if existing is None or (
                                    match.candidate.score > existing.candidate.score
                                ):
                                    monitor.matches[key] = match
                        active.pop(key, None)

                if len(active) < 10_000:
                    for key, current_value in current.items():
                        if key in active:
                            continue
                        prior = previous.get(key)
                        state = state_by_key.get(key)
                        if (
                            prior is not None
                            and state is not None
                            and stable_counts.get(key, 0) >= 3
                            and _damage_drop_detected(state, prior, current_value)
                        ):
                            active[key] = _ActiveTemporalTrace(
                                state=state,
                                values=[prior, current_value],
                                started_sample=monitor.sample_count,
                            )

                for key, current_value in current.items():
                    prior = previous.get(key)
                    state = state_by_key.get(key)
                    if (
                        prior is not None
                        and state is not None
                        and _monitor_values_stable(state, prior, current_value)
                    ):
                        stable_counts[key] = min(stable_counts.get(key, 0) + 1, 1000)
                    else:
                        stable_counts[key] = 0

                previous = current
                with self._lock:
                    monitor.sample_count += 1
                    monitor.sampled_field_count = max(
                        monitor.sampled_field_count,
                        len(current),
                    )

            for key, trace in active.items():
                match = _temporal_match(
                    trace.state,
                    trace.values,
                    event_start_sample=trace.started_sample,
                )
                if match is not None:
                    with self._lock:
                        monitor.event_counts[key] = monitor.event_counts.get(key, 0) + 1
                        existing = monitor.matches.get(key)
                        if existing is None or match.candidate.score > existing.candidate.score:
                            monitor.matches[key] = match
            with self._lock:
                monitor.state = "stopped" if monitor.stop_event.is_set() else "completed"
                monitor.waiting_for_game = False
                monitor.finished_at = datetime.now(UTC)
        except Exception as exc:  # noqa: BLE001 - retained as bounded monitor status
            with self._lock:
                monitor.state = "failed"
                monitor.waiting_for_game = False
                monitor.finished_at = datetime.now(UTC)
                monitor.warnings.append(f"Background damage monitor failed: {exc}")

    def _read_field_snapshot(
        self,
        record: _GasRecord,
        session: ProcessSession,
        states: list[_FieldState],
    ) -> dict[tuple[int, ValueType], int | float]:
        by_object: dict[int, list[_FieldState]] = {}
        for state in states:
            by_object.setdefault(state.object_address, []).append(state)

        snapshot: dict[tuple[int, ValueType], int | float] = {}
        for object_address, object_states in by_object.items():
            length = max(state.offset + value_size(state.value_type) for state in object_states)
            length = min(length, self.settings.max_unreal_object_bytes)
            try:
                data = self.backend.read(session.backend_handle, object_address, length)
            except BackendError:
                continue
            for state in object_states:
                width = value_size(state.value_type)
                end = state.offset + width
                if end > len(data):
                    continue
                snapshot[(state.address, state.value_type)] = decode_value(
                    state.value_type,
                    data[state.offset : end],
                )
        return snapshot

    def save_profile(
        self,
        scan_id: str,
        session: ProcessSession,
        address: int,
        value_type: ValueType,
        name: str = "Health",
    ) -> UnrealGasProfile:
        with self._lock:
            record = self._get(scan_id)
            if record.session_id != session.id:
                raise NotFoundError("Unreal/GAS scan does not belong to this session")
            state = record.fields.get((address, value_type))
            if state is None or not state.active:
                raise NotFoundError("the selected address is not an active Unreal/GAS candidate")
            candidate = self._candidate(record, state)
        pattern = record.gworld.selected_pattern
        module_offset = record.gworld.gworld_module_offset
        if pattern is None or module_offset is None:
            raise ScanLimitError("the scan has no restart-stable GWorld locator")
        profile_id = uuid4().hex
        profile_path = self.settings.game_profile_directory / f"{profile_id}.json"
        profile = UnrealGasProfile(
            id=profile_id,
            name=name.strip() or "Health",
            process_name=session.process_name,
            executable=session.executable,
            game_build_identity=executable_build_identity(session.executable),
            selected_pattern=pattern,
            gworld_module_offset=module_offset,
            object_path=state.object_path,
            field_offset=state.offset,
            value_type=state.value_type,
            likely_max_offset=(
                candidate.likely_max_address - state.object_address
                if candidate.likely_max_address is not None
                else None
            ),
            saved_path=str(profile_path.resolve()),
        )
        profile_path.parent.mkdir(parents=True, exist_ok=True)
        temporary = profile_path.with_suffix(".tmp")
        temporary.write_text(profile.model_dump_json(indent=2), encoding="utf-8")
        temporary.replace(profile_path)
        register_confirmed_profile(
            self.settings,
            session,
            profile,
            current_value=candidate.value,
            maximum_value=candidate.likely_max_value,
        )
        return profile

    def read_profile(
        self,
        session: ProcessSession,
        profile_id: str,
    ) -> UnrealGasProfileValue:
        if re.fullmatch(r"[0-9a-f]{32}", profile_id) is None:
            raise NotFoundError("the Unreal/GAS profile ID is invalid")
        profile_path = self.settings.game_profile_directory / f"{profile_id}.json"
        if not profile_path.is_file():
            raise NotFoundError(f"Unreal/GAS profile {profile_id} was not found")
        try:
            profile = UnrealGasProfile.model_validate_json(profile_path.read_text(encoding="utf-8"))
        except (OSError, ValueError) as exc:
            raise ScanLimitError("the saved Unreal/GAS profile is invalid") from exc
        if profile.id != profile_id:
            raise ScanLimitError("the saved Unreal/GAS profile ID does not match its file")
        current_build_identity = executable_build_identity(session.executable)
        if (
            profile.game_build_identity is not None
            and profile.game_build_identity != current_build_identity
        ):
            raise ScanLimitError("the saved profile belongs to a different game build")
        if (
            profile.process_name.casefold() != session.process_name.casefold()
            and profile.game_build_identity != current_build_identity
        ):
            raise ScanLimitError("the saved profile belongs to a different game process")
        if profile.field_offset > self.settings.max_unreal_object_bytes:
            raise ScanLimitError("the saved stat offset exceeds the object scan limit")
        if (
            profile.likely_max_offset is not None
            and profile.likely_max_offset > self.settings.max_unreal_object_bytes
        ):
            raise ScanLimitError("the saved maximum offset exceeds the object scan limit")
        regions = self.backend.regions(session.backend_handle)
        memory = _MemoryMap(regions)
        with self._lock:
            discovery = self._discoveries.get(session.id)
        if discovery is None or not self._discovery_is_live(session, memory, discovery):
            discovery = locate_gworld(
                self.backend,
                session,
                self.settings,
                regions=regions,
            )
            with self._lock:
                self._discoveries[session.id] = discovery
        if discovery.world_address is None:
            raise ScanLimitError("GWorld could not be validated for the saved profile")
        object_address = self._resolve_object_path(
            session,
            memory,
            discovery.world_address,
            profile.object_path,
        )
        address = object_address + profile.field_offset
        width = value_size(profile.value_type)
        if not memory.readable(address, width):
            raise ScanLimitError("the saved stat field is no longer readable")
        value = decode_value(
            profile.value_type,
            self.backend.read(session.backend_handle, address, width),
        )
        max_address = None
        max_value = None
        if profile.likely_max_offset is not None:
            candidate = object_address + profile.likely_max_offset
            if memory.readable(candidate, width):
                max_address = candidate
                max_value = decode_value(
                    profile.value_type,
                    self.backend.read(session.backend_handle, candidate, width),
                )
        return UnrealGasProfileValue(
            profile=profile,
            address=address,
            value=value,
            likely_max_address=max_address,
            likely_max_value=max_value,
            resolved_object_address=object_address,
        )

    def _resolve_object_path(
        self,
        session: ProcessSession,
        memory: _MemoryMap,
        world: int,
        path: str,
    ) -> int:
        if not path.startswith("GWorld"):
            raise ScanLimitError("the saved object path is not rooted at GWorld")
        current = world
        segments = path.split("->")[1:]
        if len(segments) > 8:
            raise ScanLimitError("the saved object path exceeds the depth limit")
        for segment in segments:
            match = re.fullmatch(r"\+0x([0-9A-Fa-f]+)(?:\[(\d+)\])?", segment)
            if match is None:
                raise ScanLimitError("the saved object path contains an invalid step")
            offset = int(match.group(1), 16)
            if offset > 0x10000:
                raise ScanLimitError("a saved object-path offset exceeds the safety limit")
            index_text = match.group(2)
            try:
                if index_text is None:
                    current = struct.unpack(
                        "<Q",
                        self.backend.read(
                            session.backend_handle,
                            current + offset,
                            8,
                        ),
                    )[0]
                else:
                    pointer, count, capacity = struct.unpack(
                        "<Qii",
                        self.backend.read(
                            session.backend_handle,
                            current + offset,
                            16,
                        ),
                    )
                    index = int(index_text)
                    if not (0 <= index < count <= capacity <= 8192):
                        raise ScanLimitError("a saved object-array step is out of range")
                    current = struct.unpack(
                        "<Q",
                        self.backend.read(
                            session.backend_handle,
                            pointer + index * 8,
                            8,
                        ),
                    )[0]
            except (BackendError, struct.error) as exc:
                raise ScanLimitError("a saved object-path step could not be read") from exc
            if not _plausible_uobject(self.backend, session, memory, current):
                raise ScanLimitError("a saved object-path step failed UObject validation")
        return current

    def remove_session(self, session_id: str) -> None:
        self.stop_session_monitors(session_id)
        with self._lock:
            for scan_id in [
                key for key, record in self._records.items() if record.session_id == session_id
            ]:
                self._records.pop(scan_id, None)
            self._discoveries.pop(session_id, None)
            self._name_pools.pop(session_id, None)

    def _discovery_is_live(
        self,
        session: ProcessSession,
        memory: _MemoryMap,
        discovery: UnrealDiscoveryResult,
    ) -> bool:
        if discovery.gworld_slot is None or discovery.world_address is None:
            return False
        try:
            current = struct.unpack(
                "<Q",
                self.backend.read(session.backend_handle, discovery.gworld_slot, 8),
            )[0]
        except (BackendError, struct.error):
            return False
        return current == discovery.world_address and _plausible_uobject(
            self.backend,
            session,
            memory,
            current,
        )

    def _get(self, scan_id: str) -> _GasRecord:
        record = self._records.get(scan_id)
        if record is None:
            raise NotFoundError(f"Unreal/GAS scan {scan_id} was not found")
        return record

    def _walk_objects(
        self,
        session: ProcessSession,
        memory: _MemoryMap,
        world: int,
    ) -> list[_ObjectNode]:
        queue: list[_ObjectNode] = [_ObjectNode(0, 0, world, "GWorld", 0)]
        seen: set[int] = set()
        result: list[_ObjectNode] = []
        sequence = 1
        while queue and len(result) < self.settings.max_unreal_objects:
            node = heapq.heappop(queue)
            if node.address in seen:
                continue
            seen.add(node.address)
            if not _plausible_uobject(self.backend, session, memory, node.address):
                continue
            result.append(node)
            if node.depth >= 6:
                continue
            region = memory.region(node.address)
            if region is None:
                continue
            length = min(0x800, region.end_address - node.address)
            try:
                data = self.backend.read(session.backend_handle, node.address, length)
            except BackendError:
                continue
            for offset in range(0x28, len(data) - 8 + 1, 8):
                child = struct.unpack_from("<Q", data, offset)[0]
                if child in seen or not _plausible_uobject(self.backend, session, memory, child):
                    continue
                priority = node.priority + 20 + node.depth * 5 + _path_bonus(node.depth, offset)
                heapq.heappush(
                    queue,
                    _ObjectNode(
                        priority,
                        sequence,
                        child,
                        f"{node.path}->+0x{offset:X}",
                        node.depth + 1,
                    ),
                )
                sequence += 1
            for offset in range(0x28, len(data) - 16 + 1, 8):
                pointer, count, capacity = struct.unpack_from("<Qii", data, offset)
                if not (0 < count <= capacity <= 8192):
                    continue
                sample_count = min(count, 32)
                if not memory.readable(pointer, sample_count * 8):
                    continue
                try:
                    values = struct.unpack(
                        f"<{sample_count}Q",
                        self.backend.read(session.backend_handle, pointer, sample_count * 8),
                    )
                except (BackendError, struct.error):
                    continue
                plausible = [
                    (index, child)
                    for index, child in enumerate(values)
                    if child not in seen
                    and _plausible_uobject(self.backend, session, memory, child)
                ]
                if not plausible:
                    continue
                for index, child in plausible:
                    priority = node.priority + 25 + node.depth * 5 + _path_bonus(node.depth, offset)
                    heapq.heappush(
                        queue,
                        _ObjectNode(
                            priority,
                            sequence,
                            child,
                            f"{node.path}->+0x{offset:X}[{index}]",
                            node.depth + 1,
                        ),
                    )
                    sequence += 1
        return result

    def _candidate(self, record: _GasRecord, state: _FieldState) -> UnrealGasCandidate:
        max_field = None
        if state.decreased or state.increased:
            max_field = _likely_max_field(record.fields.values(), state)
        elif record.stage == "table_guided":
            max_field = _table_likely_max_field(record.fields.values(), state)
        evidence: list[str] = []
        if state.decreased:
            evidence.append(f"decreased in {state.decreased} snapshot(s)")
        if state.increased:
            evidence.append(f"increased in {state.increased} snapshot(s)")
        if state.unchanged:
            evidence.append(f"unchanged in {state.unchanged} snapshot(s)")
        if max_field is not None:
            evidence.append("paired with a stable same-object maximum candidate")
        evidence.extend(state.advisory_evidence)
        if state.value_type is ValueType.F32 and state.offset % 8 == 4:
            evidence.append("matches the usual GAS CurrentValue alignment")
        return UnrealGasCandidate(
            address=state.address,
            object_address=state.object_address,
            object_path=state.object_path,
            field_offset=state.offset,
            value_type=state.value_type,
            value=state.previous,
            likely_max_address=max_field.address if max_field else None,
            likely_max_value=max_field.previous if max_field else None,
            score=_field_score(state) + (20 if max_field else 0),
            evidence=evidence,
        )


def _path_bonus(depth: int, offset: int) -> int:
    if depth == 0 and offset in {0x180, 0x1A0, 0x1B8, 0x330}:
        return -120
    if depth == 1 and offset == 0x38:
        return -100
    if offset == 0x30:
        return -50
    if 0x250 <= offset <= 0x350:
        return -30
    return min(offset // 32, 40)


def _plausible_stat_value(value_type: ValueType, value: int | float) -> bool:
    if value_type in {ValueType.F32, ValueType.F64}:
        number = float(value)
        return math.isfinite(number) and 1e-6 <= number <= 1_000_000
    return 0 < int(value) <= 1_000_000


def _comparison_matches(
    value_type: ValueType,
    previous: int | float,
    current: int | float,
    comparison: Comparison,
    exact: int | float | None,
) -> bool:
    equal = values_equal(value_type, current, previous)
    if comparison is Comparison.UNCHANGED:
        return equal
    if comparison is Comparison.CHANGED:
        return not equal
    if comparison is Comparison.DECREASED:
        return not equal and current < previous
    if comparison is Comparison.INCREASED:
        return not equal and current > previous
    return exact is not None and values_equal(value_type, current, exact)


def _field_score(state: _FieldState) -> int:
    score = state.decreased * 35 + state.increased * 25 + state.unchanged * 8 + state.advisory_score
    if state.value_type is ValueType.F32:
        score += 8
        if state.offset % 8 == 4:
            score += 12
    if 0 <= float(state.previous) <= 1000:
        score += 5
    if "->+0x180" in state.object_path:
        score += 8
    if "->+0x38[" in state.object_path:
        score += 8
    return max(score, 0)


_PROFILE_FEATURE_KEYWORDS: tuple[tuple[str, tuple[str, ...]], ...] = (
    ("Health", ("health", "vitality", "hitpoint", "hit_point")),
    ("Stamina", ("stamina", "endurance")),
    ("Mana / magic resource", ("mana", "magic", "spellresource", "spell_resource")),
    ("Currency / gold", ("currency", "money", "gold", "wallet", "economy")),
    ("Ammunition", ("ammo", "ammunition")),
    ("Inventory quantity", ("inventory", "itemcount", "item_count", "stack")),
    ("Experience / level", ("experience", " xp", "levelprogress", "level_progress")),
    ("Cooldown", ("cooldown", "cool_down", "recharge")),
    ("Jump height / jump tuning", ("jump", "verticalboost", "vertical_boost")),
    (
        "Movement speed / traversal tuning",
        ("movement", "movespeed", "move_speed", "locomotion", "traversal"),
    ),
)
_PROFILE_USEFUL_LABELS = {
    "Health",
    "Stamina",
    "Mana / magic resource",
    "Currency / gold",
    "Ammunition",
    "Inventory quantity",
    "Experience / level",
    "Cooldown",
}
_PROFILE_SECONDARY_LABELS = {
    "Jump height / jump tuning",
    "Movement speed / traversal tuning",
}
_PROFILE_ENGINE_NOISE = re.compile(
    r"render|shader|texture|material|lighting|\blight\b|mesh|\blod\b|particle|"
    r"\bvfx\b|animation|animinstance|skeletal|camera|viewport|transform|position|"
    r"rotation|bounds|worldpartition|world.?stream|level.?stream|navigation|navmesh|"
    r"collision|audio|sound|replicationgraph|netdriver|area.?volume|zone.?volume",
    re.IGNORECASE,
)
_PROFILE_MOVEMENT_CONTEXT = re.compile(
    r"movement|movespeed|move_speed|locomotion|traversal|jump|gravity|flight|sprint",
    re.IGNORECASE,
)


def _rank_profile_candidates(
    record: _GasRecord,
    stats_by_key: dict[tuple[int, ValueType], _ProfileStats],
    *,
    sample_count: int,
    limit: int,
) -> list[GameProfileCandidate]:
    ranked: list[GameProfileCandidate] = []
    states_by_key = record.fields
    stable_by_object_type: dict[tuple[int, ValueType], list[tuple[_FieldState, _ProfileStats]]] = {}
    for key, candidate_stats in stats_by_key.items():
        candidate_state = states_by_key.get(key)
        if candidate_state is None or candidate_stats.changed:
            continue
        stable_by_object_type.setdefault(
            (candidate_state.object_address, candidate_state.value_type),
            [],
        ).append((candidate_state, candidate_stats))
    for key, stats in stats_by_key.items():
        state = states_by_key.get(key)
        if state is None:
            continue
        suggestions, name_evidence = _profile_feature_suggestions(state, stats, sample_count)
        category, relevance, disposition_evidence = _profile_candidate_classification(
            state,
            suggestions,
        )
        if relevance == "ignored":
            continue
        if stats.changed == 0 and state.advisory_score == 0 and not suggestions:
            continue

        likely_max = _profile_likely_max_field(
            state,
            stats,
            stable_by_object_type.get((state.object_address, state.value_type), []),
        )
        evidence = [*name_evidence, disposition_evidence]
        if state.object_name or state.class_name:
            identity = " / ".join(item for item in (state.object_name, state.class_name) if item)
            evidence.append(f"live Unreal object identity: {identity}")
        if stats.changed:
            evidence.append(
                f"changed in {stats.changed} samples ({stats.increased} up, {stats.decreased} down)"
            )
        else:
            evidence.append("remained stable during the captured play window")
        evidence.extend(state.advisory_evidence)
        if likely_max is not None:
            evidence.append("paired with a stable same-object maximum candidate")

        named = bool(name_evidence or state.advisory_evidence)
        changed_ratio = stats.changed / max(sample_count - 1, 1)
        score = state.advisory_score
        score += min(stats.changed, 20) * 5
        score += min(stats.increased, 10) * 3 + min(stats.decreased, 10) * 3
        score += min(len(stats.distinct_values), 16)
        score += 55 if named else 0
        score += 25 if likely_max is not None else 0
        if 0.0 <= float(stats.minimum) <= float(stats.maximum) <= 1.0:
            score += 15
        if relevance == "useful":
            score += 30
        elif relevance == "secondary":
            score = max(0, score - 35)
        else:
            score = max(0, score - 15)
        identity = f"{state.object_name} {state.class_name}".casefold()
        movement_named = any(
            token in identity for token in ("movement", "locomotion", "traversal", "jump")
        )
        if changed_ratio > 0.8 and not movement_named and state.advisory_score == 0:
            score = max(0, score - 35)
            evidence.append("high-frequency noise lowers confidence")

        confidence = 0.2
        confidence += min(state.advisory_score / 400, 0.35)
        confidence += 0.2 if name_evidence else 0
        confidence += 0.12 if stats.changed else 0
        confidence += 0.1 if stats.increased and stats.decreased else 0
        confidence += 0.08 if likely_max is not None else 0
        if changed_ratio > 0.8 and not movement_named:
            confidence -= 0.15
        if relevance == "secondary":
            confidence -= 0.12
        elif relevance == "unknown":
            confidence -= 0.08
        confidence = min(max(confidence, 0.05), 0.95)

        ranked.append(
            GameProfileCandidate(
                address=state.address,
                object_address=state.object_address,
                object_path=state.object_path,
                object_name=state.object_name,
                class_name=state.class_name,
                field_offset=state.offset,
                value_type=state.value_type,
                baseline_value=stats.baseline,
                current_value=stats.current,
                minimum_value=stats.minimum,
                maximum_value=stats.maximum,
                changed_samples=stats.changed,
                increased_samples=stats.increased,
                decreased_samples=stats.decreased,
                unchanged_samples=stats.unchanged,
                distinct_value_count=max(1, len(stats.distinct_values)),
                likely_max_address=likely_max[0].address if likely_max else None,
                likely_max_value=likely_max[1].current if likely_max else None,
                suggested_features=suggestions,
                category=category,
                relevance=relevance,
                confidence=confidence,
                score=max(score, 0),
                evidence=evidence,
            )
        )

    ranked.sort(
        key=lambda item: (
            {"useful": 0, "secondary": 1, "unknown": 2}.get(item.relevance, 3),
            -item.score,
            -item.confidence,
            item.address,
            item.value_type.value,
        )
    )
    deduplicated: list[GameProfileCandidate] = []
    seen: set[tuple[int, int]] = set()
    for candidate in ranked:
        identity = (candidate.object_address, candidate.field_offset)
        if identity in seen:
            continue
        seen.add(identity)
        deduplicated.append(candidate)
        if len(deduplicated) >= limit:
            break
    return deduplicated


def _profile_candidate_classification(
    state: _FieldState,
    suggestions: list[str],
) -> tuple[str, str, str]:
    useful = next((item for item in suggestions if item in _PROFILE_USEFUL_LABELS), None)
    if useful is not None:
        return "player_resource", "useful", f"kept as a useful player value: {useful}"

    searchable = " ".join([state.object_name, state.class_name, *state.advisory_evidence])
    noise = _PROFILE_ENGINE_NOISE.search(searchable)
    if noise is not None:
        return (
            "engine_plumbing",
            "ignored",
            f"ignored engine/rendering/world context: {noise.group(0)}",
        )

    secondary = next(
        (item for item in suggestions if item in _PROFILE_SECONDARY_LABELS),
        None,
    )
    movement = _PROFILE_MOVEMENT_CONTEXT.search(searchable)
    if secondary is not None or movement is not None:
        label = secondary or (movement.group(0) if movement is not None else "movement")
        return (
            "movement_tuning",
            "secondary",
            f"kept in the optional movement/tuning group: {label}",
        )

    if suggestions:
        return (
            "behavior_candidate",
            "unknown",
            "kept only as an unclassified behavior candidate",
        )
    return "unclassified", "unknown", "kept only as low-priority unclassified data"


def _ignored_profile_field_count(
    record: _GasRecord,
    stats_by_key: dict[tuple[int, ValueType], _ProfileStats],
    sample_count: int,
) -> int:
    ignored = 0
    for key, stats in stats_by_key.items():
        state = record.fields.get(key)
        if state is None:
            continue
        suggestions, _ = _profile_feature_suggestions(state, stats, sample_count)
        _, relevance, _ = _profile_candidate_classification(state, suggestions)
        if relevance == "ignored":
            ignored += 1
    return ignored


def _profile_feature_suggestions(
    state: _FieldState,
    stats: _ProfileStats,
    sample_count: int,
) -> tuple[list[str], list[str]]:
    searchable = " ".join(
        [state.object_name, state.class_name, *state.advisory_evidence]
    ).casefold()
    suggestions: list[str] = []
    evidence: list[str] = []
    for label, keywords in _PROFILE_FEATURE_KEYWORDS:
        matched = next((token for token in keywords if token in searchable), None)
        if matched is None:
            continue
        suggestions.append(label)
        evidence.append(f"named engine/table context suggests {label.casefold()}")

    normalized = 0.0 <= float(stats.minimum) <= float(stats.maximum) <= 1.0
    if stats.increased and stats.decreased:
        label = (
            "Normalized resource (health / stamina / mana)"
            if normalized
            else "Current resource (health / stamina / mana)"
        )
        if label not in suggestions:
            suggestions.append(label)
        evidence.append("bidirectional play changes match a refillable resource")
    elif stats.changed and state.value_type in {ValueType.I16, ValueType.I32}:
        change_ratio = stats.changed / max(sample_count - 1, 1)
        if change_ratio <= 0.5:
            label = "Counter (currency / ammo / inventory / XP)"
            if label not in suggestions:
                suggestions.append(label)
            evidence.append("stepwise integer changes match a gameplay counter")
    return suggestions, evidence


def _profile_likely_max_field(
    state: _FieldState,
    stats: _ProfileStats,
    stable_fields: list[tuple[_FieldState, _ProfileStats]],
) -> tuple[_FieldState, _ProfileStats] | None:
    choices: list[tuple[int, _FieldState, _ProfileStats]] = []
    for candidate, candidate_stats in stable_fields:
        if candidate.address == state.address:
            continue
        if float(candidate_stats.current) < float(stats.maximum):
            continue
        distance = abs(candidate.offset - state.offset)
        choices.append((distance, candidate, candidate_stats))
    if not choices:
        return None
    _, field_state, field_stats = min(choices, key=lambda item: item[0])
    return field_state, field_stats


def _table_field_advisory(
    offset: int,
    *,
    health_offset: int,
    max_health_offset: int,
    replica_percent_offset: int,
    nested: bool = False,
) -> tuple[int, list[str]]:
    score = 0
    evidence: list[str] = []
    if not nested:
        health_distance = abs(offset - health_offset)
        if health_distance == 0:
            score += 120
            evidence.append("matches the table's advisory Health field offset")
        elif health_distance <= 0x100:
            score += 50 - health_distance // 8
            evidence.append("lies near the table's advisory Health field offset")
        elif health_distance <= 0x400:
            score += 15

        max_distance = min(abs(offset - (max_health_offset + delta)) for delta in (0, 4, 8, 12))
        if max_distance == 0:
            score += 100
            evidence.append("matches the table's advisory MaxHealth value block")
        elif max_distance <= 0x100:
            score += 35 - max_distance // 16
            evidence.append("lies near the table's advisory MaxHealth value block")
    else:
        replica_distance = abs(offset - replica_percent_offset)
        if replica_distance == 0:
            score += 100
            evidence.append("matches the table's advisory ReplicaHealthPercent offset")
        elif replica_distance <= 0x80:
            score += 25 - replica_distance // 8
            evidence.append("lies near the table's advisory health-percentage offset")
    return max(score, 0), evidence


def _table_object_advisory(object_name: str, class_name: str) -> tuple[int, list[str]]:
    labels = [item for item in (object_name, class_name) if item]
    if not labels:
        return 0, []
    text = " ".join(labels).casefold()
    score = 0
    if "bipedstateinfo" in text or "cachedcharacterstateinfo" in text:
        score += 140
    elif "stateinfo" in text:
        score += 100
    if "attribut" in text or "abilitysystem" in text:
        score += 80
    if "health" in text:
        score += 80
    if "statedata" in text:
        score += 60
    evidence = [
        "resolved Unreal object identity: "
        + (f"{object_name} ({class_name})" if class_name else object_name)
    ]
    return score, evidence


def _table_likely_max_field(
    fields: Iterable[_FieldState],
    current: _FieldState,
) -> _FieldState | None:
    if not any("Health field offset" in item for item in current.advisory_evidence):
        return None
    options = [
        item
        for item in fields
        if item is not current
        and item.object_address == current.object_address
        and item.value_type is current.value_type
        and item.changed == 0
        and float(item.previous) >= float(current.previous)
        and any("MaxHealth value block" in evidence for evidence in item.advisory_evidence)
    ]
    return min(options, key=lambda item: item.offset) if options else None


def _damage_tolerance(state: _FieldState, baseline: int | float) -> float:
    number = abs(float(baseline))
    if state.value_type in {ValueType.F32, ValueType.F64}:
        return max(number * 0.005, 0.0001)
    return max(number * 0.005, 1.0)


def _process_is_foreground(pid: int) -> bool:
    if sys.platform != "win32":
        return True
    try:
        user32 = ctypes.WinDLL("user32", use_last_error=True)
        window = user32.GetForegroundWindow()
        if not window:
            return False
        process_id = ctypes.c_ulong()
        user32.GetWindowThreadProcessId(window, ctypes.byref(process_id))
        return int(process_id.value) == pid
    except (AttributeError, OSError):
        return True


def _monitor_values_stable(
    state: _FieldState,
    previous: int | float,
    current: int | float,
) -> bool:
    if state.value_type not in {ValueType.F32, ValueType.F64}:
        return previous == current
    before = float(previous)
    after = float(current)
    tolerance = max(abs(before) * 0.00001, 0.000001)
    return math.isfinite(before) and math.isfinite(after) and abs(before - after) <= tolerance


def _damage_drop_detected(
    state: _FieldState,
    previous: int | float,
    current: int | float,
) -> bool:
    before = float(previous)
    after = float(current)
    if not math.isfinite(before) or not math.isfinite(after) or before <= 0:
        return False
    tolerance = _damage_tolerance(state, previous)
    return before - after >= tolerance and after >= -(abs(before) * 0.05 + tolerance)


def _recovered_to_baseline(
    state: _FieldState,
    values: list[int | float],
) -> bool:
    if len(values) < 3:
        return False
    baseline = float(values[0])
    current = float(values[-1])
    tolerance = _damage_tolerance(state, values[0])
    return current >= baseline - tolerance


def _temporal_match(
    state: _FieldState,
    values: list[int | float],
    *,
    event_start_sample: int | None = None,
) -> _TemporalMatch | None:
    if len(values) < 5:
        return None
    numeric = [float(value) for value in values]
    if any(not math.isfinite(value) for value in numeric):
        return None

    step_drops = [numeric[index - 1] - numeric[index] for index in range(1, len(numeric))]
    drop_sample = max(range(1, len(numeric)), key=lambda index: step_drops[index - 1])
    baseline = max(numeric[:drop_sample])
    if baseline < 0.8 or baseline > 10_000:
        return None
    tolerance = (
        max(abs(baseline) * 0.005, 0.0001)
        if state.value_type in {ValueType.F32, ValueType.F64}
        else max(abs(baseline) * 0.005, 1.0)
    )
    if step_drops[drop_sample - 1] < tolerance:
        return None

    minimum_sample = min(
        range(drop_sample, len(numeric)),
        key=lambda index: numeric[index],
    )
    if minimum_sample > len(numeric) - 3:
        return None
    lowest = numeric[minimum_sample]
    total_drop = baseline - lowest
    if total_drop < tolerance or lowest < -(abs(baseline) * 0.05 + tolerance):
        return None

    recovery_values = numeric[minimum_sample:]
    step_tolerance = (
        max(tolerance * 0.02, 0.000001)
        if state.value_type in {ValueType.F32, ValueType.F64}
        else 0.5
    )
    recovery_steps = sum(
        1
        for previous, current in zip(recovery_values, recovery_values[1:], strict=False)
        if current - previous > step_tolerance
    )
    if recovery_steps < 2:
        return None
    decline_steps = sum(
        1
        for previous, current in zip(recovery_values, recovery_values[1:], strict=False)
        if previous - current > step_tolerance
    )
    if decline_steps > 1:
        return None
    recovered = max(recovery_values) - lowest
    if recovered < max(tolerance, total_drop * 0.05):
        return None
    if max(recovery_values) > baseline + total_drop * 0.10 + tolerance:
        return None

    recovery_fraction = recovered / total_drop
    if recovery_fraction > 1.10:
        return None
    drop_fraction = total_drop / max(abs(baseline), tolerance)
    shape = tuple(max(-0.25, min(1.25, (value - lowest) / total_drop)) for value in numeric)
    score = 50
    score += min(30, round(drop_fraction * 40))
    score += min(25, round(recovery_fraction * 25))
    score += min(15, recovery_steps * 3)
    evidence = [
        "captured a sharp decrease during the live window",
        f"recovered across {recovery_steps} separate samples",
        f"recovered {recovery_fraction:.0%} of the observed drop",
    ]
    if state.value_type is ValueType.F32:
        score += 8
        evidence.append("uses the common Unreal f32 representation")
        if state.offset % 8 == 4:
            score += 8
            evidence.append("matches the usual GAS CurrentValue alignment")
    if state.advisory_score:
        score += min(state.advisory_score, 80)
        evidence.extend(state.advisory_evidence)
    return _TemporalMatch(
        candidate=UnrealGasTemporalCandidate(
            address=state.address,
            object_address=state.object_address,
            object_path=state.object_path,
            field_offset=state.offset,
            value_type=state.value_type,
            baseline_value=values[max(0, drop_sample - 1)],
            lowest_value=values[minimum_sample],
            final_value=values[-1],
            drop_sample=drop_sample,
            minimum_sample=minimum_sample,
            recovery_steps=recovery_steps,
            recovery_fraction=recovery_fraction,
            event_sample=(
                event_start_sample + drop_sample if event_start_sample is not None else None
            ),
            score=score,
            evidence=evidence,
        ),
        shape=shape,
    )


def _shape_similarity(left: tuple[float, ...], right: tuple[float, ...]) -> float:
    best = 0.0
    for shift in (-1, 0, 1):
        left_start = -shift if shift < 0 else 0
        right_start = shift if shift > 0 else 0
        size = min(len(left) - left_start, len(right) - right_start)
        if size < 4:
            continue
        first = left[left_start : left_start + size]
        second = right[right_start : right_start + size]
        mean_first = sum(first) / len(first)
        mean_second = sum(second) / len(second)
        numerator = sum(
            (one - mean_first) * (two - mean_second) for one, two in zip(first, second, strict=True)
        )
        first_scale = math.sqrt(sum((value - mean_first) ** 2 for value in first))
        second_scale = math.sqrt(sum((value - mean_second) ** 2 for value in second))
        if first_scale == 0 or second_scale == 0:
            continue
        correlation = numerator / (first_scale * second_scale)
        distance = sum(abs(one - two) for one, two in zip(first, second, strict=True)) / len(first)
        if distance <= 0.15:
            best = max(best, correlation)
    return best


def _group_temporal_matches(
    matches: list[_TemporalMatch],
    *,
    limit: int,
) -> list[UnrealGasCandidateGroup]:
    remaining = sorted(matches, key=lambda item: (-item.candidate.score, item.candidate.address))
    pending_groups: list[tuple[int, list[_TemporalMatch]]] = []
    while remaining:
        seed = remaining.pop(0)
        cluster = [seed]
        retained: list[_TemporalMatch] = []
        for item in remaining:
            seed_event = seed.candidate.event_sample
            item_event = item.candidate.event_sample
            same_event = (
                abs(item_event - seed_event) <= 1
                if seed_event is not None and item_event is not None
                else abs(item.candidate.drop_sample - seed.candidate.drop_sample) <= 1
            )
            synchronized = same_event and _shape_similarity(seed.shape, item.shape) >= 0.98
            if synchronized:
                cluster.append(item)
            else:
                retained.append(item)
        remaining = retained
        cluster.sort(key=lambda item: (-item.candidate.score, item.candidate.address))
        group_score = cluster[0].candidate.score + min(len(cluster) - 1, 3) * 15
        group_score += min(cluster[0].candidate.event_count - 1, 4) * 10
        if len({item.candidate.object_address for item in cluster[:4]}) == 1:
            group_score += 8
        pending_groups.append((group_score, cluster))

    pending_groups.sort(key=lambda item: (-item[0], item[1][0].candidate.address))
    groups: list[UnrealGasCandidateGroup] = []
    for index, (score, cluster) in enumerate(pending_groups[:limit], start=1):
        selected = cluster[:4]
        evidence = [
            "all members share the same damage-and-refill curve",
            "single-jump death/respawn changes were rejected",
        ]
        if len(cluster) > 1:
            evidence.append(f"{len(cluster)} correlated addresses moved at the same time")
        repeated = max(item.candidate.event_count for item in selected)
        if repeated > 1:
            evidence.append(f"the leading candidate repeated across {repeated} events")
        if len({item.candidate.object_address for item in selected}) == 1:
            evidence.append("members belong to the same live Unreal object")
        groups.append(
            UnrealGasCandidateGroup(
                id=f"health-group-{index}",
                score=score,
                member_count=len(selected),
                correlated_address_count=len(cluster),
                members=[item.candidate for item in selected],
                evidence=evidence,
            )
        )
    return groups


def _likely_max_field(
    fields: Iterable[_FieldState],
    current: _FieldState,
) -> _FieldState | None:
    options: list[tuple[int, _FieldState]] = []
    observed_max = max(float(item) for item in current.observations)
    for item in fields:
        if item is current or item.object_address != current.object_address:
            continue
        if item.value_type is not current.value_type or item.changed != 0:
            continue
        if float(item.previous) < observed_max:
            continue
        distance = abs(item.offset - current.offset)
        if distance > 0x400:
            continue
        alignment_penalty = 0 if item.offset % 8 == current.offset % 8 else 50
        value_penalty = int(min(abs(float(item.previous) - observed_max), 1000))
        options.append((distance + alignment_penalty + value_penalty, item))
    return min(options, key=lambda pair: pair[0])[1] if options else None


def _locate_player_pawn(
    backend: MemoryBackend,
    session: ProcessSession,
    memory: _MemoryMap,
    world: int,
    name_pool: _FNamePool | None,
) -> _ObjectNode | None:
    try:
        game_instance = struct.unpack(
            "<Q",
            backend.read(session.backend_handle, world + 0x330, 8),
        )[0]
        local_players, count, capacity = struct.unpack(
            "<Qii",
            backend.read(session.backend_handle, game_instance + 0x38, 16),
        )
        if not (0 < count <= capacity <= 8):
            return None
        local_player = struct.unpack(
            "<Q",
            backend.read(session.backend_handle, local_players, 8),
        )[0]
        controller = struct.unpack(
            "<Q",
            backend.read(session.backend_handle, local_player + 0x30, 8),
        )[0]
    except (BackendError, struct.error):
        return None
    if not all(
        _plausible_uobject(backend, session, memory, address)
        for address in (game_instance, local_player, controller)
    ):
        return None

    path_prefix = "GWorld->+0x330->+0x38[0]->+0x30"
    preferred_offsets = (0x278, 0x280, 0x288, 0x290, 0x298, 0x2A0)
    candidates: list[tuple[int, int, int, str, str]] = []
    try:
        data = backend.read(session.backend_handle, controller + 0x240, 0xE8)
    except BackendError:
        return None
    for offset in range(0x240, 0x328, 8):
        target = struct.unpack_from("<Q", data, offset - 0x240)[0]
        if not _plausible_uobject(backend, session, memory, target):
            continue
        object_name, class_name = _uobject_names(
            backend,
            session,
            name_pool,
            target,
        )
        text = f"{object_name} {class_name}".casefold()
        score = 0
        if any(token in text for token in ("pawn", "character", "biped")):
            score += 120
        if "player" in text:
            score += 40
        if any(
            token in text
            for token in (
                "component",
                "controller",
                "playerstate",
                "camera",
                "input",
                "hud",
            )
        ):
            score -= 160
        try:
            preferred_rank = preferred_offsets.index(offset)
        except ValueError:
            preferred_rank = len(preferred_offsets) + offset
        candidates.append((score, -preferred_rank, target, object_name, class_name))

    if not candidates:
        return None
    named = [item for item in candidates if item[0] > 0]
    selected = max(named or candidates, key=lambda item: (item[0], item[1]))
    _, _, address, object_name, class_name = selected
    selected_offset = next(
        offset
        for offset in range(0x240, 0x328, 8)
        if struct.unpack_from("<Q", data, offset - 0x240)[0] == address
    )
    return _ObjectNode(
        0,
        0,
        address,
        f"{path_prefix}->+0x{selected_offset:X}",
        4,
        object_name,
        class_name,
    )


def _guess_player_pawn(nodes: list[_ObjectNode]) -> _ObjectNode | None:
    pawn_offsets = {0x278, 0x280, 0x288, 0x290, 0x298, 0x2A0}
    likely: list[_ObjectNode] = []
    for node in nodes:
        parts = node.path.split("->")
        if len(parts) < 5 or "+0x38[" not in node.path or "->+0x30" not in node.path:
            continue
        tail = parts[-1]
        if tail.startswith("+0x") and "[" not in tail:
            try:
                offset = int(tail[3:], 16)
            except ValueError:
                continue
            if offset in pawn_offsets:
                likely.append(node)
    offset_order = {offset: index for index, offset in enumerate(sorted(pawn_offsets))}
    return (
        min(
            likely,
            key=lambda item: (
                item.depth,
                offset_order.get(int(item.path.rsplit("+0x", 1)[1], 16), 100),
                item.priority,
            ),
        )
        if likely
        else None
    )
