from __future__ import annotations

import ctypes
import os
import struct
import sys
from collections.abc import Callable
from ctypes import wintypes
from dataclasses import dataclass, field
from datetime import UTC, datetime, timedelta
from pathlib import Path
from threading import Event, Lock, RLock, Thread
from time import monotonic
from typing import Protocol
from uuid import uuid4

from pydantic import BaseModel, Field

from gtp_games.errors import BackendError, NotFoundError, SafetyError
from gtp_games.game_identity import executable_build_identity
from gtp_games.locators import LocatorEngine
from gtp_games.memory.base import MemoryBackend
from gtp_games.models import ProcessSession

NMS_LAST_MOVED_ITEM_BUILD = (
    "sample-sha256:988efff56e344345ac09ad6560a9b661b9d09ba636c579f0677eab61f775f0ea"
)


@dataclass(frozen=True)
class InventoryInstructionRecipe:
    name: str
    process_name: str
    module: str
    build_identity: str
    aob_pattern: str
    identity_low_offset: int = 0
    identity_high_offset: int = 8
    count_offset: int = 0x18
    maximum_offset: int = 0x20
    register_name: str = "rax"

    @property
    def record_read_size(self) -> int:
        return max(
            self.identity_low_offset + 8,
            self.identity_high_offset + 8,
            self.count_offset + 4,
            self.maximum_offset + 4,
        )


NMS_LAST_MOVED_ITEM_RECIPE = InventoryInstructionRecipe(
    name="nms-last-moved-inventory-item-v1",
    process_name="NMS.exe",
    module="NMS.exe",
    build_identity=NMS_LAST_MOVED_ITEM_BUILD,
    aob_pattern="0F 11 48 10 0F 10 43 20 0F 11 40 20 0F 11",
)

BUILTIN_INVENTORY_RECIPES = (NMS_LAST_MOVED_ITEM_RECIPE,)


@dataclass(frozen=True)
class PreparedInventoryObservation:
    session: ProcessSession
    recipe: InventoryInstructionRecipe
    build_identity: str
    anchor_address: int


class InstructionHit(BaseModel):
    thread_id: int = Field(gt=0)
    instruction_pointer: int = Field(gt=0)
    rax: int = Field(default=0, ge=0)
    rcx: int = Field(default=0, ge=0)
    rdx: int = Field(default=0, ge=0)
    rbx: int = Field(default=0, ge=0)
    rsp: int = Field(default=0, ge=0)
    rbp: int = Field(default=0, ge=0)
    rsi: int = Field(default=0, ge=0)
    rdi: int = Field(default=0, ge=0)
    r8: int = Field(default=0, ge=0)
    r9: int = Field(default=0, ge=0)
    r10: int = Field(default=0, ge=0)
    r11: int = Field(default=0, ge=0)
    r12: int = Field(default=0, ge=0)
    r13: int = Field(default=0, ge=0)
    r14: int = Field(default=0, ge=0)
    r15: int = Field(default=0, ge=0)
    mechanism: str = "windows-hardware-execute-breakpoint"
    cleanup_verified: bool = True

    def register(self, name: str) -> int:
        normalized = name.strip().casefold()
        if normalized not in {
            "rax", "rcx", "rdx", "rbx", "rsp", "rbp", "rsi", "rdi",
            "r8", "r9", "r10", "r11", "r12", "r13", "r14", "r15",
        }:
            raise ValueError(f"unsupported x64 register: {name}")
        return int(getattr(self, normalized))


class InstructionObservationBackend(Protocol):
    def observe_execute(
        self,
        pid: int,
        address: int,
        *,
        timeout_seconds: float,
        on_armed: Callable[[], None] | None = None,
        cancel_event: Event | None = None,
    ) -> InstructionHit: ...


class InstructionObservationTimeout(TimeoutError):
    """The observation window elapsed after the debugger detached cleanly."""


class InstructionObservationCancelled(RuntimeError):
    """The observation was cancelled and the debugger detached cleanly."""


class InventorySlotObservationRecord(BaseModel):
    game_key: str
    process_name: str
    build_identity: str
    process_started_at: float | None = None
    recipe_name: str
    identity_low: int = Field(ge=0)
    identity_high: int = Field(ge=0)
    identity_key: str
    count: int = Field(ge=0)
    maximum: int = Field(ge=0)
    slot_address: int = Field(ge=0)
    observed_at: datetime = Field(default_factory=lambda: datetime.now(UTC))
    address_is_current_process_diagnostic_only: bool = True


class InventoryObservationLedger(BaseModel):
    schema_version: str = "gtp-inventory-instruction-observations/v1"
    records: list[InventorySlotObservationRecord] = Field(default_factory=list)


class InventoryIdentityContinuity(BaseModel):
    same_identity_observation_count: int = Field(ge=1)
    same_process_slot_count: int = Field(ge=1)
    moved_within_process: bool = False
    identity_seen_across_processes: bool = False


class InventorySlotObservation(BaseModel):
    status: str
    session_id: str
    pid: int
    process_name: str
    build_identity: str
    recipe_name: str
    expected_build_identity: str
    signature_match_count: int = Field(ge=0)
    signature_scope_complete: bool
    anchor_address: int | None = Field(default=None, ge=0)
    thread_id: int | None = Field(default=None, ge=1)
    slot_address: int | None = Field(default=None, ge=0)
    count_address: int | None = Field(default=None, ge=0)
    maximum_address: int | None = Field(default=None, ge=0)
    identity_low: int | None = Field(default=None, ge=0)
    identity_high: int | None = Field(default=None, ge=0)
    identity_key: str | None = None
    count: int | None = Field(default=None, ge=0)
    maximum: int | None = Field(default=None, ge=0)
    continuity: InventoryIdentityContinuity | None = None
    mechanism: str = "windows-hardware-execute-breakpoint"
    timed_out: bool = False
    read_only: bool = True
    game_memory_write_performed: bool = False
    target_code_patched: bool = False
    debugger_detached: bool = True
    address_valid_for_current_process_only: bool = True
    message: str


class InventoryObserverStatus(BaseModel):
    token: str
    session_id: str
    pid: int
    process_name: str
    build_identity: str
    recipe_name: str
    anchor_address: int = Field(ge=0)
    state: str
    armed: bool = False
    armed_at: datetime | None = None
    deadline: datetime | None = None
    finished_at: datetime | None = None
    result: InventorySlotObservation | None = None
    error: str | None = None
    read_only: bool = True
    game_memory_write_performed: bool = False
    target_code_patched: bool = False
    message: str


class InventoryObservationStore:
    def __init__(self, path: Path) -> None:
        self.path = path
        self._lock = RLock()

    def remember(
        self,
        record: InventorySlotObservationRecord,
    ) -> InventoryIdentityContinuity:
        with self._lock:
            ledger = self._load()
            ledger.records.append(record)
            ledger.records = sorted(ledger.records, key=lambda item: item.observed_at)[-500:]
            self._write(ledger)
            matching = [
                item
                for item in ledger.records
                if item.game_key == record.game_key
                and item.build_identity == record.build_identity
                and item.identity_key == record.identity_key
            ]
        same_process = [
            item
            for item in matching
            if item.process_started_at == record.process_started_at
        ]
        same_process_slots = {item.slot_address for item in same_process}
        process_starts = {item.process_started_at for item in matching}
        return InventoryIdentityContinuity(
            same_identity_observation_count=len(matching),
            same_process_slot_count=len(same_process_slots),
            moved_within_process=len(same_process_slots) > 1,
            identity_seen_across_processes=len(process_starts) > 1,
        )

    def records(self) -> list[InventorySlotObservationRecord]:
        with self._lock:
            return [item.model_copy(deep=True) for item in self._load().records]

    def _load(self) -> InventoryObservationLedger:
        if not self.path.is_file():
            return InventoryObservationLedger()
        try:
            return InventoryObservationLedger.model_validate_json(
                self.path.read_text(encoding="utf-8")
            )
        except (OSError, ValueError):
            return InventoryObservationLedger()

    def _write(self, ledger: InventoryObservationLedger) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        temporary = self.path.with_suffix(self.path.suffix + ".tmp")
        temporary.write_text(ledger.model_dump_json(indent=2), encoding="utf-8")
        temporary.replace(self.path)


class InventoryInstructionEngine:
    def __init__(
        self,
        memory: MemoryBackend,
        locators: LocatorEngine,
        observer: InstructionObservationBackend,
        store: InventoryObservationStore,
        *,
        build_identity_resolver: Callable[[str | None], str | None] = executable_build_identity,
    ) -> None:
        self.memory = memory
        self.locators = locators
        self.observer = observer
        self.store = store
        self.build_identity_resolver = build_identity_resolver

    def observe(
        self,
        session: ProcessSession,
        *,
        timeout_seconds: float = 20,
        recipe_name: str | None = None,
    ) -> InventorySlotObservation:
        prepared = self.prepare(session, recipe_name=recipe_name)
        return self.observe_prepared(prepared, timeout_seconds=timeout_seconds)

    def prepare(
        self,
        session: ProcessSession,
        *,
        recipe_name: str | None = None,
    ) -> PreparedInventoryObservation:
        recipe = self._recipe_for(session.process_name, recipe_name)
        build_identity = self.build_identity_resolver(session.executable)
        if not build_identity:
            raise SafetyError("the selected game's exact executable build could not be read")
        if build_identity != recipe.build_identity:
            raise SafetyError(
                "the inventory observer has not been validated for this exact game build"
            )
        matches, scope_truncated = self.locators.find_aob(
            session,
            recipe.aob_pattern,
            module=recipe.module,
        )
        if scope_truncated:
            raise SafetyError("the inventory signature scan was incomplete; uniqueness is unknown")
        if len(matches) != 1:
            raise SafetyError(
                f"the inventory instruction signature must match exactly once, found {len(matches)}"
            )
        return PreparedInventoryObservation(
            session=session,
            recipe=recipe,
            build_identity=build_identity,
            anchor_address=matches[0],
        )

    def observe_prepared(
        self,
        prepared: PreparedInventoryObservation,
        *,
        timeout_seconds: float = 20,
        on_armed: Callable[[], None] | None = None,
        cancel_event: Event | None = None,
    ) -> InventorySlotObservation:
        if not 1 <= timeout_seconds <= 30:
            raise ValueError("timeout_seconds must be between 1 and 30")
        session = prepared.session
        anchor = prepared.anchor_address
        try:
            hit = self.observer.observe_execute(
                session.pid,
                anchor,
                timeout_seconds=timeout_seconds,
                on_armed=on_armed,
                cancel_event=cancel_event,
            )
        except InstructionObservationTimeout:
            return self.timeout_result(prepared)
        return self.decode_hit(prepared, hit)

    def timeout_result(
        self,
        prepared: PreparedInventoryObservation,
    ) -> InventorySlotObservation:
        session = prepared.session
        recipe = prepared.recipe
        return InventorySlotObservation(
            status="timeout",
            session_id=session.id,
            pid=session.pid,
            process_name=session.process_name,
            build_identity=prepared.build_identity,
            recipe_name=recipe.name,
            expected_build_identity=recipe.build_identity,
            signature_match_count=1,
            signature_scope_complete=True,
            anchor_address=prepared.anchor_address,
            timed_out=True,
            message=(
                "No inventory move reached the observed instruction. Move one item stack "
                "during the next armed learning window."
            ),
        )

    def decode_hit(
        self,
        prepared: PreparedInventoryObservation,
        hit: InstructionHit,
    ) -> InventorySlotObservation:
        session = prepared.session
        recipe = prepared.recipe
        anchor = prepared.anchor_address
        if not hit.cleanup_verified:
            raise BackendError("the instruction observer could not prove debugger cleanup")
        if hit.instruction_pointer != anchor:
            raise BackendError("the debugger reported a different instruction than the anchor")
        identity_low, identity_high, count, maximum = self._decode_slot(
            session,
            hit.rax,
            recipe,
        )
        identity_key = f"{identity_low:016X}:{identity_high:016X}"
        game_key = (session.game_key or session.process_name).casefold()
        continuity = self.store.remember(
            InventorySlotObservationRecord(
                game_key=game_key,
                process_name=session.process_name,
                build_identity=prepared.build_identity,
                process_started_at=session.process_started_at,
                recipe_name=recipe.name,
                identity_low=identity_low,
                identity_high=identity_high,
                identity_key=identity_key,
                count=count,
                maximum=maximum,
                slot_address=hit.rax,
            )
        )
        return InventorySlotObservation(
            status="observed",
            session_id=session.id,
            pid=session.pid,
            process_name=session.process_name,
            build_identity=prepared.build_identity,
            recipe_name=recipe.name,
            expected_build_identity=recipe.build_identity,
            signature_match_count=1,
            signature_scope_complete=True,
            anchor_address=anchor,
            thread_id=hit.thread_id,
            slot_address=hit.rax,
            count_address=hit.rax + recipe.count_offset,
            maximum_address=hit.rax + recipe.maximum_offset,
            identity_low=identity_low,
            identity_high=identity_high,
            identity_key=identity_key,
            count=count,
            maximum=maximum,
            continuity=continuity,
            mechanism=hit.mechanism,
            message=(
                "Captured the moved item's identity and live stack fields. The returned "
                "addresses are valid only for this process launch."
            ),
        )

    def _decode_slot(
        self,
        session: ProcessSession,
        slot_address: int,
        recipe: InventoryInstructionRecipe,
    ) -> tuple[int, int, int, int]:
        if slot_address <= 0:
            raise BackendError("the inventory instruction returned a null slot address")
        region = next(
            (
                item
                for item in self.memory.regions(session.backend_handle)
                if item.contains(slot_address, recipe.record_read_size)
            ),
            None,
        )
        if region is None or not region.readable or region.guarded:
            raise SafetyError("the observed inventory slot is not readable in this session")
        data = self.memory.read(
            session.backend_handle,
            slot_address,
            recipe.record_read_size,
        )
        identity_low = struct.unpack_from("<Q", data, recipe.identity_low_offset)[0]
        identity_high = struct.unpack_from("<Q", data, recipe.identity_high_offset)[0]
        count = struct.unpack_from("<I", data, recipe.count_offset)[0]
        maximum = struct.unpack_from("<I", data, recipe.maximum_offset)[0]
        if identity_low == 0 and identity_high == 0:
            raise SafetyError("the observed inventory record has no item identity")
        if maximum and count > maximum:
            raise SafetyError("the observed inventory count is greater than its maximum")
        return identity_low, identity_high, count, maximum

    @staticmethod
    def _recipe_for(
        process_name: str,
        recipe_name: str | None,
    ) -> InventoryInstructionRecipe:
        recipes = [
            recipe
            for recipe in BUILTIN_INVENTORY_RECIPES
            if recipe.process_name.casefold() == process_name.casefold()
            and (recipe_name is None or recipe.name == recipe_name)
        ]
        if len(recipes) != 1:
            raise NotFoundError(
                "no exact-build inventory instruction recipe is available for this game"
            )
        return recipes[0]


@dataclass
class _InventoryObserverJob:
    token: str
    prepared: PreparedInventoryObservation
    timeout_seconds: float
    state: str = "arming"
    armed_at: datetime | None = None
    deadline: datetime | None = None
    finished_at: datetime | None = None
    result: InventorySlotObservation | None = None
    error: str | None = None
    thread: Thread | None = None
    armed_event: Event = field(default_factory=Event)
    completed_event: Event = field(default_factory=Event)
    cancel_event: Event = field(default_factory=Event)


class InventoryObserverManager:
    """Own one two-phase observer per game session and guarantee bounded cleanup."""

    _ARM_TIMEOUT_SECONDS = 15.0
    _CLEANUP_TIMEOUT_SECONDS = 5.0

    def __init__(self, engine: InventoryInstructionEngine) -> None:
        self.engine = engine
        self._jobs: dict[str, _InventoryObserverJob] = {}
        self._active_by_session: dict[str, str] = {}
        self._lock = RLock()

    def start(
        self,
        session: ProcessSession,
        *,
        timeout_seconds: float = 20,
        recipe_name: str | None = None,
    ) -> InventoryObserverStatus:
        if not 1 <= timeout_seconds <= 30:
            raise ValueError("timeout_seconds must be between 1 and 30")
        with self._lock:
            active_token = self._active_by_session.get(session.id)
            if active_token is not None:
                active = self._jobs.get(active_token)
                if active is not None and not active.completed_event.is_set():
                    raise SafetyError("an inventory observer is already active for this session")
        prepared = self.engine.prepare(session, recipe_name=recipe_name)
        job = _InventoryObserverJob(
            token=uuid4().hex,
            prepared=prepared,
            timeout_seconds=timeout_seconds,
        )
        with self._lock:
            active_token = self._active_by_session.get(session.id)
            if active_token is not None:
                active = self._jobs.get(active_token)
                if active is not None and not active.completed_event.is_set():
                    raise SafetyError("an inventory observer is already active for this session")
            self._jobs[job.token] = job
            self._active_by_session[session.id] = job.token
            self._prune_completed()
        job.thread = Thread(
            target=self._run,
            args=(job,),
            name=f"gtp-inventory-observer-{job.token[:8]}",
            daemon=True,
        )
        job.thread.start()
        arm_deadline = monotonic() + self._ARM_TIMEOUT_SECONDS
        while monotonic() < arm_deadline:
            if job.armed_event.wait(timeout=0.05):
                return self._status(job)
            if job.completed_event.is_set():
                raise BackendError(job.error or "inventory observer stopped before it was armed")
        job.cancel_event.set()
        job.completed_event.wait(timeout=self._CLEANUP_TIMEOUT_SECONDS)
        if not job.completed_event.is_set():
            raise BackendError("inventory observer arm timeout cleanup did not finish")
        raise BackendError(job.error or "inventory observer did not arm before its deadline")

    def status(
        self,
        session_id: str,
        token: str,
        *,
        wait_seconds: float = 0,
    ) -> InventoryObserverStatus:
        if not 0 <= wait_seconds <= 30:
            raise ValueError("wait_seconds must be between 0 and 30")
        job = self._job(session_id, token)
        if wait_seconds:
            job.completed_event.wait(timeout=wait_seconds)
        return self._status(job)

    def cancel(self, session_id: str, token: str) -> InventoryObserverStatus:
        job = self._job(session_id, token)
        if not job.completed_event.is_set():
            with self._lock:
                if job.state in {"arming", "armed"}:
                    job.state = "cancelling"
            job.cancel_event.set()
            job.completed_event.wait(timeout=self._CLEANUP_TIMEOUT_SECONDS)
        return self._status(job)

    def cancel_session(self, session_id: str) -> None:
        with self._lock:
            jobs = [
                item
                for item in self._jobs.values()
                if item.prepared.session.id == session_id and not item.completed_event.is_set()
            ]
        for job in jobs:
            job.cancel_event.set()
        for job in jobs:
            job.completed_event.wait(timeout=self._CLEANUP_TIMEOUT_SECONDS)

    def close(self) -> None:
        with self._lock:
            session_ids = list(self._active_by_session)
        for session_id in session_ids:
            self.cancel_session(session_id)

    def _run(self, job: _InventoryObserverJob) -> None:
        def mark_armed() -> None:
            now = datetime.now(UTC)
            with self._lock:
                job.armed_at = now
                job.deadline = now + timedelta(seconds=job.timeout_seconds)
                job.state = "armed"
                job.armed_event.set()

        try:
            result = self.engine.observe_prepared(
                job.prepared,
                timeout_seconds=job.timeout_seconds,
                on_armed=mark_armed,
                cancel_event=job.cancel_event,
            )
        except InstructionObservationCancelled:
            with self._lock:
                job.state = "cancelled"
                job.finished_at = datetime.now(UTC)
        except Exception as exc:  # noqa: BLE001 - background failures become status evidence
            with self._lock:
                job.state = "failed"
                job.error = str(exc)[:500]
                job.finished_at = datetime.now(UTC)
        else:
            with self._lock:
                job.result = result
                job.state = result.status
                job.finished_at = datetime.now(UTC)
        finally:
            with self._lock:
                active_token = self._active_by_session.get(job.prepared.session.id)
                if active_token == job.token:
                    self._active_by_session.pop(job.prepared.session.id, None)
                job.completed_event.set()

    def _job(self, session_id: str, token: str) -> _InventoryObserverJob:
        with self._lock:
            job = self._jobs.get(token)
        if job is None:
            raise NotFoundError("inventory observer token was not found")
        if job.prepared.session.id != session_id:
            raise SafetyError("inventory observer token belongs to a different game session")
        return job

    def _status(self, job: _InventoryObserverJob) -> InventoryObserverStatus:
        with self._lock:
            state = job.state
            result = job.result.model_copy(deep=True) if job.result else None
            error = job.error
            armed_at = job.armed_at
            deadline = job.deadline
            finished_at = job.finished_at
        messages = {
            "arming": "Preparing the hardware observer.",
            "armed": "Observer armed. Perform one inventory move before the deadline.",
            "cancelling": "Observer cancellation requested; cleanup is running.",
            "cancelled": "Observer cancelled and detached.",
            "timeout": "Observation window expired and detached without an item move.",
            "observed": "One inventory move was captured and decoded.",
            "failed": "Observer failed closed and detached.",
        }
        prepared = job.prepared
        return InventoryObserverStatus(
            token=job.token,
            session_id=prepared.session.id,
            pid=prepared.session.pid,
            process_name=prepared.session.process_name,
            build_identity=prepared.build_identity,
            recipe_name=prepared.recipe.name,
            anchor_address=prepared.anchor_address,
            state=state,
            armed=armed_at is not None,
            armed_at=armed_at,
            deadline=deadline,
            finished_at=finished_at,
            result=result,
            error=error,
            message=messages.get(state, "Observer status available."),
        )

    def _prune_completed(self) -> None:
        completed = sorted(
            (item for item in self._jobs.values() if item.completed_event.is_set()),
            key=lambda item: item.finished_at or datetime.min.replace(tzinfo=UTC),
        )
        for item in completed[:-100]:
            self._jobs.pop(item.token, None)


if sys.platform == "win32":
    _kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    _ULONG_PTR = ctypes.c_ulonglong

    class _EXCEPTION_RECORD(ctypes.Structure):
        _fields_ = [
            ("ExceptionCode", wintypes.DWORD),
            ("ExceptionFlags", wintypes.DWORD),
            ("ExceptionRecord", ctypes.c_void_p),
            ("ExceptionAddress", ctypes.c_void_p),
            ("NumberParameters", wintypes.DWORD),
            ("ExceptionInformation", _ULONG_PTR * 15),
        ]

    class _EXCEPTION_DEBUG_INFO(ctypes.Structure):
        _fields_ = [
            ("ExceptionRecord", _EXCEPTION_RECORD),
            ("dwFirstChance", wintypes.DWORD),
        ]

    class _CREATE_THREAD_DEBUG_INFO(ctypes.Structure):
        _fields_ = [
            ("hThread", wintypes.HANDLE),
            ("lpThreadLocalBase", ctypes.c_void_p),
            ("lpStartAddress", ctypes.c_void_p),
        ]

    class _CREATE_PROCESS_DEBUG_INFO(ctypes.Structure):
        _fields_ = [
            ("hFile", wintypes.HANDLE),
            ("hProcess", wintypes.HANDLE),
            ("hThread", wintypes.HANDLE),
            ("lpBaseOfImage", ctypes.c_void_p),
            ("dwDebugInfoFileOffset", wintypes.DWORD),
            ("nDebugInfoSize", wintypes.DWORD),
            ("lpThreadLocalBase", ctypes.c_void_p),
            ("lpStartAddress", ctypes.c_void_p),
            ("lpImageName", ctypes.c_void_p),
            ("fUnicode", wintypes.WORD),
        ]

    class _EXIT_THREAD_DEBUG_INFO(ctypes.Structure):
        _fields_ = [("dwExitCode", wintypes.DWORD)]

    class _EXIT_PROCESS_DEBUG_INFO(ctypes.Structure):
        _fields_ = [("dwExitCode", wintypes.DWORD)]

    class _LOAD_DLL_DEBUG_INFO(ctypes.Structure):
        _fields_ = [
            ("hFile", wintypes.HANDLE),
            ("lpBaseOfDll", ctypes.c_void_p),
            ("dwDebugInfoFileOffset", wintypes.DWORD),
            ("nDebugInfoSize", wintypes.DWORD),
            ("lpImageName", ctypes.c_void_p),
            ("fUnicode", wintypes.WORD),
        ]

    class _UNLOAD_DLL_DEBUG_INFO(ctypes.Structure):
        _fields_ = [("lpBaseOfDll", ctypes.c_void_p)]

    class _OUTPUT_DEBUG_STRING_INFO(ctypes.Structure):
        _fields_ = [
            ("lpDebugStringData", ctypes.c_void_p),
            ("fUnicode", wintypes.WORD),
            ("nDebugStringLength", wintypes.WORD),
        ]

    class _RIP_INFO(ctypes.Structure):
        _fields_ = [("dwError", wintypes.DWORD), ("dwType", wintypes.DWORD)]

    class _DEBUG_EVENT_UNION(ctypes.Union):
        _fields_ = [
            ("Exception", _EXCEPTION_DEBUG_INFO),
            ("CreateThread", _CREATE_THREAD_DEBUG_INFO),
            ("CreateProcessInfo", _CREATE_PROCESS_DEBUG_INFO),
            ("ExitThread", _EXIT_THREAD_DEBUG_INFO),
            ("ExitProcess", _EXIT_PROCESS_DEBUG_INFO),
            ("LoadDll", _LOAD_DLL_DEBUG_INFO),
            ("UnloadDll", _UNLOAD_DLL_DEBUG_INFO),
            ("DebugString", _OUTPUT_DEBUG_STRING_INFO),
            ("RipInfo", _RIP_INFO),
        ]

    class _DEBUG_EVENT(ctypes.Structure):
        _anonymous_ = ("u",)
        _fields_ = [
            ("dwDebugEventCode", wintypes.DWORD),
            ("dwProcessId", wintypes.DWORD),
            ("dwThreadId", wintypes.DWORD),
            ("u", _DEBUG_EVENT_UNION),
        ]

    class _THREADENTRY32(ctypes.Structure):
        _fields_ = [
            ("dwSize", wintypes.DWORD),
            ("cntUsage", wintypes.DWORD),
            ("th32ThreadID", wintypes.DWORD),
            ("th32OwnerProcessID", wintypes.DWORD),
            ("tpBasePri", wintypes.LONG),
            ("tpDeltaPri", wintypes.LONG),
            ("dwFlags", wintypes.DWORD),
        ]

    _kernel32.DebugActiveProcess.argtypes = [wintypes.DWORD]
    _kernel32.DebugActiveProcess.restype = wintypes.BOOL
    _kernel32.DebugActiveProcessStop.argtypes = [wintypes.DWORD]
    _kernel32.DebugActiveProcessStop.restype = wintypes.BOOL
    _kernel32.DebugSetProcessKillOnExit.argtypes = [wintypes.BOOL]
    _kernel32.DebugSetProcessKillOnExit.restype = wintypes.BOOL
    _kernel32.ContinueDebugEvent.argtypes = [wintypes.DWORD, wintypes.DWORD, wintypes.DWORD]
    _kernel32.ContinueDebugEvent.restype = wintypes.BOOL
    _kernel32.OpenThread.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
    _kernel32.OpenThread.restype = wintypes.HANDLE
    _kernel32.GetThreadContext.argtypes = [wintypes.HANDLE, ctypes.c_void_p]
    _kernel32.GetThreadContext.restype = wintypes.BOOL
    _kernel32.SetThreadContext.argtypes = [wintypes.HANDLE, ctypes.c_void_p]
    _kernel32.SetThreadContext.restype = wintypes.BOOL
    _kernel32.SuspendThread.argtypes = [wintypes.HANDLE]
    _kernel32.SuspendThread.restype = wintypes.DWORD
    _kernel32.ResumeThread.argtypes = [wintypes.HANDLE]
    _kernel32.ResumeThread.restype = wintypes.DWORD
    _kernel32.CreateToolhelp32Snapshot.argtypes = [wintypes.DWORD, wintypes.DWORD]
    _kernel32.CreateToolhelp32Snapshot.restype = wintypes.HANDLE
    _kernel32.Thread32First.argtypes = [wintypes.HANDLE, ctypes.POINTER(_THREADENTRY32)]
    _kernel32.Thread32First.restype = wintypes.BOOL
    _kernel32.Thread32Next.argtypes = [wintypes.HANDLE, ctypes.POINTER(_THREADENTRY32)]
    _kernel32.Thread32Next.restype = wintypes.BOOL
    _kernel32.CloseHandle.argtypes = [wintypes.HANDLE]
    _kernel32.CloseHandle.restype = wintypes.BOOL

    _wait_for_debug_event = getattr(_kernel32, "WaitForDebugEventEx", None)
    if _wait_for_debug_event is None:
        _wait_for_debug_event = _kernel32.WaitForDebugEvent
    _wait_for_debug_event.argtypes = [ctypes.POINTER(_DEBUG_EVENT), wintypes.DWORD]
    _wait_for_debug_event.restype = wintypes.BOOL


_DEBUGGER_LOCK = Lock()


class _ContextBuffer:
    _SIZE = 1232
    _FLAGS_OFFSET = 48
    _DR0_OFFSET = 72
    _DR1_OFFSET = 80
    _DR2_OFFSET = 88
    _DR3_OFFSET = 96
    _DR6_OFFSET = 104
    _DR7_OFFSET = 112
    _RAX_OFFSET = 120
    _RCX_OFFSET = 128
    _RDX_OFFSET = 136
    _RBX_OFFSET = 144
    _RSP_OFFSET = 152
    _RBP_OFFSET = 160
    _RSI_OFFSET = 168
    _RDI_OFFSET = 176
    _R8_OFFSET = 184
    _R9_OFFSET = 192
    _R10_OFFSET = 200
    _R11_OFFSET = 208
    _R12_OFFSET = 216
    _R13_OFFSET = 224
    _R14_OFFSET = 232
    _R15_OFFSET = 240
    _RIP_OFFSET = 248

    def __init__(self, flags: int) -> None:
        self._raw = ctypes.create_string_buffer(self._SIZE + 15)
        self.address = (ctypes.addressof(self._raw) + 15) & ~15
        self.set_u32(self._FLAGS_OFFSET, flags)

    @property
    def pointer(self) -> ctypes.c_void_p:
        return ctypes.c_void_p(self.address)

    def get_u64(self, offset: int) -> int:
        return ctypes.c_uint64.from_address(self.address + offset).value

    def set_u64(self, offset: int, value: int) -> None:
        ctypes.c_uint64.from_address(self.address + offset).value = value

    def set_u32(self, offset: int, value: int) -> None:
        ctypes.c_uint32.from_address(self.address + offset).value = value


class WindowsHardwareBreakpointObserver:
    """Temporarily observe one x64 instruction without patching target code or data."""

    _CONTEXT_FLAGS = 0x00100000 | 0x1 | 0x2 | 0x10
    _THREAD_ACCESS = 0x0002 | 0x0008 | 0x0010 | 0x0040
    _TH32CS_SNAPTHREAD = 0x00000004
    _CREATE_THREAD_DEBUG_EVENT = 2
    _CREATE_PROCESS_DEBUG_EVENT = 3
    _EXIT_PROCESS_DEBUG_EVENT = 5
    _LOAD_DLL_DEBUG_EVENT = 6
    _EXCEPTION_DEBUG_EVENT = 1
    _STATUS_BREAKPOINT = 0x80000003
    _STATUS_SINGLE_STEP = 0x80000004
    _DBG_CONTINUE = 0x00010002
    _DBG_EXCEPTION_NOT_HANDLED = 0x80010001
    _ERROR_SEM_TIMEOUT = 121
    _INVALID_DWORD = 0xFFFFFFFF

    def observe_execute(
        self,
        pid: int,
        address: int,
        *,
        timeout_seconds: float,
        on_armed: Callable[[], None] | None = None,
        cancel_event: Event | None = None,
    ) -> InstructionHit:
        if sys.platform != "win32":
            raise BackendError("instruction observation requires native 64-bit Windows")
        if ctypes.sizeof(ctypes.c_void_p) != 8:
            raise BackendError("instruction observation requires a 64-bit companion")
        if pid <= 0 or pid == os.getpid() or address <= 0:
            raise SafetyError("invalid process or instruction address")
        if not _DEBUGGER_LOCK.acquire(blocking=False):
            raise SafetyError("another instruction observation is already active")
        attached = False
        originals: dict[int, tuple[int, int, int, int, int, int]] = {}
        event_handles: list[int] = []
        cleanup_error: Exception | None = None
        hit: InstructionHit | None = None
        armed = False
        deadline: float | None = None
        try:
            if not _kernel32.DebugActiveProcess(pid):
                self._raise_windows("DebugActiveProcess")
            attached = True
            if not _kernel32.DebugSetProcessKillOnExit(False):
                self._raise_windows("DebugSetProcessKillOnExit")
            arm_deadline = monotonic() + 10
            while hit is None:
                if cancel_event is not None and cancel_event.is_set():
                    raise InstructionObservationCancelled()
                active_deadline = deadline if deadline is not None else arm_deadline
                if monotonic() >= active_deadline:
                    if armed:
                        raise InstructionObservationTimeout()
                    raise BackendError("inventory observer did not reach its armed state")
                event = _DEBUG_EVENT()
                remaining_ms = max(
                    1,
                    min(100, int((active_deadline - monotonic()) * 1000)),
                )
                if not _wait_for_debug_event(ctypes.byref(event), remaining_ms):
                    error = ctypes.get_last_error()
                    if error == self._ERROR_SEM_TIMEOUT:
                        continue
                    raise BackendError(
                        f"WaitForDebugEvent failed (Windows error {error})"
                    )
                continue_status = self._DBG_CONTINUE
                mark_armed = False
                try:
                    code = int(event.dwDebugEventCode)
                    thread_id = int(event.dwThreadId)
                    if code == self._CREATE_PROCESS_DEBUG_EVENT:
                        self._remember_event_handle(
                            event_handles,
                            event.CreateProcessInfo.hFile,
                        )
                        self._remember_event_handle(
                            event_handles,
                            event.CreateProcessInfo.hProcess,
                        )
                        self._remember_event_handle(
                            event_handles,
                            event.CreateProcessInfo.hThread,
                        )
                        self._enable_thread(
                            thread_id,
                            address,
                            originals,
                            event.CreateProcessInfo.hThread,
                        )
                    elif code == self._CREATE_THREAD_DEBUG_EVENT:
                        self._remember_event_handle(event_handles, event.CreateThread.hThread)
                        self._enable_thread(
                            thread_id,
                            address,
                            originals,
                            event.CreateThread.hThread,
                        )
                    elif code == self._LOAD_DLL_DEBUG_EVENT:
                        self._close_event_file(event.LoadDll.hFile)
                    elif code == self._EXIT_PROCESS_DEBUG_EVENT:
                        raise NotFoundError(f"process {pid} exited during inventory observation")
                    elif code == self._EXCEPTION_DEBUG_EVENT:
                        exception = event.Exception.ExceptionRecord
                        exception_code = int(exception.ExceptionCode)
                        if exception_code == self._STATUS_SINGLE_STEP:
                            context = self._get_context(thread_id)
                            dr6 = context.get_u64(_ContextBuffer._DR6_OFFSET)
                            rip = context.get_u64(_ContextBuffer._RIP_OFFSET)
                            if dr6 & 1 and rip == address:
                                hit = InstructionHit(
                                    thread_id=thread_id,
                                    instruction_pointer=rip,
                                    rax=context.get_u64(_ContextBuffer._RAX_OFFSET),
                                    rcx=context.get_u64(_ContextBuffer._RCX_OFFSET),
                                    rdx=context.get_u64(_ContextBuffer._RDX_OFFSET),
                                    rbx=context.get_u64(_ContextBuffer._RBX_OFFSET),
                                    rsp=context.get_u64(_ContextBuffer._RSP_OFFSET),
                                    rbp=context.get_u64(_ContextBuffer._RBP_OFFSET),
                                    rsi=context.get_u64(_ContextBuffer._RSI_OFFSET),
                                    rdi=context.get_u64(_ContextBuffer._RDI_OFFSET),
                                    r8=context.get_u64(_ContextBuffer._R8_OFFSET),
                                    r9=context.get_u64(_ContextBuffer._R9_OFFSET),
                                    r10=context.get_u64(_ContextBuffer._R10_OFFSET),
                                    r11=context.get_u64(_ContextBuffer._R11_OFFSET),
                                    r12=context.get_u64(_ContextBuffer._R12_OFFSET),
                                    r13=context.get_u64(_ContextBuffer._R13_OFFSET),
                                    r14=context.get_u64(_ContextBuffer._R14_OFFSET),
                                    r15=context.get_u64(_ContextBuffer._R15_OFFSET),
                                )
                            else:
                                continue_status = self._DBG_EXCEPTION_NOT_HANDLED
                        elif exception_code == self._STATUS_BREAKPOINT and not armed:
                            mark_armed = True
                        elif exception_code != self._STATUS_BREAKPOINT or armed:
                            continue_status = self._DBG_EXCEPTION_NOT_HANDLED
                finally:
                    if hit is not None:
                        self._restore_all(pid, originals, threads_are_stopped=True)
                        originals.clear()
                    if not _kernel32.ContinueDebugEvent(
                        event.dwProcessId,
                        event.dwThreadId,
                        continue_status,
                    ):
                        self._raise_windows("ContinueDebugEvent")
                if mark_armed and not armed:
                    armed = True
                    deadline = monotonic() + timeout_seconds
                    if on_armed is not None:
                        on_armed()
            return hit
        finally:
            if attached:
                try:
                    if originals:
                        self._restore_all(pid, originals, threads_are_stopped=False)
                except Exception as exc:  # noqa: BLE001 - cleanup failure must replace success
                    cleanup_error = exc
                try:
                    if not _kernel32.DebugActiveProcessStop(pid):
                        self._raise_windows("DebugActiveProcessStop")
                except Exception as exc:  # noqa: BLE001 - cleanup failure must replace success
                    if cleanup_error is None:
                        cleanup_error = exc
            for raw_handle in event_handles:
                if raw_handle:
                    _kernel32.CloseHandle(wintypes.HANDLE(raw_handle))
            _DEBUGGER_LOCK.release()
            if cleanup_error is not None:
                raise BackendError(
                    f"instruction observer cleanup failed: {cleanup_error}"
                ) from cleanup_error

    def _enable_thread(
        self,
        thread_id: int,
        address: int,
        originals: dict[int, tuple[int, int, int, int, int, int]],
        event_handle: int | None = None,
    ) -> None:
        handle, close_handle = self._thread_handle(thread_id, event_handle)
        try:
            context = self._read_context(handle)
            original = self._clean_exact_stale_breakpoint(
                self._debug_registers(context),
                address,
                thread_id,
            )
            originals.setdefault(thread_id, original)
            context.set_u64(_ContextBuffer._DR0_OFFSET, address)
            context.set_u64(_ContextBuffer._DR6_OFFSET, original[4] & ~1)
            context.set_u64(
                _ContextBuffer._DR7_OFFSET,
                (original[5] & ~(0xF << 16)) | 1,
            )
            if not _kernel32.SetThreadContext(handle, context.pointer):
                self._raise_windows("SetThreadContext")
        finally:
            if close_handle:
                _kernel32.CloseHandle(handle)

    @staticmethod
    def _clean_exact_stale_breakpoint(
        registers: tuple[int, int, int, int, int, int],
        address: int,
        thread_id: int,
    ) -> tuple[int, int, int, int, int, int]:
        dr0, dr1, dr2, dr3, dr6, dr7 = registers
        enabled = dr7 & 0xFF
        if not enabled:
            return registers
        exact_owned_shape = enabled == 1 and dr0 == address and not (dr7 & (0xF << 16))
        if not exact_owned_shape:
            raise SafetyError(
                f"thread {thread_id} already has a hardware breakpoint; refusing to replace it"
            )
        return (
            0,
            dr1,
            dr2,
            dr3,
            dr6 & ~1,
            dr7 & ~1 & ~(0xF << 16),
        )

    def _restore_all(
        self,
        pid: int,
        originals: dict[int, tuple[int, int, int, int, int, int]],
        *,
        threads_are_stopped: bool,
    ) -> None:
        failures: list[int] = []
        for thread_id in self._thread_ids(pid):
            original = originals.get(thread_id)
            if original is None:
                continue
            handle = _kernel32.OpenThread(self._THREAD_ACCESS, False, thread_id)
            if not handle:
                continue
            suspended = False
            try:
                if not threads_are_stopped:
                    previous = _kernel32.SuspendThread(handle)
                    if previous == self._INVALID_DWORD:
                        failures.append(thread_id)
                        continue
                    suspended = True
                context = self._read_context(handle)
                for offset, value in zip(
                    (
                        _ContextBuffer._DR0_OFFSET,
                        _ContextBuffer._DR1_OFFSET,
                        _ContextBuffer._DR2_OFFSET,
                        _ContextBuffer._DR3_OFFSET,
                        _ContextBuffer._DR6_OFFSET,
                        _ContextBuffer._DR7_OFFSET,
                    ),
                    original,
                    strict=True,
                ):
                    context.set_u64(offset, value)
                if not _kernel32.SetThreadContext(handle, context.pointer):
                    failures.append(thread_id)
            finally:
                if suspended:
                    _kernel32.ResumeThread(handle)
                _kernel32.CloseHandle(handle)
        if failures:
            joined = ", ".join(str(item) for item in failures[:8])
            raise BackendError(f"could not restore debug registers for threads {joined}")

    def _get_context(self, thread_id: int) -> _ContextBuffer:
        handle = _kernel32.OpenThread(self._THREAD_ACCESS, False, thread_id)
        if not handle:
            self._raise_windows("OpenThread")
        try:
            return self._read_context(handle)
        finally:
            _kernel32.CloseHandle(handle)

    def _read_context(self, handle: int) -> _ContextBuffer:
        context = _ContextBuffer(self._CONTEXT_FLAGS)
        if not _kernel32.GetThreadContext(handle, context.pointer):
            self._raise_windows("GetThreadContext")
        return context

    @staticmethod
    def _debug_registers(context: _ContextBuffer) -> tuple[int, int, int, int, int, int]:
        return tuple(
            context.get_u64(offset)
            for offset in (
                _ContextBuffer._DR0_OFFSET,
                _ContextBuffer._DR1_OFFSET,
                _ContextBuffer._DR2_OFFSET,
                _ContextBuffer._DR3_OFFSET,
                _ContextBuffer._DR6_OFFSET,
                _ContextBuffer._DR7_OFFSET,
            )
        )  # type: ignore[return-value]

    @staticmethod
    def _thread_handle(thread_id: int, event_handle: int | None) -> tuple[int, bool]:
        if event_handle:
            return int(event_handle), False
        handle = _kernel32.OpenThread(
            WindowsHardwareBreakpointObserver._THREAD_ACCESS,
            False,
            thread_id,
        )
        if not handle:
            WindowsHardwareBreakpointObserver._raise_windows("OpenThread")
        return int(handle), True

    @staticmethod
    def _thread_ids(pid: int) -> list[int]:
        snapshot = _kernel32.CreateToolhelp32Snapshot(
            WindowsHardwareBreakpointObserver._TH32CS_SNAPTHREAD,
            0,
        )
        invalid = ctypes.c_void_p(-1).value
        if not snapshot or int(snapshot) == invalid:
            WindowsHardwareBreakpointObserver._raise_windows("CreateToolhelp32Snapshot")
        result: list[int] = []
        try:
            entry = _THREADENTRY32()
            entry.dwSize = ctypes.sizeof(entry)
            ok = _kernel32.Thread32First(snapshot, ctypes.byref(entry))
            while ok:
                if int(entry.th32OwnerProcessID) == pid:
                    result.append(int(entry.th32ThreadID))
                ok = _kernel32.Thread32Next(snapshot, ctypes.byref(entry))
        finally:
            _kernel32.CloseHandle(snapshot)
        return result

    @staticmethod
    def _remember_event_handle(handles: list[int], handle: int | None) -> None:
        if handle:
            value = int(handle)
            if value not in handles:
                handles.append(value)

    @staticmethod
    def _close_event_file(handle: int | None) -> None:
        if handle:
            _kernel32.CloseHandle(handle)

    @staticmethod
    def _raise_windows(operation: str) -> None:
        error = ctypes.get_last_error()
        raise BackendError(f"{operation} failed (Windows error {error})")


class UnsupportedInstructionObservationBackend:
    def observe_execute(
        self,
        pid: int,
        address: int,
        *,
        timeout_seconds: float,
        on_armed: Callable[[], None] | None = None,
        cancel_event: Event | None = None,
    ) -> InstructionHit:
        del pid, address, timeout_seconds, on_armed, cancel_event
        raise BackendError("instruction observation requires the native Windows backend")


def default_instruction_observer() -> InstructionObservationBackend:
    if sys.platform == "win32":
        return WindowsHardwareBreakpointObserver()
    return UnsupportedInstructionObservationBackend()
