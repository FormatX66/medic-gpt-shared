from __future__ import annotations

from datetime import UTC, datetime

from pydantic import BaseModel, Field

from gtp_games.instruction_values import InstructionValueField, InstructionValueRecipe
from gtp_games.models import ValueType

NMS_ACCELERATOR_BUILD = (
    "sample-sha256:988efff56e344345ac09ad6560a9b661b9d09ba636c579f0677eab61f775f0ea"
)
NMS_REFERENCE_CT_SHA256 = (
    "e12d5b54e48b6570aa4065b6acfc0f825ea2d066ba166576226f0f89624e1b3e"
)


class AcceleratorSource(BaseModel):
    title: str
    url: str | None = None
    source_kind: str
    trust: str = "untrusted_reference_only"
    use: str


class AcceleratorValueEvidence(BaseModel):
    name: str
    value_type: ValueType
    address: int | None = Field(default=None, ge=0)
    address_hex: str | None = None
    live_value: int | float | None = None
    external_value: int | float | None = None
    corroborated: bool = False
    status: str
    evidence: list[str] = Field(default_factory=list)


class GameAcceleratorPack(BaseModel):
    schema_version: str = "gtp-game-accelerator-pack/v1"
    session_id: str
    pid: int
    process_name: str
    game_key: str
    game_name: str | None = None
    build_identity: str
    generated_at: datetime = Field(default_factory=lambda: datetime.now(UTC))
    values: list[AcceleratorValueEvidence] = Field(default_factory=list)
    instruction_recipes: list[InstructionValueRecipe] = Field(default_factory=list)
    sources: list[AcceleratorSource] = Field(default_factory=list)
    mounted_candidate_names: list[str] = Field(default_factory=list)
    online_refresh_required: bool = False
    read_only: bool = True
    game_memory_write_performed: bool = False
    imported_code_executed: bool = False
    notes: list[str] = Field(default_factory=list)


def builtin_instruction_recipes(
    process_name: str,
    build_identity: str,
) -> list[InstructionValueRecipe]:
    if process_name.casefold() != "nms.exe" or build_identity != NMS_ACCELERATOR_BUILD:
        return []
    provenance = "Local NMS CT translated to a data-only exact-build observation recipe"
    return [
        InstructionValueRecipe(
            name="nms-currency-block-v1",
            process_name="NMS.exe",
            module="NMS.exe",
            build_identity=NMS_ACCELERATOR_BUILD,
            aob_pattern="48 8B 41 10 48 83 C1 10 FF 50 38",
            instruction_offset=0x19,
            base_register="rax",
            fields=[
                InstructionValueField(
                    name="Units",
                    offset=0xBD8C,
                    value_type=ValueType.U32,
                ),
                InstructionValueField(
                    name="Nanites",
                    offset=0xBD90,
                    value_type=ValueType.U32,
                ),
                InstructionValueField(
                    name="Quicksilver",
                    offset=0xBD94,
                    value_type=ValueType.U32,
                ),
            ],
            source_label=provenance,
            source_sha256=NMS_REFERENCE_CT_SHA256,
        ),
        InstructionValueRecipe(
            name="nms-last-moved-inventory-stack-v1",
            process_name="NMS.exe",
            module="NMS.exe",
            build_identity=NMS_ACCELERATOR_BUILD,
            aob_pattern="0F 11 48 10 0F 10 43 20 0F 11 40 20 0F 11",
            base_register="rax",
            fields=[
                InstructionValueField(
                    name="Moved inventory stack current",
                    offset=0x18,
                    value_type=ValueType.U32,
                    expected_min=0,
                ),
                InstructionValueField(
                    name="Moved inventory stack maximum",
                    offset=0x20,
                    value_type=ValueType.U32,
                    expected_min=0,
                ),
            ],
            source_label=provenance,
            source_sha256=NMS_REFERENCE_CT_SHA256,
        ),
        InstructionValueRecipe(
            name="nms-inventory-slot-access-v1",
            process_name="NMS.exe",
            module="NMS.exe",
            build_identity=NMS_ACCELERATOR_BUILD,
            aob_pattern="0F 10 4E 10 0F 11 45 D7",
            base_register="rsi",
            fields=[
                InstructionValueField(
                    name="Inventory slot current",
                    offset=0x18,
                    value_type=ValueType.U32,
                    expected_min=0,
                ),
                InstructionValueField(
                    name="Inventory slot maximum",
                    offset=0x20,
                    value_type=ValueType.U32,
                    expected_min=0,
                ),
            ],
            source_label=provenance,
            source_sha256=NMS_REFERENCE_CT_SHA256,
        ),
        InstructionValueRecipe(
            name="nms-exosuit-shield-v1",
            process_name="NMS.exe",
            module="NMS.exe",
            build_identity=NMS_ACCELERATOR_BUILD,
            aob_pattern="48 8B C8 48 85 C0 74 2F 48",
            base_register="rdi",
            fields=[
                InstructionValueField(
                    name="Exosuit shield",
                    offset=0x18,
                    value_type=ValueType.I32,
                    expected_min=0,
                    expected_max=10000,
                )
            ],
            source_label=provenance,
            source_sha256=NMS_REFERENCE_CT_SHA256,
        ),
        InstructionValueRecipe(
            name="nms-ship-shield-candidate-v1",
            process_name="NMS.exe",
            module="NMS.exe",
            build_identity=NMS_ACCELERATOR_BUILD,
            aob_pattern="0F 11 4B 10 41 0F 10 47 20 0F 11 43 20 E8",
            base_register="rbx",
            fields=[
                InstructionValueField(
                    name="Ship shield current candidate",
                    offset=0x18,
                    value_type=ValueType.F64,
                    expected_min=0,
                ),
                InstructionValueField(
                    name="Ship shield maximum candidate",
                    offset=0x20,
                    value_type=ValueType.F64,
                    expected_min=0,
                ),
            ],
            source_label=provenance,
            source_sha256=NMS_REFERENCE_CT_SHA256,
        ),
    ]


def builtin_accelerator_sources(
    process_name: str,
    build_identity: str,
) -> list[AcceleratorSource]:
    if process_name.casefold() != "nms.exe" or build_identity != NMS_ACCELERATOR_BUILD:
        return []
    return [
        AcceleratorSource(
            title="Locally supplied No Man's Sky CT",
            source_kind="cheat_engine_table",
            use="AOB, register, and structure-offset hints; Auto Assembler and Lua stay inert",
        ),
        AcceleratorSource(
            title="NMSSaveExplorer",
            url="https://github.com/CheckForUpdates/NMSSaveExplorer",
            source_kind="public_source_repository",
            use="Save decoding and inventory/currency semantic reference",
        ),
        AcceleratorSource(
            title="NMSE",
            url="https://github.com/vectorcmdr/NMSE",
            source_kind="public_source_repository",
            use="Save-context, health, currency, and inventory semantic reference",
        ),
        AcceleratorSource(
            title="NoMansSky.Api",
            url="https://github.com/gurrenm3/NoMansSky.Api",
            source_kind="public_source_repository",
            use="Feature names and signature-scanning reference only; no injection is reused",
        ),
        AcceleratorSource(
            title=(
                "NMSSaveEditor 1.21.0 resources at "
                "6047315f47321e2a8400d38bf8d904bcca88bb8d"
            ),
            url="https://github.com/goatfungus/NMSSaveEditor",
            source_kind="public_packaged_resource_reference",
            use=(
                "Data-only inventory slot/save aliases and item IDs; packaged EXE/JAR code "
                "stays inert and is never redistributed"
            ),
        ),
        AcceleratorSource(
            title="nmsmc at a44308e8d6ea6cc0c05869b8ac473a61fdbd3a7c",
            url="https://github.com/SplinterGU/nmsmc",
            source_kind="public_source_repository",
            use=(
                "MIT-licensed container stack-limit taxonomy only; modded example values are "
                "not treated as vanilla limits or RAM offsets"
            ),
        ),
    ]
