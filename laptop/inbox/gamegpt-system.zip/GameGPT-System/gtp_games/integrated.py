from __future__ import annotations

import json
import re
from datetime import UTC, datetime
from enum import StrEnum
from pathlib import Path
from uuid import uuid4

from pydantic import BaseModel, Field

from gtp_games.models import CheatTableResult, GameCheatCatalog, GameCheatFeature, ValueType


class InputKind(StrEnum):
    PROMPT = "prompt"
    VALUE = "value"
    DIRECTION = "direction"
    ACTION = "action"


class CapabilityState(StrEnum):
    REFERENCE = "reference"
    CANDIDATE = "candidate"
    LOCKED = "locked"
    VERIFIED = "verified"
    BLOCKED = "blocked"


class CapabilityAction(StrEnum):
    VERIFY = "verify"
    WATCH = "watch"
    SET = "set"
    ADJUST = "adjust"
    FREEZE = "freeze"
    RESTORE = "restore"
    OVERLAY = "overlay"
    HOTKEY = "hotkey"
    SCRIPT = "script"
    HISTORY = "history"
    REVERIFY = "reverify"
    PIN = "pin"


class MultiUseInput(BaseModel):
    raw: str
    kind: InputKind
    target: str | None = None
    value: float | None = None
    direction: str | None = None
    action: CapabilityAction | None = None
    prompt: str | None = None
    requires_write: bool = False
    executes_memory_write: bool = False
    notes: list[str] = Field(default_factory=list)


class ValuePriorityEntry(BaseModel):
    name: str
    priority: int = Field(ge=0, le=100)
    category: str
    source: str
    locator_kinds: list[str] = Field(default_factory=list)
    address_expression: str | None = None
    pointer_offsets: list[int] = Field(default_factory=list)
    layout_peers: list[str] = Field(default_factory=list)
    reference_only: bool = True
    evidence: list[str] = Field(default_factory=list)


class ValuePriorityMap(BaseModel):
    source_sha256: str
    build_compatibility: str
    entries: list[ValuePriorityEntry]
    reference_only: bool = True
    generated_at: datetime = Field(default_factory=lambda: datetime.now(UTC))


class CapabilityRow(BaseModel):
    id: str
    name: str
    value_type: ValueType | None = None
    current_value: int | float | None = None
    maximum_value: int | float | None = None
    state: CapabilityState
    source: str
    priority: int = Field(ge=0, le=100)
    actions: list[CapabilityAction]
    write_actions_unlocked: bool = False
    discovery_run_id: str | None = None
    discovery_candidate_ids: list[str] = Field(default_factory=list)
    write_tested_candidate_ids: list[str] = Field(default_factory=list)
    evidence: list[str] = Field(default_factory=list)


class LayoutPolicy(BaseModel):
    mode: str
    process_rows: int
    game_rows: int
    padding: int
    wraplength: int
    title_size: int


class IntegratedHistoryEvent(BaseModel):
    id: str = Field(default_factory=lambda: uuid4().hex)
    capability_id: str | None = None
    action: str
    before: str | int | float | bool | None = None
    after: str | int | float | bool | None = None
    reversible: bool = True
    local_only: bool = True
    created_at: datetime = Field(default_factory=lambda: datetime.now(UTC))


class IntegratedUiState(BaseModel):
    overlays: dict[str, bool] = Field(default_factory=dict)
    overlay_visible: bool = False
    overlay_hotkey: str = "<F8>"
    hotkeys: dict[str, str] = Field(default_factory=dict)
    pinned: list[str] = Field(default_factory=list)
    history: list[IntegratedHistoryEvent] = Field(default_factory=list)


_ACTION_PATTERN = re.compile(
    r"^(?P<action>set|adjust|freeze|watch|overlay|restore|reverify|verify|pin|script)"
    r"\s+(?P<target>.+?)(?:\s+to\s+(?P<value>-?\d+(?:\.\d+)?))?$",
    re.I,
)
_DIRECTION_PATTERN = re.compile(
    r"^(?:(?P<target>.+?)\s+)?(?P<direction>increased|decreased|changed|unchanged|stable)$",
    re.I,
)
_NAMED_VALUE_PATTERN = re.compile(
    r"^(?P<target>[A-Za-z][A-Za-z /_-]{1,48}?)(?:\s*(?:=|:))?\s+"
    r"(?P<value>-?\d+(?:\.\d+)?)$",
)
_WRITING_ACTIONS = {
    CapabilityAction.SET,
    CapabilityAction.ADJUST,
    CapabilityAction.FREEZE,
    CapabilityAction.RESTORE,
}
_TOP_VALUE_TERMS = {
    "health": ("survival", 100),
    "shield": ("survival", 96),
    "stamina": ("resource", 94),
    "units": ("currency", 92),
    "nanites": ("currency", 91),
    "quicksilver": ("currency", 90),
    "ammo": ("combat", 88),
    "fuel": ("resource", 86),
    "inventory": ("inventory", 84),
    "movement": ("movement", 72),
    "speed": ("movement", 72),
    "jump": ("movement", 68),
}
_NOISE_TERMS = (
    "camera",
    "render",
    "shader",
    "material",
    "transform",
    "animation",
    "viewport",
    "audio",
)
_HOTKEY_PATTERN = re.compile(
    r"^(?:(?:Control|Alt|Shift)-){0,3}(?:F(?:[1-9]|1[0-2])|[A-Za-z0-9])$",
    re.I,
)


def parse_multi_use_input(text: str, *, selected_target: str | None = None) -> MultiUseInput:
    raw = text.strip()
    if not raw:
        raise ValueError("enter a GPT request, visible value, or observed direction")
    try:
        number = float(raw)
    except ValueError:
        number = None
    if number is not None:
        return MultiUseInput(
            raw=raw,
            kind=InputKind.VALUE,
            target=selected_target,
            value=number,
            notes=["visible-value evidence only; no write was performed"],
        )
    action_match = _ACTION_PATTERN.fullmatch(raw)
    if action_match:
        action = CapabilityAction(action_match.group("action").casefold())
        value_text = action_match.group("value")
        requires_write = action in _WRITING_ACTIONS
        return MultiUseInput(
            raw=raw,
            kind=InputKind.ACTION,
            target=action_match.group("target").strip(),
            value=float(value_text) if value_text is not None else None,
            action=action,
            requires_write=requires_write,
            notes=[
                (
                    "ready for an explicit user-requested Apply with live comparison and readback"
                    if requires_write
                    else "safe local action or read-only plan"
                )
            ],
        )
    named_value = _NAMED_VALUE_PATTERN.fullmatch(raw)
    if named_value:
        return MultiUseInput(
            raw=raw,
            kind=InputKind.VALUE,
            target=named_value.group("target").strip(),
            value=float(named_value.group("value")),
            notes=["visible-value evidence only; no write was performed"],
        )
    directional = _DIRECTION_PATTERN.fullmatch(raw)
    if directional:
        return MultiUseInput(
            raw=raw,
            kind=InputKind.DIRECTION,
            target=(directional.group("target") or selected_target),
            direction=directional.group("direction").casefold(),
            notes=["event evidence only; snapshot generation remains rollbackable"],
        )
    return MultiUseInput(
        raw=raw,
        kind=InputKind.PROMPT,
        target=selected_target,
        prompt=raw,
        notes=["route through the existing GPT assistant; no memory write is implied"],
    )


def build_ct_value_priority_map(result: CheatTableResult) -> ValuePriorityMap:
    entries: dict[str, ValuePriorityEntry] = {}
    shared_bases: dict[str, list] = {}
    for hint in result.hints:
        if hint.address_expression and hint.pointer_offsets:
            shared_bases.setdefault(hint.address_expression.casefold(), []).append(hint)
    for hint in result.hints:
        name = hint.description.strip() or "Unnamed value"
        category, priority = _priority_for_name(name)
        locator_kinds: list[str] = []
        if hint.pointer_offsets:
            locator_kinds.append("pointer")
            priority += 5
        if hint.module_offset is not None:
            locator_kinds.append("module_offset")
            priority += 4
        if hint.script_present:
            locator_kinds.append("script_reference")
        peers = [
            item.description
            for item in shared_bases.get((hint.address_expression or "").casefold(), [])
            if item.description.casefold() != name.casefold()
        ]
        layout_evidence = []
        if peers:
            layout_evidence.append(
                "Shares one CT base expression with "
                + ", ".join(peers[:5])
                + "; verify the relative layout read-only before use."
            )
        _merge_priority_entry(
            entries,
            ValuePriorityEntry(
                name=name,
                priority=min(100, priority),
                category=category,
                source="ct_entry",
                locator_kinds=locator_kinds,
                address_expression=hint.address_expression,
                pointer_offsets=hint.pointer_offsets,
                layout_peers=peers,
                evidence=[
                    *hint.context[-3:],
                    *layout_evidence,
                    "imported CT content remains reference-only",
                ],
            ),
        )
    for finding in result.script_findings:
        category, priority = _priority_for_name(finding.description)
        kinds = ["aob"] if finding.signatures else []
        if finding.module_offsets:
            kinds.append("module_offset")
        _merge_priority_entry(
            entries,
            ValuePriorityEntry(
                name=finding.description,
                priority=min(100, priority + int(bool(kinds)) * 4),
                category=category,
                source=f"ct_{finding.language.casefold()}_reference",
                locator_kinds=kinds,
                evidence=[
                    f"source script SHA-256 {finding.sha256}",
                    "source code was not retained or executed",
                ],
            ),
        )
    return ValuePriorityMap(
        source_sha256=result.source_sha256,
        build_compatibility=result.build_compatibility,
        entries=sorted(
            entries.values(),
            key=lambda item: (item.priority, item.name.casefold()),
            reverse=True,
        ),
    )


def build_capability_rows(
    catalog: GameCheatCatalog | dict,
    *,
    write_enabled: bool,
) -> list[CapabilityRow]:
    parsed = (
        catalog
        if isinstance(catalog, GameCheatCatalog)
        else GameCheatCatalog.model_validate(catalog)
    )
    rows = [_capability_from_feature(item, write_enabled=write_enabled) for item in parsed.features]
    return sorted(rows, key=lambda item: (item.priority, item.name.casefold()), reverse=True)


def responsive_layout(width: int, height: int, dpi_scale: float = 1.0) -> LayoutPolicy:
    logical_width = width / max(dpi_scale, 0.5)
    logical_height = height / max(dpi_scale, 0.5)
    if logical_width < 760 or logical_height < 580:
        return LayoutPolicy(
            mode="compact",
            process_rows=4,
            game_rows=3,
            padding=8,
            wraplength=max(360, int(logical_width - 100)),
            title_size=16,
        )
    if logical_width < 1100:
        return LayoutPolicy(
            mode="standard",
            process_rows=4,
            game_rows=3,
            padding=12,
            wraplength=max(560, int(logical_width - 110)),
            title_size=17,
        )
    return LayoutPolicy(
        mode="wide",
        process_rows=5,
        game_rows=4,
        padding=16,
        wraplength=min(1180, int(logical_width - 120)),
        title_size=18,
    )


def normalize_hotkey(value: str) -> str:
    normalized = value.strip().strip("<>")
    if not _HOTKEY_PATTERN.fullmatch(normalized):
        raise ValueError("use F1-F12, a letter/number, or Control/Alt/Shift combinations")
    parts = normalized.split("-")
    key = parts[-1].upper() if len(parts[-1]) == 1 else parts[-1].title()
    modifiers = [part.title() for part in parts[:-1]]
    return f"<{'-'.join([*modifiers, key])}>"


class IntegratedStateStore:
    def __init__(self, path: Path) -> None:
        self.path = path

    def load(self) -> IntegratedUiState:
        if not self.path.is_file():
            return IntegratedUiState()
        return IntegratedUiState.model_validate_json(self.path.read_text(encoding="utf-8"))

    def save(self, state: IntegratedUiState) -> Path:
        state.history = state.history[-500:]
        self.path.parent.mkdir(parents=True, exist_ok=True)
        temporary = self.path.with_suffix(self.path.suffix + ".tmp")
        temporary.write_text(
            json.dumps(state.model_dump(mode="json"), indent=2),
            encoding="utf-8",
        )
        temporary.replace(self.path)
        return self.path

    def record(
        self,
        state: IntegratedUiState,
        *,
        action: str,
        capability_id: str | None = None,
        before: str | int | float | bool | None = None,
        after: str | int | float | bool | None = None,
    ) -> IntegratedHistoryEvent:
        event = IntegratedHistoryEvent(
            capability_id=capability_id,
            action=action,
            before=before,
            after=after,
        )
        state.history.append(event)
        self.save(state)
        return event

    def restore_local_preference(
        self,
        state: IntegratedUiState,
        event_id: str,
    ) -> IntegratedHistoryEvent:
        event = next((item for item in state.history if item.id == event_id), None)
        if event is None:
            raise KeyError(f"history event {event_id} was not found")
        if event.action == "overlay" and event.capability_id:
            state.overlays[event.capability_id] = bool(event.before)
        elif event.action == "hotkey" and event.capability_id:
            if event.before:
                state.hotkeys[event.capability_id] = str(event.before)
            else:
                state.hotkeys.pop(event.capability_id, None)
        elif event.action == "pin" and event.capability_id:
            if bool(event.before) and event.capability_id not in state.pinned:
                state.pinned.append(event.capability_id)
            elif not bool(event.before):
                state.pinned = [item for item in state.pinned if item != event.capability_id]
        else:
            raise ValueError("only local overlay, hotkey, and pin preferences can be restored here")
        restored = self.record(
            state,
            action=f"restore:{event.action}",
            capability_id=event.capability_id,
            before=event.after,
            after=event.before,
        )
        return restored


def _priority_for_name(name: str) -> tuple[str, int]:
    normalized = name.casefold()
    if any(term in normalized for term in _NOISE_TERMS):
        return "engine_noise", 10
    for term, (category, priority) in _TOP_VALUE_TERMS.items():
        if term in normalized:
            return category, priority
    return "gameplay", 55


def _merge_priority_entry(
    entries: dict[str, ValuePriorityEntry],
    candidate: ValuePriorityEntry,
) -> None:
    key = re.sub(r"\s+", " ", candidate.name.casefold()).strip()
    current = entries.get(key)
    if current is None or candidate.priority > current.priority:
        if current is not None:
            candidate.locator_kinds = sorted(set(candidate.locator_kinds + current.locator_kinds))
            candidate.layout_peers = sorted(set(candidate.layout_peers + current.layout_peers))
            candidate.evidence = list(dict.fromkeys(current.evidence + candidate.evidence))[-10:]
            candidate.address_expression = (
                candidate.address_expression or current.address_expression
            )
            candidate.pointer_offsets = candidate.pointer_offsets or current.pointer_offsets
        entries[key] = candidate
        return
    current.locator_kinds = sorted(set(current.locator_kinds + candidate.locator_kinds))
    current.layout_peers = sorted(set(current.layout_peers + candidate.layout_peers))
    current.address_expression = current.address_expression or candidate.address_expression
    current.pointer_offsets = current.pointer_offsets or candidate.pointer_offsets
    current.evidence = list(dict.fromkeys(current.evidence + candidate.evidence))[-10:]


def _capability_from_feature(
    feature: GameCheatFeature,
    *,
    write_enabled: bool,
) -> CapabilityRow:
    status = feature.status.casefold()
    discovery_verified = bool(feature.write_tested_candidate_ids)
    discovery_test_ready = bool(feature.discovery_candidate_ids)
    if (
        feature.source_kind == "confirmed_local_profile" and feature.profile_id
    ) or discovery_verified:
        state = CapabilityState.VERIFIED
    elif "locked_read_only" in status:
        state = CapabilityState.LOCKED
    elif "block" in status or "reject" in status:
        state = CapabilityState.BLOCKED
    elif feature.source_kind in {"web_reference", "ct_reference", "portable_table"}:
        state = CapabilityState.REFERENCE
    else:
        state = CapabilityState.CANDIDATE
    _, base_priority = _priority_for_name(feature.name)
    if state is CapabilityState.VERIFIED:
        actions = [
            CapabilityAction.WATCH,
            CapabilityAction.OVERLAY,
            CapabilityAction.HOTKEY,
            CapabilityAction.SCRIPT,
            CapabilityAction.HISTORY,
            CapabilityAction.REVERIFY,
            CapabilityAction.PIN,
        ]
        if write_enabled and not discovery_verified:
            actions[1:1] = [
                CapabilityAction.SET,
                CapabilityAction.ADJUST,
                CapabilityAction.FREEZE,
                CapabilityAction.RESTORE,
            ]
        elif write_enabled:
            actions[1:1] = [CapabilityAction.SET, CapabilityAction.ADJUST]
    elif state is CapabilityState.LOCKED:
        actions = ([CapabilityAction.VERIFY] if discovery_test_ready else []) + [
            CapabilityAction.WATCH,
            CapabilityAction.HISTORY,
            CapabilityAction.REVERIFY,
            CapabilityAction.PIN,
        ]
    elif state in {CapabilityState.REFERENCE, CapabilityState.CANDIDATE}:
        actions = [CapabilityAction.VERIFY, CapabilityAction.HISTORY, CapabilityAction.PIN]
    else:
        actions = [CapabilityAction.HISTORY]
    return CapabilityRow(
        id=feature.id,
        name=feature.name,
        value_type=feature.value_type,
        current_value=feature.current_value,
        maximum_value=feature.maximum_value,
        state=state,
        source=feature.source_kind,
        priority=min(100, max(base_priority, round(feature.confidence * 100))),
        actions=actions,
        write_actions_unlocked=state is CapabilityState.VERIFIED and write_enabled,
        discovery_run_id=feature.discovery_run_id,
        discovery_candidate_ids=(feature.discovery_candidate_ids if discovery_test_ready else []),
        write_tested_candidate_ids=feature.write_tested_candidate_ids,
        evidence=feature.evidence,
    )
