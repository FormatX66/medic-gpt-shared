from __future__ import annotations

import os
import sys

from mcp.server.fastmcp import FastMCP
from mcp.server.fastmcp import server as fastmcp_server_module
from mcp.types import ToolAnnotations

from gtp_games.config import Settings
from gtp_games.control import CONTROL_PROTOCOL_VERSIONS, ControlNegotiation
from gtp_games.integrated import CapabilityRow, MultiUseInput, ValuePriorityMap
from gtp_games.inventory_observer import InventoryObserverStatus, InventorySlotObservation
from gtp_games.models import (
    CheatAction,
    CheatDiscoveryRunStatus,
    CheatTableResult,
    CheatTableSourceBuild,
    Comparison,
    GameCheatCatalog,
    GameProfileMonitorStatus,
    GameValueTable,
    GameValueTableExportResult,
    HealthBarResult,
    HoldStatus,
    InventoryScreenResult,
    NmsSaveComparisonReport,
    RollbackResult,
    UnrealDiscoveryResult,
    UnrealGasMonitorStatus,
    UnrealGasProfile,
    UnrealGasProfileValue,
    UnrealGasScanSummary,
    UnrealGasTemporalResult,
    UnrealGasWatchResult,
    ValueType,
    WatchResult,
    WriteResult,
)
from gtp_games.plugin_runtime import (
    AttachedSessionResult,
    DetachedSessionResult,
    DiscoveryCandidateTestResult,
    GameCheatActionResult,
    HoldListResult,
    InventoryMatrixProbeResult,
    PluginRuntime,
    PluginStatus,
    PracticeValueResult,
    PreparedDiscoveryCandidateTestResult,
    PreparedGameCheatActionResult,
    PreparedInventoryMatrixProbeResult,
    PreparedWriteResult,
    ProcessListResult,
    ScanResult,
    WriteConfirmer,
)
from gtp_games.script_lab import (
    NativeScriptCandidate,
    NativeScriptKind,
    ScriptVerification,
)
from gtp_games.service import ApplicationService
from gtp_games.temporal import (
    CandidateGeneration,
    EventDirection,
    TemporalCorrelationSession,
)

# MCP 1.29 ships a generic settings forward reference that Pydantic 2.13 asks
# applications to resolve before reading environment-backed server settings.
fastmcp_server_module.Settings.model_rebuild(_types_namespace=vars(fastmcp_server_module))

INSTRUCTIONS = (
    "GTP Games is limited to local personal offline games the user is authorized to modify. "
    "Never assist with protected, anti-cheat, DRM, online, or competitive processes. Attach "
    "read-only unless the user explicitly requests writes. Narrow scans before preparing a "
    "write. Preserve one to five exact matching candidates and test each separately when the "
    "user chooses verification. For inventory only, the user-selected automatic mapper may "
    "apply unique odd deltas to that same bounded set, observe them, and restore every original "
    "value before saving unambiguous slot matches. An explicit user request to set a named "
    "value may use the "
    "direct Apply tool without a second phrase dialog; expected-current comparison, readback, "
    "audit, and failed-candidate restore remain mandatory. "
    "If the user selected a process in the companion window, call list_game_processes and use "
    "its selected_session instead of asking them to identify an executable name. Immediately "
    "after the first attachment, call get_game_cheat_catalog. Treat public forum/table data as "
    "advisory until its declared build fingerprint exactly matches the live executable and the "
    "companion validates a live address and behavior. Never start a set or "
    "hold action unless the user explicitly requests that named cheat. For autonomous "
    "discovery, use the dedicated controller: it attaches "
    "read-only, revisits targets after collapsed scans, and never writes game memory. If a "
    "requested feature is missing and browsing is available, research the "
    "catalog's exact-game queries on public table-author and modding-forum pages, then add direct "
    "public .CT sources as inert hints. Never copy or execute downloaded scripts. Temporal "
    "correlation must preserve earlier generations, and Script Lab candidates remain "
    "non-executable even after read-only verification. For a supported exact game build, call "
    "start_moved_inventory_observer and wait for its armed receipt before asking for or "
    "automating one item move, then retrieve the result by token."
)

READ_ONLY = ToolAnnotations(
    readOnlyHint=True,
    destructiveHint=False,
    idempotentHint=True,
    openWorldHint=False,
)
DYNAMIC_READ = ToolAnnotations(
    readOnlyHint=True,
    destructiveHint=False,
    idempotentHint=False,
    openWorldHint=False,
)
REMOTE_READ = ToolAnnotations(
    readOnlyHint=True,
    destructiveHint=False,
    idempotentHint=False,
    openWorldHint=True,
)
STATEFUL_READ = ToolAnnotations(
    readOnlyHint=False,
    destructiveHint=False,
    idempotentHint=False,
    openWorldHint=False,
)
LOCAL_MUTATION = ToolAnnotations(
    readOnlyHint=False,
    destructiveHint=False,
    idempotentHint=True,
    openWorldHint=False,
)
DESTRUCTIVE_LOCAL = ToolAnnotations(
    readOnlyHint=False,
    destructiveHint=True,
    idempotentHint=False,
    openWorldHint=False,
)


def create_mcp_server(
    settings: Settings | None = None,
    *,
    application: ApplicationService | None = None,
    confirmer: WriteConfirmer | None = None,
) -> tuple[FastMCP, PluginRuntime]:
    active_settings = settings or Settings()
    runtime = PluginRuntime(
        active_settings,
        application=application,
        confirmer=confirmer,
    )
    server = FastMCP(
        name="GTP Games",
        instructions=INSTRUCTIONS,
        host=active_settings.mcp_host,
        port=active_settings.mcp_port,
        streamable_http_path="/mcp",
        json_response=True,
        stateless_http=True,
    )

    @server.tool(
        title="Check GTP Games companion",
        description=(
            "Use this when the user wants to verify that the local GTP Games companion is "
            "ready or learn whether memory writes are available."
        ),
        annotations=READ_ONLY,
        structured_output=True,
    )
    def get_companion_status() -> PluginStatus:
        return runtime.status()

    @server.tool(
        title="Negotiate the GameGPT control protocol",
        description="Select a mutually supported canonical control protocol version.",
        annotations=READ_ONLY,
        structured_output=True,
    )
    def negotiate_gamegpt_control(
        client_versions: list[str] | None = None,
    ) -> ControlNegotiation:
        return runtime.negotiate_control(
            client_versions if client_versions is not None else list(CONTROL_PROTOCOL_VERSIONS)
        )

    @server.tool(
        title="Interpret the integrated GPT, value, and direction input",
        description=(
            "Classify one compact input as a GPT prompt, visible numeric value, observed "
            "direction, or capability action. This returns a plan and never writes game memory."
        ),
        annotations=READ_ONLY,
        structured_output=True,
    )
    def interpret_integrated_input(
        text: str,
        selected_target: str | None = None,
    ) -> MultiUseInput:
        return runtime.interpret_integrated_input(text, selected_target=selected_target)

    @server.tool(
        title="List evidence-gated integrated capabilities",
        description=(
            "Convert the current game catalog into compact capability rows. Candidate and "
            "reference values expose verification, not write actions."
        ),
        annotations=READ_ONLY,
        structured_output=True,
    )
    def get_integrated_capabilities(session_id: str) -> list[CapabilityRow]:
        return runtime.integrated_capabilities(session_id)

    @server.tool(
        title="List eligible local game processes",
        description=(
            "Refresh the companion's running-process picker and report its current selection. "
            "Processes include PID, executable name, path when available, live GPU/RAM use, "
            "game-likelihood score, and safety status. The server still rejects protected, "
            "system, anti-cheat, or unauthorized targets."
        ),
        annotations=READ_ONLY,
        structured_output=True,
    )
    def list_game_processes() -> ProcessListResult:
        return runtime.list_processes()

    @server.tool(
        title="Attach to a local game process",
        description=(
            "Use this when the user has selected a process ID. Keep write_enabled false unless "
            "the user explicitly requested controlled writes and the companion allowlist "
            "permits it. When the local app selected a launcher game or portable GTP table, "
            "pass its stable game_key and table_path. A selected table is imported only as "
            "non-write-ready discovery guidance until this launch validates it."
        ),
        annotations=STATEFUL_READ,
        structured_output=True,
    )
    def attach_game_process(
        pid: int,
        write_enabled: bool = False,
        game_key: str | None = None,
        game_name: str | None = None,
        table_path: str | None = None,
    ) -> AttachedSessionResult:
        return runtime.attach(
            pid,
            write_enabled=write_enabled,
            game_key=game_key,
            game_name=game_name,
            table_path=table_path,
        )

    @server.tool(
        title="Detach from a local game process",
        description=(
            "Use this when the user is finished with a process session or wants to switch games."
        ),
        annotations=STATEFUL_READ,
        structured_output=True,
    )
    def detach_game_process(session_id: str) -> DetachedSessionResult:
        return runtime.detach(session_id)

    @server.tool(
        title="Start an exact value scan",
        description=(
            "Use this when the user knows a value currently visible in the local game, such as "
            "health 100. Defaults to a 32-bit integer unless the user identifies another type."
        ),
        annotations=STATEFUL_READ,
        structured_output=True,
    )
    def start_value_scan(
        session_id: str,
        value: int | float,
        value_type: ValueType = ValueType.I32,
    ) -> ScanResult:
        return runtime.start_scan(session_id, value, value_type)

    @server.tool(
        title="Start an unknown value scan",
        description=(
            "Take a bounded read-only snapshot when the current value is not displayed. "
            "Use i32, i16, f32, or f64 as appropriate. Set normalized true only for f32/f64 "
            "health stored from 0.0 to 1.0, then refine after damage or healing."
        ),
        annotations=STATEFUL_READ,
        structured_output=True,
    )
    def start_unknown_value_scan(
        session_id: str,
        value_type: ValueType = ValueType.I32,
        normalized: bool = False,
    ) -> ScanResult:
        return runtime.start_unknown_scan(
            session_id,
            value_type,
            normalized=normalized,
        )

    @server.tool(
        title="Refine a value scan",
        description=(
            "Use this after the in-game value changes or stays the same. For exact filtering, "
            "provide the new value. For changed, unchanged, increased, or decreased, omit value."
        ),
        annotations=STATEFUL_READ,
        structured_output=True,
    )
    def refine_value_scan(
        scan_id: str,
        comparison: Comparison,
        value: int | float | None = None,
    ) -> ScanResult:
        return runtime.refine_scan(scan_id, comparison, value)

    @server.tool(
        title="Inspect scan candidates",
        description=(
            "Use this when the user wants to review the current candidate addresses and values "
            "for an existing scan. Limit must be between 0 and 200."
        ),
        annotations=READ_ONLY,
        structured_output=True,
    )
    def get_scan_candidates(scan_id: str, limit: int = 20) -> ScanResult:
        if not 0 <= limit <= 200:
            raise ValueError("limit must be between 0 and 200")
        return runtime.scan_candidates(scan_id, limit=limit)

    @server.tool(
        title="Observe one moved inventory stack",
        description=(
            "Open a short read-only learning window for a validated exact-build inventory "
            "instruction. Move one item stack during the window. A temporary hardware "
            "breakpoint observes the live record without patching code or writing game memory."
        ),
        annotations=STATEFUL_READ,
        structured_output=True,
    )
    def observe_moved_inventory_slot(
        session_id: str,
        timeout_seconds: float = 20,
        recipe_name: str | None = None,
    ) -> InventorySlotObservation:
        return runtime.observe_moved_inventory_slot(
            session_id,
            timeout_seconds=timeout_seconds,
            recipe_name=recipe_name,
        )

    @server.tool(
        title="Arm inventory move learning",
        description=(
            "Validate the exact build and unique inventory signature, start a background "
            "hardware observer, and return only after it is genuinely armed. Perform one "
            "inventory move only after this tool returns."
        ),
        annotations=STATEFUL_READ,
        structured_output=True,
    )
    def start_moved_inventory_observer(
        session_id: str,
        timeout_seconds: float = 20,
        recipe_name: str | None = None,
    ) -> InventoryObserverStatus:
        return runtime.start_moved_inventory_observer(
            session_id,
            timeout_seconds=timeout_seconds,
            recipe_name=recipe_name,
        )

    @server.tool(
        title="Get inventory move learning result",
        description="Return or briefly wait for one armed inventory observer result.",
        annotations=READ_ONLY,
        structured_output=True,
    )
    def get_moved_inventory_observer(
        session_id: str,
        observer_token: str,
        wait_seconds: float = 0,
    ) -> InventoryObserverStatus:
        return runtime.moved_inventory_observer_status(
            session_id,
            observer_token,
            wait_seconds=wait_seconds,
        )

    @server.tool(
        title="Cancel inventory move learning",
        description="Cancel an active observer, restore debug registers, and detach.",
        annotations=STATEFUL_READ,
        structured_output=True,
    )
    def cancel_moved_inventory_observer(
        session_id: str,
        observer_token: str,
    ) -> InventoryObserverStatus:
        return runtime.cancel_moved_inventory_observer(session_id, observer_token)

    @server.tool(
        title="Start autonomous No Man's Sky cheat discovery",
        description=(
            "Use the selected NMS.exe session and continuously work through health, "
            "shield, stamina, jetpack, currencies, vehicle energy, weapons, and scanner. "
            "The controller validates cached scans, preserves first-scan candidates until a "
            "real observed change, and promotes only stable pointer or AoB locators. Discovery "
            "itself never performs a memory write, including in a write-enabled session."
        ),
        annotations=STATEFUL_READ,
        structured_output=True,
    )
    def start_autonomous_cheat_discovery(
        process_name: str = "NMS.exe",
        session_id: str | None = None,
        target_order: list[str] | None = None,
        interval_seconds: float = 2.0,
        observation_seconds: float = 10.0,
        revisit_seconds: float = 30.0,
    ) -> CheatDiscoveryRunStatus:
        return runtime.start_autonomous_discovery(
            process_name=process_name,
            session_id=session_id,
            target_order=target_order,
            interval_seconds=interval_seconds,
            observation_seconds=observation_seconds,
            revisit_seconds=revisit_seconds,
        )

    @server.tool(
        title="Get autonomous cheat discovery progress",
        description=(
            "Report per-target scans, collapses, observed changes, locator evidence, confidence, "
            "and persistent-table promotions for a running or completed discovery loop."
        ),
        annotations=READ_ONLY,
        structured_output=True,
    )
    def get_autonomous_cheat_discovery(run_id: str) -> CheatDiscoveryRunStatus:
        return runtime.autonomous_discovery_status(run_id)

    @server.tool(
        title="Supply a visible value to autonomous discovery",
        description=(
            "Record a currently displayed exact value for Units, Nanites, Quicksilver, ammo, "
            "or another target so the loop can use an exact next scan. Source may be user or "
            "a stable local screen observation."
        ),
        annotations=STATEFUL_READ,
        structured_output=True,
    )
    def set_autonomous_cheat_discovery_value(
        run_id: str,
        target_name: str,
        value: int | float,
        source: str = "user",
    ) -> CheatDiscoveryRunStatus:
        return runtime.set_autonomous_discovery_value(
            run_id,
            target_name,
            value,
            source=source,
        )

    @server.tool(
        title="Correlate a HUD meter change with RAM",
        description=(
            "Use a stable local screenshot burst to start a normalized unknown-value baseline "
            "or refine it when the same visible meter increases or decreases. The approximate "
            "screen percentage is evidence and is not treated as exact memory data."
        ),
        annotations=STATEFUL_READ,
        structured_output=True,
    )
    def record_autonomous_cheat_screen_comparison(
        run_id: str,
        target_name: str,
        comparison: str,
        screen_value: int | float,
    ) -> CheatDiscoveryRunStatus:
        return runtime.record_autonomous_discovery_screen_comparison(
            run_id,
            target_name,
            comparison,
            screen_value,
        )

    @server.tool(
        title="Rescan every saved game value",
        description=(
            "Refresh the selected game's registered read-only save snapshot and requeue every "
            "known exact value. Previous scan generations remain available for rollback."
        ),
        annotations=STATEFUL_READ,
        structured_output=True,
    )
    def rescan_all_saved_game_values(run_id: str) -> CheatDiscoveryRunStatus:
        return runtime.rescan_autonomous_discovery_values(run_id)

    @server.tool(
        title="Capture one labeled gameplay behavior",
        description=(
            "Use only for a guided movement-speed or jump-height check. Call phase 'begin' "
            "while the player is resting, perform only the labeled action, then call phase "
            "'complete'. Each call remains read-only. Unlabeled background changes never "
            "count as behavioral validation."
        ),
        annotations=STATEFUL_READ,
        structured_output=True,
    )
    def capture_autonomous_cheat_behavior(
        run_id: str,
        target_name: str,
        phase: str,
        label: str = "",
    ) -> CheatDiscoveryRunStatus:
        return runtime.capture_autonomous_discovery_behavior(
            run_id,
            target_name,
            phase,
            label,
        )

    @server.tool(
        title="Stop autonomous cheat discovery",
        description="Stop the background read-only discovery loop and preserve its progress.",
        annotations=LOCAL_MUTATION,
        structured_output=True,
    )
    def stop_autonomous_cheat_discovery(run_id: str) -> CheatDiscoveryRunStatus:
        return runtime.stop_autonomous_discovery(run_id)

    @server.tool(
        title="Watch scan candidates read-only",
        description=(
            "Sample the current values of a bounded candidate set several times without "
            "writing memory. Use after refinements have produced a manageable set."
        ),
        annotations=DYNAMIC_READ,
        structured_output=True,
    )
    def watch_scan_candidates(
        scan_id: str,
        sample_count: int = 5,
        interval_ms: int = 500,
        limit: int = 20,
    ) -> WatchResult:
        if not 1 <= limit <= 50:
            raise ValueError("limit must be between 1 and 50")
        return runtime.watch_scan(
            scan_id,
            sample_count=sample_count,
            interval_ms=interval_ms,
            limit=limit,
        )

    @server.tool(
        title="Estimate a health bar from the game window",
        description=(
            "Capture only the selected local game window and estimate colored health-bar "
            "percentages. For best results provide x, y, width, and height for the bar; omit "
            "all four to request conservative automatic candidates. The image is not saved."
        ),
        annotations=DYNAMIC_READ,
        structured_output=True,
    )
    def estimate_health_bar(
        session_id: str,
        x: int | None = None,
        y: int | None = None,
        width: int | None = None,
        height: int | None = None,
        limit: int = 5,
    ) -> HealthBarResult:
        return runtime.detect_health_bars(
            session_id,
            x=x,
            y=y,
            width=width,
            height=height,
            limit=limit,
        )

    @server.tool(
        title="Read visible inventory values",
        description=(
            "Capture only the foreground selected game window and use the on-device Windows "
            "OCR engine to read visible inventory stack counts. Pixels are discarded, the "
            "companion overlay is masked, and this tool never writes game memory."
        ),
        annotations=DYNAMIC_READ,
        structured_output=True,
    )
    def inspect_inventory_screen(session_id: str) -> InventoryScreenResult:
        return runtime.read_inventory_screen(session_id)

    @server.tool(
        title="Inspect a Cheat Engine table safely",
        description=(
            "Read a local .CT file or fetch a public HTTPS .CT source into memory as untrusted "
            "data. Extract labels, value types, static pointers, and AOB signatures. Live "
            "read-only validation is allowed only when supplied source-build evidence exactly "
            "matches the selected executable. Original assembler, Lua, hotkeys, injection, "
            "and patch instructions are never executed or copied."
        ),
        annotations=REMOTE_READ,
        structured_output=True,
    )
    def inspect_cheat_engine_table(
        session_id: str,
        source: str,
        query: str = "health",
        limit: int = 50,
        source_author: str | None = None,
        source_release: str | None = None,
        source_updated_at: str | None = None,
        source_process_names: list[str] | None = None,
        source_executable_sha256: str | None = None,
        source_build_identity: str | None = None,
        source_store_app_id: str | None = None,
        source_store_build_id: str | None = None,
    ) -> CheatTableResult:
        if not 1 <= limit <= 200:
            raise ValueError("limit must be between 1 and 200")
        return runtime.inspect_cheat_table(
            session_id,
            source,
            query=query,
            limit=limit,
            source_build=CheatTableSourceBuild(
                author=source_author,
                release_label=source_release,
                updated_at=source_updated_at,
                process_names=source_process_names or [],
                executable_sha256=source_executable_sha256,
                build_identity=source_build_identity,
                store_app_id=source_store_app_id,
                store_build_id=source_store_build_id,
            ),
        )

    @server.tool(
        title="Import a Cheat Engine table as inert reference data",
        description=(
            "Statically parse a local .CT file or bounded public HTTPS .CT source without a "
            "process attachment. Return pointer paths, AOB signatures, module offsets, "
            "structures, script hashes, and overlay metadata. Auto Assembler, Lua, hotkeys, "
            "forms, embedded files, hooks, patches, and trainers are never executed or loaded."
        ),
        annotations=REMOTE_READ,
        structured_output=True,
    )
    def import_cheat_engine_reference(
        source: str,
        query: str = "",
        limit: int = 200,
        source_author: str | None = None,
        source_release: str | None = None,
        source_updated_at: str | None = None,
        source_process_names: list[str] | None = None,
        source_executable_sha256: str | None = None,
        source_build_identity: str | None = None,
        source_store_app_id: str | None = None,
        source_store_build_id: str | None = None,
    ) -> CheatTableResult:
        if not 1 <= limit <= 200:
            raise ValueError("limit must be between 1 and 200")
        return runtime.import_cheat_table_reference(
            source,
            query=query,
            limit=limit,
            source_build=CheatTableSourceBuild(
                author=source_author,
                release_label=source_release,
                updated_at=source_updated_at,
                process_names=source_process_names or [],
                executable_sha256=source_executable_sha256,
                build_identity=source_build_identity,
                store_app_id=source_store_app_id,
                store_build_id=source_store_build_id,
            ),
        )

    @server.tool(
        title="Build a CT-derived value priority map",
        description=(
            "Statically rank gameplay values and locator evidence from an untrusted CT source. "
            "The result remains reference-only and imported scripts are never executed."
        ),
        annotations=REMOTE_READ,
        structured_output=True,
    )
    def build_ct_value_priority_map(
        source: str,
        query: str = "",
        limit: int = 200,
    ) -> ValuePriorityMap:
        return runtime.ct_value_priority_map(source, query=query, limit=limit)

    @server.tool(
        title="Translate CT scripts into inert native candidates",
        description=(
            "Retain only imported script hashes, declarative locator intent, and rollbackable "
            "native plans. Auto Assembler, Lua, hooks, and patches are not copied or executed."
        ),
        annotations=REMOTE_READ,
        structured_output=True,
    )
    def translate_ct_script_candidates(
        source: str,
        query: str = "",
        limit: int = 50,
    ) -> list[NativeScriptCandidate]:
        return runtime.translate_ct_script_candidates(source, query=query, limit=limit)

    @server.tool(
        title="Start a rollbackable temporal correlation",
        description=(
            "Create generation zero from read-only candidate values. Later events are scored "
            "without deleting earlier generations."
        ),
        annotations=STATEFUL_READ,
        structured_output=True,
    )
    def start_temporal_correlation(
        target: str,
        values: dict[str, float],
        value_type: str = "unknown",
        label: str = "baseline",
    ) -> TemporalCorrelationSession:
        return runtime.start_temporal_correlation(
            target,
            values,
            value_type=value_type,
            label=label,
        )

    @server.tool(
        title="Capture a temporal gameplay event",
        description=(
            "Score a bounded read-only snapshot as changed, stable, increased, decreased, or "
            "a negative control while preserving its parent generation."
        ),
        annotations=STATEFUL_READ,
        structured_output=True,
    )
    def capture_temporal_event(
        session_id: str,
        values: dict[str, float],
        direction: EventDirection,
        label: str,
    ) -> CandidateGeneration:
        return runtime.capture_temporal_event(
            session_id,
            values,
            direction=direction,
            label=label,
        )

    @server.tool(
        title="Read a temporal correlation session",
        description="Return every preserved snapshot and candidate generation without mutation.",
        annotations=READ_ONLY,
        structured_output=True,
    )
    def get_temporal_correlation(session_id: str) -> TemporalCorrelationSession:
        return runtime.temporal_correlation(session_id)

    @server.tool(
        title="Roll back a temporal candidate generation",
        description=(
            "Select an earlier preserved generation as the branch point. This changes only "
            "local discovery state and never writes game memory."
        ),
        annotations=LOCAL_MUTATION,
        structured_output=True,
    )
    def rollback_temporal_generation(
        session_id: str,
        generation_id: str,
    ) -> CandidateGeneration:
        return runtime.rollback_temporal_generation(session_id, generation_id)

    @server.tool(
        title="Build a native Script Lab candidate",
        description=(
            "Create a declarative value, locator, patch, or overlay candidate with mandatory "
            "rollback. The candidate remains reference-only and cannot execute."
        ),
        annotations=STATEFUL_READ,
        structured_output=True,
    )
    def build_native_script_candidate(
        name: str,
        target: str,
        kind: NativeScriptKind,
        operation: str,
        parameters: dict[str, str | int | float | bool] | None = None,
        locator_kind: str | None = None,
    ) -> NativeScriptCandidate:
        return runtime.build_script_candidate(
            name=name,
            target=target,
            kind=kind,
            operation=operation,
            parameters=parameters,
            locator_kind=locator_kind,
        )

    @server.tool(
        title="Verify a native Script Lab candidate read-only",
        description=(
            "Evaluate exact-build, unique-locator, original-state, behavior, and rollback "
            "evidence. Passing still does not execute the candidate."
        ),
        annotations=STATEFUL_READ,
        structured_output=True,
    )
    def verify_native_script_candidate(
        candidate_id: str,
        exact_build_match: bool,
        locator_match_count: int | None,
        original_state_captured: bool,
        rollback_verified: bool,
        behavioral_events: int,
    ) -> ScriptVerification:
        return runtime.verify_script_candidate(
            candidate_id,
            exact_build_match=exact_build_match,
            locator_match_count=locator_match_count,
            original_state_captured=original_state_captured,
            rollback_verified=rollback_verified,
            behavioral_events=behavioral_events,
        )

    @server.tool(
        title="Get the first-connection game cheat catalog",
        description=(
            "Call immediately after attaching. Report background game/engine discovery, load "
            "confirmed local profiles, and list which requested cheats are ready versus which "
            "need table research or live calibration. No game memory is changed."
        ),
        annotations=DYNAMIC_READ,
        structured_output=True,
    )
    def get_game_cheat_catalog(session_id: str) -> GameCheatCatalog:
        return runtime.game_cheat_catalog(session_id)

    @server.tool(
        title="Read this game's separate value table",
        description=(
            "Read the native GTP table for the selected game build. Confirmed features and "
            "unresolved profiling candidates are stored in separate sections and use "
            "restart-stable object paths and offsets, never stale raw addresses. The file is "
            "data-only and contains no executable table scripts."
        ),
        annotations=READ_ONLY,
        structured_output=True,
    )
    def get_game_value_table(session_id: str) -> GameValueTable:
        return runtime.game_value_table(session_id)

    @server.tool(
        title="Compare local No Man's Sky saves",
        description=(
            "Read and compare two local NMS save snapshots without modifying or copying the "
            "original files. Rank field-level numeric deltas and label changes that match "
            "known Units, Nanites, or Quicksilver deltas so live-memory discovery can use "
            "save evidence instead of blind scans. Omit names to compare the two newest saves."
        ),
        annotations=DYNAMIC_READ,
        structured_output=True,
    )
    def compare_nms_save_snapshots(
        older_filename: str | None = None,
        newer_filename: str | None = None,
        limit: int = 250,
    ) -> NmsSaveComparisonReport:
        return runtime.compare_nms_saves(
            older_filename=older_filename,
            newer_filename=newer_filename,
            limit=limit,
        )

    @server.tool(
        title="Export this game's portable value table",
        description=(
            "Create or refresh a shareable data-only GTP table for the selected game build. "
            "The export contains restart-stable object paths, offsets, types, and confidence "
            "labels, but strips raw addresses, live values, profile/session IDs, scripts, "
            "source ledgers, executable paths, and other machine-specific paths. Importing an "
            "export never grants write permission; every feature must revalidate locally."
        ),
        annotations=LOCAL_MUTATION,
        structured_output=True,
    )
    def export_game_value_table(session_id: str) -> GameValueTableExportResult:
        return runtime.export_game_value_table(session_id)

    @server.tool(
        title="Add public table sources to the game cheat catalog",
        description=(
            "Inspect up to ten local .CT files or public HTTPS .CT URLs as untrusted data and "
            "add matching feature hints to the current game catalog. Scripts, trainers, Lua, "
            "hooks, and patches are ignored; hints cannot perform writes until independently "
            "confirmed and saved as a local profile."
        ),
        annotations=REMOTE_READ,
        structured_output=True,
    )
    def add_game_cheat_catalog_sources(
        session_id: str,
        sources: list[str],
        query: str = "health stamina mana money gold",
    ) -> GameCheatCatalog:
        if not 1 <= len(sources) <= 10:
            raise ValueError("provide between 1 and 10 sources")
        return runtime.add_game_cheat_sources(session_id, sources, query=query)

    @server.tool(
        title="Locate Unreal Engine GWorld read-only",
        description=(
            "Use this before an Unreal/GAS scan. Search only the selected game's live "
            "executable pages for conservative GWorld read signatures, resolve the global "
            "slot, and validate the live UObject externally. This never injects a DLL, calls "
            "game code, or writes memory."
        ),
        annotations=DYNAMIC_READ,
        structured_output=True,
    )
    def locate_unreal_gworld(session_id: str) -> UnrealDiscoveryResult:
        return runtime.locate_unreal_engine(session_id)

    @server.tool(
        title="Start an Unreal GAS health snapshot",
        description=(
            "Take a bounded read-only baseline rooted at GWorld. Walk plausible live Unreal "
            "objects and owned/container references externally, then record plausible i16, "
            "i32, f32, and f64 stat fields. Use before the player takes damage."
        ),
        annotations=STATEFUL_READ,
        structured_output=True,
    )
    def start_unreal_gas_health_scan(
        session_id: str,
        value_types: list[ValueType] | None = None,
    ) -> UnrealGasScanSummary:
        return runtime.start_unreal_gas_scan(session_id, value_types)

    @server.tool(
        title="Relocate table-guided Unreal health fields",
        description=(
            "Use an old Cheat Engine or reflection layout only as advisory metadata. Start "
            "from the already validated live player pawn, inspect a bounded neighborhood "
            "around the table's old state-object pointer, validate every live UObject, and "
            "record plausible f32 Health, MaxHealth, and percentage fields. Offsets may "
            "relocate and no table script is executed. This is read-only."
        ),
        annotations=STATEFUL_READ,
        structured_output=True,
    )
    def start_unreal_table_guided_health_scan(
        scan_id: str,
        pawn_pointer_offset: int = 0xD30,
        pointer_radius: int = 0x100,
        health_offset: int = 0x1A4,
        max_health_offset: int = 0xE18,
        nested_state_offset: int = 0x150,
        replica_percent_offset: int = 0x12C,
    ) -> UnrealGasScanSummary:
        return runtime.start_unreal_table_guided_scan(
            scan_id,
            pawn_pointer_offset=pawn_pointer_offset,
            pointer_radius=pointer_radius,
            health_offset=health_offset,
            max_health_offset=max_health_offset,
            nested_state_offset=nested_state_offset,
            replica_percent_offset=replica_percent_offset,
        )

    @server.tool(
        title="Refine an Unreal GAS health snapshot",
        description=(
            "Compare the current read-only Unreal stat snapshot with the previous one. "
            "Use decreased after damage, unchanged while stable, increased after healing, "
            "or exact when a displayed value is known."
        ),
        annotations=STATEFUL_READ,
        structured_output=True,
    )
    def refine_unreal_gas_health_scan(
        scan_id: str,
        comparison: Comparison,
        value: int | float | None = None,
    ) -> UnrealGasScanSummary:
        return runtime.refine_unreal_gas_scan(scan_id, comparison, value)

    @server.tool(
        title="Inspect Unreal GAS health candidates",
        description=(
            "Review the highest-scoring read-only candidates, their GWorld-rooted object "
            "paths, behavior evidence, and a likely same-object maximum value."
        ),
        annotations=READ_ONLY,
        structured_output=True,
    )
    def get_unreal_gas_health_candidates(
        scan_id: str,
        limit: int = 20,
    ) -> UnrealGasScanSummary:
        if not 0 <= limit <= 100:
            raise ValueError("limit must be between 0 and 100")
        return runtime.unreal_gas_scan_candidates(scan_id, limit=limit)

    @server.tool(
        title="Watch Unreal GAS health candidates read-only",
        description=(
            "Continuously sample a bounded candidate set after damage/heal refinements. "
            "Reports current and likely maximum values without changing scan state or writing "
            "game memory."
        ),
        annotations=DYNAMIC_READ,
        structured_output=True,
    )
    def watch_unreal_gas_health_candidates(
        scan_id: str,
        sample_count: int = 5,
        interval_ms: int = 500,
        limit: int = 20,
    ) -> UnrealGasWatchResult:
        if not 1 <= limit <= 50:
            raise ValueError("limit must be between 1 and 50")
        return runtime.watch_unreal_gas_scan(
            scan_id,
            sample_count=sample_count,
            interval_ms=interval_ms,
            limit=limit,
        )

    @server.tool(
        title="Capture an Unreal GAS damage and refill event",
        description=(
            "Use this instead of manual decreased/unchanged prompts when health regenerates. "
            "Start a fresh unknown Unreal/GAS baseline while health is full, tell the player "
            "to take damage as this capture begins, then continuously sample the entire "
            "bounded field pool. It detects a sharp drop followed by multi-step recovery, "
            "rejects single-jump death/respawn changes, and preserves synchronized groups of "
            "up to four gameplay, GAS, UI, or replication copies. This is read-only."
        ),
        annotations=DYNAMIC_READ,
        structured_output=True,
    )
    def capture_unreal_gas_damage_refill(
        scan_id: str,
        sample_count: int = 30,
        interval_ms: int = 500,
        group_limit: int = 10,
    ) -> UnrealGasTemporalResult:
        return runtime.capture_unreal_gas_damage_refill(
            scan_id,
            sample_count=sample_count,
            interval_ms=interval_ms,
            group_limit=group_limit,
        )

    @server.tool(
        title="Start a background Unreal GAS damage monitor",
        description=(
            "Use when the player cannot take damage on command. Start from a fresh unknown "
            "Unreal/GAS baseline, then let the player continue normally. The monitor returns "
            "immediately and waits in the background for a natural damage drop plus gradual "
            "refill. It scans the bounded field pool read-only, rejects death/respawn jumps, "
            "and preserves correlated groups of up to four values."
        ),
        annotations=STATEFUL_READ,
        structured_output=True,
    )
    def start_unreal_gas_damage_monitor(
        scan_id: str,
        interval_ms: int = 500,
        duration_seconds: int = 300,
        group_limit: int = 10,
    ) -> UnrealGasMonitorStatus:
        return runtime.start_unreal_gas_damage_monitor(
            scan_id,
            interval_ms=interval_ms,
            duration_seconds=duration_seconds,
            group_limit=group_limit,
        )

    @server.tool(
        title="Check a background damage monitor",
        description=(
            "Report whether the read-only natural-damage monitor is still running and list "
            "any synchronized candidate groups found so far."
        ),
        annotations=DYNAMIC_READ,
        structured_output=True,
    )
    def get_unreal_gas_damage_monitor(
        monitor_id: str,
    ) -> UnrealGasMonitorStatus:
        return runtime.unreal_gas_damage_monitor_status(monitor_id)

    @server.tool(
        title="Stop a background damage monitor",
        description=(
            "Stop the read-only natural-damage monitor early and return any candidate groups "
            "it found. This changes only local monitor state and never writes game memory."
        ),
        annotations=LOCAL_MUTATION,
        structured_output=True,
    )
    def stop_unreal_gas_damage_monitor(
        monitor_id: str,
    ) -> UnrealGasMonitorStatus:
        return runtime.stop_unreal_gas_damage_monitor(monitor_id)

    @server.tool(
        title="Start one-pass full game profiling",
        description=(
            "Start one bounded read-only monitor over the entire validated Unreal object "
            "field pool. It batch-samples live play and builds a single candidate ledger for "
            "health, stamina, mana, currency, ammo, inventory, XP, cooldowns, movement, jump "
            "tuning, and other resources. Engine names, inert table evidence, current/maximum "
            "pairing, and change patterns raise confidence. Ambiguous fields remain candidates; "
            "nothing is written or prepared for writing."
        ),
        annotations=STATEFUL_READ,
        structured_output=True,
    )
    def start_full_game_profile_monitor(
        scan_id: str,
        interval_ms: int = 1000,
        duration_seconds: int = 900,
        candidate_limit: int = 50,
    ) -> GameProfileMonitorStatus:
        return runtime.start_unreal_game_profile_monitor(
            scan_id,
            interval_ms=interval_ms,
            duration_seconds=duration_seconds,
            candidate_limit=candidate_limit,
        )

    @server.tool(
        title="Check full game profiling",
        description=(
            "Return the current read-only candidate ledger, including live object identity, "
            "min/max/current values, change counts, likely feature categories, confidence, "
            "and restart-rooted object paths."
        ),
        annotations=DYNAMIC_READ,
        structured_output=True,
    )
    def get_full_game_profile_monitor(
        monitor_id: str,
    ) -> GameProfileMonitorStatus:
        return runtime.unreal_game_profile_monitor_status(monitor_id)

    @server.tool(
        title="Stop and save full game profiling",
        description=(
            "Stop the read-only profiling pass and save its candidate ledger locally. This "
            "changes only local monitor/report state and never changes game memory."
        ),
        annotations=LOCAL_MUTATION,
        structured_output=True,
    )
    def stop_full_game_profile_monitor(
        monitor_id: str,
    ) -> GameProfileMonitorStatus:
        return runtime.stop_unreal_game_profile_monitor(monitor_id)

    @server.tool(
        title="Save a confirmed Unreal GAS pointer profile",
        description=(
            "Save the selected active candidate as a local restart profile rooted at the "
            "validated GWorld module offset and object path. This writes only a local JSON "
            "profile; it never writes or prepares writes to game memory."
        ),
        annotations=LOCAL_MUTATION,
        structured_output=True,
    )
    def save_unreal_gas_health_profile(
        scan_id: str,
        address: int,
        value_type: ValueType,
        name: str = "Health",
    ) -> UnrealGasProfile:
        return runtime.save_unreal_gas_profile(scan_id, address, value_type, name)

    @server.tool(
        title="Read a saved Unreal GAS profile",
        description=(
            "Re-locate GWorld in the current game launch, validate every saved object-path "
            "step, and report the current stat and likely maximum values read-only."
        ),
        annotations=DYNAMIC_READ,
        structured_output=True,
    )
    def read_saved_unreal_gas_health_profile(
        session_id: str,
        profile_id: str,
    ) -> UnrealGasProfileValue:
        return runtime.read_unreal_gas_profile(session_id, profile_id)

    @server.tool(
        title="Prepare a named game cheat",
        description=(
            "Use only when the user explicitly asks for a named ready feature from the current "
            "game cheat catalog. Set changes it once; hold maintains it for a bounded duration. "
            "Only a live-validated local profile is accepted. Public table/forum hints are "
            "rejected. This step does not write memory and never reveals the native phrase."
        ),
        annotations=STATEFUL_READ,
        structured_output=True,
    )
    def prepare_game_cheat_action(
        session_id: str,
        feature_id: str,
        action: CheatAction,
        value: int | float | None = None,
        interval_ms: int = 250,
        duration_seconds: int = 300,
    ) -> PreparedGameCheatActionResult:
        return runtime.prepare_game_cheat_action(
            session_id,
            feature_id,
            action,
            value,
            interval_ms=interval_ms,
            duration_seconds=duration_seconds,
        )

    @server.tool(
        title="Request native confirmation for a named game cheat",
        description=(
            "Use only after the user explicitly says to continue with a prepared named cheat. "
            "The companion revalidates the address, then opens a native review dialog. ChatGPT "
            "cannot see or enter the required phrase. A hold stops automatically at its bounded "
            "duration, on detach, on validation failure, or when explicitly stopped."
        ),
        annotations=DESTRUCTIVE_LOCAL,
        structured_output=True,
    )
    def confirm_game_cheat_action_locally(intent_id: str) -> GameCheatActionResult:
        return runtime.confirm_game_cheat_action_locally(intent_id)

    @server.tool(
        title="Apply a requested named game value now",
        description=(
            "Apply a prepared set or hold immediately after the user explicitly requested the "
            "named value change. This skips the typed phrase dialog but retains the selected-"
            "game allowlist, expected-current comparison, write readback, audit, and bounded "
            "hold limits."
        ),
        annotations=DESTRUCTIVE_LOCAL,
        structured_output=True,
    )
    def apply_game_cheat_action(intent_id: str) -> GameCheatActionResult:
        return runtime.apply_game_cheat_action(intent_id)

    @server.tool(
        title="List active named game cheat holds",
        description=(
            "Report active and recently stopped bounded value holds for the selected game. "
            "This reads companion state and does not touch game memory."
        ),
        annotations=DYNAMIC_READ,
        structured_output=True,
    )
    def list_game_cheat_holds(session_id: str) -> HoldListResult:
        return runtime.list_game_cheat_holds(session_id)

    @server.tool(
        title="Stop a named game cheat hold",
        description=(
            "Stop a running value hold immediately. This does not restore or perform another "
            "game-memory write; it only prevents further hold writes."
        ),
        annotations=LOCAL_MUTATION,
        structured_output=True,
    )
    def stop_game_cheat_hold(hold_id: str) -> HoldStatus:
        return runtime.stop_game_cheat_hold(hold_id)

    @server.tool(
        title="Prepare one learned-value candidate test",
        description=(
            "Prepare a reversible test for one of one-to-five exact learned candidates in the "
            "selected offline game. This step performs no write. Each candidate remains "
            "separate, and the native companion must confirm the test write next."
        ),
        annotations=STATEFUL_READ,
        structured_output=True,
    )
    def prepare_discovery_candidate_test(
        run_id: str,
        target_name: str,
        candidate_id: str,
        test_value: int | float,
    ) -> PreparedDiscoveryCandidateTestResult:
        return runtime.prepare_discovery_candidate_test(
            run_id,
            target_name,
            candidate_id,
            test_value,
        )

    @server.tool(
        title="Record and, when needed, restore a learned-value candidate test",
        description=(
            "Use after the native test write and the user reports whether the visible game "
            "value changed. A match locks that candidate. A mismatch opens a second native "
            "confirmation to restore the original bytes before rejecting the candidate."
        ),
        annotations=DESTRUCTIVE_LOCAL,
        structured_output=True,
    )
    def finalize_discovery_candidate_test(
        intent_id: str,
        matched_in_game: bool,
        restore_after_test: bool = False,
        verification_source: str = "user",
    ) -> DiscoveryCandidateTestResult:
        return runtime.finalize_discovery_candidate_test(
            intent_id,
            matched_in_game=matched_in_game,
            restore_after_test=restore_after_test,
            verification_source=verification_source,
        )

    @server.tool(
        title="Prepare an odd-delta inventory matrix",
        description=(
            "Prepare, without writing, one reversible integer change per inventory candidate. "
            "Candidates receive unique odd deltas (+1, +3, +5, and so on) so a later screen "
            "observation can distinguish several valid slots."
        ),
        annotations=STATEFUL_READ,
        structured_output=True,
    )
    def prepare_inventory_matrix_probe(
        run_id: str,
        target_name: str = "inventory item quantity",
    ) -> PreparedInventoryMatrixProbeResult:
        return runtime.prepare_inventory_matrix_probe(run_id, target_name)

    @server.tool(
        title="Apply a prepared inventory matrix",
        description=(
            "Apply the short prepared odd-delta inventory probe to the selected authorized "
            "offline game. Any partial failure restores changes already made."
        ),
        annotations=DESTRUCTIVE_LOCAL,
        structured_output=True,
    )
    def apply_inventory_matrix_probe(
        probe_id: str,
    ) -> PreparedInventoryMatrixProbeResult:
        return runtime.apply_inventory_matrix_probe(probe_id)

    @server.tool(
        title="Restore and record an inventory matrix",
        description=(
            "Restore every original stack value after the observation window, then record only "
            "unambiguous candidate-to-item matches. Empty matches still restore the whole probe."
        ),
        annotations=DESTRUCTIVE_LOCAL,
        structured_output=True,
    )
    def restore_inventory_matrix_probe(
        probe_id: str,
        matched_candidates: dict[str, str] | None = None,
        reference_urls: dict[str, str] | None = None,
    ) -> InventoryMatrixProbeResult:
        return runtime.restore_inventory_matrix_probe(
            probe_id,
            matched_candidates=matched_candidates,
            reference_urls=reference_urls,
        )

    @server.tool(
        title="Prepare a controlled memory write",
        description=(
            "Use this only for a selected exact scan candidate after narrowing the set to no "
            "more than five and the user explicitly asks to change it. This prepares but does "
            "not execute a write. The confirmation phrase is "
            "kept from ChatGPT and is shown only in the native Windows companion."
        ),
        annotations=STATEFUL_READ,
        structured_output=True,
    )
    def prepare_memory_write(
        session_id: str,
        address: int,
        value_type: ValueType,
        expected_current: int | float,
        new_value: int | float,
        reason: str,
    ) -> PreparedWriteResult:
        return runtime.prepare_write(
            session_id,
            address,
            value_type,
            expected_current,
            new_value,
            reason,
        )

    @server.tool(
        title="Request native confirmation for a prepared write",
        description=(
            "Use this only after a write was prepared and the user explicitly says to continue. "
            "The local companion opens a native Windows review dialog. ChatGPT cannot see or "
            "enter the required phrase, and cancellation leaves memory unchanged."
        ),
        annotations=DESTRUCTIVE_LOCAL,
        structured_output=True,
    )
    def confirm_prepared_write_locally(intent_id: str) -> WriteResult:
        return runtime.confirm_write_locally(intent_id)

    @server.tool(
        title="Apply a requested prepared value now",
        description=(
            "Apply a prepared value immediately after the user explicitly requested it. This "
            "skips the typed phrase dialog but retains process allowlisting, candidate checks, "
            "expected-current comparison, write readback, and audit."
        ),
        annotations=DESTRUCTIVE_LOCAL,
        structured_output=True,
    )
    def apply_prepared_write(intent_id: str) -> WriteResult:
        return runtime.apply_prepared_write(intent_id)

    @server.tool(
        title="Roll back one verified game-memory write",
        description=(
            "Restore the original value from a verified execution receipt. The rollback is "
            "refused if the process or current value changed."
        ),
        annotations=DESTRUCTIVE_LOCAL,
        structured_output=True,
    )
    def rollback_game_memory_write(rollback_token: str) -> RollbackResult:
        return runtime.rollback_memory_write(rollback_token)

    @server.tool(
        title="Change a practice simulator value",
        description=(
            "Use this only with the simulated development backend to imitate an in-game value "
            "change before rescanning. It is unavailable for real processes."
        ),
        annotations=LOCAL_MUTATION,
        structured_output=True,
    )
    def set_practice_value(name: str, value: int | float) -> PracticeValueResult:
        return runtime.set_practice_value(name, value)

    return server, runtime


def run() -> None:
    _ensure_windowed_logging_streams()
    server, runtime = create_mcp_server()
    try:
        server.run(transport="streamable-http")
    finally:
        runtime.close()


def run_stdio() -> None:
    server, runtime = create_mcp_server()
    try:
        server.run(transport="stdio")
    finally:
        runtime.close()


def _ensure_windowed_logging_streams() -> None:
    """Give Uvicorn valid streams in a PyInstaller --windowed service child."""

    if sys.stdout is None:
        sys.stdout = open(os.devnull, "w", encoding="utf-8")  # noqa: SIM115
    if sys.stderr is None:
        sys.stderr = open(os.devnull, "w", encoding="utf-8")  # noqa: SIM115


if __name__ == "__main__":
    run()
