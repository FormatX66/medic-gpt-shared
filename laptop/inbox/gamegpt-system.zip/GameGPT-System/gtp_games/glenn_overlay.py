"""GameGPT-owned Glenn overlay prototype.

The installed Glenn plugin is treated as a read-only art/animation source. All
state and rendering layers in this file belong to GameGPT.
"""

from __future__ import annotations

import argparse
import ctypes
import json
import sys
import tkinter as tk
from pathlib import Path
from tkinter import ttk

from PIL import Image, ImageDraw, ImageTk

from .programs import MicrophoneGate, MovementScope, OverlayNavigator, Point, Rect

DEFAULT_GLENN_ROOT = Path(
    r"C:\Users\bruce\.codex\plugins\cache\personal\glenn-dogzig"
    r"\0.1.0+codex.20260730223700"
)


def windows_virtual_desktop() -> Rect:
    if sys.platform != "win32":
        return Rect(0, 0, 1920, 1080)
    user32 = ctypes.windll.user32
    return Rect(
        user32.GetSystemMetrics(76),
        user32.GetSystemMetrics(77),
        user32.GetSystemMetrics(76) + user32.GetSystemMetrics(78),
        user32.GetSystemMetrics(77) + user32.GetSystemMetrics(79),
    )


def load_glenn_frame(root: Path, size: int = 176) -> Image.Image:
    """Read one original frame without importing or executing the installed plugin."""
    config = json.loads((root / "assets" / "pet-config.json").read_text(encoding="utf-8"))
    cell_w, cell_h = config["cellSize"]
    frame_spec = config["animations"]["idle"]["frames"][0]
    atlas = Image.open(root / config["atlases"][frame_spec["atlas"]]).convert("RGBA")
    left = int(frame_spec["col"]) * cell_w
    top = int(frame_spec["row"]) * cell_h
    frame = atlas.crop((left, top, left + cell_w, top + cell_h))
    frame.thumbnail((size, size), Image.Resampling.LANCZOS)
    return frame


def render_state_layer(frame: Image.Image, *, muted: bool, label: str) -> Image.Image:
    """Draw GameGPT-owned non-destructive status and friendly mouth tape."""
    rendered = frame.copy()
    draw = ImageDraw.Draw(rendered)
    width, height = rendered.size
    if muted:
        tape_y = int(height * 0.59)
        draw.rounded_rectangle(
            (int(width * 0.37), tape_y, int(width * 0.69), tape_y + 18),
            radius=4,
            fill=(240, 202, 114, 245),
            outline=(92, 70, 34, 255),
            width=2,
        )
        draw.line(
            (int(width * 0.49), tape_y + 4, int(width * 0.56), tape_y + 14),
            fill=(92, 70, 34, 180),
            width=2,
        )
    draw.rounded_rectangle((4, height - 25, width - 4, height - 3), 6, fill=(20, 24, 30, 225))
    draw.text((10, height - 22), label, fill=(255, 255, 255, 255))
    return rendered


class GlennGameGPTOverlay:
    def __init__(self, glenn_root: Path = DEFAULT_GLENN_ROOT) -> None:
        self.glenn_root = glenn_root
        self.gate = MicrophoneGate(start_muted=True)
        desktop = windows_virtual_desktop()
        self.navigator = OverlayNavigator(virtual_desktop=desktop, monitors=(desktop,))
        self.base_frame = load_glenn_frame(glenn_root)
        self.root = tk.Tk()
        self.root.title("GameGPT — Glenn Dogzig")
        self.root.overrideredirect(True)
        self.root.attributes("-topmost", True)
        self.root.configure(bg="#010101")
        self.root.wm_attributes("-transparentcolor", "#010101")
        self.root.geometry("220x225")
        self.canvas = tk.Canvas(
            self.root, width=220, height=185, bg="#010101", highlightthickness=0
        )
        self.canvas.pack()
        self.status = ttk.Label(self.root, text="Muted", anchor="center")
        self.status.pack(fill="x")
        controls = ttk.Frame(self.root)
        controls.pack(fill="x")
        ttk.Button(controls, text="Mic", command=self.toggle_mute).pack(side="left")
        ttk.Button(controls, text="Wait", command=self.toggle_wait).pack(side="left")
        ttk.Button(controls, text="Recall", command=self.recall).pack(side="left")
        ttk.Button(controls, text="Hide", command=self.hide).pack(side="left")
        self.root.bind("<Control-Shift-m>", lambda _event: self.toggle_mute())
        self.root.bind("<Control-Shift-w>", lambda _event: self.toggle_wait())
        self.root.bind("<Control-Shift-r>", lambda _event: self.recall())
        self.root.bind("<Escape>", lambda _event: self.kill())
        self._drag_origin: tuple[int, int, int, int] | None = None
        self.canvas.bind("<ButtonPress-1>", self._start_drag)
        self.canvas.bind("<B1-Motion>", self._drag)
        self._photo: ImageTk.PhotoImage | None = None
        self._render()
        self.recall()

    def _render(self) -> None:
        snap = self.gate.snapshot
        image = render_state_layer(
            self.base_frame, muted=snap.tape_visible, label=snap.state_label
        )
        self._photo = ImageTk.PhotoImage(image)
        self.canvas.delete("all")
        self.canvas.create_image(110, 92, image=self._photo)
        self.status.configure(text=snap.state_label)

    def toggle_mute(self) -> None:
        if self.gate.snapshot.state.value == "muted":
            self.gate.unmute()
        else:
            self.gate.mute()
        self._render()

    def toggle_wait(self) -> None:
        if self.gate.snapshot.state.value == "waiting":
            self.gate.resume()
        else:
            self.gate.wait()
        self._render()

    def recall(self) -> None:
        position = self.navigator.recall()
        self.root.deiconify()
        self.root.geometry(f"220x225+{round(position.x - 110)}+{round(position.y - 112)}")

    def move_to(self, point: Point) -> None:
        position = self.navigator.move_to(point)
        self.root.geometry(f"220x225+{round(position.x - 110)}+{round(position.y - 112)}")

    def point_at(self, target: Point, label: str) -> None:
        plan = self.navigator.point_at(target, label)
        self.move_to(plan.pet_position)
        self.status.configure(text=f"Pointing: {plan.label} →")

    def set_scope(self, scope: MovementScope) -> None:
        self.navigator.set_scope(scope)
        self.recall()

    def hide(self) -> None:
        self.navigator.hide()
        self.root.withdraw()

    def kill(self) -> None:
        self.navigator.kill()
        self.root.destroy()

    def _start_drag(self, event) -> None:
        self._drag_origin = (event.x_root, event.y_root, self.root.winfo_x(), self.root.winfo_y())

    def _drag(self, event) -> None:
        if self._drag_origin is None:
            return
        x, y, window_x, window_y = self._drag_origin
        self.root.geometry(f"+{window_x + event.x_root - x}+{window_y + event.y_root - y}")

    def run(self, *, smoke_test: bool = False) -> None:
        if smoke_test:
            self.root.after(1200, self.kill)
        self.root.mainloop()


def main() -> None:
    parser = argparse.ArgumentParser(description="GameGPT Glenn overlay prototype")
    parser.add_argument("--glenn-root", type=Path, default=DEFAULT_GLENN_ROOT)
    parser.add_argument("--smoke-test", action="store_true")
    args = parser.parse_args()
    GlennGameGPTOverlay(args.glenn_root).run(smoke_test=args.smoke_test)


if __name__ == "__main__":
    main()
