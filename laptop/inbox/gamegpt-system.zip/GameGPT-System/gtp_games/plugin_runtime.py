from __future__ import annotations

import sys
from dataclasses import dataclass
from datetime import datetime
from threading import RLock
from typing import Protocol
from uuid import uuid4

from pydantic import BaseModel, Field

from gtp_games import __version__
from gtp_games.chat_learnings import ChatLearningStore, LearnedAddress, LearnedGameValue
from gtp_games.codec import values_equal
from gtp_games.config import Settings
from gtp_games.control import (
    CANONICAL_ROLE,
    CONTROL_API,
    CONTROL_PROTOCOL_VERSIONS,
    ControlNegotiation,
    negotiate_control,
)
from gtp_games.errors import NotFoundError, SafetyError
from gtp_games.game_accelerators import GameAcceleratorPack
from gtp_games.game_identity import executable_build_identity
from gtp_games.game_table_registry import GameTableRegistry, GameTableRegistryStatus
from gtp_games.instruction_values import (
    InstructionValueObserverStatus,
    InstructionValueRecipe,
)
from gtp_games.integrated import (
    CapabilityRow,
    MultiUseInput,
    ValuePriorityMap,
    build_capability_rows,
    build_ct_value_priority_map,
    parse_multi_use_input,
)
from gtp_games.inventory_observer import InventoryObserverStatus, InventorySlotObservation
from gtp_games.models import (
    CheatAction,
    CheatDiscoveryRunStatus,
    CheatTableResult,
    CheatTableSourceBuild,
    Comparison,
    GameCheatCatalog,
    GameProfileMonitorStatus,
    GameValueTable,
    GameValueTableEntry,
    GameValueTableExportResult,
    HealthBarResult,
    HoldIntentView,
    HoldStatus,
    InventoryScreenResult,
    LocatorKind,
    MemoryLocator,
    NmsSaveComparisonReport,
    PortableGameValueTable,
    ProcessInfo,
    RollbackResult,
    SavedInventoryLiveResolution,
    SavedInventoryResult,
    ScanActivity,
    ScanCandidate,
    ScanKind,
    UnrealDiscoveryResult,
    UnrealGasMonitorStatus,
    UnrealGasProfile,
    UnrealGasProfileValue,
    UnrealGasScanSummary,
    UnrealGasTemporalResult,
    UnrealGasWatchResult,
    ValueType,
    WatchResult,
    WebCheatDiscoveryResult,
    WriteIntentView,
    WriteResult,
)
from gtp_games.script_lab import (
    NativeScriptCandidate,
    NativeScriptKind,
    ScriptVerification,
    build_native_script,
    translate_ct_script_reference,
    verify_script_candidate,
)
from gtp_games.service import ApplicationService
from gtp_games.temporal import (
    CandidateGeneration,
    EventDirection,
    TemporalCorrelationScanner,
    TemporalCorrelationSession,
)


class PluginStatus(BaseModel):
    status: str = "ready"
    version: str = __version__
    backend: str
    writes_available: bool
    write_process_allowlist: list[str] = Field(default_factory=list)
    scan_activity: ScanActivity | None = None
    table_registry: GameTableRegistryStatus
    safety_scope: str = "local personal offline games only"
    control_api: str = CONTROL_API
    control_protocol_versions: list[str] = Field(
        default_factory=lambda: list(CONTROL_PROTOCOL_VERSIONS)
    )
    canonical_role: str = CANONICAL_ROLE
    instance_id: str
    started_at: datetime
    active_session_count: int = 0
    write_receipt_count: int = 0


class AttachedSessionResult(BaseModel):
    session_id: str
    pid: int
    process_name: str
    executable: str | None = None
    process_started_at: float | None = None
    game_key: str | None = None
    game_name: str | None = None
    selected_table_path: str | None = None
    selected_table_status: str | None = None
    write_enabled: bool
    backend: str


class ProcessListResult(BaseModel):
    processes: list[ProcessInfo]
    refreshed_at: datetime
    selected_session: AttachedSessionResult | None = None


class DetachedSessionResult(BaseModel):
    session_id: str
    detached: bool = True


class ScanResult(BaseModel):
    scan_id: str
    session_id: str
    scan_kind: ScanKind
    value_type: ValueType
    normalized: bool
    comparison: Comparison
    generation: int
    result_count: int
    truncated: bool
    scope_truncated: bool
    scanned_bytes: int
    eligible_bytes: int
    selected_region_count: int
    cache_backed: bool = False
    cached_bytes: int = 0
    cache_reused: bool = False
    reused_from_scan_id: str | None = None
    candidates: list[ScanCandidate] = Field(default_factory=list)


class PreparedWriteResult(BaseModel):
    intent_id: str
    session_id: str
    address: int
    value_type: ValueType
    expected_current: int | float
    new_value: int | float
    reason: str
    expires_at: datetime
    local_confirmation_required: bool = False


class RawMemoryReadResult(BaseModel):
    session_id: str
    address: int
    address_hex: str
    value_type: ValueType
    value: int | float


class ResolvedGameValue(BaseModel):
    feature_id: str
    name: str
    table_status: str
    source: str
    address: int | None = None
    address_hex: str | None = None
    value_type: ValueType
    current_value: int | float | None = None
    locator: MemoryLocator
    exact_build: bool = False
    write_ready: bool = False
    error: str | None = None


class LearnedGameValuesResult(BaseModel):
    session_id: str
    process_name: str
    game_key: str
    game_build_identity: str | None = None
    confirmed_features: list[GameValueTableEntry] = Field(default_factory=list)
    candidate_features: list[GameValueTableEntry] = Field(default_factory=list)
    resolved_values: list[ResolvedGameValue] = Field(default_factory=list)
    conversational_values: list[LearnedGameValue] = Field(default_factory=list)
    notes: list[str] = Field(default_factory=list)


class PreparedGameCheatActionResult(BaseModel):
    intent_id: str
    session_id: str
    feature_id: str
    action: CheatAction
    value: int | float
    interval_ms: int | None = None
    duration_seconds: int | None = None
    expires_at: datetime
    local_confirmation_required: bool = False


class PreparedDiscoveryCandidateTestResult(BaseModel):
    intent_id: str
    run_id: str
    target_name: str
    candidate_id: str
    candidate_index: int
    candidate_count: int
    session_id: str
    address: int
    value_type: ValueType
    original_value: int | float
    test_value: int | float
    expires_at: datetime
    local_confirmation_required: bool = False


class DiscoveryCandidateTestResult(BaseModel):
    run_id: str
    target_name: str
    candidate_id: str
    matched_in_game: bool
    restored: bool = False
    verification_source: str = "user"
    status: CheatDiscoveryRunStatus


class InventoryMatrixProbeEntry(BaseModel):
    intent_id: str
    candidate_id: str
    address: int
    value_type: ValueType
    original_value: int
    delta: int
    test_value: int


class PreparedInventoryMatrixProbeResult(BaseModel):
    probe_id: str
    run_id: str
    target_name: str
    entries: list[InventoryMatrixProbeEntry]
    expires_at: datetime
    applied: bool = False


class InventoryMatrixProbeResult(BaseModel):
    probe_id: str
    run_id: str
    target_name: str
    restored: bool
    matched_candidates: dict[str, str] = Field(default_factory=dict)
    status: CheatDiscoveryRunStatus


class GameCheatActionResult(BaseModel):
    feature_id: str
    action: CheatAction
    write: WriteResult | None = None
    hold: HoldStatus | None = None


class HoldListResult(BaseModel):
    session_id: str
    holds: list[HoldStatus] = Field(default_factory=list)


class PracticeValueResult(BaseModel):
    name: str
    address: int
    value: int | float


class WriteConfirmer(Protocol):
    def request(self, intent: WriteIntentView | HoldIntentView) -> str | None: ...


@dataclass(frozen=True)
class _PendingDiscoveryCandidateTest:
    run_id: str
    target_name: str
    candidate_id: str
    session_id: str
    address: int
    value_type: ValueType
    original_value: int | float
    test_value: int | float


@dataclass
class _PendingInventoryMatrixProbe:
    probe_id: str
    run_id: str
    target_name: str
    session_id: str
    entries: list[InventoryMatrixProbeEntry]
    expires_at: datetime
    applied: bool = False


class WindowsWriteConfirmer:
    """Collect the final phrase in a companion-owned native Windows dialog."""

    def request(self, intent: WriteIntentView | HoldIntentView) -> str | None:
        if sys.platform != "win32":
            raise SafetyError("local write confirmation is available only on Windows")

        try:
            import tkinter as tk
            from tkinter import ttk

            return self._show_dialog(tk, ttk, intent)
        except SafetyError:
            raise
        except Exception as exc:
            raise SafetyError("the local write confirmation dialog could not be opened") from exc

    @staticmethod
    def _show_dialog(tk, ttk, intent: WriteIntentView | HoldIntentView) -> str | None:
        root = tk.Tk()
        is_hold = isinstance(intent, HoldIntentView)
        root.title(
            "GTP Games — Confirm local value hold"
            if is_hold
            else "GTP Games — Confirm local value change"
        )
        root.geometry("520x380" if is_hold else "520x330")
        root.resizable(False, False)
        root.attributes("-topmost", True)

        result: dict[str, str | None] = {"phrase": None}
        entry_value = tk.StringVar()

        frame = ttk.Frame(root, padding=24)
        frame.pack(fill="both", expand=True)
        ttk.Label(frame, text="Local confirmation required", font=("Segoe UI", 16, "bold")).pack(
            anchor="w"
        )
        ttk.Label(
            frame,
            text=(
                "ChatGPT prepared this change but cannot authorize it. "
                "Review the values and type the exact phrase yourself."
            ),
            wraplength=460,
        ).pack(anchor="w", pady=(8, 14))
        details = (
            f"Feature: {intent.feature_name}\n"
            f"Address: 0x{intent.address:X}\n"
            f"Current: {intent.expected_current} ({intent.value_type})\n"
            f"Hold at: {intent.hold_value}\n"
            f"Every: {intent.interval_ms} ms\n"
            f"Stops after: {intent.duration_seconds} seconds"
            if is_hold
            else (
                f"Address: 0x{intent.address:X}\n"
                f"Current: {intent.expected_current} ({intent.value_type})\n"
                f"New value: {intent.new_value}"
            )
        )
        ttk.Label(
            frame,
            text=details,
            font=("Consolas", 10),
        ).pack(anchor="w")
        ttk.Label(frame, text=f"Type exactly: {intent.confirmation_phrase}").pack(
            anchor="w", pady=(14, 5)
        )
        entry = ttk.Entry(frame, textvariable=entry_value, width=56)
        entry.pack(fill="x")

        button_row = ttk.Frame(frame)
        button_row.pack(fill="x", pady=(18, 0))
        confirm_button = ttk.Button(
            button_row,
            text="Confirm hold" if is_hold else "Confirm once",
            state="disabled",
        )
        confirm_button.pack(side="right")
        cancel_button = ttk.Button(button_row, text="Cancel")
        cancel_button.pack(side="right", padx=(0, 8))

        def update_button(*_args) -> None:
            state = "normal" if entry_value.get() == intent.confirmation_phrase else "disabled"
            confirm_button.configure(state=state)

        def confirm() -> None:
            if entry_value.get() == intent.confirmation_phrase:
                result["phrase"] = entry_value.get()
                root.destroy()

        def cancel() -> None:
            root.destroy()

        entry_value.trace_add("write", update_button)
        confirm_button.configure(command=confirm)
        cancel_button.configure(command=cancel)
        root.protocol("WM_DELETE_WINDOW", cancel)
        entry.focus_set()
        root.mainloop()
        return result["phrase"]


class PluginRuntime:
    def __init__(
        self,
        settings: Settings,
        *,
        application: ApplicationService | None = None,
        confirmer: WriteConfirmer | None = None,
    ) -> None:
        self.settings = settings
        self.application = application or ApplicationService(settings)
        self.confirmer = confirmer or WindowsWriteConfirmer()
        self._pending_intents: dict[str, WriteIntentView] = {}
        self._pending_holds: dict[str, HoldIntentView] = {}
        self._pending_game_actions: dict[str, tuple[CheatAction, str]] = {}
        self._pending_candidate_tests: dict[str, _PendingDiscoveryCandidateTest] = {}
        self._pending_inventory_matrix_probes: dict[str, _PendingInventoryMatrixProbe] = {}
        self._confirming: set[str] = set()
        self._active_session: AttachedSessionResult | None = None
        self._temporal_scanner = TemporalCorrelationScanner()
        self._temporal_sessions: dict[str, TemporalCorrelationSession] = {}
        self._script_candidates: dict[str, NativeScriptCandidate] = {}
        self._chat_learnings = ChatLearningStore(settings.chat_learnings_path)
        self._table_registry = GameTableRegistry(
            settings.game_table_registry_directory,
            remote_url=settings.game_table_registry_remote,
            timeout_seconds=settings.game_table_registry_timeout_seconds,
        )
        self._lock = RLock()

    def status(self) -> PluginStatus:
        return PluginStatus(
            backend=self.application.backend.name,
            writes_available=self.settings.allow_writes,
            write_process_allowlist=list(self.settings.allowed_process_patterns),
            scan_activity=self.application.scan_activity(),
            table_registry=self._table_registry.status(),
            instance_id=self.application.instance_id,
            started_at=self.application.started_at,
            active_session_count=self.application.active_session_count,
            write_receipt_count=self.application.write_receipt_count,
        )

    def negotiate_control(self, client_versions: list[str]) -> ControlNegotiation:
        return negotiate_control(client_versions, instance_id=self.application.instance_id)

    @staticmethod
    def interpret_integrated_input(
        text: str,
        *,
        selected_target: str | None = None,
    ) -> MultiUseInput:
        return parse_multi_use_input(text, selected_target=selected_target)

    def integrated_capabilities(self, session_id: str) -> list[CapabilityRow]:
        catalog = self.application.game_cheat_catalog(session_id)
        return build_capability_rows(catalog, write_enabled=catalog.write_enabled)

    def ct_value_priority_map(
        self,
        source: str,
        *,
        query: str = "",
        limit: int = 200,
        source_build: CheatTableSourceBuild | None = None,
    ) -> ValuePriorityMap:
        result = self.import_cheat_table_reference(
            source,
            query=query,
            limit=limit,
            source_build=source_build,
        )
        return build_ct_value_priority_map(result)

    def start_temporal_correlation(
        self,
        target: str,
        values: dict[str, float],
        *,
        value_type: str = "unknown",
        label: str = "baseline",
    ) -> TemporalCorrelationSession:
        session = self._temporal_scanner.start(
            target,
            values,
            value_type=value_type,
            label=label,
        )
        with self._lock:
            self._temporal_sessions[session.id] = session
        return session

    def temporal_correlation(self, session_id: str) -> TemporalCorrelationSession:
        with self._lock:
            session = self._temporal_sessions.get(session_id)
        if session is None:
            raise NotFoundError(f"temporal correlation session {session_id} was not found")
        return session

    def capture_temporal_event(
        self,
        session_id: str,
        values: dict[str, float],
        *,
        direction: EventDirection,
        label: str,
    ) -> CandidateGeneration:
        session = self.temporal_correlation(session_id)
        return self._temporal_scanner.capture(
            session,
            values,
            direction=direction,
            label=label,
        )

    def rollback_temporal_generation(
        self,
        session_id: str,
        generation_id: str,
    ) -> CandidateGeneration:
        session = self.temporal_correlation(session_id)
        return self._temporal_scanner.rollback(session, generation_id)

    def build_script_candidate(
        self,
        *,
        name: str,
        target: str,
        kind: NativeScriptKind,
        operation: str,
        parameters: dict[str, str | int | float | bool] | None = None,
        locator_kind: str | None = None,
    ) -> NativeScriptCandidate:
        candidate = build_native_script(
            name=name,
            target=target,
            kind=kind,
            operation=operation,
            parameters=parameters,
            locator_kind=locator_kind,
        )
        with self._lock:
            self._script_candidates[candidate.id] = candidate
        return candidate

    def translate_ct_script_candidates(
        self,
        source: str,
        *,
        query: str = "",
        limit: int = 50,
    ) -> list[NativeScriptCandidate]:
        result = self.import_cheat_table_reference(source, query=query, limit=limit)
        candidates = [
            translate_ct_script_reference(
                finding,
                table_sha256=result.source_sha256,
                target=finding.description,
            )
            for finding in result.script_findings
        ]
        with self._lock:
            self._script_candidates.update({item.id: item for item in candidates})
        return candidates

    def verify_script_candidate(
        self,
        candidate_id: str,
        *,
        exact_build_match: bool,
        locator_match_count: int | None,
        original_state_captured: bool,
        rollback_verified: bool,
        behavioral_events: int,
    ) -> ScriptVerification:
        with self._lock:
            candidate = self._script_candidates.get(candidate_id)
        if candidate is None:
            raise NotFoundError(f"script candidate {candidate_id} was not found")
        return verify_script_candidate(
            candidate,
            exact_build_match=exact_build_match,
            locator_match_count=locator_match_count,
            original_state_captured=original_state_captured,
            rollback_verified=rollback_verified,
            behavioral_events=behavioral_events,
        )

    def list_processes(self) -> ProcessListResult:
        return ProcessListResult(
            processes=self.application.list_processes(),
            refreshed_at=datetime.now().astimezone(),
            selected_session=self.active_session(),
        )

    def attach(
        self,
        pid: int,
        *,
        write_enabled: bool = False,
        game_key: str | None = None,
        game_name: str | None = None,
        table_path: str | None = None,
        start_catalog_discovery: bool = True,
    ) -> AttachedSessionResult:
        selected_table_path = table_path
        selected_game_key = game_key
        if selected_table_path is None and self.settings.auto_load_registry_tables:
            process = self.application.backend.find_process(pid)
            if process is not None:
                exact_table = self._table_registry.find_exact_table(
                    process_name=process.name,
                    build_identity=executable_build_identity(process.executable),
                    game_key=game_key,
                )
                if exact_table is not None:
                    selected_table_path = str(exact_table)
                    if selected_game_key is None:
                        selected_game_key = PortableGameValueTable.model_validate_json(
                            exact_table.read_text(encoding="utf-8")
                        ).game_key
        session = self.application.attach(
            pid,
            write_enabled=write_enabled,
            game_key=selected_game_key,
            game_name=game_name,
            table_path=selected_table_path,
            start_catalog_discovery=start_catalog_discovery,
        )
        try:
            self.application.revalidate_persistent_value_locators(session.id)
        except Exception as exc:  # noqa: BLE001 - persistence cannot block game attachment
            self.application.audit.record(
                "persistent_locator_revalidation_skipped",
                session_id=session.id,
                error=str(exc)[:300],
                game_memory_write=False,
            )
        attached = AttachedSessionResult(
            session_id=session.id,
            pid=session.pid,
            process_name=session.process_name,
            executable=session.executable,
            process_started_at=session.process_started_at,
            game_key=session.game_key,
            game_name=session.game_name,
            selected_table_path=session.selected_table_path,
            selected_table_status=session.selected_table_status,
            write_enabled=session.write_enabled,
            backend=session.backend_name,
        )
        with self._lock:
            previous = self._active_session
            self._active_session = attached
        if previous is not None and previous.session_id != attached.session_id:
            self._detach_application_session(previous.session_id)
        return attached

    def detach(self, session_id: str) -> DetachedSessionResult:
        self._restore_session_inventory_probes(session_id)
        self.application.detach(session_id)
        with self._lock:
            if self._active_session and self._active_session.session_id == session_id:
                self._active_session = None
            stale_ids = [
                intent_id
                for intent_id, intent in self._pending_intents.items()
                if intent.session_id == session_id
            ]
            for intent_id in stale_ids:
                self._pending_intents.pop(intent_id, None)
            stale_hold_ids = [
                intent_id
                for intent_id, intent in self._pending_holds.items()
                if intent.session_id == session_id
            ]
            for intent_id in stale_hold_ids:
                self._pending_holds.pop(intent_id, None)
                self._pending_game_actions.pop(intent_id, None)
        return DetachedSessionResult(session_id=session_id)

    def active_session(self) -> AttachedSessionResult | None:
        with self._lock:
            if self._active_session is None:
                return None
            return self._active_session.model_copy()

    def read_memory_value(
        self,
        session_id: str,
        address: int,
        value_type: ValueType = ValueType.I32,
    ) -> RawMemoryReadResult:
        value = self.application.read_value(session_id, address, value_type)
        self.application.audit.record(
            "direct_raw_value_read",
            session_id=session_id,
            address=f"0x{address:X}",
            value_type=value_type,
            game_memory_write=False,
        )
        return RawMemoryReadResult(
            session_id=session_id,
            address=address,
            address_hex=f"0x{address:X}",
            value_type=value_type,
            value=value,
        )

    def learned_game_values(self, session_id: str) -> LearnedGameValuesResult:
        attached = self.active_session()
        if attached is None or attached.session_id != session_id:
            raise NotFoundError("the selected game session is not active")
        build_identity = executable_build_identity(attached.executable)
        table = self.application.game_value_table(session_id)
        table = self._backfill_persistent_value_locators(
            session_id,
            attached,
            build_identity,
            table,
        )
        exact_build = bool(
            build_identity
            and table.game_build_identity
            and build_identity == table.game_build_identity
        )
        resolved_values: list[ResolvedGameValue] = []
        for source, entries in (
            ("confirmed", table.confirmed_features),
            ("candidate", table.candidate_features),
        ):
            for entry in entries:
                locator = entry.locator
                if not locator or locator.kind is LocatorKind.RAW_ADDRESS:
                    continue
                address: int | None = None
                current_value: int | float | None = None
                error: str | None = None
                try:
                    address = self.application.resolve_memory_locator(session_id, locator)
                    current_value = self.application.read_value(
                        session_id,
                        address,
                        entry.value_type,
                    )
                except Exception as exc:  # noqa: BLE001 - return failed locators as evidence
                    error = str(exc)[:300]
                resolved_values.append(
                    ResolvedGameValue(
                        feature_id=entry.id,
                        name=entry.name,
                        table_status=entry.status,
                        source=source,
                        address=address,
                        address_hex=f"0x{address:X}" if address is not None else None,
                        value_type=entry.value_type,
                        current_value=current_value,
                        locator=locator,
                        exact_build=exact_build,
                        write_ready=bool(
                            source == "confirmed"
                            and exact_build
                            and attached.write_enabled
                            and address is not None
                            and error is None
                        ),
                        error=error,
                    )
                )
        views: list[LearnedGameValue] = []
        for record in self._chat_learnings.records():
            if record.process_name.casefold() != attached.process_name.casefold():
                continue
            same_build = record.game_build_identity == build_identity
            same_process = bool(
                same_build
                and attached.process_started_at is not None
                and record.process_started_at == attached.process_started_at
            )
            addresses: list[LearnedAddress] = []
            for learned in record.addresses:
                current_value: int | float | None = None
                live_readable = False
                if same_process:
                    try:
                        current_value = self.application.read_value(
                            session_id,
                            learned.address,
                            learned.value_type,
                        )
                        live_readable = True
                    except Exception:  # noqa: BLE001 - stale raw addresses remain evidence only
                        pass
                addresses.append(
                    learned.model_copy(
                        update={
                            "current_value": current_value,
                            "live_readable": live_readable,
                        }
                    )
                )
            views.append(
                record.model_copy(
                    update={
                        "addresses": addresses,
                        "same_build": same_build,
                        "same_process_incarnation": same_process,
                        "requires_revalidation": not same_process,
                    }
                )
            )
        return LearnedGameValuesResult(
            session_id=session_id,
            process_name=attached.process_name,
            game_key=table.game_key,
            game_build_identity=build_identity,
            confirmed_features=table.confirmed_features,
            candidate_features=table.candidate_features,
            resolved_values=resolved_values,
            conversational_values=sorted(
                views,
                key=lambda item: (
                    not item.same_process_incarnation,
                    -item.last_validated_at.timestamp(),
                ),
            ),
            notes=[
                "Load these observations before starting a new scan.",
                "Keep multiple matching candidates; mirrored game values may all be correct.",
                (
                    "Resolved pointer, module, and signature-pointer locators show the current "
                    "address after a restart."
                ),
                "Raw addresses are reused only inside the same process incarnation.",
                (
                    "Across a restart or build change, use the saved type and behavior as "
                    "scan guidance and revalidate."
                ),
            ],
        )

    def game_accelerator_pack(self, session_id: str) -> GameAcceleratorPack:
        return self.application.build_game_accelerator_pack(session_id)

    def discover_public_game_sources(self, session_id: str) -> WebCheatDiscoveryResult:
        return self.application.discover_public_game_sources(session_id)

    def _backfill_persistent_value_locators(
        self,
        session_id: str,
        attached: AttachedSessionResult,
        build_identity: str | None,
        table: GameValueTable,
    ) -> GameValueTable:
        existing = {
            entry.name.casefold()
            for entry in [*table.confirmed_features, *table.candidate_features]
            if entry.locator is not None and entry.locator.kind is not LocatorKind.RAW_ADDRESS
        }
        changed = False
        for record in self._chat_learnings.records():
            if (
                record.label.casefold() in existing
                or record.process_name.casefold() != attached.process_name.casefold()
                or build_identity is None
                or record.game_build_identity != build_identity
                or attached.process_started_at is None
                or record.process_started_at != attached.process_started_at
            ):
                continue
            verified_by_type: dict[ValueType, list[int]] = {}
            for learned in record.addresses:
                if learned.verification == "write_verified":
                    verified_by_type.setdefault(learned.value_type, []).append(learned.address)
            for value_type, addresses in verified_by_type.items():
                try:
                    table = self.application.register_verified_persistent_locators(
                        session_id,
                        label=record.label,
                        value_type=value_type,
                        addresses=addresses,
                    )
                except Exception:  # noqa: BLE001 - learned raw values remain usable
                    continue
                found = any(
                    entry.name.casefold() == record.label.casefold()
                    and entry.locator is not None
                    and entry.locator.kind is not LocatorKind.RAW_ADDRESS
                    for entry in [*table.confirmed_features, *table.candidate_features]
                )
                if found:
                    existing.add(record.label.casefold())
                    changed = True
        if not changed:
            return table
        try:
            exported = self.application.export_game_value_table(session_id)
            if self._table_registry.enabled:
                self._table_registry.stage_export(exported.exported_path)
        except Exception:  # noqa: BLE001 - local table still keeps the verified recipe
            pass
        return table

    def remember_scan_candidates(
        self,
        session_id: str,
        scan_id: str,
        label: str,
        *,
        verification: str = "exact_match",
        verified_addresses: list[int] | None = None,
    ) -> LearnedGameValue:
        if verification not in {"exact_match", "behavior_verified"}:
            raise ValueError(
                "verification must be exact_match or behavior_verified; use verified_addresses "
                "for write/readback evidence"
            )
        attached = self.active_session()
        if attached is None or attached.session_id != session_id:
            raise NotFoundError("the selected game session is not active")
        scan = self.scan_candidates(scan_id, limit=20)
        if scan.session_id != session_id:
            raise SafetyError("the selected scan belongs to a different game session")
        if scan.truncated or scan.result_count > 20:
            raise SafetyError("narrow the scan to at most 20 untruncated candidates first")
        verified = set(verified_addresses or [])
        available = {item.address for item in scan.candidates}
        if not verified.issubset(available):
            raise SafetyError("every verified address must belong to the selected scan")
        addresses: list[LearnedAddress] = []
        for candidate in scan.candidates:
            current = self.application.read_value(
                session_id,
                candidate.address,
                scan.value_type,
            )
            address_verification = (
                "write_verified" if candidate.address in verified else verification
            )
            addresses.append(
                LearnedAddress(
                    address=candidate.address,
                    address_hex=f"0x{candidate.address:X}",
                    value_type=scan.value_type,
                    observed_value=current,
                    current_value=current,
                    live_readable=True,
                    verification=address_verification,
                )
            )
        overall_verification = "write_verified" if verified else verification
        persistence_evidence: list[str] = []
        if verified:
            try:
                table = self.application.register_verified_persistent_locators(
                    session_id,
                    label=label,
                    value_type=scan.value_type,
                    addresses=sorted(verified),
                )
                persistent = [
                    entry
                    for entry in [*table.confirmed_features, *table.candidate_features]
                    if entry.name.casefold() == label.casefold()
                    and entry.locator is not None
                    and entry.locator.kind is not LocatorKind.RAW_ADDRESS
                    and entry.write_test_status == "confirmed"
                ]
                if persistent:
                    persistence_evidence.append(
                        f"Saved {len(persistent)} restart-stable locator(s) for this value."
                    )
                    exported = self.application.export_game_value_table(session_id)
                    if self._table_registry.enabled:
                        self._table_registry.stage_export(exported.exported_path)
                        persistence_evidence.append(
                            "Staged the portable exact-build table in the local registry."
                        )
                else:
                    persistence_evidence.append(
                        "No restart-stable locator was found; raw addresses remain launch-only."
                    )
            except Exception as exc:  # noqa: BLE001 - raw learning must still be preserved
                persistence_evidence.append(
                    f"Persistent locator discovery was unavailable: {str(exc)[:200]}"
                )
        record = self._chat_learnings.remember(
            label=label,
            game_key=self.application.game_value_table(session_id).game_key,
            process_name=attached.process_name,
            executable=attached.executable,
            game_build_identity=executable_build_identity(attached.executable),
            process_started_at=attached.process_started_at,
            scan_id=scan.scan_id,
            scan_generation=scan.generation,
            addresses=addresses,
            verification=overall_verification,
            evidence=[
                (
                    f"Retained all {scan.result_count} candidates from scan generation "
                    f"{scan.generation}."
                ),
                "Candidate addresses were re-read before this record was saved.",
                *(
                    [f"Write/readback verification exists for {len(verified)} candidate(s)."]
                    if verified
                    else []
                ),
                *persistence_evidence,
            ],
        )
        self.application.audit.record(
            "chat_scan_candidates_remembered",
            session_id=session_id,
            scan_id=scan_id,
            label=label,
            candidate_count=len(addresses),
            verified_count=len(verified),
            game_memory_write=False,
        )
        return record

    def write_memory_value(
        self,
        session_id: str,
        address: int,
        value_type: ValueType,
        new_value: int | float,
        *,
        expected_current: int | float | None = None,
        operation_id: str | None = None,
    ) -> WriteResult:
        return self.application.write_direct_value(
            session_id,
            address,
            value_type,
            new_value,
            expected_current=expected_current,
            operation_id=operation_id,
        )

    def rollback_memory_write(self, rollback_token: str) -> RollbackResult:
        return self.application.rollback_direct_write(rollback_token)

    def start_scan(
        self,
        session_id: str,
        value: int | float,
        value_type: ValueType = ValueType.I32,
    ) -> ScanResult:
        return self._scan_result(self.application.start_scan(session_id, value_type, value))

    def start_unknown_scan(
        self,
        session_id: str,
        value_type: ValueType = ValueType.I32,
        *,
        normalized: bool = False,
    ) -> ScanResult:
        return self._scan_result(
            self.application.start_unknown_scan(
                session_id,
                value_type,
                normalized=normalized,
            )
        )

    def refine_scan(
        self,
        scan_id: str,
        comparison: Comparison,
        value: int | float | None = None,
    ) -> ScanResult:
        return self._scan_result(self.application.rescan(scan_id, comparison, value))

    def scan_candidates(self, scan_id: str, *, limit: int = 20) -> ScanResult:
        return self._scan_result(self.application.scan_summary(scan_id, limit=limit))

    def start_autonomous_discovery(
        self,
        *,
        process_name: str = "NMS.exe",
        session_id: str | None = None,
        target_order: list[str] | None = None,
        interval_seconds: float = 2.0,
        observation_seconds: float = 10.0,
        revisit_seconds: float = 30.0,
    ) -> CheatDiscoveryRunStatus:
        active = self.active_session()
        if session_id is None:
            if (
                active is not None
                and active.process_name.casefold() == process_name.casefold()
            ):
                session_id = active.session_id
            else:
                process = next(
                    (
                        item
                        for item in self.application.list_processes()
                        if item.name.casefold() == process_name.casefold() and item.attachable
                    ),
                    None,
                )
                if process is None:
                    return self.application.start_waiting_autonomous_discovery(
                        process_name=process_name,
                        target_order=target_order,
                        interval_seconds=interval_seconds,
                        observation_seconds=observation_seconds,
                        revisit_seconds=revisit_seconds,
                    )
                session_id = self.attach(
                    process.pid,
                    write_enabled=False,
                    game_key="no-man-s-sky",
                    game_name="No Man's Sky",
                    start_catalog_discovery=False,
                ).session_id
        return self.application.start_autonomous_discovery(
            session_id,
            target_order=target_order,
            interval_seconds=interval_seconds,
            observation_seconds=observation_seconds,
            revisit_seconds=revisit_seconds,
        )

    def autonomous_discovery_status(self, run_id: str) -> CheatDiscoveryRunStatus:
        return self.application.autonomous_discovery_status(run_id)

    def set_autonomous_discovery_value(
        self,
        run_id: str,
        target_name: str,
        value: int | float,
        *,
        source: str = "user",
    ) -> CheatDiscoveryRunStatus:
        return self.application.set_autonomous_discovery_value(
            run_id,
            target_name,
            value,
            source=source,
        )

    def record_autonomous_discovery_screen_comparison(
        self,
        run_id: str,
        target_name: str,
        comparison: str,
        screen_value: int | float,
    ) -> CheatDiscoveryRunStatus:
        return self.application.record_autonomous_discovery_screen_comparison(
            run_id,
            target_name,
            comparison,
            screen_value,
        )

    def rescan_autonomous_discovery_values(
        self,
        run_id: str,
    ) -> CheatDiscoveryRunStatus:
        return self.application.rescan_autonomous_discovery_values(run_id)

    def capture_autonomous_discovery_behavior(
        self,
        run_id: str,
        target_name: str,
        phase: str,
        label: str = "",
    ) -> CheatDiscoveryRunStatus:
        return self.application.capture_autonomous_discovery_behavior(
            run_id,
            target_name,
            phase,
            label,
        )

    def stop_autonomous_discovery(self, run_id: str) -> CheatDiscoveryRunStatus:
        return self.application.stop_autonomous_discovery(run_id)

    def watch_scan(
        self,
        scan_id: str,
        *,
        sample_count: int = 5,
        interval_ms: int = 500,
        limit: int = 20,
    ) -> WatchResult:
        return self.application.watch_scan(
            scan_id,
            sample_count=sample_count,
            interval_ms=interval_ms,
            limit=limit,
        )

    def detect_health_bars(
        self,
        session_id: str,
        *,
        x: int | None = None,
        y: int | None = None,
        width: int | None = None,
        height: int | None = None,
        limit: int = 5,
    ) -> HealthBarResult:
        return self.application.detect_health_bars(
            session_id,
            x=x,
            y=y,
            width=width,
            height=height,
            limit=limit,
        )

    def read_inventory_screen(self, session_id: str) -> InventoryScreenResult:
        return self.application.read_inventory_screen(session_id)

    def read_saved_inventory(
        self,
        session_id: str | None = None,
        *,
        limit: int = 250,
    ) -> SavedInventoryResult:
        return self.application.read_saved_inventory(session_id, limit=limit)

    def resolve_saved_inventory_stack(
        self,
        session_id: str,
        item_id: str,
        *,
        container_name: str | None = "Inventory",
        stack_size_group: str | None = "Personal",
        full_scan: bool = False,
        limit: int = 20,
    ) -> SavedInventoryLiveResolution:
        return self.application.resolve_saved_inventory_stack(
            session_id,
            item_id,
            container_name=container_name,
            stack_size_group=stack_size_group,
            full_scan=full_scan,
            limit=limit,
        )

    def observe_moved_inventory_slot(
        self,
        session_id: str,
        *,
        timeout_seconds: float = 20,
        recipe_name: str | None = None,
    ) -> InventorySlotObservation:
        return self.application.observe_moved_inventory_slot(
            session_id,
            timeout_seconds=timeout_seconds,
            recipe_name=recipe_name,
        )

    def start_moved_inventory_observer(
        self,
        session_id: str,
        *,
        timeout_seconds: float = 20,
        recipe_name: str | None = None,
    ) -> InventoryObserverStatus:
        return self.application.start_moved_inventory_observer(
            session_id,
            timeout_seconds=timeout_seconds,
            recipe_name=recipe_name,
        )

    def moved_inventory_observer_status(
        self,
        session_id: str,
        observer_token: str,
        *,
        wait_seconds: float = 0,
    ) -> InventoryObserverStatus:
        return self.application.moved_inventory_observer_status(
            session_id,
            observer_token,
            wait_seconds=wait_seconds,
        )

    def cancel_moved_inventory_observer(
        self,
        session_id: str,
        observer_token: str,
    ) -> InventoryObserverStatus:
        return self.application.cancel_moved_inventory_observer(
            session_id,
            observer_token,
        )

    def start_instruction_value_observer(
        self,
        session_id: str,
        recipe: InstructionValueRecipe,
        *,
        timeout_seconds: float = 20,
    ) -> InstructionValueObserverStatus:
        return self.application.start_instruction_value_observer(
            session_id,
            recipe,
            timeout_seconds=timeout_seconds,
        )

    def instruction_value_observer_status(
        self,
        session_id: str,
        observer_token: str,
        *,
        wait_seconds: float = 0,
    ) -> InstructionValueObserverStatus:
        return self.application.instruction_value_observer_status(
            session_id,
            observer_token,
            wait_seconds=wait_seconds,
        )

    def cancel_instruction_value_observer(
        self,
        session_id: str,
        observer_token: str,
    ) -> InstructionValueObserverStatus:
        return self.application.cancel_instruction_value_observer(
            session_id,
            observer_token,
        )

    def inspect_cheat_table(
        self,
        session_id: str,
        source: str,
        *,
        query: str = "health",
        limit: int = 50,
        source_build: CheatTableSourceBuild | None = None,
    ) -> CheatTableResult:
        return self.application.inspect_cheat_table(
            session_id,
            source,
            query=query,
            limit=limit,
            source_build=source_build,
        )

    def import_cheat_table_reference(
        self,
        source: str,
        *,
        query: str = "",
        limit: int = 200,
        source_build: CheatTableSourceBuild | None = None,
    ) -> CheatTableResult:
        return self.application.import_cheat_table_reference(
            source,
            query=query,
            limit=limit,
            source_build=source_build,
        )

    def game_cheat_catalog(self, session_id: str) -> GameCheatCatalog:
        return self.application.game_cheat_catalog(session_id)

    def game_value_table(self, session_id: str) -> GameValueTable:
        return self.application.game_value_table(session_id)

    def compare_nms_saves(
        self,
        *,
        older_filename: str | None = None,
        newer_filename: str | None = None,
        limit: int = 250,
    ) -> NmsSaveComparisonReport:
        return self.application.compare_nms_saves(
            older_filename=older_filename,
            newer_filename=newer_filename,
            limit=limit,
        )

    def export_game_value_table(self, session_id: str) -> GameValueTableExportResult:
        return self.application.export_game_value_table(session_id)

    def sync_game_table_registry(
        self,
        action: str = "status",
        *,
        session_id: str | None = None,
    ) -> GameTableRegistryStatus:
        if action not in {"status", "pull", "stage", "publish"}:
            raise ValueError("action must be status, pull, stage, or publish")
        attached = self.active_session()
        if session_id is not None and (
            attached is None or attached.session_id != session_id
        ):
            raise NotFoundError("the selected game session is not active")
        selected = attached if attached and session_id in {None, attached.session_id} else None
        exact_path = None
        if selected is not None:
            exact = self._table_registry.find_exact_table(
                process_name=selected.process_name,
                build_identity=executable_build_identity(selected.executable),
                game_key=selected.game_key,
            )
            exact_path = str(exact) if exact else None
        if action == "status":
            return self._table_registry.status(exact_table_path=exact_path)
        if action == "pull":
            result = self._table_registry.pull()
        else:
            if selected is None:
                raise SafetyError("attach a game before staging or publishing its table")
            exported = self.application.export_game_value_table(selected.session_id)
            result = (
                self._table_registry.stage_export(exported.exported_path)
                if action == "stage"
                else self._table_registry.publish(exported.exported_path)
            )
        self.application.audit.record(
            "game_table_registry_synced",
            action=action,
            session_id=selected.session_id if selected else None,
            changed=result.changed,
            commit=result.commit,
            game_memory_write=False,
        )
        return result

    def add_game_cheat_sources(
        self,
        session_id: str,
        sources: list[str],
        *,
        query: str = "health stamina mana money gold",
    ) -> GameCheatCatalog:
        return self.application.add_game_cheat_sources(
            session_id,
            sources,
            query=query,
        )

    def locate_unreal_engine(self, session_id: str) -> UnrealDiscoveryResult:
        return self.application.locate_unreal_engine(session_id)

    def start_unreal_gas_scan(
        self,
        session_id: str,
        value_types: list[ValueType] | None = None,
    ) -> UnrealGasScanSummary:
        return self.application.start_unreal_gas_scan(session_id, value_types)

    def refine_unreal_gas_scan(
        self,
        scan_id: str,
        comparison: Comparison,
        value: int | float | None = None,
    ) -> UnrealGasScanSummary:
        return self.application.refine_unreal_gas_scan(scan_id, comparison, value)

    def start_unreal_table_guided_scan(
        self,
        scan_id: str,
        *,
        pawn_pointer_offset: int = 0xD30,
        pointer_radius: int = 0x100,
        health_offset: int = 0x1A4,
        max_health_offset: int = 0xE18,
        nested_state_offset: int = 0x150,
        replica_percent_offset: int = 0x12C,
    ) -> UnrealGasScanSummary:
        return self.application.start_unreal_table_guided_scan(
            scan_id,
            pawn_pointer_offset=pawn_pointer_offset,
            pointer_radius=pointer_radius,
            health_offset=health_offset,
            max_health_offset=max_health_offset,
            nested_state_offset=nested_state_offset,
            replica_percent_offset=replica_percent_offset,
        )

    def unreal_gas_scan_candidates(
        self,
        scan_id: str,
        *,
        limit: int = 20,
    ) -> UnrealGasScanSummary:
        return self.application.unreal_gas_scan_summary(scan_id, limit=limit)

    def watch_unreal_gas_scan(
        self,
        scan_id: str,
        *,
        sample_count: int = 5,
        interval_ms: int = 500,
        limit: int = 20,
    ) -> UnrealGasWatchResult:
        return self.application.watch_unreal_gas_scan(
            scan_id,
            sample_count=sample_count,
            interval_ms=interval_ms,
            limit=limit,
        )

    def capture_unreal_gas_damage_refill(
        self,
        scan_id: str,
        *,
        sample_count: int = 30,
        interval_ms: int = 500,
        group_limit: int = 10,
    ) -> UnrealGasTemporalResult:
        return self.application.capture_unreal_gas_damage_refill(
            scan_id,
            sample_count=sample_count,
            interval_ms=interval_ms,
            group_limit=group_limit,
        )

    def start_unreal_gas_damage_monitor(
        self,
        scan_id: str,
        *,
        interval_ms: int = 500,
        duration_seconds: int = 300,
        group_limit: int = 10,
    ) -> UnrealGasMonitorStatus:
        return self.application.start_unreal_gas_damage_monitor(
            scan_id,
            interval_ms=interval_ms,
            duration_seconds=duration_seconds,
            group_limit=group_limit,
        )

    def unreal_gas_damage_monitor_status(
        self,
        monitor_id: str,
    ) -> UnrealGasMonitorStatus:
        return self.application.unreal_gas_damage_monitor_status(monitor_id)

    def stop_unreal_gas_damage_monitor(
        self,
        monitor_id: str,
    ) -> UnrealGasMonitorStatus:
        return self.application.stop_unreal_gas_damage_monitor(monitor_id)

    def start_unreal_game_profile_monitor(
        self,
        scan_id: str,
        *,
        interval_ms: int = 1000,
        duration_seconds: int = 900,
        candidate_limit: int = 50,
    ) -> GameProfileMonitorStatus:
        return self.application.start_unreal_game_profile_monitor(
            scan_id,
            interval_ms=interval_ms,
            duration_seconds=duration_seconds,
            candidate_limit=candidate_limit,
        )

    def unreal_game_profile_monitor_status(
        self,
        monitor_id: str,
    ) -> GameProfileMonitorStatus:
        return self.application.unreal_game_profile_monitor_status(monitor_id)

    def stop_unreal_game_profile_monitor(
        self,
        monitor_id: str,
    ) -> GameProfileMonitorStatus:
        return self.application.stop_unreal_game_profile_monitor(monitor_id)

    def save_unreal_gas_profile(
        self,
        scan_id: str,
        address: int,
        value_type: ValueType,
        name: str = "Health",
    ) -> UnrealGasProfile:
        return self.application.save_unreal_gas_profile(
            scan_id,
            address,
            value_type,
            name,
        )

    def read_unreal_gas_profile(
        self,
        session_id: str,
        profile_id: str,
    ) -> UnrealGasProfileValue:
        return self.application.read_unreal_gas_profile(session_id, profile_id)

    def prepare_game_cheat_action(
        self,
        session_id: str,
        feature_id: str,
        action: CheatAction,
        value: int | float | None = None,
        *,
        interval_ms: int = 250,
        duration_seconds: int = 300,
    ) -> PreparedGameCheatActionResult:
        intent = self.application.prepare_game_cheat_action(
            session_id,
            feature_id,
            action,
            value,
            interval_ms=interval_ms,
            duration_seconds=duration_seconds,
        )
        with self._lock:
            self._pending_game_actions[intent.id] = (action, feature_id)
            if isinstance(intent, HoldIntentView):
                self._pending_holds[intent.id] = intent
                selected_value = intent.hold_value
                selected_interval = intent.interval_ms
                selected_duration = intent.duration_seconds
            else:
                self._pending_intents[intent.id] = intent
                selected_value = intent.new_value
                selected_interval = None
                selected_duration = None
        return PreparedGameCheatActionResult(
            intent_id=intent.id,
            session_id=intent.session_id,
            feature_id=feature_id,
            action=action,
            value=selected_value,
            interval_ms=selected_interval,
            duration_seconds=selected_duration,
            expires_at=intent.expires_at,
        )

    def confirm_game_cheat_action_locally(self, intent_id: str) -> GameCheatActionResult:
        with self._lock:
            metadata = self._pending_game_actions.get(intent_id)
            if metadata is None:
                raise NotFoundError(f"pending game cheat action {intent_id} was not found")
            if intent_id in self._confirming:
                raise SafetyError("this game cheat action is already awaiting local confirmation")
            action, feature_id = metadata
            intent = (
                self._pending_holds.get(intent_id)
                if action is CheatAction.HOLD
                else self._pending_intents.get(intent_id)
            )
            if intent is None:
                raise NotFoundError(f"pending game cheat action {intent_id} was not found")
            self._confirming.add(intent_id)
        try:
            phrase = self.confirmer.request(intent)
            if phrase is None:
                raise SafetyError("the local user cancelled the game cheat action")
            if action is CheatAction.HOLD:
                hold = self.application.confirm_hold(intent_id, phrase)
                result = GameCheatActionResult(
                    feature_id=feature_id,
                    action=action,
                    hold=hold,
                )
            else:
                write = self.application.confirm_write(intent_id, phrase)
                result = GameCheatActionResult(
                    feature_id=feature_id,
                    action=action,
                    write=write,
                )
            with self._lock:
                self._pending_intents.pop(intent_id, None)
                self._pending_holds.pop(intent_id, None)
                self._pending_game_actions.pop(intent_id, None)
            return result
        finally:
            with self._lock:
                self._confirming.discard(intent_id)

    def apply_game_cheat_action(self, intent_id: str) -> GameCheatActionResult:
        """Apply an explicit user-requested named value action without another dialog."""

        with self._lock:
            metadata = self._pending_game_actions.get(intent_id)
            if metadata is None:
                raise NotFoundError(f"pending game cheat action {intent_id} was not found")
            if intent_id in self._confirming:
                raise SafetyError("this game cheat action is already being applied")
            action, feature_id = metadata
            intent = (
                self._pending_holds.get(intent_id)
                if action is CheatAction.HOLD
                else self._pending_intents.get(intent_id)
            )
            if intent is None:
                raise NotFoundError(f"pending game cheat action {intent_id} was not found")
            self._confirming.add(intent_id)
        try:
            if action is CheatAction.HOLD:
                hold = self.application.confirm_hold(intent_id, intent.confirmation_phrase)
                result = GameCheatActionResult(
                    feature_id=feature_id,
                    action=action,
                    hold=hold,
                )
            else:
                write = self.application.confirm_write(intent_id, intent.confirmation_phrase)
                result = GameCheatActionResult(
                    feature_id=feature_id,
                    action=action,
                    write=write,
                )
            self.application.audit.record(
                "user_requested_quick_game_action_applied",
                intent_id=intent_id,
                feature_id=feature_id,
                action=action,
            )
            with self._lock:
                self._pending_intents.pop(intent_id, None)
                self._pending_holds.pop(intent_id, None)
                self._pending_game_actions.pop(intent_id, None)
            return result
        finally:
            with self._lock:
                self._confirming.discard(intent_id)

    def list_game_cheat_holds(self, session_id: str) -> HoldListResult:
        return HoldListResult(
            session_id=session_id,
            holds=self.application.list_holds(session_id),
        )

    def stop_game_cheat_hold(self, hold_id: str) -> HoldStatus:
        return self.application.stop_hold(hold_id)

    def prepare_write(
        self,
        session_id: str,
        address: int,
        value_type: ValueType,
        expected_current: int | float,
        new_value: int | float,
        reason: str,
    ) -> PreparedWriteResult:
        intent = self.application.prepare_write(
            session_id,
            address,
            value_type,
            expected_current,
            new_value,
            reason,
        )
        with self._lock:
            self._pending_intents[intent.id] = intent
        return PreparedWriteResult(
            intent_id=intent.id,
            session_id=intent.session_id,
            address=intent.address,
            value_type=intent.value_type,
            expected_current=intent.expected_current,
            new_value=intent.new_value,
            reason=intent.reason,
            expires_at=intent.expires_at,
        )

    def confirm_write_locally(self, intent_id: str) -> WriteResult:
        with self._lock:
            intent = self._pending_intents.get(intent_id)
            if intent is None:
                raise NotFoundError(f"pending write intent {intent_id} was not found")
            if intent_id in self._confirming:
                raise SafetyError("this write intent is already awaiting local confirmation")
            self._confirming.add(intent_id)
        try:
            phrase = self.confirmer.request(intent)
            if phrase is None:
                raise SafetyError("the local user cancelled the write")
            result = self.application.confirm_write(intent_id, phrase)
            with self._lock:
                self._pending_intents.pop(intent_id, None)
            return result
        finally:
            with self._lock:
                self._confirming.discard(intent_id)

    def apply_prepared_write(self, intent_id: str) -> WriteResult:
        """Apply a prepared user-requested value change without a phrase dialog."""

        with self._lock:
            intent = self._pending_intents.get(intent_id)
            if intent is None:
                raise NotFoundError(f"pending write intent {intent_id} was not found")
            if intent_id in self._confirming:
                raise SafetyError("this write intent is already being applied")
            self._confirming.add(intent_id)
        try:
            result = self.application.confirm_write(intent_id, intent.confirmation_phrase)
            self.application.audit.record(
                "user_requested_quick_write_applied",
                intent_id=intent_id,
                session_id=intent.session_id,
            )
            with self._lock:
                self._pending_intents.pop(intent_id, None)
            return result
        finally:
            with self._lock:
                self._confirming.discard(intent_id)

    def prepare_discovery_candidate_test(
        self,
        run_id: str,
        target_name: str,
        candidate_id: str,
        test_value: int | float,
    ) -> PreparedDiscoveryCandidateTestResult:
        context = self.application.discovery.candidate_test_context(
            run_id,
            target_name,
            candidate_id,
        )
        prepared = self.prepare_write(
            context.session_id,
            context.address,
            context.value_type,
            context.current_value,
            test_value,
            (
                f"controlled candidate {context.candidate_index}/{context.candidate_count} "
                f"test for {context.target_name}"
            ),
        )
        pending = _PendingDiscoveryCandidateTest(
            run_id=context.run_id,
            target_name=context.target_name,
            candidate_id=context.candidate_id,
            session_id=context.session_id,
            address=context.address,
            value_type=context.value_type,
            original_value=context.current_value,
            test_value=test_value,
        )
        with self._lock:
            self._pending_candidate_tests[prepared.intent_id] = pending
        return PreparedDiscoveryCandidateTestResult(
            intent_id=prepared.intent_id,
            run_id=context.run_id,
            target_name=context.target_name,
            candidate_id=context.candidate_id,
            candidate_index=context.candidate_index,
            candidate_count=context.candidate_count,
            session_id=context.session_id,
            address=context.address,
            value_type=context.value_type,
            original_value=context.current_value,
            test_value=test_value,
            expires_at=prepared.expires_at,
        )

    def finalize_discovery_candidate_test(
        self,
        intent_id: str,
        *,
        matched_in_game: bool,
        restore_after_test: bool = False,
        verification_source: str = "user",
    ) -> DiscoveryCandidateTestResult:
        with self._lock:
            pending = self._pending_candidate_tests.get(intent_id)
        if pending is None:
            raise NotFoundError(f"candidate write test {intent_id} was not found")

        current = self.application.read_value(
            pending.session_id,
            pending.address,
            pending.value_type,
        )
        if matched_in_game:
            if not values_equal(pending.value_type, current, pending.test_value):
                raise SafetyError(
                    "the candidate no longer contains the confirmed test value; scan it again"
                )
            restored = False
            observed_value = pending.test_value
            if restore_after_test:
                restore = self.prepare_write(
                    pending.session_id,
                    pending.address,
                    pending.value_type,
                    pending.test_value,
                    pending.original_value,
                    f"restore verified {pending.target_name} trace to its original value",
                )
                self.apply_prepared_write(restore.intent_id)
                restored = True
                observed_value = pending.original_value
            status = self.application.discovery.record_candidate_test(
                pending.run_id,
                pending.target_name,
                pending.candidate_id,
                matched_in_game=True,
                observed_value=observed_value,
                verification_source=verification_source,
                restored_after_test=restored,
            )
        else:
            if values_equal(pending.value_type, current, pending.original_value):
                restored = True
            elif values_equal(pending.value_type, current, pending.test_value):
                restore = self.prepare_write(
                    pending.session_id,
                    pending.address,
                    pending.value_type,
                    pending.test_value,
                    pending.original_value,
                    f"restore rejected {pending.target_name} candidate to its original value",
                )
                self.apply_prepared_write(restore.intent_id)
                restored = True
            else:
                raise SafetyError(
                    "the tested candidate changed unexpectedly; inspect it before restoring"
                )
            status = self.application.discovery.record_candidate_test(
                pending.run_id,
                pending.target_name,
                pending.candidate_id,
                matched_in_game=False,
                observed_value=pending.original_value,
                verification_source=verification_source,
                restored_after_test=restored,
            )
        self.application.audit.record(
            "discovery_candidate_write_test_completed",
            run_id=pending.run_id,
            session_id=pending.session_id,
            target_name=pending.target_name,
            candidate_id=pending.candidate_id,
            matched_in_game=matched_in_game,
            restored=restored,
            verification_source=verification_source,
        )
        with self._lock:
            self._pending_candidate_tests.pop(intent_id, None)
        return DiscoveryCandidateTestResult(
            run_id=pending.run_id,
            target_name=pending.target_name,
            candidate_id=pending.candidate_id,
            matched_in_game=matched_in_game,
            restored=restored,
            verification_source=verification_source,
            status=status,
        )

    def prepare_inventory_matrix_probe(
        self,
        run_id: str,
        target_name: str = "inventory item quantity",
    ) -> PreparedInventoryMatrixProbeResult:
        """Prepare unique +1/+3/+5 changes for every current inventory candidate."""

        status = self.application.autonomous_discovery_status(run_id)
        target = next(
            (item for item in status.targets if item.name.casefold() == target_name.casefold()),
            None,
        )
        if target is None:
            raise NotFoundError(f"discovery target {target_name!r} was not found")
        candidate_ids = [
            candidate.id
            for candidate in target.candidates
            if candidate.write_test_status in {"ready", "confirmed"}
            and candidate.id not in target.rejected_candidate_ids
        ]
        if not 1 <= len(candidate_ids) <= 5:
            raise SafetyError("inventory mapping requires a one-to-five candidate set")

        entries: list[InventoryMatrixProbeEntry] = []
        prepared_ids: list[str] = []
        session_id = ""
        try:
            for index, candidate_id in enumerate(candidate_ids):
                context = self.application.discovery.candidate_test_context(
                    run_id,
                    target_name,
                    candidate_id,
                )
                if context.value_type not in {
                    ValueType.I8,
                    ValueType.U8,
                    ValueType.I16,
                    ValueType.U16,
                    ValueType.I32,
                    ValueType.U32,
                    ValueType.I64,
                    ValueType.U64,
                }:
                    raise SafetyError("inventory odd-delta mapping requires integer stack values")
                if any(entry.address == context.address for entry in entries):
                    raise SafetyError("inventory candidates resolved to a duplicate address")
                delta = index * 2 + 1
                original = int(context.current_value)
                test_value = _bounded_integer_probe_value(context.value_type, original, delta)
                prepared = self.prepare_write(
                    context.session_id,
                    context.address,
                    context.value_type,
                    original,
                    test_value,
                    f"reversible inventory matrix candidate {index + 1}/{len(candidate_ids)}",
                )
                prepared_ids.append(prepared.intent_id)
                session_id = context.session_id
                entries.append(
                    InventoryMatrixProbeEntry(
                        intent_id=prepared.intent_id,
                        candidate_id=candidate_id,
                        address=context.address,
                        value_type=context.value_type,
                        original_value=original,
                        delta=test_value - original,
                        test_value=test_value,
                    )
                )
        except Exception:
            with self._lock:
                for intent_id in prepared_ids:
                    self._pending_intents.pop(intent_id, None)
            raise

        probe_id = uuid4().hex
        expires_at = min(
            self._pending_intents[entry.intent_id].expires_at for entry in entries
        )
        pending = _PendingInventoryMatrixProbe(
            probe_id=probe_id,
            run_id=run_id,
            target_name=target.name,
            session_id=session_id,
            entries=entries,
            expires_at=expires_at,
        )
        with self._lock:
            self._pending_inventory_matrix_probes[probe_id] = pending
        self.application.audit.record(
            "inventory_matrix_probe_prepared",
            probe_id=probe_id,
            run_id=run_id,
            session_id=session_id,
            candidate_count=len(entries),
            deltas=[entry.delta for entry in entries],
        )
        return self._inventory_matrix_view(pending)

    def apply_inventory_matrix_probe(
        self,
        probe_id: str,
    ) -> PreparedInventoryMatrixProbeResult:
        with self._lock:
            pending = self._pending_inventory_matrix_probes.get(probe_id)
        if pending is None:
            raise NotFoundError(f"inventory matrix probe {probe_id} was not found")
        if pending.applied:
            return self._inventory_matrix_view(pending)
        applied: list[InventoryMatrixProbeEntry] = []
        try:
            for entry in pending.entries:
                self.apply_prepared_write(entry.intent_id)
                applied.append(entry)
        except Exception as exc:
            for entry in reversed(applied):
                try:
                    self._restore_inventory_matrix_entry(pending.session_id, entry)
                except Exception:  # noqa: BLE001 - preserve original failure and audit rollback gap
                    pass
            with self._lock:
                for entry in pending.entries:
                    self._pending_intents.pop(entry.intent_id, None)
                self._pending_inventory_matrix_probes.pop(probe_id, None)
            raise SafetyError(
                "inventory matrix probe failed; already-applied values were restored"
            ) from exc
        pending.applied = True
        self.application.audit.record(
            "inventory_matrix_probe_applied",
            probe_id=probe_id,
            run_id=pending.run_id,
            session_id=pending.session_id,
            candidate_count=len(pending.entries),
        )
        return self._inventory_matrix_view(pending)

    def restore_inventory_matrix_probe(
        self,
        probe_id: str,
        *,
        matched_candidates: dict[str, str] | None = None,
        reference_urls: dict[str, str] | None = None,
    ) -> InventoryMatrixProbeResult:
        with self._lock:
            pending = self._pending_inventory_matrix_probes.get(probe_id)
        if pending is None:
            raise NotFoundError(f"inventory matrix probe {probe_id} was not found")
        restore_errors: list[str] = []
        if pending.applied:
            for entry in reversed(pending.entries):
                try:
                    self._restore_inventory_matrix_entry(pending.session_id, entry)
                except Exception as exc:  # noqa: BLE001 - restore the rest before reporting
                    restore_errors.append(f"{entry.candidate_id}: {exc}")
        if restore_errors:
            raise SafetyError(
                "inventory matrix restore needs attention: " + "; ".join(restore_errors)
            )
        matches = matched_candidates or {}
        status = self.application.discovery.record_inventory_matrix_matches(
            pending.run_id,
            pending.target_name,
            matches,
            reference_urls,
        )
        with self._lock:
            for entry in pending.entries:
                self._pending_intents.pop(entry.intent_id, None)
            self._pending_inventory_matrix_probes.pop(probe_id, None)
        self.application.audit.record(
            "inventory_matrix_probe_restored",
            probe_id=probe_id,
            run_id=pending.run_id,
            session_id=pending.session_id,
            matched_candidates=matches,
        )
        return InventoryMatrixProbeResult(
            probe_id=probe_id,
            run_id=pending.run_id,
            target_name=pending.target_name,
            restored=True,
            matched_candidates=matches,
            status=status,
        )

    def _restore_inventory_matrix_entry(
        self,
        session_id: str,
        entry: InventoryMatrixProbeEntry,
    ) -> None:
        current = self.application.read_value(session_id, entry.address, entry.value_type)
        if values_equal(entry.value_type, current, entry.original_value):
            return
        if not values_equal(entry.value_type, current, entry.test_value):
            raise SafetyError("candidate changed unexpectedly during the observation window")
        restore = self.prepare_write(
            session_id,
            entry.address,
            entry.value_type,
            entry.test_value,
            entry.original_value,
            "restore inventory matrix candidate to its original stack value",
        )
        self.apply_prepared_write(restore.intent_id)

    @staticmethod
    def _inventory_matrix_view(
        pending: _PendingInventoryMatrixProbe,
    ) -> PreparedInventoryMatrixProbeResult:
        return PreparedInventoryMatrixProbeResult(
            probe_id=pending.probe_id,
            run_id=pending.run_id,
            target_name=pending.target_name,
            entries=pending.entries,
            expires_at=pending.expires_at,
            applied=pending.applied,
        )

    def set_practice_value(self, name: str, value: int | float) -> PracticeValueResult:
        address = self.application.mutate_simulator(name, value)
        return PracticeValueResult(name=name, address=address, value=value)

    def close(self) -> None:
        with self._lock:
            probe_ids = list(self._pending_inventory_matrix_probes)
        for probe_id in probe_ids:
            try:
                self.restore_inventory_matrix_probe(probe_id)
            except Exception:  # noqa: BLE001 - application shutdown continues after best effort
                pass
        with self._lock:
            candidate_test_ids = list(self._pending_candidate_tests)
        for intent_id in candidate_test_ids:
            try:
                self._restore_pending_candidate_test(intent_id)
            except Exception:  # noqa: BLE001 - application shutdown continues after best effort
                pass
        self.application.close()
        with self._lock:
            self._active_session = None
            self._pending_intents.clear()
            self._pending_holds.clear()
            self._pending_game_actions.clear()
            self._pending_candidate_tests.clear()
            self._pending_inventory_matrix_probes.clear()

    def _detach_application_session(self, session_id: str) -> None:
        self._restore_session_inventory_probes(session_id)
        self._restore_session_candidate_tests(session_id)
        self.application.detach(session_id)
        with self._lock:
            stale_ids = [
                intent_id
                for intent_id, intent in self._pending_intents.items()
                if intent.session_id == session_id
            ]
            for intent_id in stale_ids:
                self._pending_intents.pop(intent_id, None)
                self._pending_game_actions.pop(intent_id, None)
                self._pending_candidate_tests.pop(intent_id, None)
            stale_hold_ids = [
                intent_id
                for intent_id, intent in self._pending_holds.items()
                if intent.session_id == session_id
            ]
            for intent_id in stale_hold_ids:
                self._pending_holds.pop(intent_id, None)
                self._pending_game_actions.pop(intent_id, None)

    def _restore_session_inventory_probes(self, session_id: str) -> None:
        with self._lock:
            probe_ids = [
                probe_id
                for probe_id, probe in self._pending_inventory_matrix_probes.items()
                if probe.session_id == session_id
            ]
        for probe_id in probe_ids:
            self.restore_inventory_matrix_probe(probe_id)

    def _restore_session_candidate_tests(self, session_id: str) -> None:
        with self._lock:
            intent_ids = [
                intent_id
                for intent_id, pending in self._pending_candidate_tests.items()
                if pending.session_id == session_id
            ]
        for intent_id in intent_ids:
            self._restore_pending_candidate_test(intent_id)

    def _restore_pending_candidate_test(self, intent_id: str) -> None:
        with self._lock:
            pending = self._pending_candidate_tests.get(intent_id)
        if pending is None:
            return
        current = self.application.read_value(
            pending.session_id,
            pending.address,
            pending.value_type,
        )
        if values_equal(pending.value_type, current, pending.test_value):
            restore = self.prepare_write(
                pending.session_id,
                pending.address,
                pending.value_type,
                pending.test_value,
                pending.original_value,
                f"restore unfinished {pending.target_name} candidate trace",
            )
            self.apply_prepared_write(restore.intent_id)
        elif not values_equal(pending.value_type, current, pending.original_value):
            raise SafetyError(
                "unfinished candidate trace changed unexpectedly; inspect it before restoring"
            )
        with self._lock:
            self._pending_candidate_tests.pop(intent_id, None)
            self._pending_intents.pop(intent_id, None)

    @staticmethod
    def _scan_result(summary) -> ScanResult:
        return ScanResult(
            scan_id=summary.id,
            session_id=summary.session_id,
            scan_kind=summary.scan_kind,
            value_type=summary.value_type,
            normalized=summary.normalized,
            comparison=summary.comparison,
            generation=summary.generation,
            result_count=summary.result_count,
            truncated=summary.truncated,
            scope_truncated=summary.scope_truncated,
            scanned_bytes=summary.scanned_bytes,
            eligible_bytes=summary.eligible_bytes,
            selected_region_count=summary.selected_region_count,
            cache_backed=summary.cache_backed,
            cached_bytes=summary.cached_bytes,
            cache_reused=summary.cache_reused,
            reused_from_scan_id=summary.reused_from_scan_id,
            candidates=summary.candidates,
        )


_INTEGER_BOUNDS: dict[ValueType, tuple[int, int]] = {
    ValueType.I8: (-(2**7), 2**7 - 1),
    ValueType.U8: (0, 2**8 - 1),
    ValueType.I16: (-(2**15), 2**15 - 1),
    ValueType.U16: (0, 2**16 - 1),
    ValueType.I32: (-(2**31), 2**31 - 1),
    ValueType.U32: (0, 2**32 - 1),
    ValueType.I64: (-(2**63), 2**63 - 1),
    ValueType.U64: (0, 2**64 - 1),
}


def _bounded_integer_probe_value(value_type: ValueType, original: int, delta: int) -> int:
    lower, upper = _INTEGER_BOUNDS[value_type]
    if original + delta <= upper:
        return original + delta
    if original - delta >= lower:
        return original - delta
    raise SafetyError("inventory stack value has no room for a reversible odd-delta probe")
