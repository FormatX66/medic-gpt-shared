from __future__ import annotations

import json
from datetime import UTC, datetime
from pathlib import Path
from threading import Lock
from typing import Any


class AuditLogger:
    def __init__(self, path: Path | None) -> None:
        self._path = path
        self._lock = Lock()
        self.events: list[dict[str, Any]] = []

    def record(self, event: str, **details: Any) -> None:
        entry = {
            "timestamp": datetime.now(UTC).isoformat(),
            "event": event,
            **details,
        }
        with self._lock:
            self.events.append(entry)
            if self._path is not None:
                self._path.parent.mkdir(parents=True, exist_ok=True)
                with self._path.open("a", encoding="utf-8") as stream:
                    stream.write(json.dumps(entry, sort_keys=True) + "\n")
