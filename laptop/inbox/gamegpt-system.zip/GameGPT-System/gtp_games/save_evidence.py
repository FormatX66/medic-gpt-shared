from __future__ import annotations

import hashlib
import json
from collections.abc import Callable
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from threading import RLock

from gtp_games.nms_save import newest_save, read_currency_snapshot

_NMS_CACHE_LOCK = RLock()
_NMS_CACHE_KEY: tuple[Path, int, int] | None = None
_NMS_CACHE_VALUE: SaveValueSnapshot | None = None


@dataclass(frozen=True)
class SaveValueSnapshot:
    """Game-neutral, read-only values extracted from one save generation."""

    game_key: str
    provider_name: str
    snapshot_id: str
    modified_at: datetime
    values: dict[str, int | float]
    evidence: dict[str, list[str]] = field(default_factory=dict)


SaveValueReader = Callable[[], SaveValueSnapshot | None]


class SaveEvidenceRegistry:
    """Small registry so every selected game checks the same save-learning hook."""

    def __init__(self) -> None:
        self._readers: dict[str, tuple[str, SaveValueReader]] = {}

    def register(self, game_key: str, provider_name: str, reader: SaveValueReader) -> None:
        self._readers[_normalize_game_key(game_key)] = (provider_name, reader)

    def provider_name(self, game_key: str) -> str | None:
        entry = self._readers.get(_normalize_game_key(game_key))
        return entry[0] if entry is not None else None

    def read(self, game_key: str) -> SaveValueSnapshot | None:
        entry = self._readers.get(_normalize_game_key(game_key))
        return entry[1]() if entry is not None else None


def build_default_save_evidence_registry() -> SaveEvidenceRegistry:
    registry = SaveEvidenceRegistry()
    for game_key in ("nms", "no-man-s-sky", "no-mans-sky"):
        registry.register(game_key, "No Man's Sky local save", _read_nms_snapshot)
    return registry


def _read_nms_snapshot() -> SaveValueSnapshot | None:
    global _NMS_CACHE_KEY, _NMS_CACHE_VALUE  # noqa: PLW0603 - one bounded process cache

    path = newest_save()
    if path is None:
        return None
    stat = path.stat()
    cache_key = (path.resolve(), stat.st_mtime_ns, stat.st_size)
    with _NMS_CACHE_LOCK:
        if cache_key == _NMS_CACHE_KEY:
            return _NMS_CACHE_VALUE
    snapshot = read_currency_snapshot()
    if snapshot is None:
        return None
    evidence: dict[str, list[str]] = {
        name: ["Read from the newest local NMS save without changing it."]
        for name in snapshot.values
    }
    with _NMS_CACHE_LOCK:
        previous = _NMS_CACHE_VALUE
    if previous is not None:
        for name, value in snapshot.values.items():
            old_value = previous.values.get(name)
            if old_value is None or old_value == value:
                continue
            delta = int(value) - int(old_value)
            evidence.setdefault(name, []).append(
                f"Save snapshot evidence: {name} changed by {delta:+d} since the "
                "previous observed save generation."
            )
    identity_payload = json.dumps(
        {
            "modified_at": snapshot.modified_at.astimezone(UTC).isoformat(),
            "size": snapshot.save_path.stat().st_size,
            "values": snapshot.values,
        },
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    result = SaveValueSnapshot(
        game_key="no-man-s-sky",
        provider_name="No Man's Sky local save",
        snapshot_id=hashlib.sha256(identity_payload).hexdigest(),
        modified_at=snapshot.modified_at,
        values=dict(snapshot.values),
        evidence=evidence,
    )
    with _NMS_CACHE_LOCK:
        _NMS_CACHE_KEY = cache_key
        _NMS_CACHE_VALUE = result
    return result


def _normalize_game_key(game_key: str) -> str:
    return "-".join(game_key.strip().casefold().replace("'", "").split())
