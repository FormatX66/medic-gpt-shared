from __future__ import annotations

import hashlib
import ipaddress
import os
import re
import socket
import xml.etree.ElementTree as ET
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.parse import urljoin, urlsplit
from urllib.request import HTTPRedirectHandler, Request, build_opener

from gtp_games.codec import decode_value, value_size
from gtp_games.errors import BackendError, SafetyError
from gtp_games.game_identity import executable_build_fingerprint
from gtp_games.memory.base import MemoryBackend
from gtp_games.models import (
    CheatTableCheck,
    CheatTableHint,
    CheatTableModuleOffset,
    CheatTableOverlayFinding,
    CheatTableResult,
    CheatTableScriptFinding,
    CheatTableSignature,
    CheatTableSourceBuild,
    CheatTableStructure,
    CheatTableStructureField,
    GameBuildFingerprint,
    MemoryRegion,
    MemoryRegionKind,
    ProcessSession,
    ValueType,
)

_MODULE_ADDRESS = re.compile(
    r'^"?(?P<module>[^"\r\n]+?\.exe)"?\s*(?P<sign>[+-])\s*(?P<offset>[0-9a-f]+)$',
    re.IGNORECASE,
)
_ABSOLUTE_ADDRESS = re.compile(r"^(?:0x)?(?P<address>[0-9a-f]{6,16})$", re.IGNORECASE)
_AOB_CALL = re.compile(r"\baobscan(?P<module>module)?\s*\((?P<args>[^)\r\n]+)\)", re.I)
_SCRIPT_MODULE_OFFSET = re.compile(
    r'(?P<expression>(?:"(?P<quoted>[^"\r\n]+\.exe)"|'
    r"(?P<bare>[A-Za-z0-9_.-]+\.exe))\s*\+\s*(?P<offset>[0-9A-Fa-f]{1,16}))",
    re.I,
)
_LUA_UI_API = re.compile(
    r"\b(?:createForm|createLabel|createButton|createPanel|createImage|showTableFile)\b",
    re.I,
)
_SCRIPT_TAGS = {"assemblerscript", "luascript", "script"}
_TABLE_CONTENT_TYPES = {
    "application/octet-stream",
    "application/xml",
    "text/plain",
    "text/xml",
}
_SCRIPT_DIRECTIVES = {
    "alloc",
    "aobscan",
    "aobscanmodule",
    "assert",
    "call",
    "createthread",
    "db",
    "dd",
    "dealloc",
    "define",
    "dq",
    "dw",
    "globalalloc",
    "jmp",
    "loadlibrary",
    "luacall",
    "nop",
    "readmem",
    "registersymbol",
    "unregistersymbol",
}
_MUTATING_DIRECTIVES = {
    "alloc",
    "call",
    "createthread",
    "db",
    "dd",
    "dealloc",
    "dq",
    "dw",
    "globalalloc",
    "jmp",
    "loadlibrary",
    "luacall",
    "nop",
    "readmem",
}
_VALUE_TYPES = {
    "byte": ValueType.U8,
    "2 bytes": ValueType.I16,
    "4 bytes": ValueType.I32,
    "8 bytes": ValueType.I64,
    "float": ValueType.F32,
    "double": ValueType.F64,
}


def inspect_cheat_table(
    path: str | Path,
    *,
    backend: MemoryBackend,
    session: ProcessSession,
    max_bytes: int,
    max_signature_scan_bytes: int,
    query: str = "health",
    limit: int = 50,
    source_build: CheatTableSourceBuild | None = None,
) -> CheatTableResult:
    """Parse local static table hints and validate them read-only."""

    table_path = Path(path).expanduser().resolve()
    if table_path.suffix.casefold() != ".ct":
        raise SafetyError("only Cheat Engine .CT table files are accepted")
    try:
        size = table_path.stat().st_size
    except OSError as exc:
        raise SafetyError("the Cheat Engine table could not be opened") from exc
    if size <= 0 or size > max_bytes:
        raise SafetyError(f"Cheat Engine table size must be between 1 and {max_bytes} bytes")
    try:
        raw = table_path.read_bytes()
    except OSError as exc:
        raise SafetyError("the Cheat Engine table could not be read") from exc
    return inspect_cheat_table_bytes(
        raw,
        source=str(table_path),
        source_kind="file",
        backend=backend,
        session=session,
        max_bytes=max_bytes,
        max_signature_scan_bytes=max_signature_scan_bytes,
        query=query,
        limit=limit,
        source_build=source_build,
    )


def inspect_cheat_table_url(
    url: str,
    *,
    backend: MemoryBackend,
    session: ProcessSession,
    max_bytes: int,
    max_signature_scan_bytes: int,
    query: str = "health",
    limit: int = 50,
    source_build: CheatTableSourceBuild | None = None,
) -> CheatTableResult:
    """Fetch a public HTTPS table into memory and inspect it without executing or saving it."""

    raw, final_url = _download_cheat_table(url, max_bytes=max_bytes)
    return inspect_cheat_table_bytes(
        raw,
        source=final_url,
        source_kind="url",
        backend=backend,
        session=session,
        max_bytes=max_bytes,
        max_signature_scan_bytes=max_signature_scan_bytes,
        query=query,
        limit=limit,
        source_build=source_build,
    )


def import_cheat_table_reference(
    path: str | Path,
    *,
    max_bytes: int,
    query: str = "",
    limit: int = 200,
    source_build: CheatTableSourceBuild | None = None,
) -> CheatTableResult:
    """Statically import a local table as inert reference metadata."""

    table_path = Path(path).expanduser().resolve()
    if table_path.suffix.casefold() != ".ct":
        raise SafetyError("only Cheat Engine .CT table files are accepted")
    try:
        size = table_path.stat().st_size
        if not 1 <= size <= max_bytes:
            raise SafetyError(f"Cheat Engine table size must be between 1 and {max_bytes} bytes")
        raw = table_path.read_bytes()
    except SafetyError:
        raise
    except OSError as exc:
        raise SafetyError("the Cheat Engine table could not be read") from exc
    return inspect_cheat_table_bytes(
        raw,
        source=str(table_path),
        source_kind="file",
        backend=None,
        session=None,
        max_bytes=max_bytes,
        max_signature_scan_bytes=0,
        query=query,
        limit=limit,
        source_build=source_build,
    )


def import_cheat_table_reference_url(
    url: str,
    *,
    max_bytes: int,
    query: str = "",
    limit: int = 200,
    source_build: CheatTableSourceBuild | None = None,
) -> CheatTableResult:
    """Download bounded public CT XML and statically import only inert metadata."""

    raw, final_url = _download_cheat_table(url, max_bytes=max_bytes)
    return inspect_cheat_table_bytes(
        raw,
        source=final_url,
        source_kind="url",
        backend=None,
        session=None,
        max_bytes=max_bytes,
        max_signature_scan_bytes=0,
        query=query,
        limit=limit,
        source_build=source_build,
    )


def inspect_cheat_table_bytes(
    raw: bytes,
    *,
    source: str,
    source_kind: str,
    backend: MemoryBackend | None,
    session: ProcessSession | None,
    max_bytes: int,
    max_signature_scan_bytes: int,
    query: str = "health",
    limit: int = 50,
    source_build: CheatTableSourceBuild | None = None,
) -> CheatTableResult:
    """Inspect bounded table XML as inert data and validate safe hints read-only."""

    if not 1 <= len(raw) <= max_bytes:
        raise SafetyError(f"Cheat Engine table size must be between 1 and {max_bytes} bytes")
    if not 1 <= limit <= 200:
        raise SafetyError("Cheat Engine table result limit must be between 1 and 200")
    upper = raw.upper()
    if b"<!DOCTYPE" in upper or b"<!ENTITY" in upper:
        raise SafetyError("DTD and entity declarations are not allowed in Cheat Engine tables")
    try:
        root = ET.fromstring(raw)
    except ET.ParseError as exc:
        raise SafetyError("the Cheat Engine table XML is invalid") from exc
    if _local_tag(root.tag).casefold() != "cheattable":
        raise SafetyError("the downloaded XML is not a Cheat Engine table")

    hints, scripts = _extract_entries(root, limit=10_000)
    structures = _extract_structures(root, limit=100)
    overlays = _extract_overlays(root, scripts, limit=100)
    declared_build = source_build or CheatTableSourceBuild()
    current_build = executable_build_fingerprint(session.executable) if session else None
    build_compatibility = _build_compatibility(declared_build, current_build)
    live_validation = bool(
        backend is not None and session is not None and build_compatibility == "exact"
    )
    normalized_query = query.strip().casefold()
    matching = [
        hint
        for hint in hints
        if not normalized_query or normalized_query in hint.description.casefold()
    ][:limit]
    script_limit = min(limit, 5) if live_validation else limit
    matching_scripts = [
        item
        for item in scripts
        if not normalized_query
        or normalized_query in item[0].casefold()
        or normalized_query in item[2].casefold()
    ][:script_limit]
    regions = backend.regions(session.backend_handle) if live_validation else []
    if live_validation:
        assert backend is not None and session is not None
        checks = [
            _check_hint(hint, backend=backend, session=session, regions=regions)
            for hint in matching
        ]
    else:
        checks = [
            _check_result(
                hint,
                status=(
                    "reference only; live validation skipped because source build is "
                    f"{build_compatibility}"
                ),
            )
            for hint in matching
        ]
    per_script_scan_bytes = max_signature_scan_bytes // max(1, len(matching_scripts))
    script_findings = [
        _analyze_script(
            description,
            tag,
            text,
            backend=backend,
            session=session,
            regions=regions,
            max_scan_bytes=per_script_scan_bytes,
            allow_live_scan=live_validation,
        )
        for description, tag, text in matching_scripts
    ]
    warnings = [
        "Imported Auto Assembler and Lua remain inert; only hashes and declarative locator "
        "patterns were retained."
    ]
    if build_compatibility != "exact":
        warnings.append(
            "No locator was read from the live process because the table source was not "
            "cryptographically bound to this exact game build."
        )
    locator_pattern_count = sum(
        bool(item.module_offset is not None) + bool(item.pointer_offsets) for item in matching
    ) + sum(len(item.signatures) + len(item.module_offsets) for item in script_findings)
    return CheatTableResult(
        source_sha256=hashlib.sha256(raw).hexdigest(),
        source_path=source,
        source_kind=source_kind,
        table_version=root.attrib.get("CheatEngineTableVersion"),
        hint_count=len(hints),
        ignored_script_count=len(scripts),
        locator_pattern_count=locator_pattern_count,
        build_compatibility=build_compatibility,
        source_build=declared_build,
        current_build=current_build,
        live_validation_performed=live_validation,
        hints=matching,
        checks=checks,
        script_findings=script_findings,
        structures=structures,
        overlays=overlays,
        warnings=warnings,
    )


def _extract_entries(
    root: ET.Element,
    *,
    limit: int,
) -> tuple[list[CheatTableHint], list[tuple[str, str, str]]]:
    hints: list[CheatTableHint] = []
    scripts: list[tuple[str, str, str]] = []
    seen_script_nodes: set[int] = set()
    parents = {child: parent for parent in root.iter() for child in parent}
    for entry in (node for node in root.iter() if _local_tag(node.tag) == "CheatEntry"):
        if len(hints) >= limit:
            raise SafetyError(f"Cheat Engine table exceeds the {limit}-entry safety limit")
        description = (_direct_text(entry, "Description") or "Unnamed table entry").strip('" ')
        address_expression = (_direct_text(entry, "Address") or "").strip() or None
        value_type = _VALUE_TYPES.get(
            (_direct_text(entry, "VariableType") or "").strip().casefold()
        )
        offsets: list[int] = []
        offsets_node = _direct_child(entry, "Offsets")
        if offsets_node is not None:
            for offset_node in offsets_node:
                if _local_tag(offset_node.tag) != "Offset":
                    continue
                parsed_offset = _parse_pointer_offset(offset_node.text)
                if parsed_offset is None:
                    offsets = []
                    break
                offsets.append(parsed_offset)
        module, module_offset = _parse_address_expression(address_expression)
        context, address_chain = _entry_context(entry, parents)
        own_scripts = _entry_script_nodes(entry)
        seen_script_nodes.update(id(node) for node in own_scripts)
        scripts.extend((description, _local_tag(node.tag), node.text or "") for node in own_scripts)
        hints.append(
            CheatTableHint(
                description=description,
                context=context,
                value_type=value_type,
                address_expression=address_expression,
                address_chain=address_chain,
                module=module,
                module_offset=module_offset,
                pointer_offsets=offsets,
                script_present=bool(own_scripts),
            )
        )
    for node in root.iter():
        tag = _local_tag(node.tag)
        if tag.casefold() not in _SCRIPT_TAGS or id(node) in seen_script_nodes:
            continue
        scripts.append((f"Table-level {tag}", tag, node.text or ""))
    return hints, scripts


def _extract_structures(root: ET.Element, *, limit: int) -> list[CheatTableStructure]:
    structures: list[CheatTableStructure] = []
    for node in root.iter():
        if _local_tag(node.tag).casefold() != "structure":
            continue
        fields: list[CheatTableStructureField] = []
        for element in node.iter():
            if _local_tag(element.tag).casefold() != "element":
                continue
            offset = _parse_nonnegative_int(element.attrib.get("Offset"))
            if offset is None:
                continue
            bytesize = _parse_nonnegative_int(element.attrib.get("Bytesize"))
            fields.append(
                CheatTableStructureField(
                    description=(
                        element.attrib.get("Description")
                        or element.attrib.get("Name")
                        or f"field_0x{offset:X}"
                    ),
                    offset=offset,
                    value_type=element.attrib.get("Vartype") or element.attrib.get("VariableType"),
                    bytesize=bytesize,
                )
            )
            if len(fields) >= 2_000:
                break
        name = node.attrib.get("Name") or node.attrib.get("Description") or "Unnamed structure"
        structures.append(
            CheatTableStructure(name=name, field_count=len(fields), fields=fields[:500])
        )
        if len(structures) >= limit:
            break
    return structures


def _extract_overlays(
    root: ET.Element,
    scripts: list[tuple[str, str, str]],
    *,
    limit: int,
) -> list[CheatTableOverlayFinding]:
    overlays: list[CheatTableOverlayFinding] = []
    tag_kinds = {
        "forms": "form-container",
        "form": "form",
        "hotkeys": "hotkey-container",
        "hotkey": "hotkey",
        "trainerorigin": "trainer-ui",
        "tablefiles": "embedded-file-container",
        "tablefile": "embedded-file",
    }
    for node in root.iter():
        tag = _local_tag(node.tag)
        kind = tag_kinds.get(tag.casefold())
        if kind is None:
            continue
        overlays.append(
            CheatTableOverlayFinding(
                kind=kind,
                name=node.attrib.get("Name") or node.attrib.get("Description") or tag,
                element_count=sum(1 for _ in node.iter()) - 1,
            )
        )
        if len(overlays) >= limit:
            return overlays
    for description, tag, text in scripts:
        ui_calls = _LUA_UI_API.findall(text)
        if not ui_calls:
            continue
        overlays.append(
            CheatTableOverlayFinding(
                kind="lua-ui-reference",
                name=f"{description} ({tag})",
                element_count=len(ui_calls),
            )
        )
        if len(overlays) >= limit:
            break
    return overlays


def _parse_nonnegative_int(value: str | None) -> int | None:
    if value is None:
        return None
    normalized = value.strip()
    try:
        base = (
            16
            if normalized.casefold().startswith("0x") or re.search(r"[A-Fa-f]", normalized)
            else 10
        )
        parsed = int(normalized, base)
    except ValueError:
        return None
    return parsed if parsed >= 0 else None


def _parse_pointer_offset(value: str | None) -> int | None:
    """Parse inert CE pointer-offset addition without evaluating arbitrary text."""

    if value is None:
        return None
    normalized = value.strip()
    if not re.fullmatch(r"(?:0x)?[0-9A-Fa-f]+(?:\s*\+\s*(?:0x)?[0-9A-Fa-f]+){0,7}", normalized):
        return None
    parsed = sum(int(term.strip(), 16) for term in normalized.split("+"))
    return parsed if parsed <= 0xFFFFFFFFFFFFFFFF else None


def _entry_context(
    entry: ET.Element,
    parents: dict[ET.Element, ET.Element],
) -> tuple[list[str], list[str]]:
    ancestors: list[ET.Element] = []
    current: ET.Element | None = entry
    while current is not None:
        if _local_tag(current.tag) == "CheatEntry":
            ancestors.append(current)
        current = parents.get(current)
    ancestors.reverse()
    context = [
        (_direct_text(item, "Description") or "Unnamed table entry").strip('" ')
        for item in ancestors[:-1]
    ]
    address_chain = [
        address for item in ancestors if (address := (_direct_text(item, "Address") or "").strip())
    ]
    return context, address_chain


def _entry_script_nodes(entry: ET.Element) -> list[ET.Element]:
    found: list[ET.Element] = []

    def visit(node: ET.Element) -> None:
        for child in node:
            tag = _local_tag(child.tag)
            if tag in {"CheatEntry", "CheatEntries"}:
                continue
            if tag.casefold() in _SCRIPT_TAGS:
                found.append(child)
            else:
                visit(child)

    visit(entry)
    return found


def _analyze_script(
    description: str,
    tag: str,
    script: str,
    *,
    backend: MemoryBackend | None,
    session: ProcessSession | None,
    regions: list[MemoryRegion],
    max_scan_bytes: int,
    allow_live_scan: bool,
) -> CheatTableScriptFinding:
    language = (
        "lua" if tag.casefold() == "luascript" or "{$lua}" in script.casefold() else "assembler"
    )
    words = {word.casefold() for word in re.findall(r"\b[A-Za-z][A-Za-z0-9_]*\b", script)}
    directives = sorted(words & _SCRIPT_DIRECTIVES)
    rejected = sorted(words & _MUTATING_DIRECTIVES)
    if language == "lua":
        rejected = sorted(set(rejected) | {"lua execution"})

    signatures: list[CheatTableSignature] = []
    module_offsets: list[CheatTableModuleOffset] = []
    plans: list[str] = []
    calls = list(_AOB_CALL.finditer(script))[:5]
    per_signature_scan_bytes = max_scan_bytes // max(1, len(calls))
    for call in calls:
        parsed = _parse_aob_call(call)
        if parsed is None:
            continue
        name, module, pattern = parsed
        matches: list[int] = []
        scope_truncated = False
        if allow_live_scan:
            assert backend is not None and session is not None
            matches, scope_truncated = _find_aob_matches(
                pattern,
                module=module,
                backend=backend,
                session=session,
                regions=regions,
                max_scan_bytes=per_signature_scan_bytes,
            )
        signatures.append(
            CheatTableSignature(
                name=name,
                module=module,
                pattern=pattern,
                matches=matches,
                scope_truncated=scope_truncated,
            )
        )
        target = module or "the main game module"
        if allow_live_scan:
            plans.append(f"Located signature {name} in {target} using read-only code-page reads")
        else:
            plans.append(
                f"After an exact build match, locate signature {name} in {target} using "
                "read-only code-page reads"
            )

    seen_offsets: set[tuple[str, int]] = set()
    for match in _SCRIPT_MODULE_OFFSET.finditer(script):
        module = match.group("quoted") or match.group("bare")
        offset = int(match.group("offset"), 16)
        key = (module.casefold(), offset)
        if key in seen_offsets:
            continue
        seen_offsets.add(key)
        module_offsets.append(
            CheatTableModuleOffset(
                module=module,
                offset=offset,
                expression=match.group("expression"),
            )
        )
        if len(module_offsets) >= 100:
            break

    if signatures:
        status = "original script ignored; translated to read-only signature checks"
    else:
        status = "original script ignored; no safe read-only address signature was available"
    return CheatTableScriptFinding(
        description=description,
        language=language,
        sha256=hashlib.sha256(script.encode("utf-8", errors="replace")).hexdigest(),
        directives=directives,
        rejected_directives=rejected,
        read_only_plan=plans,
        signatures=signatures,
        module_offsets=module_offsets,
        status=status,
    )


def _parse_aob_call(match: re.Match[str]) -> tuple[str, str | None, str] | None:
    args = [part.strip() for part in match.group("args").split(",")]
    is_module = bool(match.group("module"))
    if (is_module and len(args) != 3) or (not is_module and len(args) != 2):
        return None
    name = args[0]
    module = args[1].strip('"') if is_module else None
    pattern = args[2] if is_module else args[1]
    if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]{0,63}", name):
        return None
    tokens = pattern.split()
    if not 2 <= len(tokens) <= 512:
        return None
    if any(not re.fullmatch(r"(?:[0-9A-Fa-f]{2}|\?{1,2})", token) for token in tokens):
        return None
    return name, module, " ".join(tokens).upper()


def _find_aob_matches(
    pattern: str,
    *,
    module: str | None,
    backend: MemoryBackend,
    session: ProcessSession,
    regions: list[MemoryRegion],
    max_scan_bytes: int,
) -> tuple[list[int], bool]:
    tokens = pattern.split()
    expression = b"".join(
        b"." if token.startswith("?") else re.escape(bytes([int(token, 16)])) for token in tokens
    )
    compiled = re.compile(expression, re.DOTALL)
    eligible = [
        region
        for region in regions
        if region.committed
        and region.readable
        and region.executable
        and not region.guarded
        and region.kind == MemoryRegionKind.IMAGE
        and _signature_region_matches(region, module)
    ]
    eligible.sort(
        key=lambda item: (
            not bool(item.resident),
            not item.main_module,
            item.base_address,
        )
    )
    eligible_bytes = sum(region.size for region in eligible)
    remaining = max_scan_bytes
    matches: list[int] = []
    overlap = max(0, len(tokens) - 1)
    for region in eligible:
        if remaining <= 0 or len(matches) >= 10:
            break
        region_remaining = min(region.size, remaining)
        offset = 0
        tail = b""
        while offset < region_remaining and len(matches) < 10:
            size = min(1024 * 1024, region_remaining - offset)
            try:
                chunk = backend.read(session.backend_handle, region.base_address + offset, size)
            except BackendError:
                break
            data = tail + chunk
            data_base = region.base_address + offset - len(tail)
            for found in compiled.finditer(data):
                address = data_base + found.start()
                if address not in matches:
                    matches.append(address)
                if len(matches) >= 10:
                    break
            tail = data[-overlap:] if overlap else b""
            offset += size
            remaining -= size
    return matches, eligible_bytes > max_scan_bytes


def _signature_region_matches(region: MemoryRegion, module: str | None) -> bool:
    if module is None or module.casefold() in {"$process", "process"}:
        return region.main_module
    if not region.name:
        return False
    return os.path.basename(region.name).casefold() == os.path.basename(module).casefold()


def _parse_address_expression(expression: str | None) -> tuple[str | None, int | None]:
    if not expression:
        return None, None
    match = _MODULE_ADDRESS.fullmatch(expression.strip())
    if match:
        offset = int(match.group("offset"), 16)
        if match.group("sign") == "-":
            offset = -offset
        return match.group("module"), offset
    absolute = _ABSOLUTE_ADDRESS.fullmatch(expression.strip())
    if absolute:
        return None, int(absolute.group("address"), 16)
    return None, None


def _build_compatibility(
    source: CheatTableSourceBuild,
    current: GameBuildFingerprint | None,
) -> str:
    if current is None:
        return "unavailable"
    comparisons: list[bool] = []
    if source.executable_sha256:
        comparisons.append(source.executable_sha256.casefold() == current.sha256.casefold())
    if source.build_identity:
        comparisons.append(source.build_identity.casefold() == current.sample_identity.casefold())
    if source.store_build_id:
        comparisons.append(
            source.store_build_id.casefold() == (current.store_build_id or "").casefold()
        )
    if source.store_app_id:
        comparisons.append(
            source.store_app_id.casefold() == (current.store_app_id or "").casefold()
        )
    if source.process_names and not any(
        os.path.basename(name).casefold() == current.executable_name.casefold()
        for name in source.process_names
    ):
        return "mismatch"
    if not comparisons:
        return "unverified"
    return "exact" if all(comparisons) else "mismatch"


def _check_hint(
    hint: CheatTableHint,
    *,
    backend: MemoryBackend,
    session: ProcessSession,
    regions: list[MemoryRegion],
) -> CheatTableCheck:
    if hint.value_type is None:
        return _check_result(hint, status="unsupported value type")
    if hint.module_offset is None:
        return _check_result(hint, status="dynamic, relative, or unsupported address expression")
    if hint.module:
        module_base = _module_base(regions, hint.module)
        if module_base is None:
            return _check_result(hint, status=f"module not loaded: {hint.module}")
        base_address = module_base + hint.module_offset
    else:
        base_address = hint.module_offset

    candidates = [base_address]
    if hint.pointer_offsets:
        candidates = []
        for offsets in (hint.pointer_offsets, list(reversed(hint.pointer_offsets))):
            resolved = _resolve_pointer_chain(
                base_address,
                offsets,
                backend=backend,
                session=session,
                regions=regions,
            )
            if resolved is not None and resolved not in candidates:
                candidates.append(resolved)
    for address in candidates:
        region = _region_for(regions, address, value_size(hint.value_type))
        if region is None or not region.readable:
            continue
        try:
            value = decode_value(
                hint.value_type,
                backend.read(session.backend_handle, address, value_size(hint.value_type)),
            )
        except BackendError:
            continue
        status = "validated read-only hint"
        if not region.writable or region.executable:
            status = "readable hint outside writable data"
        return _check_result(hint, address=address, value=value, status=status)
    return _check_result(hint, status="address did not resolve to readable memory")


def _resolve_pointer_chain(
    address: int,
    offsets: list[int],
    *,
    backend: MemoryBackend,
    session: ProcessSession,
    regions: list[MemoryRegion],
) -> int | None:
    current = address
    for offset in offsets:
        region = _region_for(regions, current, 8)
        if region is None or not region.readable:
            return None
        try:
            pointer = decode_value(
                ValueType.U64,
                backend.read(session.backend_handle, current, 8),
            )
        except BackendError:
            return None
        if not pointer:
            return None
        current = int(pointer) + offset
    return current


def _module_base(regions: list[MemoryRegion], module: str) -> int | None:
    wanted = os.path.basename(module).casefold()
    bases = [
        region.allocation_base
        for region in regions
        if region.name
        and os.path.basename(region.name).casefold() == wanted
        and region.allocation_base is not None
    ]
    return min(bases) if bases else None


def _region_for(regions: list[MemoryRegion], address: int, size: int) -> MemoryRegion | None:
    return next((region for region in regions if region.contains(address, size)), None)


def _check_result(
    hint: CheatTableHint,
    *,
    status: str,
    address: int | None = None,
    value: int | float | None = None,
) -> CheatTableCheck:
    return CheatTableCheck(
        description=hint.description,
        value_type=hint.value_type,
        address=address,
        value=value,
        status=status,
        script_ignored=hint.script_present,
    )


def _download_cheat_table(url: str, *, max_bytes: int) -> tuple[bytes, str]:
    _validate_public_https_url(url)
    opener = build_opener(_SafeRedirectHandler())
    request = Request(
        url,
        headers={
            "Accept": "application/xml,text/xml,text/plain,application/octet-stream",
            "Accept-Encoding": "identity",
            "User-Agent": "GTP-Games-ReadOnly-Table-Inspector/0.3",
        },
    )
    try:
        with opener.open(request, timeout=15) as response:
            final_url = response.geturl()
            _validate_public_https_url(final_url)
            content_type = response.headers.get_content_type().casefold()
            if content_type not in _TABLE_CONTENT_TYPES:
                raise SafetyError(f"remote table content type is not accepted: {content_type}")
            declared = response.headers.get("Content-Length")
            if declared and int(declared) > max_bytes:
                raise SafetyError("remote Cheat Engine table exceeds the download size limit")
            raw = response.read(max_bytes + 1)
    except SafetyError:
        raise
    except (HTTPError, URLError, OSError, ValueError) as exc:
        raise SafetyError("the remote Cheat Engine table could not be downloaded") from exc
    if len(raw) > max_bytes:
        raise SafetyError("remote Cheat Engine table exceeds the download size limit")
    return raw, final_url


class _SafeRedirectHandler(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        destination = urljoin(req.full_url, newurl)
        _validate_public_https_url(destination)
        return super().redirect_request(req, fp, code, msg, headers, destination)


def _validate_public_https_url(url: str) -> None:
    parsed = urlsplit(url)
    if parsed.scheme.casefold() != "https" or not parsed.hostname:
        raise SafetyError("remote tables must use a public HTTPS URL")
    if parsed.username or parsed.password or parsed.port not in {None, 443}:
        raise SafetyError("remote table URLs cannot contain credentials or non-HTTPS ports")
    try:
        addresses = {
            item[4][0] for item in socket.getaddrinfo(parsed.hostname, 443, type=socket.SOCK_STREAM)
        }
    except OSError as exc:
        raise SafetyError("the remote table host could not be resolved") from exc
    if not addresses:
        raise SafetyError("the remote table host did not resolve")
    for address in addresses:
        ip = ipaddress.ip_address(address)
        if not ip.is_global:
            raise SafetyError("remote table URLs cannot target local or private network addresses")


def _direct_child(entry: ET.Element, name: str) -> ET.Element | None:
    return next((child for child in entry if _local_tag(child.tag) == name), None)


def _direct_text(entry: ET.Element, name: str) -> str | None:
    child = _direct_child(entry, name)
    return None if child is None else child.text


def _local_tag(tag: str) -> str:
    return tag.rsplit("}", 1)[-1]
