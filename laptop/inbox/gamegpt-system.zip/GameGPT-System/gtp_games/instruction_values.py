from __future__ import annotations

from dataclasses import dataclass, field
from datetime import UTC, datetime, timedelta
from threading import Event, RLock, Thread
from time import monotonic
from uuid import uuid4

from pydantic import BaseModel, Field

from gtp_games.codec import decode_value, value_size
from gtp_games.errors import BackendError, NotFoundError, SafetyError
from gtp_games.game_identity import executable_build_identity
from gtp_games.inventory_observer import (
    InstructionHit,
    InstructionObservationBackend,
    InstructionObservationCancelled,
    InstructionObservationTimeout,
)
from gtp_games.locators import LocatorEngine
from gtp_games.memory.base import MemoryBackend
from gtp_games.models import ProcessSession, ValueType

_REGISTERS = {
    "rax", "rcx", "rdx", "rbx", "rsp", "rbp", "rsi", "rdi",
    "r8", "r9", "r10", "r11", "r12", "r13", "r14", "r15",
}


class InstructionValueField(BaseModel):
    name: str = Field(min_length=1, max_length=100)
    offset: int = Field(ge=-0x100000, le=0x100000)
    value_type: ValueType
    expected_min: float | None = None
    expected_max: float | None = None


class InstructionValueRecipe(BaseModel):
    """A data-only translation of a source-level instruction/structure hint."""

    name: str = Field(min_length=1, max_length=120)
    process_name: str = Field(min_length=1, max_length=260)
    module: str = Field(min_length=1, max_length=260)
    build_identity: str = Field(min_length=1, max_length=200)
    aob_pattern: str = Field(min_length=2, max_length=2000)
    instruction_offset: int = Field(default=0, ge=-0x1000, le=0x1000)
    base_register: str = Field(min_length=2, max_length=4)
    pointer_offsets: list[int] = Field(default_factory=list, max_length=8)
    fields: list[InstructionValueField] = Field(min_length=1, max_length=32)
    source_label: str = Field(default="translated reference", max_length=300)
    source_sha256: str | None = Field(default=None, min_length=64, max_length=64)

    def checked_register(self) -> str:
        register = self.base_register.strip().casefold()
        if register not in _REGISTERS:
            raise SafetyError(f"unsupported x64 base register: {self.base_register}")
        return register


@dataclass(frozen=True)
class PreparedInstructionValueObservation:
    session: ProcessSession
    recipe: InstructionValueRecipe
    build_identity: str
    signature_address: int
    instruction_address: int


class ObservedInstructionValue(BaseModel):
    name: str
    address: int = Field(ge=0)
    address_hex: str
    offset: int
    value_type: ValueType
    value: int | float
    within_expected_range: bool | None = None


class InstructionValueObservation(BaseModel):
    status: str
    session_id: str
    pid: int
    process_name: str
    build_identity: str
    recipe_name: str
    source_label: str
    source_sha256: str | None = None
    signature_address: int = Field(ge=0)
    instruction_address: int = Field(ge=0)
    signature_match_count: int = Field(default=1, ge=0)
    signature_scope_complete: bool = True
    thread_id: int | None = Field(default=None, ge=1)
    base_register: str
    register_value: int | None = Field(default=None, ge=0)
    base_address: int | None = Field(default=None, ge=0)
    fields: list[ObservedInstructionValue] = Field(default_factory=list)
    timed_out: bool = False
    read_only: bool = True
    game_memory_write_performed: bool = False
    target_code_patched: bool = False
    debugger_detached: bool = True
    address_valid_for_current_process_only: bool = True
    message: str


class InstructionValueObserverStatus(BaseModel):
    token: str
    session_id: str
    pid: int
    process_name: str
    build_identity: str
    recipe_name: str
    instruction_address: int = Field(ge=0)
    state: str
    armed: bool = False
    armed_at: datetime | None = None
    deadline: datetime | None = None
    finished_at: datetime | None = None
    result: InstructionValueObservation | None = None
    error: str | None = None
    read_only: bool = True
    game_memory_write_performed: bool = False
    target_code_patched: bool = False
    message: str


class InstructionValueEngine:
    def __init__(
        self,
        memory: MemoryBackend,
        locators: LocatorEngine,
        observer: InstructionObservationBackend,
        *,
        build_identity_resolver=executable_build_identity,
    ) -> None:
        self.memory = memory
        self.locators = locators
        self.observer = observer
        self.build_identity_resolver = build_identity_resolver

    def prepare(
        self,
        session: ProcessSession,
        recipe: InstructionValueRecipe,
    ) -> PreparedInstructionValueObservation:
        if session.process_name.casefold() != recipe.process_name.casefold():
            raise SafetyError("the observation recipe belongs to a different process")
        recipe.checked_register()
        if len({item.name.casefold() for item in recipe.fields}) != len(recipe.fields):
            raise SafetyError("instruction value field names must be unique")
        for item in recipe.fields:
            if (
                item.expected_min is not None
                and item.expected_max is not None
                and item.expected_min > item.expected_max
            ):
                raise SafetyError(f"invalid expected range for {item.name}")
        for offset in recipe.pointer_offsets:
            if not -0x100000 <= offset <= 0x100000:
                raise SafetyError("pointer offsets must be within plus or minus 1 MiB")
        build_identity = self.build_identity_resolver(session.executable)
        if not build_identity:
            raise SafetyError("the selected game's exact executable build could not be read")
        if build_identity != recipe.build_identity:
            raise SafetyError("the instruction recipe has not been validated for this exact build")
        matches, scope_truncated = self.locators.find_aob(
            session,
            recipe.aob_pattern,
            module=recipe.module,
        )
        if scope_truncated:
            raise SafetyError(
                "the instruction signature scan was incomplete; uniqueness is unknown"
            )
        if len(matches) != 1:
            raise SafetyError(
                f"the instruction signature must match exactly once, found {len(matches)}"
            )
        return PreparedInstructionValueObservation(
            session=session,
            recipe=recipe,
            build_identity=build_identity,
            signature_address=matches[0],
            instruction_address=matches[0] + recipe.instruction_offset,
        )

    def observe_prepared(
        self,
        prepared: PreparedInstructionValueObservation,
        *,
        timeout_seconds: float = 20,
        on_armed=None,
        cancel_event: Event | None = None,
    ) -> InstructionValueObservation:
        if not 1 <= timeout_seconds <= 30:
            raise ValueError("timeout_seconds must be between 1 and 30")
        try:
            hit = self.observer.observe_execute(
                prepared.session.pid,
                prepared.instruction_address,
                timeout_seconds=timeout_seconds,
                on_armed=on_armed,
                cancel_event=cancel_event,
            )
        except InstructionObservationTimeout:
            return self.timeout_result(prepared)
        return self.decode_hit(prepared, hit)

    def timeout_result(
        self,
        prepared: PreparedInstructionValueObservation,
    ) -> InstructionValueObservation:
        recipe = prepared.recipe
        session = prepared.session
        return InstructionValueObservation(
            status="timeout",
            session_id=session.id,
            pid=session.pid,
            process_name=session.process_name,
            build_identity=prepared.build_identity,
            recipe_name=recipe.name,
            source_label=recipe.source_label,
            source_sha256=recipe.source_sha256,
            signature_address=prepared.signature_address,
            instruction_address=prepared.instruction_address,
            base_register=recipe.checked_register(),
            timed_out=True,
            message="The instruction did not execute during this bounded learning window.",
        )

    def decode_hit(
        self,
        prepared: PreparedInstructionValueObservation,
        hit: InstructionHit,
    ) -> InstructionValueObservation:
        if not hit.cleanup_verified:
            raise BackendError("the instruction observer could not prove debugger cleanup")
        if hit.instruction_pointer != prepared.instruction_address:
            raise BackendError("the debugger reported a different instruction than the anchor")
        recipe = prepared.recipe
        register = recipe.checked_register()
        register_value = hit.register(register)
        base_address = self._follow_pointers(
            prepared.session,
            register_value,
            recipe.pointer_offsets,
        )
        observed: list[ObservedInstructionValue] = []
        for field_spec in recipe.fields:
            address = base_address + field_spec.offset
            data = self._read_checked(
                prepared.session,
                address,
                value_size(field_spec.value_type),
            )
            value = decode_value(field_spec.value_type, data)
            within: bool | None = None
            if field_spec.expected_min is not None or field_spec.expected_max is not None:
                within = (
                    (field_spec.expected_min is None or value >= field_spec.expected_min)
                    and (field_spec.expected_max is None or value <= field_spec.expected_max)
                )
            observed.append(
                ObservedInstructionValue(
                    name=field_spec.name,
                    address=address,
                    address_hex=f"0x{address:X}",
                    offset=field_spec.offset,
                    value_type=field_spec.value_type,
                    value=value,
                    within_expected_range=within,
                )
            )
        return InstructionValueObservation(
            status="observed",
            session_id=prepared.session.id,
            pid=prepared.session.pid,
            process_name=prepared.session.process_name,
            build_identity=prepared.build_identity,
            recipe_name=recipe.name,
            source_label=recipe.source_label,
            source_sha256=recipe.source_sha256,
            signature_address=prepared.signature_address,
            instruction_address=prepared.instruction_address,
            thread_id=hit.thread_id,
            base_register=register,
            register_value=register_value,
            base_address=base_address,
            fields=observed,
            message=(
                "Captured the translated structure without patching code or writing game "
                "memory. Returned addresses are valid only for this process launch."
            ),
        )

    def _follow_pointers(
        self,
        session: ProcessSession,
        base_address: int,
        offsets: list[int],
    ) -> int:
        if base_address <= 0:
            raise SafetyError("the selected register did not contain a usable address")
        current = base_address
        for offset in offsets:
            pointer_bytes = self._read_checked(session, current + offset, 8)
            current = int.from_bytes(pointer_bytes, "little", signed=False)
            if current <= 0:
                raise SafetyError("the translated pointer chain resolved to null")
        return current

    def _read_checked(self, session: ProcessSession, address: int, size: int) -> bytes:
        region = next(
            (
                item
                for item in self.memory.regions(session.backend_handle)
                if item.contains(address, size)
            ),
            None,
        )
        if region is None or not region.readable or region.guarded:
            raise SafetyError("a translated structure field is not readable in this session")
        return self.memory.read(session.backend_handle, address, size)


@dataclass
class _InstructionValueJob:
    token: str
    prepared: PreparedInstructionValueObservation
    timeout_seconds: float
    state: str = "arming"
    armed_at: datetime | None = None
    deadline: datetime | None = None
    finished_at: datetime | None = None
    result: InstructionValueObservation | None = None
    error: str | None = None
    thread: Thread | None = None
    armed_event: Event = field(default_factory=Event)
    completed_event: Event = field(default_factory=Event)
    cancel_event: Event = field(default_factory=Event)


class InstructionValueObserverManager:
    _ARM_TIMEOUT_SECONDS = 15.0
    _CLEANUP_TIMEOUT_SECONDS = 5.0

    def __init__(self, engine: InstructionValueEngine) -> None:
        self.engine = engine
        self._jobs: dict[str, _InstructionValueJob] = {}
        self._active_by_session: dict[str, str] = {}
        self._lock = RLock()

    def start(
        self,
        session: ProcessSession,
        recipe: InstructionValueRecipe,
        *,
        timeout_seconds: float = 20,
    ) -> InstructionValueObserverStatus:
        if not 1 <= timeout_seconds <= 30:
            raise ValueError("timeout_seconds must be between 1 and 30")
        with self._lock:
            active_token = self._active_by_session.get(session.id)
            if active_token and not self._jobs[active_token].completed_event.is_set():
                raise SafetyError(
                    "an instruction value observer is already active for this session"
                )
        prepared = self.engine.prepare(session, recipe)
        job = _InstructionValueJob(
            token=uuid4().hex,
            prepared=prepared,
            timeout_seconds=timeout_seconds,
        )
        with self._lock:
            self._jobs[job.token] = job
            self._active_by_session[session.id] = job.token
            self._prune_completed()
        job.thread = Thread(
            target=self._run,
            args=(job,),
            name=f"gtp-instruction-value-{job.token[:8]}",
            daemon=True,
        )
        job.thread.start()
        arm_deadline = monotonic() + self._ARM_TIMEOUT_SECONDS
        while monotonic() < arm_deadline:
            if job.armed_event.wait(timeout=0.05):
                return self._status(job)
            if job.completed_event.is_set():
                raise BackendError(job.error or "instruction observer stopped before arming")
        job.cancel_event.set()
        job.completed_event.wait(timeout=self._CLEANUP_TIMEOUT_SECONDS)
        if not job.completed_event.is_set():
            raise BackendError("instruction observer arm timeout cleanup did not finish")
        raise BackendError(job.error or "instruction observer did not arm before its deadline")

    def status(
        self,
        session_id: str,
        token: str,
        *,
        wait_seconds: float = 0,
    ) -> InstructionValueObserverStatus:
        if not 0 <= wait_seconds <= 30:
            raise ValueError("wait_seconds must be between 0 and 30")
        job = self._job(session_id, token)
        if wait_seconds:
            job.completed_event.wait(timeout=wait_seconds)
        return self._status(job)

    def cancel(self, session_id: str, token: str) -> InstructionValueObserverStatus:
        job = self._job(session_id, token)
        if not job.completed_event.is_set():
            with self._lock:
                if job.state in {"arming", "armed"}:
                    job.state = "cancelling"
            job.cancel_event.set()
            job.completed_event.wait(timeout=self._CLEANUP_TIMEOUT_SECONDS)
        return self._status(job)

    def cancel_session(self, session_id: str) -> None:
        with self._lock:
            jobs = [
                job for job in self._jobs.values()
                if job.prepared.session.id == session_id and not job.completed_event.is_set()
            ]
        for job in jobs:
            job.cancel_event.set()
        for job in jobs:
            job.completed_event.wait(timeout=self._CLEANUP_TIMEOUT_SECONDS)

    def close(self) -> None:
        with self._lock:
            session_ids = list(self._active_by_session)
        for session_id in session_ids:
            self.cancel_session(session_id)

    def _run(self, job: _InstructionValueJob) -> None:
        def mark_armed() -> None:
            now = datetime.now(UTC)
            with self._lock:
                job.armed_at = now
                job.deadline = now + timedelta(seconds=job.timeout_seconds)
                job.state = "armed"
                job.armed_event.set()

        try:
            result = self.engine.observe_prepared(
                job.prepared,
                timeout_seconds=job.timeout_seconds,
                on_armed=mark_armed,
                cancel_event=job.cancel_event,
            )
        except InstructionObservationCancelled:
            with self._lock:
                job.state = "cancelled"
                job.finished_at = datetime.now(UTC)
        except Exception as exc:  # noqa: BLE001 - expose bounded background failure
            with self._lock:
                job.state = "failed"
                job.error = str(exc)[:500]
                job.finished_at = datetime.now(UTC)
        else:
            with self._lock:
                job.result = result
                job.state = result.status
                job.finished_at = datetime.now(UTC)
        finally:
            with self._lock:
                if self._active_by_session.get(job.prepared.session.id) == job.token:
                    self._active_by_session.pop(job.prepared.session.id, None)
                job.completed_event.set()

    def _job(self, session_id: str, token: str) -> _InstructionValueJob:
        with self._lock:
            job = self._jobs.get(token)
        if job is None:
            raise NotFoundError("instruction value observer token was not found")
        if job.prepared.session.id != session_id:
            raise SafetyError("instruction observer token belongs to a different game session")
        return job

    def _status(self, job: _InstructionValueJob) -> InstructionValueObserverStatus:
        with self._lock:
            state = job.state
            result = job.result.model_copy(deep=True) if job.result else None
            error = job.error
            armed_at = job.armed_at
            deadline = job.deadline
            finished_at = job.finished_at
        messages = {
            "arming": "Preparing the read-only hardware observer.",
            "armed": "Observer armed; waiting for the target instruction to execute.",
            "cancelling": "Observer cancellation requested; cleanup is running.",
            "cancelled": "Observer cancelled and detached.",
            "timeout": "Observation window expired and detached without an instruction hit.",
            "observed": "The instruction executed and its translated fields were read.",
            "failed": "Observer failed closed and detached.",
        }
        prepared = job.prepared
        return InstructionValueObserverStatus(
            token=job.token,
            session_id=prepared.session.id,
            pid=prepared.session.pid,
            process_name=prepared.session.process_name,
            build_identity=prepared.build_identity,
            recipe_name=prepared.recipe.name,
            instruction_address=prepared.instruction_address,
            state=state,
            armed=armed_at is not None,
            armed_at=armed_at,
            deadline=deadline,
            finished_at=finished_at,
            result=result,
            error=error,
            message=messages.get(state, "Observer status available."),
        )

    def _prune_completed(self) -> None:
        completed = sorted(
            (job for job in self._jobs.values() if job.completed_event.is_set()),
            key=lambda job: job.finished_at or datetime.min.replace(tzinfo=UTC),
        )
        for job in completed[:-100]:
            self._jobs.pop(job.token, None)
