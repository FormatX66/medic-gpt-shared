from __future__ import annotations

import bisect
import os
import struct
from dataclasses import dataclass

from gtp_games.cheat_tables import _find_aob_matches
from gtp_games.errors import BackendError, NotFoundError, ScanLimitError
from gtp_games.memory.base import MemoryBackend
from gtp_games.models import (
    LocatorKind,
    MemoryLocator,
    MemoryRegion,
    MemoryRegionKind,
    ProcessSession,
)
from gtp_games.scanner import select_scan_regions


@dataclass(frozen=True)
class _PointerHit:
    slot_address: int
    pointed_value: int
    target_address: int


class LocatorEngine:
    """Resolve and discover restart-friendly read-only memory locators."""

    def __init__(
        self,
        backend: MemoryBackend,
        *,
        max_scan_bytes: int,
        max_region_bytes: int,
        chunk_bytes: int,
        max_aob_scan_bytes: int | None = None,
    ) -> None:
        self.backend = backend
        self.max_scan_bytes = max_scan_bytes
        self.max_region_bytes = max_region_bytes
        self.chunk_bytes = max(4096, chunk_bytes)
        self.max_aob_scan_bytes = max_aob_scan_bytes or max_scan_bytes

    def resolve(self, session: ProcessSession, locator: MemoryLocator) -> int:
        regions = self.backend.regions(session.backend_handle)
        if locator.kind is LocatorKind.RAW_ADDRESS:
            if locator.address is None:
                raise NotFoundError("raw locator has no address")
            return locator.address
        if locator.kind in {LocatorKind.AOB, LocatorKind.AOB_POINTER}:
            if not locator.aob_pattern:
                raise NotFoundError("AoB locator has no signature")
            matches, _ = _find_aob_matches(
                locator.aob_pattern,
                module=locator.module,
                backend=self.backend,
                session=session,
                regions=regions,
                max_scan_bytes=self.max_aob_scan_bytes,
            )
            if locator.match_count == 1 and len(matches) != 1:
                raise NotFoundError("AoB locator is no longer unique")
            if not matches:
                raise NotFoundError("AoB locator did not match this launch")
            if locator.kind is LocatorKind.AOB:
                return matches[0] + locator.aob_offset
            return self._resolve_aob_pointer(session, matches[0], locator)
        module_base = self._module_base(regions, locator.module)
        if module_base is None or locator.module_offset is None:
            raise NotFoundError("locator module is not loaded")
        address = module_base + locator.module_offset
        if locator.kind is LocatorKind.MODULE_OFFSET:
            return address
        if locator.kind is not LocatorKind.POINTER_CHAIN:
            raise NotFoundError("unsupported locator kind")
        for offset in locator.pointer_offsets:
            try:
                pointer = struct.unpack(
                    "<Q",
                    self.backend.read(session.backend_handle, address, 8),
                )[0]
            except (BackendError, struct.error) as exc:
                raise NotFoundError("pointer chain could not be resolved") from exc
            if pointer == 0:
                raise NotFoundError("pointer chain resolved through null")
            address = pointer + offset
        return address

    def _resolve_aob_pointer(
        self,
        session: ProcessSession,
        match_address: int,
        locator: MemoryLocator,
    ) -> int:
        displacement_offset = locator.aob_displacement_offset
        instruction_size = locator.aob_instruction_size
        if displacement_offset is None or instruction_size is None:
            raise NotFoundError("AoB pointer locator has no displacement decoder")
        if not locator.pointer_offsets:
            raise NotFoundError("AoB pointer locator has no pointer offsets")
        instruction_address = match_address + locator.aob_offset
        if displacement_offset + 4 > instruction_size:
            raise NotFoundError("AoB pointer displacement falls outside the instruction")
        try:
            displacement = struct.unpack(
                "<i",
                self.backend.read(
                    session.backend_handle,
                    instruction_address + displacement_offset,
                    4,
                ),
            )[0]
        except (BackendError, struct.error) as exc:
            raise NotFoundError("AoB pointer displacement could not be read") from exc
        address = instruction_address + instruction_size + displacement
        for offset in locator.pointer_offsets:
            try:
                pointer = struct.unpack(
                    "<Q",
                    self.backend.read(session.backend_handle, address, 8),
                )[0]
            except (BackendError, struct.error) as exc:
                raise NotFoundError("AoB pointer chain could not be resolved") from exc
            if pointer == 0:
                raise NotFoundError("AoB pointer chain resolved through null")
            address = pointer + offset
        return address

    def find_aob(
        self,
        session: ProcessSession,
        pattern: str,
        *,
        module: str | None = None,
    ) -> tuple[list[int], bool]:
        return _find_aob_matches(
            pattern,
            module=module,
            backend=self.backend,
            session=session,
            regions=self.backend.regions(session.backend_handle),
            max_scan_bytes=self.max_aob_scan_bytes,
        )

    def find_pointer_chains(
        self,
        session: ProcessSession,
        target_address: int,
        *,
        max_depth: int = 3,
        max_offset: int = 0x2000,
        max_results: int = 5,
    ) -> list[MemoryLocator]:
        if not 1 <= max_depth <= 8:
            raise ScanLimitError("pointer depth must be between 1 and 8")
        if not 0 <= max_offset <= 0x100000:
            raise ScanLimitError("pointer offset must be between 0 and 0x100000")
        if not 1 <= max_results <= 100:
            raise ScanLimitError("pointer result limit must be between 1 and 100")

        regions = self.backend.regions(session.backend_handle)
        module_regions = [region for region in regions if region.main_module]
        module_base = min(
            (region.base_address for region in module_regions),
            default=None,
        )
        module_name = self._module_name(module_regions, session)
        if module_base is not None:
            containing = next(
                (region for region in module_regions if region.contains(target_address)),
                None,
            )
            if containing is not None:
                return [
                    MemoryLocator(
                        kind=LocatorKind.MODULE_OFFSET,
                        module=module_name,
                        module_offset=target_address - module_base,
                    )
                ]

        scan_regions = self._pointer_regions(regions)
        frontier: dict[int, list[int]] = {target_address: []}
        seen_nodes = {target_address}
        results: list[MemoryLocator] = []
        for _depth in range(1, max_depth + 1):
            hits = self._find_pointer_slots(
                session,
                scan_regions,
                sorted(frontier),
                max_offset=max_offset,
            )
            next_frontier: dict[int, list[int]] = {}
            for hit in hits:
                suffix = frontier[hit.target_address]
                offsets = [hit.target_address - hit.pointed_value, *suffix]
                root_region = next(
                    (region for region in module_regions if region.contains(hit.slot_address, 8)),
                    None,
                )
                if module_base is not None and root_region is not None:
                    results.append(
                        MemoryLocator(
                            kind=LocatorKind.POINTER_CHAIN,
                            module=module_name,
                            module_offset=hit.slot_address - module_base,
                            pointer_offsets=offsets,
                        )
                    )
                    if len(results) >= max_results:
                        return results
                elif hit.slot_address not in seen_nodes:
                    seen_nodes.add(hit.slot_address)
                    next_frontier[hit.slot_address] = offsets
            if not next_frontier:
                break
            frontier = next_frontier
        return results

    def _pointer_regions(self, regions: list[MemoryRegion]) -> list[MemoryRegion]:
        candidates = [
            region
            for region in regions
            if region.committed
            and region.readable
            and region.writable
            and not region.executable
            and not region.guarded
            and region.kind in {MemoryRegionKind.PRIVATE, MemoryRegionKind.IMAGE}
        ]
        return select_scan_regions(
            candidates,
            max_bytes=self.max_scan_bytes,
            max_region_bytes=self.max_region_bytes,
            width=8,
        ).regions

    def _find_pointer_slots(
        self,
        session: ProcessSession,
        regions: list[MemoryRegion],
        targets: list[int],
        *,
        max_offset: int,
    ) -> list[_PointerHit]:
        hits: list[_PointerHit] = []
        for region in regions:
            offset = 0
            while offset + 8 <= region.size:
                size = min(self.chunk_bytes, region.size - offset)
                size -= size % 8
                if size < 8:
                    break
                address = region.base_address + offset
                try:
                    data = self.backend.read(session.backend_handle, address, size)
                except BackendError:
                    break
                for index, (pointer,) in enumerate(struct.iter_unpack("<Q", data)):
                    if pointer == 0:
                        continue
                    target_index = bisect.bisect_left(targets, pointer)
                    while target_index < len(targets):
                        target = targets[target_index]
                        if target - pointer > max_offset:
                            break
                        hits.append(
                            _PointerHit(
                                slot_address=address + index * 8,
                                pointed_value=pointer,
                                target_address=target,
                            )
                        )
                        target_index += 1
                offset += size
        return hits

    @staticmethod
    def _module_base(
        regions: list[MemoryRegion],
        module: str | None,
    ) -> int | None:
        matches = [
            region.base_address
            for region in regions
            if region.main_module
            and (
                module is None
                or not region.name
                or os.path.basename(region.name).casefold() == os.path.basename(module).casefold()
            )
        ]
        return min(matches, default=None)

    @staticmethod
    def _module_name(
        module_regions: list[MemoryRegion],
        session: ProcessSession,
    ) -> str:
        named = next((region.name for region in module_regions if region.name), None)
        return os.path.basename(named or session.executable or session.process_name)
