from __future__ import annotations

from contextlib import asynccontextmanager
from typing import Annotated

from fastapi import Depends, FastAPI, Query, Request
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field

from gtp_games import __version__
from gtp_games.assistant import AssistantCoordinator
from gtp_games.assistant.models import AssistantReply
from gtp_games.config import Settings
from gtp_games.control import (
    CANONICAL_ROLE,
    CONTROL_API,
    CONTROL_PROTOCOL_VERSIONS,
    ControlNegotiation,
    negotiate_control,
)
from gtp_games.errors import GTPError, NotFoundError, SafetyError
from gtp_games.models import (
    CheatDiscoveryRunStatus,
    CheatTableResult,
    CheatTableSourceBuild,
    Comparison,
    GameCheatCatalog,
    GameProfileMonitorStatus,
    GameValueTable,
    HealthBarResult,
    InventoryScreenResult,
    MemoryRegion,
    ProcessInfo,
    ProcessSession,
    ScanSummary,
    UnrealDiscoveryResult,
    UnrealGasMonitorStatus,
    UnrealGasProfile,
    UnrealGasProfileValue,
    UnrealGasScanSummary,
    UnrealGasTemporalResult,
    UnrealGasWatchResult,
    ValueType,
    WatchResult,
)
from gtp_games.service import ApplicationService


class AttachRequest(BaseModel):
    pid: int = Field(gt=0)
    write_enabled: bool = False
    game_key: str | None = Field(default=None, max_length=160)
    game_name: str | None = Field(default=None, max_length=240)
    table_path: str | None = Field(default=None, max_length=4096)


class ReadValueRequest(BaseModel):
    address: int = Field(ge=0)
    value_type: ValueType = ValueType.I32


class ReadValueResponse(BaseModel):
    address: int
    value_type: ValueType
    value: int | float


class StartScanRequest(BaseModel):
    value_type: ValueType = ValueType.I32
    value: int | float


class StartUnknownScanRequest(BaseModel):
    value_type: ValueType = ValueType.I32
    normalized: bool = False


class RescanRequest(BaseModel):
    comparison: Comparison
    value: int | float | None = None


class WatchScanRequest(BaseModel):
    sample_count: int = Field(default=5, ge=1, le=30)
    interval_ms: int = Field(default=500, ge=100, le=5000)
    limit: int = Field(default=20, ge=1, le=50)


class AutonomousDiscoveryRequest(BaseModel):
    target_order: list[str] | None = Field(default=None, max_length=20)
    interval_seconds: float = Field(default=2.0, ge=0.25, le=60)
    observation_seconds: float = Field(default=10.0, ge=1, le=600)
    revisit_seconds: float = Field(default=30.0, ge=1, le=3600)


class AutonomousDiscoveryValueRequest(BaseModel):
    target_name: str = Field(min_length=1, max_length=100)
    value: int | float


class AutonomousDiscoveryBehaviorRequest(BaseModel):
    target_name: str = Field(min_length=1, max_length=100)
    phase: str = Field(min_length=1, max_length=20)
    label: str = Field(default="", max_length=120)


class HealthBarRequest(BaseModel):
    x: int | None = Field(default=None, ge=0)
    y: int | None = Field(default=None, ge=0)
    width: int | None = Field(default=None, gt=0)
    height: int | None = Field(default=None, gt=0)
    limit: int = Field(default=5, ge=1, le=20)


class CheatTableRequest(BaseModel):
    source: str = Field(min_length=1, max_length=4096)
    query: str = Field(default="health", max_length=200)
    limit: int = Field(default=50, ge=1, le=200)
    source_author: str | None = Field(default=None, max_length=200)
    source_release: str | None = Field(default=None, max_length=200)
    source_updated_at: str | None = Field(default=None, max_length=100)
    source_process_names: list[str] = Field(default_factory=list, max_length=20)
    source_executable_sha256: str | None = Field(default=None, max_length=64)
    source_build_identity: str | None = Field(default=None, max_length=200)
    source_store_app_id: str | None = Field(default=None, max_length=100)
    source_store_build_id: str | None = Field(default=None, max_length=100)

    def source_build(self) -> CheatTableSourceBuild:
        return CheatTableSourceBuild(
            author=self.source_author,
            release_label=self.source_release,
            updated_at=self.source_updated_at,
            process_names=self.source_process_names,
            executable_sha256=self.source_executable_sha256,
            build_identity=self.source_build_identity,
            store_app_id=self.source_store_app_id,
            store_build_id=self.source_store_build_id,
        )


class GameCheatSourcesRequest(BaseModel):
    sources: list[str] = Field(min_length=1, max_length=10)
    query: str = Field(default="health stamina mana money gold", max_length=200)


class UnrealGasStartRequest(BaseModel):
    value_types: list[ValueType] | None = None


class UnrealGasRefineRequest(BaseModel):
    comparison: Comparison
    value: int | float | None = None


class UnrealTableGuidedRequest(BaseModel):
    pawn_pointer_offset: int = Field(default=0xD30, ge=0x28, le=0x10000)
    pointer_radius: int = Field(default=0x100, ge=0, le=0x1000)
    health_offset: int = Field(default=0x1A4, ge=0, le=0x10000)
    max_health_offset: int = Field(default=0xE18, ge=0, le=0x10000)
    nested_state_offset: int = Field(default=0x150, ge=0, le=0x10000)
    replica_percent_offset: int = Field(default=0x12C, ge=0, le=0x10000)


class UnrealGasTemporalRequest(BaseModel):
    sample_count: int = Field(default=30, ge=5, le=60)
    interval_ms: int = Field(default=500, ge=100, le=2000)
    group_limit: int = Field(default=10, ge=1, le=20)


class UnrealGasMonitorRequest(BaseModel):
    interval_ms: int = Field(default=500, ge=100, le=2000)
    duration_seconds: int = Field(default=300, ge=1, le=3600)
    group_limit: int = Field(default=10, ge=1, le=20)


class GameProfileMonitorRequest(BaseModel):
    interval_ms: int = Field(default=1000, ge=250, le=5000)
    duration_seconds: int = Field(default=900, ge=1, le=3600)
    candidate_limit: int = Field(default=50, ge=10, le=200)


class UnrealGasProfileRequest(BaseModel):
    address: int = Field(ge=0)
    value_type: ValueType
    name: str = Field(default="Health", min_length=1, max_length=100)


class AssistantMessageRequest(BaseModel):
    session_id: str
    message: str = Field(min_length=1, max_length=2000)
    conversation_id: str | None = None


class SimulatorValueRequest(BaseModel):
    value: int | float


class SimulatorValueResponse(BaseModel):
    name: str
    address: int
    value: int | float


class HealthResponse(BaseModel):
    status: str
    version: str
    backend: str
    assistant_provider: str
    writes_enabled: bool
    control_api: str
    control_protocol_versions: list[str]
    canonical_role: str
    instance_id: str
    started_at: str
    active_session_count: int
    write_receipt_count: int


class ControlNegotiationRequest(BaseModel):
    client_versions: list[str] = Field(default_factory=list, max_length=20)


def get_application(request: Request) -> ApplicationService:
    return request.app.state.application


def get_assistant(request: Request) -> AssistantCoordinator:
    return request.app.state.assistant


AppService = Annotated[ApplicationService, Depends(get_application)]
AssistantService = Annotated[AssistantCoordinator, Depends(get_assistant)]


def create_app(settings: Settings | None = None) -> FastAPI:
    active_settings = settings or Settings()
    application = ApplicationService(active_settings)
    assistant = AssistantCoordinator(application, active_settings)

    @asynccontextmanager
    async def lifespan(_: FastAPI):
        yield
        application.close()

    app = FastAPI(
        title="GTP Games API",
        version=__version__,
        description=(
            "Safety-scoped local game memory scanning and assistant API. "
            "Use only with local personal games you are authorized to modify."
        ),
        lifespan=lifespan,
    )
    app.state.application = application
    app.state.assistant = assistant
    app.state.settings = active_settings

    @app.exception_handler(GTPError)
    async def handle_gtp_error(_: Request, exc: GTPError) -> JSONResponse:
        if isinstance(exc, NotFoundError):
            status = 404
        elif isinstance(exc, SafetyError):
            status = 403
        else:
            status = 400
        return JSONResponse(status_code=status, content={"detail": str(exc)})

    @app.get("/health", response_model=HealthResponse, tags=["system"])
    def health(service: AppService) -> HealthResponse:
        return HealthResponse(
            status="ok",
            version=__version__,
            backend=service.backend.name,
            assistant_provider=active_settings.assistant_provider,
            writes_enabled=active_settings.allow_writes,
            control_api=CONTROL_API,
            control_protocol_versions=list(CONTROL_PROTOCOL_VERSIONS),
            canonical_role=CANONICAL_ROLE,
            instance_id=service.instance_id,
            started_at=service.started_at.isoformat(),
            active_session_count=service.active_session_count,
            write_receipt_count=service.write_receipt_count,
        )

    @app.post(
        "/v1/control/negotiate",
        response_model=ControlNegotiation,
        tags=["system"],
    )
    def negotiate(body: ControlNegotiationRequest, service: AppService) -> ControlNegotiation:
        return negotiate_control(body.client_versions, instance_id=service.instance_id)

    @app.get("/v1/processes", response_model=list[ProcessInfo], tags=["processes"])
    def list_processes(service: AppService) -> list[ProcessInfo]:
        return service.list_processes()

    @app.post("/v1/sessions", response_model=ProcessSession, tags=["processes"])
    def attach(
        body: AttachRequest,
        service: AppService,
    ) -> ProcessSession:
        return service.attach(
            body.pid,
            write_enabled=body.write_enabled,
            game_key=body.game_key,
            game_name=body.game_name,
            table_path=body.table_path,
        )

    @app.delete("/v1/sessions/{session_id}", status_code=204, tags=["processes"])
    def detach(
        session_id: str,
        service: AppService,
    ) -> None:
        service.detach(session_id)

    @app.get(
        "/v1/sessions/{session_id}/regions",
        response_model=list[MemoryRegion],
        tags=["memory"],
    )
    def regions(
        session_id: str,
        service: AppService,
    ) -> list[MemoryRegion]:
        return service.regions(session_id)

    @app.post(
        "/v1/sessions/{session_id}/read",
        response_model=ReadValueResponse,
        tags=["memory"],
    )
    def read_value(
        session_id: str,
        body: ReadValueRequest,
        service: AppService,
    ) -> ReadValueResponse:
        return ReadValueResponse(
            address=body.address,
            value_type=body.value_type,
            value=service.read_value(session_id, body.address, body.value_type),
        )

    @app.post(
        "/v1/sessions/{session_id}/scans",
        response_model=ScanSummary,
        tags=["scans"],
    )
    def start_scan(
        session_id: str,
        body: StartScanRequest,
        service: AppService,
    ) -> ScanSummary:
        return service.start_scan(session_id, body.value_type, body.value)

    @app.post(
        "/v1/sessions/{session_id}/scans/unknown",
        response_model=ScanSummary,
        tags=["scans"],
    )
    def start_unknown_scan(
        session_id: str,
        body: StartUnknownScanRequest,
        service: AppService,
    ) -> ScanSummary:
        return service.start_unknown_scan(
            session_id,
            body.value_type,
            normalized=body.normalized,
        )

    @app.post("/v1/scans/{scan_id}/rescan", response_model=ScanSummary, tags=["scans"])
    def rescan(
        scan_id: str,
        body: RescanRequest,
        service: AppService,
    ) -> ScanSummary:
        return service.rescan(scan_id, body.comparison, body.value)

    @app.get("/v1/scans/{scan_id}", response_model=ScanSummary, tags=["scans"])
    def scan_summary(
        scan_id: str,
        service: AppService,
        limit: int = Query(default=20, ge=0, le=200),
    ) -> ScanSummary:
        return service.scan_summary(scan_id, limit=limit)

    @app.post("/v1/scans/{scan_id}/watch", response_model=WatchResult, tags=["scans"])
    def watch_scan(
        scan_id: str,
        body: WatchScanRequest,
        service: AppService,
    ) -> WatchResult:
        return service.watch_scan(
            scan_id,
            sample_count=body.sample_count,
            interval_ms=body.interval_ms,
            limit=body.limit,
        )

    @app.post(
        "/v1/sessions/{session_id}/autonomous-discovery",
        response_model=CheatDiscoveryRunStatus,
        tags=["discovery"],
    )
    def start_autonomous_discovery(
        session_id: str,
        body: AutonomousDiscoveryRequest,
        service: AppService,
    ) -> CheatDiscoveryRunStatus:
        return service.start_autonomous_discovery(
            session_id,
            target_order=body.target_order,
            interval_seconds=body.interval_seconds,
            observation_seconds=body.observation_seconds,
            revisit_seconds=body.revisit_seconds,
        )

    @app.get(
        "/v1/autonomous-discovery/{run_id}",
        response_model=CheatDiscoveryRunStatus,
        tags=["discovery"],
    )
    def autonomous_discovery_status(
        run_id: str,
        service: AppService,
    ) -> CheatDiscoveryRunStatus:
        return service.autonomous_discovery_status(run_id)

    @app.post(
        "/v1/autonomous-discovery/{run_id}/value",
        response_model=CheatDiscoveryRunStatus,
        tags=["discovery"],
    )
    def set_autonomous_discovery_value(
        run_id: str,
        body: AutonomousDiscoveryValueRequest,
        service: AppService,
    ) -> CheatDiscoveryRunStatus:
        return service.set_autonomous_discovery_value(
            run_id,
            body.target_name,
            body.value,
        )

    @app.post(
        "/v1/autonomous-discovery/{run_id}/rescan-values",
        response_model=CheatDiscoveryRunStatus,
        tags=["discovery"],
    )
    def rescan_autonomous_discovery_values(
        run_id: str,
        service: AppService,
    ) -> CheatDiscoveryRunStatus:
        return service.rescan_autonomous_discovery_values(run_id)

    @app.post(
        "/v1/autonomous-discovery/{run_id}/behavior",
        response_model=CheatDiscoveryRunStatus,
        tags=["discovery"],
    )
    def capture_autonomous_discovery_behavior(
        run_id: str,
        body: AutonomousDiscoveryBehaviorRequest,
        service: AppService,
    ) -> CheatDiscoveryRunStatus:
        return service.capture_autonomous_discovery_behavior(
            run_id,
            body.target_name,
            body.phase,
            body.label,
        )

    @app.post(
        "/v1/autonomous-discovery/{run_id}/stop",
        response_model=CheatDiscoveryRunStatus,
        tags=["discovery"],
    )
    def stop_autonomous_discovery(
        run_id: str,
        service: AppService,
    ) -> CheatDiscoveryRunStatus:
        return service.stop_autonomous_discovery(run_id)

    @app.post(
        "/v1/sessions/{session_id}/health-bar",
        response_model=HealthBarResult,
        tags=["memory"],
    )
    def estimate_health_bar(
        session_id: str,
        body: HealthBarRequest,
        service: AppService,
    ) -> HealthBarResult:
        return service.detect_health_bars(
            session_id,
            x=body.x,
            y=body.y,
            width=body.width,
            height=body.height,
            limit=body.limit,
        )

    @app.post(
        "/v1/sessions/{session_id}/inventory-screen",
        response_model=InventoryScreenResult,
        tags=["memory"],
    )
    def inspect_inventory_screen(
        session_id: str,
        service: AppService,
    ) -> InventoryScreenResult:
        return service.read_inventory_screen(session_id)

    @app.post(
        "/v1/cheat-table-reference",
        response_model=CheatTableResult,
        tags=["memory"],
    )
    def import_cheat_table_reference(
        body: CheatTableRequest,
        service: AppService,
    ) -> CheatTableResult:
        return service.import_cheat_table_reference(
            body.source,
            query=body.query,
            limit=body.limit,
            source_build=body.source_build(),
        )

    @app.post(
        "/v1/sessions/{session_id}/cheat-table",
        response_model=CheatTableResult,
        tags=["memory"],
    )
    def inspect_cheat_table(
        session_id: str,
        body: CheatTableRequest,
        service: AppService,
    ) -> CheatTableResult:
        return service.inspect_cheat_table(
            session_id,
            body.source,
            query=body.query,
            limit=body.limit,
            source_build=body.source_build(),
        )

    @app.get(
        "/v1/sessions/{session_id}/game-cheats",
        response_model=GameCheatCatalog,
        tags=["memory"],
    )
    def game_cheat_catalog(
        session_id: str,
        service: AppService,
    ) -> GameCheatCatalog:
        return service.game_cheat_catalog(session_id)

    @app.get(
        "/v1/sessions/{session_id}/game-value-table",
        response_model=GameValueTable,
        tags=["catalog"],
    )
    def game_value_table(
        session_id: str,
        service: AppService,
    ) -> GameValueTable:
        return service.game_value_table(session_id)

    @app.post(
        "/v1/sessions/{session_id}/game-cheats/sources",
        response_model=GameCheatCatalog,
        tags=["memory"],
    )
    def add_game_cheat_sources(
        session_id: str,
        body: GameCheatSourcesRequest,
        service: AppService,
    ) -> GameCheatCatalog:
        return service.add_game_cheat_sources(
            session_id,
            body.sources,
            query=body.query,
        )

    @app.post(
        "/v1/sessions/{session_id}/unreal/gworld",
        response_model=UnrealDiscoveryResult,
        tags=["memory"],
    )
    def locate_unreal_gworld(
        session_id: str,
        service: AppService,
    ) -> UnrealDiscoveryResult:
        return service.locate_unreal_engine(session_id)

    @app.post(
        "/v1/sessions/{session_id}/unreal/gas-scans",
        response_model=UnrealGasScanSummary,
        tags=["scans"],
    )
    def start_unreal_gas_scan(
        session_id: str,
        body: UnrealGasStartRequest,
        service: AppService,
    ) -> UnrealGasScanSummary:
        return service.start_unreal_gas_scan(session_id, body.value_types)

    @app.post(
        "/v1/unreal/gas-scans/{scan_id}/refine",
        response_model=UnrealGasScanSummary,
        tags=["scans"],
    )
    def refine_unreal_gas_scan(
        scan_id: str,
        body: UnrealGasRefineRequest,
        service: AppService,
    ) -> UnrealGasScanSummary:
        return service.refine_unreal_gas_scan(scan_id, body.comparison, body.value)

    @app.post(
        "/v1/unreal/gas-scans/{scan_id}/table-guided",
        response_model=UnrealGasScanSummary,
        tags=["scans"],
    )
    def start_unreal_table_guided_scan(
        scan_id: str,
        body: UnrealTableGuidedRequest,
        service: AppService,
    ) -> UnrealGasScanSummary:
        return service.start_unreal_table_guided_scan(
            scan_id,
            pawn_pointer_offset=body.pawn_pointer_offset,
            pointer_radius=body.pointer_radius,
            health_offset=body.health_offset,
            max_health_offset=body.max_health_offset,
            nested_state_offset=body.nested_state_offset,
            replica_percent_offset=body.replica_percent_offset,
        )

    @app.get(
        "/v1/unreal/gas-scans/{scan_id}",
        response_model=UnrealGasScanSummary,
        tags=["scans"],
    )
    def unreal_gas_scan_summary(
        scan_id: str,
        service: AppService,
        limit: int = Query(default=20, ge=0, le=100),
    ) -> UnrealGasScanSummary:
        return service.unreal_gas_scan_summary(scan_id, limit=limit)

    @app.post(
        "/v1/unreal/gas-scans/{scan_id}/watch",
        response_model=UnrealGasWatchResult,
        tags=["scans"],
    )
    def watch_unreal_gas_scan(
        scan_id: str,
        body: WatchScanRequest,
        service: AppService,
    ) -> UnrealGasWatchResult:
        return service.watch_unreal_gas_scan(
            scan_id,
            sample_count=body.sample_count,
            interval_ms=body.interval_ms,
            limit=body.limit,
        )

    @app.post(
        "/v1/unreal/gas-scans/{scan_id}/capture-damage-refill",
        response_model=UnrealGasTemporalResult,
        tags=["scans"],
    )
    def capture_unreal_gas_damage_refill(
        scan_id: str,
        body: UnrealGasTemporalRequest,
        service: AppService,
    ) -> UnrealGasTemporalResult:
        return service.capture_unreal_gas_damage_refill(
            scan_id,
            sample_count=body.sample_count,
            interval_ms=body.interval_ms,
            group_limit=body.group_limit,
        )

    @app.post(
        "/v1/unreal/gas-scans/{scan_id}/damage-monitor",
        response_model=UnrealGasMonitorStatus,
        tags=["scans"],
    )
    def start_unreal_gas_damage_monitor(
        scan_id: str,
        body: UnrealGasMonitorRequest,
        service: AppService,
    ) -> UnrealGasMonitorStatus:
        return service.start_unreal_gas_damage_monitor(
            scan_id,
            interval_ms=body.interval_ms,
            duration_seconds=body.duration_seconds,
            group_limit=body.group_limit,
        )

    @app.get(
        "/v1/unreal/gas-damage-monitors/{monitor_id}",
        response_model=UnrealGasMonitorStatus,
        tags=["scans"],
    )
    def unreal_gas_damage_monitor_status(
        monitor_id: str,
        service: AppService,
    ) -> UnrealGasMonitorStatus:
        return service.unreal_gas_damage_monitor_status(monitor_id)

    @app.post(
        "/v1/unreal/gas-damage-monitors/{monitor_id}/stop",
        response_model=UnrealGasMonitorStatus,
        tags=["scans"],
    )
    def stop_unreal_gas_damage_monitor(
        monitor_id: str,
        service: AppService,
    ) -> UnrealGasMonitorStatus:
        return service.stop_unreal_gas_damage_monitor(monitor_id)

    @app.post(
        "/v1/unreal/gas-scans/{scan_id}/game-profile-monitor",
        response_model=GameProfileMonitorStatus,
        tags=["scans"],
    )
    def start_unreal_game_profile_monitor(
        scan_id: str,
        body: GameProfileMonitorRequest,
        service: AppService,
    ) -> GameProfileMonitorStatus:
        return service.start_unreal_game_profile_monitor(
            scan_id,
            interval_ms=body.interval_ms,
            duration_seconds=body.duration_seconds,
            candidate_limit=body.candidate_limit,
        )

    @app.get(
        "/v1/unreal/game-profile-monitors/{monitor_id}",
        response_model=GameProfileMonitorStatus,
        tags=["scans"],
    )
    def unreal_game_profile_monitor_status(
        monitor_id: str,
        service: AppService,
    ) -> GameProfileMonitorStatus:
        return service.unreal_game_profile_monitor_status(monitor_id)

    @app.post(
        "/v1/unreal/game-profile-monitors/{monitor_id}/stop",
        response_model=GameProfileMonitorStatus,
        tags=["scans"],
    )
    def stop_unreal_game_profile_monitor(
        monitor_id: str,
        service: AppService,
    ) -> GameProfileMonitorStatus:
        return service.stop_unreal_game_profile_monitor(monitor_id)

    @app.post(
        "/v1/unreal/gas-scans/{scan_id}/profile",
        response_model=UnrealGasProfile,
        tags=["scans"],
    )
    def save_unreal_gas_profile(
        scan_id: str,
        body: UnrealGasProfileRequest,
        service: AppService,
    ) -> UnrealGasProfile:
        return service.save_unreal_gas_profile(
            scan_id,
            body.address,
            body.value_type,
            body.name,
        )

    @app.get(
        "/v1/sessions/{session_id}/unreal/profiles/{profile_id}",
        response_model=UnrealGasProfileValue,
        tags=["memory"],
    )
    def read_unreal_gas_profile(
        session_id: str,
        profile_id: str,
        service: AppService,
    ) -> UnrealGasProfileValue:
        return service.read_unreal_gas_profile(session_id, profile_id)

    @app.post("/v1/assistant/messages", response_model=AssistantReply, tags=["assistant"])
    def assistant_message(
        body: AssistantMessageRequest,
        assistant_service: AssistantService,
    ) -> AssistantReply:
        return assistant_service.handle(body.session_id, body.message, body.conversation_id)

    @app.post(
        "/v1/simulator/values/{name}",
        response_model=SimulatorValueResponse,
        tags=["simulator"],
    )
    def mutate_simulator(
        name: str,
        body: SimulatorValueRequest,
        service: AppService,
    ) -> SimulatorValueResponse:
        return SimulatorValueResponse(
            name=name,
            address=service.mutate_simulator(name, body.value),
            value=body.value,
        )

    return app
