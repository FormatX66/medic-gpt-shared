from __future__ import annotations

import json
from dataclasses import dataclass
from threading import RLock
from uuid import uuid4

from openai import OpenAI

from gtp_games.assistant.models import AssistantReply
from gtp_games.config import Settings
from gtp_games.errors import ConfigurationError, GTPError
from gtp_games.models import Comparison, ValueType
from gtp_games.service import ApplicationService

TOOLS = [
    {
        "type": "function",
        "name": "start_value_scan",
        "description": "Start an exact scan for the player's current scalar value.",
        "strict": True,
        "parameters": {
            "type": "object",
            "properties": {
                "value": {"type": "number"},
                "value_type": {
                    "type": "string",
                    "enum": [item.value for item in ValueType],
                },
            },
            "required": ["value", "value_type"],
            "additionalProperties": False,
        },
    },
    {
        "type": "function",
        "name": "refine_value_scan",
        "description": "Filter the active scan using the player's latest observation.",
        "strict": True,
        "parameters": {
            "type": "object",
            "properties": {
                "comparison": {
                    "type": "string",
                    "enum": [item.value for item in Comparison],
                },
                "value": {"type": ["number", "null"]},
            },
            "required": ["comparison", "value"],
            "additionalProperties": False,
        },
    },
    {
        "type": "function",
        "name": "list_scan_candidates",
        "description": "List a small sample of current candidates from the active scan.",
        "strict": True,
        "parameters": {
            "type": "object",
            "properties": {},
            "required": [],
            "additionalProperties": False,
        },
    },
]


INSTRUCTIONS = """You are GTP Games, an assistant for local, personal, offline games.
Use only the supplied tools. Help the user narrow an ordinary scalar game value through an exact
scan followed by rescans. Default unknown integers to i32 and ask for the current value when it is
missing. Do not help with online games, anti-cheat, protected processes, DRM, code injection, or
executable-memory changes. This direct-API mode is read and scan only. Controlled writes are
available only through the MCP plugin and its native local confirmation dialog. Never invent an
address, session, scan result, or successful write.
"""


@dataclass
class OpenAIConversation:
    id: str
    session_id: str
    active_scan_id: str | None = None
    response_id: str | None = None


class OpenAIToolAssistant:
    def __init__(self, application: ApplicationService, settings: Settings) -> None:
        if settings.openai_api_key is None:
            raise ConfigurationError(
                "GTP_ASSISTANT_PROVIDER=openai requires OPENAI_API_KEY in the environment"
            )
        self.application = application
        self.settings = settings
        self.client = OpenAI(api_key=settings.openai_api_key.get_secret_value())
        self._conversations: dict[str, OpenAIConversation] = {}
        self._lock = RLock()

    def handle(
        self,
        session_id: str,
        message: str,
        conversation_id: str | None = None,
    ) -> AssistantReply:
        state = self._conversation(session_id, conversation_id)
        request: dict = {
            "model": self.settings.openai_model,
            "instructions": INSTRUCTIONS,
            "input": message,
            "tools": TOOLS,
            "parallel_tool_calls": False,
        }
        if state.response_id:
            request["previous_response_id"] = state.response_id
        response = self.client.responses.create(**request)
        actions: list[str] = []
        latest_data: dict = {}

        for _ in range(5):
            calls = [item for item in response.output if item.type == "function_call"]
            if not calls:
                state.response_id = response.id
                return AssistantReply(
                    conversation_id=state.id,
                    message=response.output_text or "The assistant returned no text.",
                    active_scan_id=state.active_scan_id,
                    tool_actions=actions,
                    data=latest_data,
                )
            outputs = []
            for call in calls:
                try:
                    arguments = json.loads(call.arguments)
                    result = self._execute_tool(state, call.name, arguments)
                except (GTPError, ValueError, TypeError, json.JSONDecodeError) as exc:
                    result = {"error": str(exc)}
                actions.append(call.name)
                latest_data = result
                outputs.append(
                    {
                        "type": "function_call_output",
                        "call_id": call.call_id,
                        "output": json.dumps(result),
                    }
                )
            response = self.client.responses.create(
                model=self.settings.openai_model,
                instructions=INSTRUCTIONS,
                previous_response_id=response.id,
                input=outputs,
                tools=TOOLS,
                parallel_tool_calls=False,
            )
        raise ConfigurationError("assistant exceeded the five-step tool-call limit")

    def _execute_tool(
        self,
        state: OpenAIConversation,
        name: str,
        arguments: dict,
    ) -> dict:
        if name == "start_value_scan":
            summary = self.application.start_scan(
                state.session_id,
                ValueType(arguments["value_type"]),
                arguments["value"],
            )
            state.active_scan_id = summary.id
            return summary.model_dump(mode="json")
        if name == "refine_value_scan":
            if state.active_scan_id is None:
                raise GTPError("no active scan; start a scan first")
            summary = self.application.rescan(
                state.active_scan_id,
                Comparison(arguments["comparison"]),
                arguments.get("value"),
            )
            return summary.model_dump(mode="json")
        if name == "list_scan_candidates":
            if state.active_scan_id is None:
                raise GTPError("no active scan; start a scan first")
            return self.application.scan_summary(state.active_scan_id).model_dump(mode="json")
        raise GTPError(f"unsupported assistant tool: {name}")

    def _conversation(
        self,
        session_id: str,
        conversation_id: str | None,
    ) -> OpenAIConversation:
        with self._lock:
            if conversation_id is not None and conversation_id in self._conversations:
                state = self._conversations[conversation_id]
                if state.session_id != session_id:
                    raise GTPError("conversation belongs to a different process session")
                return state
            state = OpenAIConversation(id=conversation_id or uuid4().hex, session_id=session_id)
            self._conversations[state.id] = state
            return state
