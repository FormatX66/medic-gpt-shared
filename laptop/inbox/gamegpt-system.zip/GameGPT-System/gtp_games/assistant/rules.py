from __future__ import annotations

import re
from dataclasses import dataclass
from threading import RLock
from uuid import uuid4

from gtp_games.assistant.models import AssistantReply
from gtp_games.errors import GTPError
from gtp_games.models import Comparison, ValueType
from gtp_games.service import ApplicationService

_NUMBER = re.compile(r"(?<![A-Za-z0-9_.-])-?\d+(?:\.\d+)?")


@dataclass
class RuleConversation:
    id: str
    session_id: str
    active_scan_id: str | None = None


class RulesAssistant:
    def __init__(self, application: ApplicationService) -> None:
        self.application = application
        self._conversations: dict[str, RuleConversation] = {}
        self._lock = RLock()

    def handle(
        self,
        session_id: str,
        message: str,
        conversation_id: str | None = None,
    ) -> AssistantReply:
        state = self._conversation(session_id, conversation_id)
        normalized = message.strip().lower()
        if not normalized:
            return self._reply(state, "Tell me the current value you want to find.")
        if self._is_write_request(normalized):
            return self._reply(
                state,
                "Controlled changes are available only through the GTP Games plugin, "
                "which uses a native local confirmation dialog.",
            )

        try:
            if state.active_scan_id is None and self._is_scan_request(normalized):
                return self._start_scan(state, message)
            if state.active_scan_id is not None and self._is_rescan_request(normalized):
                return self._rescan(state, message)
            if state.active_scan_id is not None and any(
                word in normalized for word in ("show", "result", "candidate", "where")
            ):
                summary = self.application.scan_summary(state.active_scan_id)
                return self._reply(
                    state,
                    f"The active scan has {summary.result_count} candidate(s).",
                    actions=["list_scan_candidates"],
                    data=summary.model_dump(mode="json"),
                )
        except GTPError as exc:
            return self._reply(state, f"I could not do that safely: {exc}")

        if state.active_scan_id is None:
            return self._reply(
                state,
                "Try: ‘Find my health; it is currently 100.’ I will start with a "
                "32-bit integer scan.",
            )
        return self._reply(
            state,
            "Change the value in the game, then tell me its new value or say changed, increased, "
            "decreased, or unchanged.",
        )

    def _start_scan(self, state: RuleConversation, message: str) -> AssistantReply:
        value = self._last_number(message)
        if value is None:
            return self._reply(
                state,
                "What is the value right now? For example: ‘Find health; it is 100.’",
            )
        value_type = self._infer_type(message, value)
        summary = self.application.start_scan(state.session_id, value_type, value)
        state.active_scan_id = summary.id
        suffix = " The result cap was reached." if summary.truncated else ""
        return self._reply(
            state,
            f"Started a {value_type} scan for {value}. Found {summary.result_count} candidate(s)."
            f"{suffix} Change the value in the game and tell me what happened.",
            actions=["start_value_scan"],
            data=summary.model_dump(mode="json"),
        )

    def _rescan(self, state: RuleConversation, message: str) -> AssistantReply:
        normalized = message.lower()
        value = self._last_number(message)
        if "unchanged" in normalized or "same" in normalized:
            comparison = Comparison.UNCHANGED
            value = None
        elif "increas" in normalized or "went up" in normalized or "higher" in normalized:
            comparison = Comparison.INCREASED
            value = None
        elif "decreas" in normalized or "went down" in normalized or "lower" in normalized:
            comparison = Comparison.DECREASED
            value = None
        elif "changed" in normalized and value is None:
            comparison = Comparison.CHANGED
        elif value is not None:
            comparison = Comparison.EXACT
        else:
            return self._reply(
                state,
                "Tell me the new exact value, or say changed, increased, decreased, or unchanged.",
            )
        assert state.active_scan_id is not None
        summary = self.application.rescan(state.active_scan_id, comparison, value)
        if 1 <= summary.result_count <= 5:
            next_step = (
                " A small candidate set remains; mirrored copies may all be valid. Keep the "
                "set and inspect or test each address separately before preparing a write."
            )
        elif summary.result_count == 0:
            next_step = " No candidates remain; start a new scan and verify the value type."
        else:
            next_step = " Change the value again and give me another observation."
        return self._reply(
            state,
            f"Applied the {comparison} filter. {summary.result_count} candidate(s) "
            f"remain.{next_step}",
            actions=["refine_value_scan"],
            data=summary.model_dump(mode="json"),
        )

    def _conversation(self, session_id: str, conversation_id: str | None) -> RuleConversation:
        with self._lock:
            if conversation_id is not None:
                state = self._conversations.get(conversation_id)
                if state is not None:
                    if state.session_id != session_id:
                        raise GTPError("conversation belongs to a different process session")
                    return state
            state = RuleConversation(id=conversation_id or uuid4().hex, session_id=session_id)
            self._conversations[state.id] = state
            return state

    @staticmethod
    def _is_scan_request(message: str) -> bool:
        return any(word in message for word in ("find", "scan", "search", "locate"))

    @staticmethod
    def _is_rescan_request(message: str) -> bool:
        return (
            any(
                word in message
                for word in (
                    "now",
                    "changed",
                    "unchanged",
                    "same",
                    "increas",
                    "decreas",
                    "higher",
                    "lower",
                    "went up",
                    "went down",
                )
            )
            or RulesAssistant._last_number(message) is not None
        )

    @staticmethod
    def _is_write_request(message: str) -> bool:
        return any(word in message for word in ("set it", "write", "change it to", "make it"))

    @staticmethod
    def _last_number(message: str) -> int | float | None:
        matches = _NUMBER.findall(message)
        if not matches:
            return None
        raw = matches[-1]
        return float(raw) if "." in raw else int(raw)

    @staticmethod
    def _infer_type(message: str, value: int | float) -> ValueType:
        normalized = message.lower()
        if isinstance(value, float) or "float" in normalized:
            return ValueType.F32
        aliases = {
            "byte": ValueType.U8,
            "i8": ValueType.I8,
            "u8": ValueType.U8,
            "i16": ValueType.I16,
            "u16": ValueType.U16,
            "i32": ValueType.I32,
            "u32": ValueType.U32,
            "i64": ValueType.I64,
            "u64": ValueType.U64,
            "double": ValueType.F64,
            "f64": ValueType.F64,
        }
        return next((kind for alias, kind in aliases.items() if alias in normalized), ValueType.I32)

    @staticmethod
    def _reply(
        state: RuleConversation,
        message: str,
        *,
        actions: list[str] | None = None,
        data: dict | None = None,
    ) -> AssistantReply:
        return AssistantReply(
            conversation_id=state.id,
            message=message,
            active_scan_id=state.active_scan_id,
            tool_actions=actions or [],
            data=data or {},
        )
