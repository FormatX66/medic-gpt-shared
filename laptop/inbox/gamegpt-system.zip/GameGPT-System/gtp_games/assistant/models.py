from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field


class AssistantReply(BaseModel):
    conversation_id: str
    message: str
    active_scan_id: str | None = None
    tool_actions: list[str] = Field(default_factory=list)
    data: dict[str, Any] = Field(default_factory=dict)
