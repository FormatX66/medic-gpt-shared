from __future__ import annotations

from gtp_games.assistant.models import AssistantReply
from gtp_games.assistant.openai_tools import OpenAIToolAssistant
from gtp_games.assistant.rules import RulesAssistant
from gtp_games.config import Settings
from gtp_games.service import ApplicationService


class AssistantCoordinator:
    def __init__(self, application: ApplicationService, settings: Settings) -> None:
        self.provider = settings.assistant_provider
        self._assistant = (
            OpenAIToolAssistant(application, settings)
            if self.provider == "openai"
            else RulesAssistant(application)
        )

    def handle(
        self,
        session_id: str,
        message: str,
        conversation_id: str | None = None,
    ) -> AssistantReply:
        return self._assistant.handle(session_id, message, conversation_id)
