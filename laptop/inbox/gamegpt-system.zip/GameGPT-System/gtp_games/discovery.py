from __future__ import annotations

import hashlib
import re
from dataclasses import dataclass, field
from datetime import UTC, datetime, timedelta
from pathlib import Path
from threading import Event, RLock, Thread
from typing import TYPE_CHECKING
from uuid import uuid4

from gtp_games.codec import values_equal
from gtp_games.errors import NotFoundError, SafetyError
from gtp_games.game_tables import (
    ensure_game_value_table,
    quarantine_legacy_behavioral_discoveries,
    register_discovery_candidates,
)
from gtp_games.models import (
    CheatDiscoveryRunStatus,
    Comparison,
    DiscoveryCandidate,
    DiscoveryTargetState,
    DiscoveryTargetStatus,
    LocatorKind,
    MemoryLocator,
    ProcessSession,
    ScanCandidateStability,
    ScanKind,
    ValidationRule,
    ValueType,
)
from gtp_games.save_evidence import SaveEvidenceRegistry, build_default_save_evidence_registry

if TYPE_CHECKING:
    from gtp_games.service import ApplicationService


DEFAULT_NMS_TARGET_ORDER = [
    "Units",
    "Nanites",
    "Quicksilver",
    "health",
    "shield",
    "hazard protection",
    "life support",
    "stamina",
    "jetpack",
    "movement speed",
    "jump height",
    "inventory item quantity",
    "inventory capacity",
    "launch thrusters",
    "pulse/hyperdrive",
    "weapon heat/ammo",
    "scanner",
]
DEFAULT_GENERIC_TARGET_ORDER = [
    "health",
    "shield",
    "stamina",
    "inventory item quantity",
    "weapon heat/ammo",
]

EXPLICIT_BEHAVIOR_VALIDATION_MARKER = "Explicit labeled behavior-window correlation v2."
MAX_EQUIVALENT_LOCKED_CANDIDATES = 5
SAME_PROCESS_LAYOUT_SOURCE = "same_process_verified_layout"
NMS_CURRENCY_LAYOUT = {
    "Units": 0,
    "Nanites": 4,
    "Quicksilver": 8,
}


@dataclass(frozen=True)
class TargetSpec:
    name: str
    value_type: ValueType
    normalized: bool
    exact_value: int | float | None
    expected_directions: tuple[Comparison, ...]
    value_min: float | None = None
    value_max: float | None = None
    requires_exact_value: bool = False
    purpose: str = ""
    experiment_prompt: str = ""
    behavioral_correlation: bool = False


@dataclass(frozen=True)
class PublicPattern:
    target: str
    module: str
    pattern: str
    source_url: str
    source_date: str
    description: str


_TARGET_SPECS = {
    spec.name.casefold(): spec
    for spec in (
        TargetSpec(
            "health",
            ValueType.F32,
            True,
            1.0,
            (Comparison.DECREASED, Comparison.INCREASED),
            0,
            1,
            experiment_prompt="After the shield is empty, take one safe hit, then heal once.",
        ),
        TargetSpec(
            "shield",
            ValueType.F32,
            True,
            1.0,
            (Comparison.DECREASED, Comparison.INCREASED),
            0,
            1,
            experiment_prompt="Take one small hit, then avoid damage while the shield refills.",
        ),
        TargetSpec(
            "hazard protection",
            ValueType.F32,
            True,
            1.0,
            (Comparison.DECREASED, Comparison.INCREASED),
            0,
            1,
            experiment_prompt=(
                "Stay outdoors on a hazardous planet until the hazard meter falls, then enter "
                "shelter and let it recover."
            ),
        ),
        TargetSpec(
            "life support",
            ValueType.F32,
            True,
            1.0,
            (Comparison.DECREASED, Comparison.INCREASED),
            0,
            1,
            experiment_prompt=(
                "Sprint or jetpack until life support falls, then recharge it once from the menu."
            ),
        ),
        TargetSpec(
            "stamina",
            ValueType.F32,
            True,
            1.0,
            (Comparison.DECREASED, Comparison.INCREASED),
            0,
            1,
            experiment_prompt="Sprint until the meter falls, then stand still until it refills.",
        ),
        TargetSpec(
            "jetpack",
            ValueType.F32,
            True,
            1.0,
            (Comparison.DECREASED, Comparison.INCREASED),
            0,
            1,
            experiment_prompt="Hold jetpack until its meter falls, then release until it refills.",
        ),
        TargetSpec(
            "movement speed",
            ValueType.F32,
            False,
            None,
            (Comparison.INCREASED, Comparison.DECREASED),
            -5_000,
            5_000,
            purpose="Find live locomotion values and restart-stable tuning locators.",
            experiment_prompt=(
                "Stand still for the baseline, then walk and sprint in a clear straight line."
            ),
            behavioral_correlation=True,
        ),
        TargetSpec(
            "jump height",
            ValueType.F32,
            False,
            None,
            (Comparison.INCREASED, Comparison.DECREASED),
            -5_000,
            5_000,
            purpose="Find vertical movement and jump/jetpack tuning values.",
            experiment_prompt=(
                "Stand on level ground, then perform several ordinary jumps without using menus."
            ),
            behavioral_correlation=True,
        ),
        TargetSpec(
            "Units",
            ValueType.U32,
            False,
            None,
            (Comparison.DECREASED, Comparison.INCREASED),
            0,
            4_294_967_295,
            True,
        ),
        TargetSpec(
            "Nanites",
            ValueType.U32,
            False,
            None,
            (Comparison.DECREASED, Comparison.INCREASED),
            0,
            4_294_967_295,
            True,
        ),
        TargetSpec(
            "Quicksilver",
            ValueType.U32,
            False,
            None,
            (Comparison.DECREASED, Comparison.INCREASED),
            0,
            4_294_967_295,
            True,
        ),
        TargetSpec(
            "inventory item quantity",
            ValueType.I32,
            False,
            None,
            (Comparison.DECREASED, Comparison.INCREASED),
            0,
            2_147_483_647,
            True,
            "Find a selected inventory stack count without assuming a fixed address.",
            "Enter a visible stack count, then collect, split, craft, or consume that item once.",
        ),
        TargetSpec(
            "inventory capacity",
            ValueType.U32,
            False,
            None,
            (Comparison.INCREASED,),
            0,
            10_000,
            True,
            "Find owned/available slot or capacity counters for inventory expansion.",
            "Enter the visible slot/capacity count, then unlock one slot when practical.",
        ),
        TargetSpec(
            "launch thrusters",
            ValueType.F32,
            True,
            1.0,
            (Comparison.DECREASED, Comparison.INCREASED),
            0,
            1,
        ),
        TargetSpec(
            "pulse/hyperdrive",
            ValueType.F32,
            True,
            1.0,
            (Comparison.DECREASED, Comparison.INCREASED),
            0,
            1,
        ),
        TargetSpec(
            "weapon heat/ammo",
            ValueType.I32,
            False,
            None,
            (Comparison.DECREASED, Comparison.INCREASED),
            0,
            2_147_483_647,
            True,
        ),
        TargetSpec(
            "scanner", ValueType.F32, True, 1.0, (Comparison.DECREASED, Comparison.INCREASED), 0, 1
        ),
    )
}

_PUBLIC_PATTERNS = (
    PublicPattern(
        target="stamina",
        module="NMS.exe",
        pattern="F3 0F 5C C6 F3 ?? ?? ?? ?? ?? ?? ?? EB",
        source_url="https://fearlessrevolution.com/viewtopic.php?t=20214",
        source_date="2022-07-24",
        description="Community stamina-decrement AoB; advisory until uniquely matched live.",
    ),
    PublicPattern(
        target="jetpack",
        module="NMS.exe",
        pattern="0F 10 ?? ?? ?? ?? ?? 0F 59 55 B0",
        source_url="https://fearlessrevolution.com/viewtopic.php?t=20214",
        source_date="2022-07-22",
        description="Community jetpack-speed AoB; useful only as related code evidence.",
    ),
)


@dataclass
class _Run:
    status: CheatDiscoveryRunStatus
    session: ProcessSession | None
    process_name: str
    game_key: str
    game_name: str
    interval_seconds: float
    observation_seconds: float
    revisit_seconds: float
    pointer_candidate_limit: int
    stop_event: Event = field(default_factory=Event)
    thread: Thread | None = None
    cursor: int = 0
    public_patterns_checked: set[str] = field(default_factory=set)
    next_save_check_at: datetime | None = None
    operation_lock: RLock = field(default_factory=RLock)
    screen_baseline_scan_ids: dict[tuple[ValueType, bool], str] = field(default_factory=dict)


@dataclass(frozen=True)
class CandidateTestContext:
    run_id: str
    target_name: str
    candidate_id: str
    session_id: str
    address: int
    value_type: ValueType
    current_value: int | float
    candidate_index: int
    candidate_count: int


class DiscoveryManager:
    """Round-robin autonomous discovery that only reads from process memory."""

    def __init__(
        self,
        service: ApplicationService,
        *,
        save_evidence_registry: SaveEvidenceRegistry | None = None,
    ) -> None:
        self.service = service
        self.save_evidence_registry = (
            save_evidence_registry or build_default_save_evidence_registry()
        )
        self._runs: dict[str, _Run] = {}
        self._lock = RLock()

    def start(
        self,
        session: ProcessSession,
        *,
        target_order: list[str] | None = None,
        interval_seconds: float = 2.0,
        observation_seconds: float = 10.0,
        revisit_seconds: float = 30.0,
        pointer_candidate_limit: int = 8,
        background: bool = True,
    ) -> CheatDiscoveryRunStatus:
        self._validate_options(
            interval_seconds,
            observation_seconds,
            revisit_seconds,
            pointer_candidate_limit,
        )
        with self._lock:
            existing = next(
                (
                    item
                    for item in self._runs.values()
                    if (
                        item.status.session_id == session.id
                        or self._same_process_incarnation(item.status, session)
                    )
                    and item.status.state == "running"
                    and not item.stop_event.is_set()
                ),
                None,
            )
            if existing is not None:
                self._prioritize_targets(existing, target_order)
                existing.status.updated_at = datetime.now(UTC)
                note = "Reused the active learner; no competing scanner was started."
                if not existing.status.warnings or existing.status.warnings[-1] != note:
                    existing.status.warnings.append(note)
                    existing.status.warnings = existing.status.warnings[-20:]
                self._persist(existing)
                return existing.status.model_copy(deep=True)
        game_key = session.game_key or "game"
        table = ensure_game_value_table(self.service.settings, session)
        selected_targets = self._initial_target_order(session, target_order, table)
        run = self._create_run(
            session=session,
            process_name=session.process_name,
            game_key=game_key,
            game_name=session.game_name or session.process_name,
            target_order=selected_targets,
            interval_seconds=interval_seconds,
            observation_seconds=observation_seconds,
            revisit_seconds=revisit_seconds,
            pointer_candidate_limit=pointer_candidate_limit,
            state="running",
        )
        run.status.table_path = table.saved_path
        self._restore_same_process_exact_locks(run)
        self._revalidate_persistent_locators(run)
        self._persist(run)
        self._start_worker(run, background)
        return run.status.model_copy(deep=True)

    def _prioritize_targets(self, run: _Run, requested: list[str] | None) -> None:
        if not requested:
            return False
        existing = {target.name.casefold(): target for target in run.status.targets}
        prioritized: list[DiscoveryTargetStatus] = []
        seen: set[str] = set()
        for name in requested:
            spec = self._spec(name)
            key = spec.name.casefold()
            target = existing.get(key)
            if target is None:
                target = self._new_target_status(spec)
            prioritized.append(target)
            seen.add(key)
        prioritized.extend(
            target for target in run.status.targets if target.name.casefold() not in seen
        )
        run.status.targets = prioritized
        run.status.target_order = [target.name for target in prioritized]
        run.cursor = 0
        self._refresh_save_values(run, force=False, initial=True)

    def start_waiting(
        self,
        process_name: str = "NMS.exe",
        *,
        game_key: str = "no-man-s-sky",
        game_name: str = "No Man's Sky",
        target_order: list[str] | None = None,
        interval_seconds: float = 2.0,
        observation_seconds: float = 10.0,
        revisit_seconds: float = 30.0,
        pointer_candidate_limit: int = 8,
        background: bool = True,
    ) -> CheatDiscoveryRunStatus:
        self._validate_options(
            interval_seconds,
            observation_seconds,
            revisit_seconds,
            pointer_candidate_limit,
        )
        with self._lock:
            existing = next(
                (
                    item
                    for item in self._runs.values()
                    if item.process_name.casefold() == process_name.casefold()
                    and item.game_key.casefold() == game_key.casefold()
                    and item.status.state in {"waiting_for_process", "running"}
                    and not item.stop_event.is_set()
                ),
                None,
            )
            if existing is not None:
                self._prioritize_targets(existing, target_order)
                existing.status.updated_at = datetime.now(UTC)
                note = "Reused the existing game supervisor; no duplicate learner was started."
                if not existing.status.warnings or existing.status.warnings[-1] != note:
                    existing.status.warnings.append(note)
                    existing.status.warnings = existing.status.warnings[-20:]
                self._persist(existing)
                return existing.status.model_copy(deep=True)
        run = self._create_run(
            session=None,
            process_name=process_name,
            game_key=game_key,
            game_name=game_name,
            target_order=target_order,
            interval_seconds=interval_seconds,
            observation_seconds=observation_seconds,
            revisit_seconds=revisit_seconds,
            pointer_candidate_limit=pointer_candidate_limit,
            state="waiting_for_process",
        )
        run.status.warnings.append(
            f"{process_name} is closed; discovery will attach read-only when it starts."
        )
        self._persist(run)
        self._start_worker(run, background)
        return run.status.model_copy(deep=True)

    def _create_run(
        self,
        *,
        session: ProcessSession | None,
        process_name: str,
        game_key: str,
        game_name: str,
        target_order: list[str] | None,
        interval_seconds: float,
        observation_seconds: float,
        revisit_seconds: float,
        pointer_candidate_limit: int,
        state: str,
    ) -> _Run:
        if target_order is not None:
            order = target_order
        else:
            is_nms = process_name.casefold() == "nms.exe" or game_key.casefold() in {
                "nms",
                "no-man-s-sky",
            }
            order = list(DEFAULT_NMS_TARGET_ORDER if is_nms else DEFAULT_GENERIC_TARGET_ORDER)
        specs = [self._spec(name) for name in order]
        run_id = uuid4().hex
        status = CheatDiscoveryRunStatus(
            id=run_id,
            process_name=process_name,
            session_id=session.id if session else None,
            pid=session.pid if session else None,
            process_started_at=session.process_started_at if session else None,
            game_key=game_key,
            state=state,
            target_order=[spec.name for spec in specs],
            write_enabled=bool(session and session.write_enabled),
            saved_path=str(self._run_path(game_key, run_id)),
            targets=[self._new_target_status(spec) for spec in specs],
        )
        run = _Run(
            status=status,
            session=session,
            process_name=process_name,
            game_key=game_key,
            game_name=game_name,
            interval_seconds=interval_seconds,
            observation_seconds=observation_seconds,
            revisit_seconds=revisit_seconds,
            pointer_candidate_limit=pointer_candidate_limit,
        )
        with self._lock:
            self._runs[run_id] = run
        self._refresh_save_values(run, force=True, initial=True)
        return run

    @staticmethod
    def _new_target_status(spec: TargetSpec) -> DiscoveryTargetStatus:
        return DiscoveryTargetStatus(
            name=spec.name,
            purpose=spec.purpose,
            experiment_prompt=spec.experiment_prompt,
            requires_visible_value=spec.requires_exact_value,
            value_type=spec.value_type,
            normalized=spec.normalized,
            exact_value=spec.exact_value,
            exact_value_source=("default_normalized" if spec.exact_value is not None else None),
            requires_behavior_capture=spec.behavioral_correlation,
        )

    @staticmethod
    def _validate_options(
        interval_seconds: float,
        observation_seconds: float,
        revisit_seconds: float,
        pointer_candidate_limit: int,
    ) -> None:
        if not 0.25 <= interval_seconds <= 60:
            raise SafetyError("discovery interval must be between 0.25 and 60 seconds")
        if not 1 <= observation_seconds <= 600:
            raise SafetyError("observation window must be between 1 and 600 seconds")
        if not 1 <= revisit_seconds <= 3600:
            raise SafetyError("revisit delay must be between 1 and 3600 seconds")
        if not 1 <= pointer_candidate_limit <= 32:
            raise SafetyError("pointer candidate limit must be between 1 and 32")

    def _start_worker(self, run: _Run, background: bool) -> None:
        if background:
            run.thread = Thread(
                target=self._worker,
                args=(run.status.id,),
                name=f"gtp-discovery-{run.status.id[:8]}",
                daemon=True,
            )
            run.thread.start()

    def status(self, run_id: str) -> CheatDiscoveryRunStatus:
        with self._lock:
            run = self._get(run_id)
            return run.status.model_copy(deep=True)

    def latest_status_for_session(
        self,
        session_id: str,
        *,
        process_started_at: float | None = None,
    ) -> CheatDiscoveryRunStatus | None:
        with self._lock:
            matching = [
                run.status
                for run in self._runs.values()
                if run.status.session_id == session_id
                and run.status.state != "stopped"
                and (
                    process_started_at is None
                    or run.status.process_started_at == process_started_at
                )
            ]
            if not matching:
                return None
            latest = max(matching, key=lambda status: status.updated_at)
            return latest.model_copy(deep=True)

    def stop(self, run_id: str) -> CheatDiscoveryRunStatus:
        with self._lock:
            run = self._get(run_id)
            run.stop_event.set()
            thread = run.thread
        if thread is not None and thread.is_alive():
            thread.join(timeout=min(5.0, run.interval_seconds + 1.0))
        with self._lock:
            run.status.state = "stopped"
            run.status.active_target = None
            run.status.updated_at = datetime.now(UTC)
            self._persist(run)
            return run.status.model_copy(deep=True)

    def stop_session(self, session_id: str) -> None:
        with self._lock:
            run_ids = [
                run_id
                for run_id, run in self._runs.items()
                if run.session is not None
                and run.session.id == session_id
                and run.status.state == "running"
            ]
        for run_id in run_ids:
            self.stop(run_id)

    def close(self) -> None:
        with self._lock:
            run_ids = list(self._runs)
        for run_id in run_ids:
            self.stop(run_id)

    def set_exact_value(
        self,
        run_id: str,
        target_name: str,
        value: int | float,
        *,
        source: str = "user",
    ) -> CheatDiscoveryRunStatus:
        if source not in {"user", "screen"}:
            raise SafetyError("exact-value source must be user or screen")
        with self._lock:
            run = self._get(run_id)
            try:
                target = self._target(run, target_name)
            except NotFoundError:
                if source != "screen":
                    raise
                spec = self._spec(target_name)
                target = self._new_target_status(spec)
                run.status.targets.append(target)
                run.status.target_order.append(target.name)
            if (
                target.exact_value is not None
                and values_equal(target.value_type, target.exact_value, value)
            ):
                if target.state in {
                    DiscoveryTargetState.LOCKED,
                    DiscoveryTargetState.CONFIRMED,
                }:
                    target.notes.append(
                        "The current screen value still matches the locked target; its lock "
                        "was preserved."
                    )
                    target.notes = target.notes[-20:]
                    run.status.updated_at = datetime.now(UTC)
                    self._persist(run)
                return run.status.model_copy(deep=True)
            confirmed_candidates = [
                candidate
                for candidate in target.candidates
                if candidate.write_test_status == "confirmed"
            ]
            if confirmed_candidates:
                target.state = (
                    DiscoveryTargetState.CONFIRMED
                    if any(candidate.promoted for candidate in confirmed_candidates)
                    else DiscoveryTargetState.LOCKED
                )
                target.revisit_after = None
                target.notes.append(
                    "The visible value changed during normal play; the reversible write-"
                    "confirmed locator stayed locked instead of restarting discovery."
                )
                target.notes = target.notes[-20:]
                run.status.updated_at = datetime.now(UTC)
                self._persist(run)
                return run.status.model_copy(deep=True)
            target.exact_value = value
            target.exact_value_source = source
            if target.failed_exact_value is not None and not values_equal(
                target.value_type,
                target.failed_exact_value,
                value,
            ):
                target.failed_exact_value = None
            target.state = (
                DiscoveryTargetState.OBSERVING
                if target.scan_id is not None
                else DiscoveryTargetState.QUEUED
            )
            target.revisit_after = None
            target.notes.append(
                "A stable screen observation was queued for an exact next scan."
                if source == "screen"
                else "A visible exact value was supplied for the next read-only scan."
            )
            run.status.updated_at = datetime.now(UTC)
            self._persist(run)
            return run.status.model_copy(deep=True)

    def record_screen_comparison(
        self,
        run_id: str,
        target_name: str,
        comparison: str,
        screen_value: int | float,
    ) -> CheatDiscoveryRunStatus:
        """Drive an unknown scan from visible meter direction, not guessed equality."""

        signal = comparison.strip().casefold()
        if signal not in {"baseline", "increased", "decreased"}:
            raise SafetyError("screen comparison must be baseline, increased, or decreased")
        with self._lock:
            run = self._get(run_id)
        with run.operation_lock:
            with self._lock:
                run = self._get(run_id)
                try:
                    target = self._target(run, target_name)
                except NotFoundError:
                    spec = self._spec(target_name)
                    target = self._new_target_status(spec)
                    run.status.targets.append(target)
                    run.status.target_order.append(target.name)
                spec = self._spec(target.name)
                if target.state in {
                    DiscoveryTargetState.LOCKED,
                    DiscoveryTargetState.CONFIRMED,
                }:
                    return run.status.model_copy(deep=True)
                session = self._live_session(run)
                existing_scan_id = target.scan_id
                target.exact_value = screen_value
                target.exact_value_source = "screen_temporal"
                target.failed_exact_value = None
                run.status.active_target = target.name

            existing_kind = None
            if existing_scan_id is not None:
                try:
                    existing_kind = self.service.scan_summary(
                        existing_scan_id,
                        limit=0,
                    ).scan_kind
                except Exception:  # noqa: BLE001 - stale scan becomes a fresh baseline
                    existing_scan_id = None

            if existing_scan_id is None or existing_kind is ScanKind.EXACT:
                baseline_key = (spec.value_type, spec.normalized)
                with self._lock:
                    baseline_scan_id = run.screen_baseline_scan_ids.get(baseline_key)
                if baseline_scan_id is not None:
                    try:
                        self.service.scan_summary(baseline_scan_id, limit=0)
                    except Exception:  # noqa: BLE001 - detached/stale snapshot is rebuilt
                        baseline_scan_id = None
                if baseline_scan_id is None:
                    baseline = self.service.start_unknown_scan(
                        session.id,
                        spec.value_type,
                        normalized=spec.normalized,
                    )
                    baseline_scan_id = baseline.id
                    with self._lock:
                        run.screen_baseline_scan_ids[baseline_key] = baseline_scan_id
                summary = self.service.clone_scan(baseline_scan_id)
                with self._lock:
                    run = self._get(run_id)
                    target = self._target(run, target_name)
                    if existing_scan_id is not None:
                        target.rollback_scan_ids = [
                            *target.rollback_scan_ids,
                            existing_scan_id,
                        ][-3:]
                    target.scan_id = summary.id
                    target.scanned_exact_value = None
                    target.generation = summary.generation
                    target.candidate_count = summary.result_count
                    target.candidates = []
                    target.state = DiscoveryTargetState.OBSERVING
                    target.revisit_after = None
                    target.notes.append(
                        "Started a rollbackable unknown-value baseline from the stable HUD "
                        "meter; the estimated screen percentage was not treated as exact "
                        "memory data. Same-type HUD meters reuse one read-only mount snapshot."
                    )
                    if signal != "baseline":
                        target.notes.append(
                            f"The first {signal} screen signal established the baseline; the next "
                            "visible change will refine it."
                        )
                    run.status.updated_at = datetime.now(UTC)
                    self._persist(run)
                    return run.status.model_copy(deep=True)

            if signal == "baseline":
                with self._lock:
                    run = self._get(run_id)
                    target = self._target(run, target_name)
                    target.notes.append("The temporal HUD baseline is already active.")
                    target.notes = target.notes[-20:]
                    run.status.updated_at = datetime.now(UTC)
                    self._persist(run)
                    return run.status.model_copy(deep=True)

            direction = Comparison(signal)
            fork = self.service.clone_scan(existing_scan_id)
            refined = self.service.rescan(fork.id, direction)
            if refined.result_count == 0:
                self.service.discard_scan(fork.id)
                with self._lock:
                    run = self._get(run_id)
                    target = self._target(run, target_name)
                    target.notes.append(
                        f"Ignored one {signal} HUD signal because it eliminated every RAM "
                        "candidate; the previous generation was preserved."
                    )
                    target.notes = target.notes[-20:]
                    run.status.updated_at = datetime.now(UTC)
                    self._persist(run)
                    return run.status.model_copy(deep=True)

            stability = self.service.scan_candidate_stability(
                refined.id,
                limit=max(200, run.pointer_candidate_limit),
            )
            with self._lock:
                run = self._get(run_id)
                target = self._target(run, target_name)
                target.rollback_scan_ids = [
                    *target.rollback_scan_ids,
                    existing_scan_id,
                ][-3:]
                target.scan_id = refined.id
                target.generation = refined.generation
                target.candidate_count = refined.result_count
                target.change_events += 1
                target.last_direction = direction
                target.state = (
                    DiscoveryTargetState.CANDIDATE
                    if refined.result_count <= self.service.settings.max_scan_results
                    else DiscoveryTargetState.OBSERVING
                )
                target.revisit_after = None
                target.notes.append(
                    f"HUD burst observed {signal}; temporal RAM generation {refined.generation} "
                    f"retained {refined.result_count} candidates."
                )
                if refined.result_count <= self.service.settings.max_scan_results:
                    discovered = self._materialize_candidates(run, target, spec, stability)
                    if discovered:
                        target.candidates = self._merge_candidates(
                            target.candidates,
                            discovered,
                            retain_current_generation=True,
                        )
                        self._mark_write_test_ready(target)
                        self._lock_candidate_group_for_run(target)
                        table = register_discovery_candidates(
                            self.service.settings,
                            session,
                            target.candidates,
                            replace_target=target.name,
                        )
                        run.status.table_path = table.saved_path
                target.notes = target.notes[-20:]
                run.status.updated_at = datetime.now(UTC)
                self._persist(run)
                return run.status.model_copy(deep=True)

    def rescan_saved_values(self, run_id: str) -> CheatDiscoveryRunStatus:
        """Requeue every known exact value and refresh any registered save snapshot."""

        with self._lock:
            run = self._get(run_id)
            self._refresh_save_values(run, force=True, initial=False)
            run.status.updated_at = datetime.now(UTC)
            self._persist(run)
            return run.status.model_copy(deep=True)

    def candidate_test_context(
        self,
        run_id: str,
        target_name: str,
        candidate_id: str,
    ) -> CandidateTestContext:
        with self._lock:
            run = self._get(run_id)
            if run.status.state != "running":
                raise SafetyError("the discovery run is not active")
            session = self._live_session(run)
            if not session.write_enabled:
                raise SafetyError("the selected game session is not write-enabled")
            target = self._target(run, target_name)
            eligible = [
                candidate
                for candidate in target.candidates
                if candidate.write_test_status in {"ready", "confirmed"}
                and candidate.id not in target.rejected_candidate_ids
            ]
            if not 1 <= len(eligible) <= MAX_EQUIVALENT_LOCKED_CANDIDATES:
                raise SafetyError("the value does not have a one-to-five candidate test set")
            candidate = next((item for item in eligible if item.id == candidate_id), None)
            if candidate is None:
                raise NotFoundError("the selected candidate is not ready for a write test")
            if candidate.stability is None:
                raise SafetyError("the candidate has no live scan address")
            address = candidate.stability.address
            current_value = self.service.read_value(session.id, address, candidate.value_type)
            if candidate.current_value is None:
                raise SafetyError("the candidate has no saved value for the write test")
            if not values_equal(
                candidate.value_type,
                candidate.current_value,
                current_value,
            ):
                previous_value = candidate.current_value
                candidate.current_value = current_value
                candidate.stability.current_value = current_value
                evidence = (
                    "Write-test preflight refreshed the candidate baseline from "
                    f"{previous_value} to {current_value}; no write occurred."
                )
                candidate.evidence.append(evidence)
                target.notes.append(evidence)
                run.status.updated_at = datetime.now(UTC)
                self._persist(run)
            return CandidateTestContext(
                run_id=run_id,
                target_name=target.name,
                candidate_id=candidate.id,
                session_id=session.id,
                address=address,
                value_type=candidate.value_type,
                current_value=current_value,
                candidate_index=eligible.index(candidate) + 1,
                candidate_count=len(eligible),
            )

    def record_candidate_test(
        self,
        run_id: str,
        target_name: str,
        candidate_id: str,
        *,
        matched_in_game: bool,
        observed_value: int | float,
        verification_source: str = "user",
        restored_after_test: bool = False,
    ) -> CheatDiscoveryRunStatus:
        if verification_source not in {"user", "screen"}:
            raise SafetyError("candidate verification source must be user or screen")
        with self._lock:
            run = self._get(run_id)
            session = self._live_session(run)
            target = self._target(run, target_name)
            candidate = next(
                (item for item in target.candidates if item.id == candidate_id),
                None,
            )
            if candidate is None:
                raise NotFoundError("the tested candidate is no longer active")
            if matched_in_game:
                candidate.current_value = observed_value
                candidate.write_test_status = "confirmed"
                candidate.confidence = 1.0
                candidate.validated_events = max(
                    candidate.validated_events,
                    candidate.validation_rule.minimum_change_events,
                )
                candidate.locked_for_run = True
                candidate.evidence = [
                    *candidate.evidence,
                    (
                        "A local screen observation confirmed that the reversible trace change "
                        "reached the displayed game value."
                        if verification_source == "screen"
                        else "The user confirmed that a controlled write changed the visible "
                        "game value."
                    ),
                    *(
                        ["The original value was restored immediately after the trace check."]
                        if restored_after_test
                        else []
                    ),
                ][-20:]
                target.exact_value = observed_value
                target.exact_value_source = (
                    "screen_write_test" if verification_source == "screen" else "user_write_test"
                )
                target.scanned_exact_value = observed_value
                target.state = DiscoveryTargetState.LOCKED
                target.revisit_after = None
                target.notes.append(
                    f"Candidate {candidate_id[:8]} was confirmed by a controlled in-game "
                    f"write test{' and restored' if restored_after_test else ''}, then locked "
                    "for this run."
                )
            else:
                candidate.write_test_status = "rejected"
                candidate.locked_for_run = False
                if candidate.id not in target.rejected_candidate_ids:
                    target.rejected_candidate_ids.append(candidate.id)
                target.candidates = [item for item in target.candidates if item.id != candidate.id]
                target.candidate_count = max(0, target.candidate_count - 1)
                target.state = (
                    DiscoveryTargetState.LOCKED
                    if any(item.write_test_status == "confirmed" for item in target.candidates)
                    else DiscoveryTargetState.CANDIDATE
                    if target.candidates
                    else DiscoveryTargetState.REVISIT_PENDING
                )
                target.revisit_after = None
                target.notes.append(
                    f"Candidate {candidate_id[:8]} did not change the visible game value; "
                    "its original bytes were restored and it was rejected for this run."
                )
            table = register_discovery_candidates(
                self.service.settings,
                session,
                target.candidates,
                replace_target=target.name,
            )
            run.status.table_path = table.saved_path
            run.status.updated_at = datetime.now(UTC)
            self._persist(run)
            return run.status.model_copy(deep=True)

    def record_inventory_matrix_matches(
        self,
        run_id: str,
        target_name: str,
        matched_candidates: dict[str, str],
        reference_urls: dict[str, str] | None = None,
    ) -> CheatDiscoveryRunStatus:
        """Keep every screen-correlated slot found by a restored odd-delta probe."""

        cleaned = {
            candidate_id: label.strip()
            for candidate_id, label in matched_candidates.items()
            if candidate_id and label.strip()
        }
        if not cleaned:
            return self.status(run_id)
        with self._lock:
            run = self._get(run_id)
            session = self._live_session(run)
            target = self._target(run, target_name)
            candidates = {candidate.id: candidate for candidate in target.candidates}
            unknown = sorted(set(cleaned) - set(candidates))
            if unknown:
                raise NotFoundError("an inventory matrix candidate is no longer active")
            urls = reference_urls or {}
            for candidate_id, label in cleaned.items():
                candidate = candidates[candidate_id]
                candidate.reference_name = label
                candidate.reference_url = urls.get(candidate_id)
                candidate.write_test_status = "confirmed"
                candidate.locked_for_run = True
                candidate.source_correlated = True
                candidate.validated_events += 1
                candidate.confidence = max(candidate.confidence, 0.95)
                candidate.evidence = [
                    *candidate.evidence,
                    f"Reversible odd-delta inventory probe matched this locator to {label}.",
                    "The original stack value was restored after the observation window.",
                    *(
                        [f"Canonical name matched to {candidate.reference_url}."]
                        if candidate.reference_url
                        else []
                    ),
                ][-20:]
                candidate.promoted = self._promotable(candidate)
            target.state = DiscoveryTargetState.LOCKED
            target.notes.append(
                f"Inventory matrix mapped {len(cleaned)} independently valid slot value(s); "
                "none were discarded merely because another slot also matched."
            )
            table = register_discovery_candidates(
                self.service.settings,
                session,
                target.candidates,
                replace_target=target.name,
            )
            run.status.table_path = table.saved_path
            run.status.updated_at = datetime.now(UTC)
            self._persist(run)
            return run.status.model_copy(deep=True)

    def begin_behavior_capture(
        self,
        run_id: str,
        target_name: str,
        label: str,
    ) -> CheatDiscoveryRunStatus:
        """Create a fresh read-only baseline for one explicitly labeled action."""

        cleaned_label = label.strip()
        if not cleaned_label:
            raise SafetyError("a short gameplay action label is required")
        with self._lock:
            run = self._get(run_id)
            target = self._target(run, target_name)
            spec = self._spec(target.name)
            if not spec.behavioral_correlation:
                raise SafetyError(
                    f"{target.name} uses visible-value discovery, not behavior capture"
                )
            session = self._live_session(run)
            previous_scan_id = target.scan_id
            target.behavior_capture_state = "preparing"
            target.behavior_capture_label = cleaned_label
            target.behavior_capture_started_at = datetime.now(UTC)
            target.scan_id = None
            target.state = DiscoveryTargetState.SCANNING
            target.revisit_after = None
            run.status.active_target = target.name
            run.status.updated_at = datetime.now(UTC)
            self._persist(run)

        if previous_scan_id is not None:
            try:
                self.service.discard_scan(previous_scan_id)
            except Exception:  # noqa: BLE001 - a stale baseline is safe to abandon
                pass
        summary = self.service.start_unknown_scan(
            session.id,
            spec.value_type,
            normalized=spec.normalized,
        )
        with self._lock:
            run = self._get(run_id)
            target = self._target(run, target_name)
            if summary.result_count == 0:
                target.behavior_capture_state = None
                target.behavior_capture_started_at = None
                self._collapsed(run, target, "Behavior baseline returned no candidates.")
            else:
                target.scan_id = summary.id
                target.generation = summary.generation
                target.candidate_count = summary.result_count
                target.state = DiscoveryTargetState.OBSERVING
                target.behavior_capture_state = "armed"
                target.notes.append(
                    f"Behavior baseline armed for '{cleaned_label}'. Perform only that action, "
                    "then finish the capture."
                )
            run.status.updated_at = datetime.now(UTC)
            self._persist(run)
            return run.status.model_copy(deep=True)

    def complete_behavior_capture(
        self,
        run_id: str,
        target_name: str,
    ) -> CheatDiscoveryRunStatus:
        """Refine exactly one armed baseline after the labeled action is complete."""

        with self._lock:
            run = self._get(run_id)
            target = self._target(run, target_name)
            spec = self._spec(target.name)
            if not spec.behavioral_correlation:
                raise SafetyError(
                    f"{target.name} uses visible-value discovery, not behavior capture"
                )
            if target.behavior_capture_state != "armed" or target.scan_id is None:
                raise SafetyError("set a resting baseline before finishing this action")
            scan_id = target.scan_id
            label = target.behavior_capture_label or target.name
            session = self._live_session(run)
            target.behavior_capture_state = "finishing"
            run.status.active_target = target.name

        refined = self.service.rescan(scan_id, Comparison.CHANGED)
        stability = self.service.scan_candidate_stability(
            refined.id,
            limit=max(200, run.pointer_candidate_limit),
        )
        with self._lock:
            run = self._get(run_id)
            target = self._target(run, target_name)
            target.scan_id = None
            target.generation = refined.generation
            target.candidate_count = refined.result_count
            target.behavior_capture_state = "complete"
            target.behavior_capture_started_at = None
            target.revisit_after = None
            if refined.result_count == 0:
                target.state = DiscoveryTargetState.REVISIT_PENDING
                target.restart_count += 1
                target.notes.append(
                    f"'{label}' produced no changed candidates; capture another clean action."
                )
            else:
                target.change_events += 1
                target.behavior_event_count += 1
                target.last_direction = self._dominant_direction(stability)
                target.state = DiscoveryTargetState.CANDIDATE
                target.notes.append(
                    f"Captured explicit action '{label}'; {refined.result_count} candidates "
                    "changed inside that window."
                )
                discovered = self._materialize_candidates(
                    run,
                    target,
                    spec,
                    stability,
                    explicit_behavior_capture=True,
                )
                if discovered:
                    target.candidates = self._merge_candidates(
                        target.candidates,
                        discovered,
                        accumulate_events=True,
                        retain_current_generation=True,
                    )
                    self._lock_candidate_group_for_run(target)
                    table = register_discovery_candidates(
                        self.service.settings,
                        session,
                        target.candidates,
                        replace_target=target.name,
                    )
                    run.status.table_path = table.saved_path
                    if any(candidate.promoted for candidate in target.candidates):
                        target.state = DiscoveryTargetState.CONFIRMED
            try:
                self.service.discard_scan(refined.id)
            except Exception:  # noqa: BLE001 - the completed cache may already be gone
                pass
            run.status.updated_at = datetime.now(UTC)
            self._persist(run)
            return run.status.model_copy(deep=True)

    def cancel_behavior_capture(
        self,
        run_id: str,
        target_name: str,
    ) -> CheatDiscoveryRunStatus:
        with self._lock:
            run = self._get(run_id)
            target = self._target(run, target_name)
            spec = self._spec(target.name)
            if not spec.behavioral_correlation:
                raise SafetyError(
                    f"{target.name} uses visible-value discovery, not behavior capture"
                )
            scan_id = target.scan_id
            target.scan_id = None
            target.behavior_capture_state = None
            target.behavior_capture_label = None
            target.behavior_capture_started_at = None
            target.state = DiscoveryTargetState.QUEUED
            target.notes.append("Behavior capture was cancelled without recording an event.")
            run.status.updated_at = datetime.now(UTC)
            self._persist(run)
        if scan_id is not None:
            try:
                self.service.discard_scan(scan_id)
            except Exception:  # noqa: BLE001 - cancellation is already complete
                pass
        return self.status(run_id)

    def run_cycle(self, run_id: str) -> CheatDiscoveryRunStatus:
        supervised = self.supervise(run_id)
        if supervised.state != "running":
            return supervised
        with self._lock:
            run = self._get(run_id)
            if run.status.state != "running":
                return run.status.model_copy(deep=True)
            now = datetime.now(UTC)
            if run.next_save_check_at is None or run.next_save_check_at <= now:
                self._refresh_save_values(run, force=False, initial=False)
                run.next_save_check_at = now + timedelta(seconds=5)
            target = self._next_due_target(run)
            run.status.updated_at = datetime.now(UTC)
            if target is None:
                run.status.active_target = None
                self._persist(run)
                return run.status.model_copy(deep=True)
            run.status.cycle_count += 1
            run.status.active_target = target.name

        try:
            with run.operation_lock:
                self._cycle_target(run, target)
        except Exception as exc:  # noqa: BLE001 - keep the long-running loop alive
            with self._lock:
                target.state = DiscoveryTargetState.REVISIT_PENDING
                target.revisit_after = datetime.now(UTC) + timedelta(seconds=run.revisit_seconds)
                target.notes.append(f"Read-only discovery pass failed and will retry: {exc}")
                run.status.warnings.append(f"{target.name}: {exc}")
                run.status.warnings = run.status.warnings[-20:]
        with self._lock:
            run.status.updated_at = datetime.now(UTC)
            self._persist(run)
            return run.status.model_copy(deep=True)

    def supervise(self, run_id: str) -> CheatDiscoveryRunStatus:
        """Keep a discovery run alive across process closure and relaunch."""

        with self._lock:
            run = self._get(run_id)
            if run.status.state == "stopped":
                return run.status.model_copy(deep=True)
            session = run.session

        if session is not None:
            try:
                if self.service.regions(session.id):
                    return self.status(run_id)
            except Exception:  # noqa: BLE001 - any dead handle returns to waiting mode
                pass
            self._mark_waiting(run)

        process = next(
            (
                item
                for item in self.service.list_processes()
                if item.name.casefold() == run.process_name.casefold() and item.attachable
            ),
            None,
        )
        if process is None:
            return self.status(run_id)
        try:
            desired_write_mode = run.status.write_enabled and self.service.settings.allow_writes
            attached = self.service.attach(
                process.pid,
                write_enabled=desired_write_mode,
                game_key=run.game_key,
                game_name=run.game_name,
                start_catalog_discovery=False,
            )
        except Exception as exc:  # noqa: BLE001 - retry later without killing the run
            with self._lock:
                warning = f"Read-only reattach is waiting: {exc}"
                if not run.status.warnings or run.status.warnings[-1] != warning:
                    run.status.warnings.append(warning)
                    run.status.warnings = run.status.warnings[-20:]
                run.status.updated_at = datetime.now(UTC)
                self._persist(run)
                return run.status.model_copy(deep=True)

        with self._lock:
            run.session = attached
            run.status.session_id = attached.id
            run.status.pid = attached.pid
            run.status.process_started_at = attached.process_started_at
            run.status.write_enabled = attached.write_enabled
            run.status.state = "running"
            run.status.active_target = None
            run.public_patterns_checked.clear()
            for target in run.status.targets:
                if target.state is not DiscoveryTargetState.CONFIRMED:
                    target.scan_id = None
                    target.generation = 0
                    target.candidate_count = 0
                    target.scanned_exact_value = None
                    target.state = DiscoveryTargetState.QUEUED
                    target.revisit_after = None
                    target.behavior_capture_state = None
                    target.behavior_capture_label = None
                    target.behavior_capture_started_at = None
            self._refresh_save_values(run, force=True, initial=True)
            table = ensure_game_value_table(self.service.settings, attached)
            run.status.table_path = table.saved_path
            self._revalidate_persistent_locators(run)
            run.status.updated_at = datetime.now(UTC)
            self._persist(run)
            return run.status.model_copy(deep=True)

    def _mark_waiting(self, run: _Run) -> None:
        with self._lock:
            session = run.session
            run.session = None
            run.status.state = "waiting_for_process"
            run.status.session_id = None
            run.status.pid = None
            run.status.process_started_at = None
            run.status.active_target = None
            for target in run.status.targets:
                if target.state is not DiscoveryTargetState.CONFIRMED:
                    retained = bool(target.candidates)
                    target.scan_id = None
                    target.generation = 0
                    target.candidate_count = 0
                    target.scanned_exact_value = None
                    target.state = DiscoveryTargetState.QUEUED
                    target.revisit_after = None
                    target.behavior_capture_state = None
                    target.behavior_capture_label = None
                    target.behavior_capture_started_at = None
                    for candidate in target.candidates:
                        candidate.locked_for_run = False
                        if candidate.write_test_status == "ready":
                            candidate.write_test_status = "untested"
                    target.candidate_count = len(target.candidates)
                    if retained:
                        target.notes.append(
                            "The game process ended; retained locators now require live "
                            "revalidation before they can lock or be write-tested again."
                        )
            mode = "write-testing" if run.status.write_enabled else "read-only"
            warning = f"{run.process_name} closed; waiting to resume {mode} discovery."
            if not run.status.warnings or run.status.warnings[-1] != warning:
                run.status.warnings.append(warning)
                run.status.warnings = run.status.warnings[-20:]
            run.status.updated_at = datetime.now(UTC)
            self._persist(run)
        if session is not None:
            self.service.release_discovery_session(session.id)

    def _worker(self, run_id: str) -> None:
        while True:
            with self._lock:
                run = self._get(run_id)
                if run.stop_event.is_set() or run.status.state == "stopped":
                    return
                interval = run.interval_seconds
            self.run_cycle(run_id)
            if run.stop_event.wait(interval):
                return

    def _cycle_target(self, run: _Run, target: DiscoveryTargetStatus) -> None:
        spec = self._spec(target.name)
        if spec.behavioral_correlation:
            return
        session = self._live_session(run)
        self._check_public_patterns(run, target, spec)
        if target.scan_id is None:
            self._start_target_scan(run, target, spec)
            return
        if target.state not in {
            DiscoveryTargetState.OBSERVING,
            DiscoveryTargetState.CANDIDATE,
        }:
            return
        if target.revisit_after and target.revisit_after > datetime.now(UTC):
            return

        original_scan_id = target.scan_id
        original = self.service.scan_summary(original_scan_id, limit=0)
        if original.scan_kind is not ScanKind.EXACT:
            target.revisit_after = datetime.now(UTC) + timedelta(seconds=run.observation_seconds)
            note = "Waiting for an explicit labeled gameplay action before the next scan."
            if not target.notes or target.notes[-1] != note:
                target.notes.append(note)
            return
        if target.exact_value is None or target.scanned_exact_value is None:
            target.revisit_after = datetime.now(UTC) + timedelta(seconds=run.observation_seconds)
            return
        if values_equal(target.value_type, target.scanned_exact_value, target.exact_value):
            target.revisit_after = datetime.now(UTC) + timedelta(seconds=run.observation_seconds)
            note = (
                f"Holding {target.candidate_count} candidates until {target.name} changes; "
                "no idle timer refinement was applied."
            )
            if not target.notes or target.notes[-1] != note:
                target.notes.append(note)
            return

        previous_exact = target.scanned_exact_value
        fork = self.service.clone_scan(original_scan_id)
        refined = self.service.rescan(fork.id, Comparison.EXACT, target.exact_value)
        if refined.result_count == 0:
            self.service.discard_scan(fork.id)
            rebased = self.service.start_scan(
                session.id,
                spec.value_type,
                target.exact_value,
            )
            if rebased.result_count == 0:
                self.service.discard_scan(rebased.id)
                target.failed_exact_value = target.exact_value
                target.revisit_after = None
                note = (
                    f"The observed {target.name} value {target.exact_value} matched no saved "
                    "candidate or fresh baseline; waiting for a new value or representation."
                )
                if not target.notes or target.notes[-1] != note:
                    target.notes.append(note)
                return
            target.rollback_scan_ids = [
                *target.rollback_scan_ids,
                original_scan_id,
            ][-3:]
            target.scan_id = rebased.id
            target.scanned_exact_value = target.exact_value
            target.failed_exact_value = None
            target.generation = rebased.generation
            target.candidate_count = rebased.result_count
            target.candidates = []
            target.state = DiscoveryTargetState.OBSERVING
            target.revisit_after = datetime.now(UTC) + timedelta(seconds=run.observation_seconds)
            target.notes.append(
                f"The prior candidates did not match {target.exact_value}; preserved scan "
                f"{original_scan_id[:8]} for rollback and immediately rebased with "
                f"{rebased.result_count} fresh candidates."
            )
            table = register_discovery_candidates(
                self.service.settings,
                session,
                [],
                replace_target=target.name,
            )
            run.status.table_path = table.saved_path
            return

        target.scan_id = refined.id
        target.scanned_exact_value = target.exact_value
        target.generation = refined.generation
        target.candidate_count = refined.result_count
        target.change_events += 1
        stability = self.service.scan_candidate_stability(
            refined.id,
            limit=max(200, run.pointer_candidate_limit),
        )
        if float(target.exact_value) > float(previous_exact):
            target.last_direction = Comparison.INCREASED
        elif float(target.exact_value) < float(previous_exact):
            target.last_direction = Comparison.DECREASED
        else:
            target.last_direction = Comparison.CHANGED
        target.state = (
            DiscoveryTargetState.CANDIDATE
            if refined.result_count <= self.service.settings.max_scan_results
            else DiscoveryTargetState.OBSERVING
        )
        target.revisit_after = datetime.now(UTC) + timedelta(seconds=run.observation_seconds)
        target.notes.append(
            f"Exact next scan matched {previous_exact} -> {target.exact_value} "
            f"({target.last_direction.value}); {refined.result_count} candidates remain."
        )
        if refined.result_count <= self.service.settings.max_scan_results:
            discovered = self._materialize_candidates(run, target, spec, stability)
            if discovered:
                target.candidates = self._merge_candidates(
                    target.candidates,
                    discovered,
                    retain_current_generation=True,
                )
                self._mark_write_test_ready(target)
                self._lock_candidate_group_for_run(target)
                table = register_discovery_candidates(
                    self.service.settings,
                    session,
                    target.candidates,
                    replace_target=target.name,
                )
                run.status.table_path = table.saved_path
                if any(candidate.promoted for candidate in target.candidates):
                    target.state = DiscoveryTargetState.CONFIRMED

    def _start_target_scan(
        self,
        run: _Run,
        target: DiscoveryTargetStatus,
        spec: TargetSpec,
    ) -> None:
        session = self._live_session(run)
        target.state = DiscoveryTargetState.SCANNING
        exact_value = target.exact_value
        if spec.requires_exact_value and exact_value is None:
            target.state = DiscoveryTargetState.REVISIT_PENDING
            target.revisit_after = datetime.now(UTC) + timedelta(seconds=run.revisit_seconds)
            note = "An exact visible value is required; the unsafe full-memory scan was skipped."
            if not target.notes or target.notes[-1] != note:
                target.notes.append(note)
            return
        if exact_value is not None:
            summary = self.service.reuse_exact_scan(
                session.id,
                spec.value_type,
                exact_value,
            )
            if summary is None:
                summary = self.service.start_scan(
                    session.id,
                    spec.value_type,
                    exact_value,
                )
        else:
            summary = self.service.start_unknown_scan(
                session.id,
                spec.value_type,
                normalized=spec.normalized,
            )
        if summary.result_count == 0:
            if exact_value is not None:
                target.failed_exact_value = exact_value
            self._collapsed(run, target, "Fresh scan returned no candidates.")
            return
        if self._apply_nms_currency_layout(run, target, summary.id, summary.result_count):
            return
        target.scan_id = summary.id
        target.scanned_exact_value = exact_value
        target.failed_exact_value = None
        target.generation = summary.generation
        target.candidate_count = summary.result_count
        target.state = DiscoveryTargetState.OBSERVING
        target.revisit_after = datetime.now(UTC) + timedelta(seconds=run.observation_seconds)
        cache_note = " Reused a validated cache." if summary.cache_reused else ""
        target.notes.append(
            f"Started a read-only {summary.scan_kind.value} scan with "
            f"{summary.result_count} candidates.{cache_note}"
        )

    def _apply_nms_currency_layout(
        self,
        run: _Run,
        source_target: DiscoveryTargetStatus,
        source_scan_id: str,
        source_result_count: int,
        *,
        source_was_broad_scan: bool = True,
    ) -> bool:
        """Validate the inert CT currency layout with focused read-only checks."""

        if (
            source_target.name != "Units"
            or run.process_name.casefold() != "nms.exe"
            or not 1 <= source_result_count <= MAX_EQUIVALENT_LOCKED_CANDIDATES
        ):
            return False
        targets: dict[str, DiscoveryTargetStatus] = {}
        for name in NMS_CURRENCY_LAYOUT:
            try:
                target = self._target(run, name)
            except NotFoundError:
                return False
            if target.exact_value is None or target.exact_value_source not in {
                "user",
                "nms_save",
                "save_snapshot",
                "screen",
                "user_write_test",
                "screen_write_test",
                SAME_PROCESS_LAYOUT_SOURCE,
            }:
                return False
            targets[name] = target

        session = self._live_session(run)
        source = self.service.scan_summary(
            source_scan_id,
            limit=MAX_EQUIVALENT_LOCKED_CANDIDATES,
        )
        matching_bases: list[int] = []
        for source_candidate in source.candidates:
            base_address = source_candidate.address
            matches_layout = True
            for name, relative_offset in NMS_CURRENCY_LAYOUT.items():
                target = targets[name]
                try:
                    current = self.service.read_value(
                        session.id,
                        base_address + relative_offset,
                        target.value_type,
                    )
                except Exception:  # noqa: BLE001 - one unreadable neighbor is not a match
                    matches_layout = False
                    break
                if not values_equal(target.value_type, current, target.exact_value):
                    matches_layout = False
                    break
            if matches_layout:
                matching_bases.append(base_address)
        if not matching_bases:
            source_target.notes.append(
                "The imported CT +0/+4/+8 currency relationship did not match the current "
                "exact candidates; independent learning remains active."
            )
            return False

        staged: dict[str, tuple] = {}
        for name, relative_offset in NMS_CURRENCY_LAYOUT.items():
            target = targets[name]
            addresses = [base + relative_offset for base in matching_bases]
            focused = self.service.register_targeted_exact_candidates(
                session.id,
                target.value_type,
                target.exact_value,
                addresses,
            )
            if focused.result_count != len(addresses):
                self.service.discard_scan(focused.id)
                for _, prior_focused, _ in staged.values():
                    self.service.discard_scan(prior_focused.id)
                return False
            stability = self.service.scan_candidate_stability(focused.id, limit=len(addresses))
            candidates: list[DiscoveryCandidate] = []
            for stats in stability:
                existing = self._candidate_resolving_to(run, target, stats.address)
                locator = (
                    existing.locator
                    if existing is not None
                    else MemoryLocator(kind=LocatorKind.RAW_ADDRESS, address=stats.address)
                )
                starts = set(existing.validated_process_starts if existing is not None else [])
                if session.process_started_at is not None:
                    starts.add(session.process_started_at)
                candidate = DiscoveryCandidate(
                    id=(
                        existing.id
                        if existing is not None
                        else self._candidate_id(target.name, locator)
                    ),
                    target=target.name,
                    value_type=target.value_type,
                    locator=locator,
                    current_value=stats.current_value,
                    stability=stats,
                    validation_rule=self._validation_rule(self._spec(target.name)),
                    confidence=max(0.9, existing.confidence if existing is not None else 0),
                    validated_events=max(
                        1, existing.validated_events if existing is not None else 0
                    ),
                    validated_launches=len(starts),
                    validated_process_starts=sorted(starts),
                    source_correlated=True,
                    write_test_status=(
                        existing.write_test_status if existing is not None else "untested"
                    ),
                    promoted=existing.promoted if existing is not None else False,
                    evidence=[
                        *(existing.evidence if existing is not None else []),
                        "Matched exact Units, Nanites, and Quicksilver values in one live "
                        "contiguous +0/+4/+8 block.",
                        "The relative layout came from an inert CT reference; no table script "
                        "was executed.",
                        "Only focused read-only validation was performed.",
                    ],
                )
                if candidate.id not in target.rejected_candidate_ids:
                    candidates.append(candidate)
            if not candidates:
                self.service.discard_scan(focused.id)
                for _, prior_focused, _ in staged.values():
                    self.service.discard_scan(prior_focused.id)
                return False
            staged[name] = (target, focused, candidates)

        for target, focused, candidates in staged.values():
            target.scan_id = focused.id
            target.scanned_exact_value = target.exact_value
            target.failed_exact_value = None
            target.generation = focused.generation
            target.candidates = candidates
            target.candidate_count = len(candidates)
            target.change_events = max(1, target.change_events)
            target.state = DiscoveryTargetState.CANDIDATE
            target.revisit_after = None
            self._mark_write_test_ready(target)
            self._lock_candidate_group_for_run(target)
            if any(candidate.promoted for candidate in target.candidates):
                target.state = DiscoveryTargetState.CONFIRMED
            target.notes.append(
                f"Locked {len(candidates)} CT-structured currency block candidate(s) "
                "read-only; the three currency values were validated together."
            )
            table = register_discovery_candidates(
                self.service.settings,
                session,
                target.candidates,
                replace_target=target.name,
            )
            run.status.table_path = table.saved_path
        self.service.discard_scan(source_scan_id)
        run.status.warnings.append(
            "Used one Units scan plus focused +4/+8 reads for the NMS currency block; "
            "no independent Nanites or Quicksilver full scan was needed."
            if source_was_broad_scan
            else "Reused a validated Units locator plus focused +4/+8 reads for the NMS "
            "currency block; no broad currency scan was needed."
        )
        run.status.warnings = run.status.warnings[-20:]
        return True

    def _apply_nms_currency_layout_from_known_locators(self, run: _Run) -> bool:
        if run.process_name.casefold() != "nms.exe":
            return False
        try:
            units = self._target(run, "Units")
        except NotFoundError:
            return False
        if units.exact_value is None:
            return False
        addresses: list[int] = []
        session = self._live_session(run)
        for candidate in units.candidates:
            try:
                address = self.service.locators.resolve(session, candidate.locator)
                current = self.service.read_value(session.id, address, units.value_type)
            except Exception:  # noqa: BLE001 - stale locators are ignored
                continue
            if values_equal(units.value_type, current, units.exact_value):
                addresses.append(address)
        addresses = sorted(set(addresses))[:MAX_EQUIVALENT_LOCKED_CANDIDATES]
        if not addresses:
            return False
        focused = self.service.register_targeted_exact_candidates(
            session.id,
            units.value_type,
            units.exact_value,
            addresses,
        )
        applied = self._apply_nms_currency_layout(
            run,
            units,
            focused.id,
            focused.result_count,
            source_was_broad_scan=False,
        )
        if not applied:
            self.service.discard_scan(focused.id)
        return applied

    def _candidate_resolving_to(
        self,
        run: _Run,
        target: DiscoveryTargetStatus,
        address: int,
    ) -> DiscoveryCandidate | None:
        session = self._live_session(run)
        for candidate in target.candidates:
            try:
                if self.service.locators.resolve(session, candidate.locator) == address:
                    return candidate
            except Exception:  # noqa: BLE001 - stale locator cannot match this address
                continue
        return None

    def _collapsed(self, run: _Run, target: DiscoveryTargetStatus, note: str) -> None:
        target.scan_id = None
        target.scanned_exact_value = None
        target.candidate_count = 0
        target.restart_count += 1
        target.state = DiscoveryTargetState.REVISIT_PENDING
        target.revisit_after = datetime.now(UTC) + timedelta(seconds=run.revisit_seconds)
        target.notes.append(f"{note} The controller will restart it on a later pass.")

    def _materialize_candidates(
        self,
        run: _Run,
        target: DiscoveryTargetStatus,
        spec: TargetSpec,
        stability: list[ScanCandidateStability],
        *,
        explicit_behavior_capture: bool = False,
    ) -> list[DiscoveryCandidate]:
        if not stability:
            return []
        session = self._live_session(run)
        found: list[DiscoveryCandidate] = []
        for stats in stability[: run.pointer_candidate_limit]:
            source_correlated = explicit_behavior_capture or self._source_correlated(
                target,
                spec,
                stats,
            )
            locators = self.service.locators.find_pointer_chains(
                session,
                stats.address,
                max_depth=3,
                max_offset=0x2000,
                max_results=3,
            )
            if not locators:
                locators = [MemoryLocator(kind=LocatorKind.RAW_ADDRESS, address=stats.address)]
            for locator in locators:
                rule = self._validation_rule(spec)
                launches = [session.process_started_at] if session.process_started_at else []
                confidence = self._score_candidate(
                    stats,
                    locator,
                    validated_launches=len(launches),
                    source_correlated=source_correlated,
                )
                candidate = DiscoveryCandidate(
                    id=self._candidate_id(target.name, locator),
                    target=target.name,
                    value_type=spec.value_type,
                    locator=locator,
                    current_value=stats.current_value,
                    stability=stats,
                    validation_rule=rule,
                    confidence=confidence,
                    validated_events=(1 if explicit_behavior_capture else stats.changed),
                    validated_launches=len(launches),
                    validated_process_starts=launches,
                    source_correlated=source_correlated,
                    evidence=[
                        f"Observed {stats.changed} value-change events in this launch.",
                        (
                            f"Direction counts: decreased={stats.decreased}, "
                            f"increased={stats.increased}."
                        ),
                        (
                            "Resolved through a main-module pointer chain."
                            if locator.kind is LocatorKind.POINTER_CHAIN
                            else "No restart-stable pointer was found in the bounded scan."
                        ),
                        "No memory write was performed.",
                        (
                            f"Exact value correlated from {target.exact_value_source}."
                            if target.exact_value_source
                            in {
                                "nms_save",
                                "save_snapshot",
                                "user",
                                "screen",
                                "screen_temporal",
                                "user_write_test",
                                "screen_write_test",
                            }
                            else (
                                (
                                    f"Explicit behavior window '{target.behavior_capture_label}' "
                                    "correlated this candidate."
                                )
                                if explicit_behavior_capture
                                else "Target identity is not yet source-correlated."
                            )
                        ),
                        *(
                            [EXPLICIT_BEHAVIOR_VALIDATION_MARKER]
                            if explicit_behavior_capture
                            else []
                        ),
                    ],
                )
                candidate.promoted = self._promotable(candidate)
                found.append(candidate)
        return found

    @staticmethod
    def _source_correlated(
        target: DiscoveryTargetStatus,
        spec: TargetSpec,
        stats: ScanCandidateStability,
    ) -> bool:
        del spec, stats
        return target.exact_value_source in {
            "nms_save",
            "save_snapshot",
            "user",
            "screen",
            "screen_temporal",
            "user_write_test",
            "screen_write_test",
            SAME_PROCESS_LAYOUT_SOURCE,
        }

    def _check_public_patterns(
        self,
        run: _Run,
        target: DiscoveryTargetStatus,
        spec: TargetSpec,
    ) -> None:
        session = self._live_session(run)
        key = target.name.casefold()
        if key in run.public_patterns_checked:
            return
        run.public_patterns_checked.add(key)
        for public in _PUBLIC_PATTERNS:
            if public.target.casefold() != key:
                continue
            matches, truncated = self.service.locators.find_aob(
                session,
                public.pattern,
                module=public.module,
            )
            if not matches:
                target.notes.append(f"Public {public.source_date} AoB did not match this build.")
                continue
            locator = MemoryLocator(
                kind=LocatorKind.AOB,
                module=public.module,
                aob_pattern=public.pattern,
                match_count=len(matches),
            )
            launches = [session.process_started_at] if session.process_started_at else []
            confidence = 0.55 if len(matches) == 1 and not truncated else 0.35
            candidate = DiscoveryCandidate(
                id=self._candidate_id(target.name, locator),
                target=target.name,
                value_type=spec.value_type,
                locator=locator,
                validation_rule=self._validation_rule(spec),
                confidence=confidence,
                validated_launches=len(launches),
                validated_process_starts=launches,
                evidence=[
                    public.description,
                    f"Source: {public.source_url}",
                    f"Live match count: {len(matches)}.",
                    "The original script was not executed.",
                ],
            )
            target.candidates = self._merge_candidates(target.candidates, [candidate])
            register_discovery_candidates(
                self.service.settings,
                session,
                [candidate],
            )

    def _revalidate_persistent_locators(self, run: _Run) -> None:
        session = self._live_session(run)
        behavioral_targets = {
            target.name
            for target in run.status.targets
            if self._spec(target.name).behavioral_correlation
        }
        table = quarantine_legacy_behavioral_discoveries(
            self.service.settings,
            session,
            behavioral_targets,
            EXPLICIT_BEHAVIOR_VALIDATION_MARKER,
        )
        updated: list[DiscoveryCandidate] = []
        current_start = session.process_started_at
        target_names = {target.name.casefold(): target.name for target in run.status.targets}
        behavioral_keys = {name.casefold() for name in behavioral_targets}
        locked_keys = {
            target.name.casefold()
            for target in run.status.targets
            if target.state is DiscoveryTargetState.LOCKED
        }
        for entry in [*table.confirmed_features, *table.candidate_features]:
            if entry.locator is None or entry.validation_rule is None:
                continue
            if entry.name.casefold() in locked_keys:
                continue
            if (
                entry.name.casefold() in behavioral_keys
                and EXPLICIT_BEHAVIOR_VALIDATION_MARKER not in entry.validation_rule.notes
            ):
                continue
            if entry.locator.kind is LocatorKind.RAW_ADDRESS:
                continue
            try:
                address = self.service.locators.resolve(session, entry.locator)
                current_value = None
                if entry.locator.kind is not LocatorKind.AOB:
                    current_value = self.service.read_value(
                        session.id,
                        address,
                        entry.value_type,
                    )
                    if not self._value_in_rule(current_value, entry.validation_rule):
                        continue
            except Exception:  # noqa: BLE001 - stale candidates simply remain unpromoted
                continue
            starts = list(entry.validated_process_starts)
            if current_start is not None and current_start not in starts:
                starts.append(current_start)
            confidence = min(1.0, max(entry.confidence, entry.stability_score) + 0.1)
            target_name = next(
                (
                    target_names[name.casefold()]
                    for name in entry.suggested_features
                    if name.casefold() in target_names
                ),
                entry.name,
            )
            candidate = DiscoveryCandidate(
                id=entry.source_id or entry.id,
                target=target_name,
                value_type=entry.value_type,
                locator=entry.locator,
                current_value=current_value,
                validation_rule=entry.validation_rule,
                confidence=confidence,
                validated_events=entry.validated_events,
                validated_launches=len(starts),
                validated_process_starts=starts,
                source_correlated=entry.source_correlated,
                write_test_status=entry.write_test_status,
                reference_name=(entry.name if entry.name != target_name else None),
                evidence=[
                    *entry.evidence,
                    "Locator resolved and passed its validation rule on this launch.",
                ][-20:],
            )
            candidate.promoted = self._promotable(candidate)
            updated.append(candidate)
        if updated:
            register_discovery_candidates(self.service.settings, session, updated)
            for candidate in updated:
                try:
                    target = self._target(run, candidate.target)
                except NotFoundError:
                    continue
                target.candidates = self._merge_candidates(target.candidates, [candidate])
                if candidate.promoted:
                    target.state = DiscoveryTargetState.CONFIRMED
            currency_targets = [
                target
                for target in run.status.targets
                if target.name in NMS_CURRENCY_LAYOUT
            ]
            if not currency_targets or not all(
                target.state is DiscoveryTargetState.LOCKED for target in currency_targets
            ):
                self._apply_nms_currency_layout_from_known_locators(run)

    def _restore_same_process_exact_locks(self, run: _Run) -> int:
        """Carry exact current-launch locks across a companion-only restart."""

        session = self._live_session(run)
        directory = self._run_path(run.game_key, "candidate").parent
        try:
            paths = sorted(
                directory.glob("*.json"),
                key=lambda path: path.stat().st_mtime,
                reverse=True,
            )[:20]
        except OSError:
            return 0
        previous_runs: list[CheatDiscoveryRunStatus] = []
        for path in paths:
            try:
                previous = CheatDiscoveryRunStatus.model_validate_json(
                    path.read_text(encoding="utf-8")
                )
            except (OSError, ValueError):
                continue
            if (
                previous.id == run.status.id
                or previous.process_name.casefold() != session.process_name.casefold()
                or previous.pid != session.pid
                or previous.process_started_at != session.process_started_at
            ):
                continue
            previous_runs.append(previous)
        restored_layout = self._restore_same_process_nms_currency_layout(
            run,
            previous_runs,
        )
        if restored_layout:
            return restored_layout
        for previous in previous_runs:
            restored_targets: list[DiscoveryTargetStatus] = []
            for previous_target in previous.targets:
                if (
                    previous_target.exact_value_source
                    not in {
                        "user",
                        "nms_save",
                        "save_snapshot",
                        "screen",
                        "user_write_test",
                        "screen_write_test",
                        SAME_PROCESS_LAYOUT_SOURCE,
                    }
                    or previous_target.exact_value is None
                    or not 1 <= previous_target.candidate_count <= MAX_EQUIVALENT_LOCKED_CANDIDATES
                ):
                    continue
                try:
                    target = self._target(run, previous_target.name)
                except NotFoundError:
                    continue
                matching: list[DiscoveryCandidate] = []
                for candidate in previous_target.candidates:
                    if (
                        candidate.id in previous_target.rejected_candidate_ids
                        or candidate.write_test_status not in {"ready", "confirmed"}
                        or not candidate.source_correlated
                        or candidate.stability is None
                    ):
                        continue
                    try:
                        current_value = self.service.read_value(
                            session.id,
                            candidate.stability.address,
                            candidate.value_type,
                        )
                    except Exception:  # noqa: BLE001 - stale raw candidates are not restored
                        continue
                    if not values_equal(
                        candidate.value_type,
                        current_value,
                        previous_target.exact_value,
                    ):
                        continue
                    restored = candidate.model_copy(deep=True)
                    restored.current_value = current_value
                    restored.locked_for_run = True
                    restored.promoted = False
                    restored.evidence = [
                        *restored.evidence,
                        (
                            "Re-read and matched after a companion-only restart of the same "
                            "game process."
                        ),
                    ][-20:]
                    matching.append(restored)
                if len(matching) != previous_target.candidate_count:
                    continue
                target.exact_value = previous_target.exact_value
                target.exact_value_source = previous_target.exact_value_source
                target.scanned_exact_value = previous_target.scanned_exact_value
                target.scan_id = None
                target.generation = previous_target.generation
                target.candidate_count = len(matching)
                target.change_events = previous_target.change_events
                target.last_direction = previous_target.last_direction
                target.candidates = matching
                target.state = DiscoveryTargetState.LOCKED
                target.revisit_after = None
                target.notes = [
                    *previous_target.notes,
                    (
                        f"Restored {len(matching)} exact read-only candidate(s) after a "
                        "companion-only restart; the game process identity and live values "
                        "still match."
                    ),
                ][-30:]
                restored_targets.append(target)
            if not restored_targets:
                continue
            register_discovery_candidates(
                self.service.settings,
                session,
                [candidate for target in restored_targets for candidate in target.candidates],
            )
            note = (
                f"Restored {len(restored_targets)} exact read-only target lock(s) from the "
                "same running game process."
            )
            run.status.warnings.append(note)
            run.status.warnings = run.status.warnings[-20:]
            return len(restored_targets)
        return 0

    def _restore_same_process_nms_currency_layout(
        self,
        run: _Run,
        previous_runs: list[CheatDiscoveryRunStatus],
    ) -> int:
        """Refresh a previously verified CT-layout block in the same game process."""

        if run.process_name.casefold() != "nms.exe" or not previous_runs:
            return 0
        try:
            targets = {name: self._target(run, name) for name in NMS_CURRENCY_LAYOUT}
        except NotFoundError:
            return 0
        supported_addresses = {name: set() for name in NMS_CURRENCY_LAYOUT}
        confirmed_addresses = {name: set() for name in NMS_CURRENCY_LAYOUT}
        for previous in previous_runs:
            for target in previous.targets:
                if target.name not in supported_addresses:
                    continue
                for candidate in target.candidates:
                    locator = candidate.locator
                    if (
                        locator.kind is not LocatorKind.RAW_ADDRESS
                        or locator.address is None
                        or candidate.stability is None
                        or candidate.stability.address != locator.address
                        or not candidate.locked_for_run
                        or not candidate.source_correlated
                        or candidate.write_test_status not in {"ready", "confirmed"}
                    ):
                        continue
                    supported_addresses[target.name].add(locator.address)
                    if candidate.write_test_status == "confirmed":
                        confirmed_addresses[target.name].add(locator.address)

        session = self._live_session(run)
        blocks: dict[tuple[int | float, ...], list[int]] = {}
        for base in sorted(supported_addresses["Units"]):
            support_count = sum(
                base + offset in supported_addresses[name]
                for name, offset in NMS_CURRENCY_LAYOUT.items()
            )
            if support_count < 2:
                continue
            values: list[int | float] = []
            seed_matches = 0
            for name, offset in NMS_CURRENCY_LAYOUT.items():
                target = targets[name]
                try:
                    current = self.service.read_value(
                        session.id,
                        base + offset,
                        target.value_type,
                    )
                except Exception:  # noqa: BLE001 - stale same-process evidence is ignored
                    values = []
                    break
                if not self._value_in_rule(current, self._validation_rule(self._spec(name))):
                    values = []
                    break
                values.append(current)
                if target.exact_value is not None and values_equal(
                    target.value_type,
                    current,
                    target.exact_value,
                ):
                    seed_matches += 1
            if not values or (support_count < 3 and seed_matches < 1):
                continue
            blocks.setdefault(tuple(values), []).append(base)
        if not blocks:
            return 0
        values, bases = max(
            blocks.items(),
            key=lambda item: (len(item[1]), item[0]),
        )
        bases = bases[:MAX_EQUIVALENT_LOCKED_CANDIDATES]
        prior_exact = {
            name: (target.exact_value, target.exact_value_source, list(target.notes))
            for name, target in targets.items()
        }
        for (_name, target), value in zip(targets.items(), values, strict=True):
            target.exact_value = value
            target.exact_value_source = SAME_PROCESS_LAYOUT_SOURCE
            target.notes.append(
                "Refreshed from a previously correlated +0/+4/+8 currency block in "
                "this same running NMS process."
            )
        focused = self.service.register_targeted_exact_candidates(
            session.id,
            targets["Units"].value_type,
            values[0],
            bases,
        )
        applied = self._apply_nms_currency_layout(
            run,
            targets["Units"],
            focused.id,
            focused.result_count,
            source_was_broad_scan=False,
        )
        if applied:
            preserved: list[DiscoveryCandidate] = []
            for name, target in targets.items():
                for candidate in target.candidates:
                    address = candidate.stability.address if candidate.stability else None
                    if address not in confirmed_addresses[name]:
                        continue
                    candidate.write_test_status = "confirmed"
                    candidate.evidence = [
                        *candidate.evidence,
                        (
                            "Preserved the prior visible write confirmation after re-reading "
                            "the same address in the same running game process."
                        ),
                    ][-20:]
                    preserved.append(candidate)
            if preserved:
                register_discovery_candidates(
                    self.service.settings,
                    session,
                    preserved,
                )
            return len(NMS_CURRENCY_LAYOUT)
        self.service.discard_scan(focused.id)
        for name, target in targets.items():
            exact_value, exact_source, notes = prior_exact[name]
            target.exact_value = exact_value
            target.exact_value_source = exact_source
            target.notes = notes
        return 0

    def _next_due_target(self, run: _Run) -> DiscoveryTargetStatus | None:
        now = datetime.now(UTC)
        urgent: list[DiscoveryTargetStatus] = []
        starting_exact: list[DiscoveryTargetStatus] = []
        for target in run.status.targets:
            spec = self._spec(target.name)
            if target.state in {DiscoveryTargetState.LOCKED, DiscoveryTargetState.CONFIRMED}:
                continue
            if spec.behavioral_correlation or target.exact_value_source == "default_normalized":
                continue
            if spec.requires_exact_value and target.exact_value is None:
                continue
            if target.revisit_after is not None and target.revisit_after > now:
                continue
            if (
                target.failed_exact_value is not None
                and target.exact_value is not None
                and values_equal(target.value_type, target.failed_exact_value, target.exact_value)
            ):
                continue
            if (
                target.scan_id is not None
                and target.scanned_exact_value is not None
                and target.exact_value is not None
                and not values_equal(
                    target.value_type,
                    target.scanned_exact_value,
                    target.exact_value,
                )
            ):
                urgent.append(target)
            elif target.scan_id is None and target.exact_value is not None:
                starting_exact.append(target)
        if urgent:
            return urgent[0]
        if starting_exact:
            source_rank = {
                "user": 0,
                "nms_save": 1,
                "save_snapshot": 1,
                "screen": 2,
            }
            return min(
                starting_exact,
                key=lambda target: source_rank.get(target.exact_value_source or "", 3),
            )
        count = len(run.status.targets)
        for _ in range(count):
            target = run.status.targets[run.cursor % count]
            run.cursor = (run.cursor + 1) % count
            if target.state in {DiscoveryTargetState.LOCKED, DiscoveryTargetState.CONFIRMED}:
                continue
            if self._spec(target.name).behavioral_correlation:
                continue
            if target.exact_value_source == "default_normalized":
                continue
            if target.revisit_after is not None and target.revisit_after > now:
                continue
            return target
        return None

    @staticmethod
    def _mark_write_test_ready(target: DiscoveryTargetStatus) -> None:
        if (
            target.exact_value_source
            not in {
                "user",
                "nms_save",
                "save_snapshot",
                "screen",
                "screen_temporal",
                "user_write_test",
                "screen_write_test",
                SAME_PROCESS_LAYOUT_SOURCE,
            }
            or not 1 <= target.candidate_count <= MAX_EQUIVALENT_LOCKED_CANDIDATES
        ):
            return
        for candidate in target.candidates:
            if candidate.id in target.rejected_candidate_ids or candidate.validated_events < 1:
                continue
            if candidate.current_value is None or target.exact_value is None:
                continue
            if target.exact_value_source != "screen_temporal" and not values_equal(
                candidate.value_type,
                candidate.current_value,
                target.exact_value,
            ):
                continue
            if candidate.write_test_status == "untested":
                candidate.write_test_status = "ready"
                candidate.evidence = [
                    *candidate.evidence,
                    "Ready for a separately confirmed write test in the selected offline game.",
                ][-20:]

    @staticmethod
    def _dominant_direction(
        stability: list[ScanCandidateStability],
    ) -> Comparison:
        increased = sum(item.increased for item in stability)
        decreased = sum(item.decreased for item in stability)
        if decreased > increased:
            return Comparison.DECREASED
        if increased > decreased:
            return Comparison.INCREASED
        return Comparison.CHANGED

    @staticmethod
    def _validation_rule(spec: TargetSpec) -> ValidationRule:
        return ValidationRule(
            value_min=spec.value_min,
            value_max=spec.value_max,
            expected_directions=list(spec.expected_directions),
            minimum_change_events=3,
            minimum_launches=2,
            require_unique_aob=True,
            require_non_raw_locator=True,
            require_source_correlation=True,
            notes=[
                "Promote only after repeated matching state changes.",
                "Re-resolve the pointer or AoB on at least two process launches.",
                (
                    "Require repeated guided gameplay correlation before naming the target."
                    if spec.behavioral_correlation
                    else "Require an exact user/save correlation before naming the target."
                ),
                *([EXPLICIT_BEHAVIOR_VALIDATION_MARKER] if spec.behavioral_correlation else []),
            ],
        )

    @staticmethod
    def _score_candidate(
        stats: ScanCandidateStability,
        locator: MemoryLocator,
        *,
        validated_launches: int,
        source_correlated: bool,
    ) -> float:
        score = 0.2
        score += min(0.25, stats.changed * 0.08)
        if stats.decreased and stats.increased:
            score += 0.12
        elif stats.decreased or stats.increased:
            score += 0.06
        if locator.kind is LocatorKind.POINTER_CHAIN:
            score += 0.25
        elif locator.kind is LocatorKind.MODULE_OFFSET:
            score += 0.3
        elif (
            locator.kind in {LocatorKind.AOB, LocatorKind.AOB_POINTER}
            and locator.match_count == 1
        ):
            score += 0.3
        score += min(0.15, validated_launches * 0.075)
        if source_correlated:
            score += 0.1
        return round(min(1.0, score), 3)

    @staticmethod
    def _promotable(candidate: DiscoveryCandidate) -> bool:
        rule = candidate.validation_rule
        return (
            candidate.confidence >= 0.85
            and candidate.validated_events >= rule.minimum_change_events
            and candidate.validated_launches >= rule.minimum_launches
            and (not rule.require_source_correlation or candidate.source_correlated)
            and (
                not rule.require_non_raw_locator
                or candidate.locator.kind is not LocatorKind.RAW_ADDRESS
            )
            and (
                candidate.locator.kind not in {LocatorKind.AOB, LocatorKind.AOB_POINTER}
                or not rule.require_unique_aob
                or candidate.locator.match_count == 1
            )
        )

    @staticmethod
    def _value_in_rule(value: int | float, rule: ValidationRule) -> bool:
        numeric = float(value)
        if rule.value_min is not None and numeric < rule.value_min:
            return False
        return rule.value_max is None or numeric <= rule.value_max

    @staticmethod
    def _merge_candidates(
        existing: list[DiscoveryCandidate],
        incoming: list[DiscoveryCandidate],
        *,
        accumulate_events: bool = False,
        retain_current_generation: bool = False,
    ) -> list[DiscoveryCandidate]:
        incoming_ids = {candidate.id for candidate in incoming}
        merged = {
            candidate.id: candidate
            for candidate in existing
            if not retain_current_generation
            or candidate.id in incoming_ids
            or candidate.locator.kind in {LocatorKind.AOB, LocatorKind.AOB_POINTER}
        }
        for candidate in incoming:
            previous = merged.get(candidate.id)
            if previous is not None:
                selected = (
                    candidate
                    if candidate.confidence >= previous.confidence
                    else previous.model_copy(deep=True)
                )
                starts = sorted(
                    set(previous.validated_process_starts) | set(candidate.validated_process_starts)
                )
                selected.validated_process_starts = starts
                selected.validated_launches = len(starts)
                selected.validated_events = (
                    previous.validated_events + candidate.validated_events
                    if accumulate_events
                    else max(previous.validated_events, candidate.validated_events)
                )
                selected.source_correlated = (
                    previous.source_correlated or candidate.source_correlated
                )
                write_test_rank = {
                    "untested": 0,
                    "ready": 1,
                    "rejected": 2,
                    "confirmed": 3,
                }
                selected.write_test_status = max(
                    (previous.write_test_status, candidate.write_test_status),
                    key=lambda status: write_test_rank.get(status, 0),
                )
                selected.locked_for_run = previous.locked_for_run or candidate.locked_for_run
                selected.reference_name = previous.reference_name or candidate.reference_name
                selected.reference_url = previous.reference_url or candidate.reference_url
                selected.evidence = [*previous.evidence, *candidate.evidence][-20:]
                selected.promoted = DiscoveryManager._promotable(selected)
                merged[candidate.id] = selected
            else:
                merged[candidate.id] = candidate
        return sorted(
            merged.values(),
            key=lambda candidate: (-candidate.confidence, candidate.id),
        )[:50]

    @staticmethod
    def _lock_candidate_group_for_run(target: DiscoveryTargetStatus) -> None:
        """Lock a small equivalent set without granting write or promotion."""

        for candidate in target.candidates:
            candidate.locked_for_run = False
        exact_source = target.exact_value_source in {
            "user",
            "nms_save",
            "save_snapshot",
            "screen",
            "screen_temporal",
            "user_write_test",
            "screen_write_test",
            SAME_PROCESS_LAYOUT_SOURCE,
        }
        small_exact_set = (
            exact_source
            and target.exact_value is not None
            and 1 <= target.candidate_count <= MAX_EQUIVALENT_LOCKED_CANDIDATES
        )
        eligible: list[DiscoveryCandidate] = []
        for candidate in target.candidates:
            rule = candidate.validation_rule
            exact_match = (
                target.exact_value is None
                or candidate.current_value is not None
                and abs(float(candidate.current_value) - float(target.exact_value)) <= 1e-6
            )
            exact_candidate = (
                small_exact_set
                and candidate.id not in target.rejected_candidate_ids
                and candidate.validated_events >= 1
                and candidate.source_correlated
                and candidate.write_test_status in {"ready", "confirmed"}
                and exact_match
            )
            fully_validated_candidate = (
                candidate.confidence >= 1.0
                and candidate.validated_events >= rule.minimum_change_events
                and candidate.source_correlated
                and candidate.locator.kind is not LocatorKind.RAW_ADDRESS
                and exact_match
            )
            if exact_candidate or fully_validated_candidate:
                eligible.append(candidate)
        if not eligible:
            return
        if small_exact_set and len(eligible) != target.candidate_count:
            return
        if len(eligible) > MAX_EQUIVALENT_LOCKED_CANDIDATES:
            note = (
                f"{len(eligible)} matching 100% candidates remain; learning continues until "
                f"the equivalent set narrows to {MAX_EQUIVALENT_LOCKED_CANDIDATES} or fewer."
            )
            if not target.notes or target.notes[-1] != note:
                target.notes.append(note)
            return
        for candidate in eligible:
            candidate.locked_for_run = True
        target.state = DiscoveryTargetState.LOCKED
        target.revisit_after = None
        count = len(eligible)
        label = "candidate is" if count == 1 else "equivalent candidates are"
        if small_exact_set:
            note = (
                f"{count} exact matching {label} locked read-only for this run; each locator "
                "stays separate and controlled write verification is still required before "
                "editing unlocks."
            )
        else:
            note = (
                f"{count} matching 100% {label} locked read-only for this run; each locator "
                "stays separate and restart validation is still required before write actions "
                "can unlock."
            )
        if not target.notes or target.notes[-1] != note:
            target.notes.append(note)

    @staticmethod
    def _lock_single_candidate_for_run(target: DiscoveryTargetStatus) -> None:
        """Compatibility wrapper for callers from the pre-group lock implementation."""

        DiscoveryManager._lock_candidate_group_for_run(target)

    @staticmethod
    def _candidate_id(target: str, locator: MemoryLocator) -> str:
        payload = f"{target.casefold()}\0{locator.model_dump_json()}".encode()
        return hashlib.sha256(payload).hexdigest()[:24]

    @staticmethod
    def _spec(name: str) -> TargetSpec:
        try:
            return _TARGET_SPECS[name.casefold()]
        except KeyError as exc:
            lowered = name.casefold()
            if lowered.startswith("screen value: "):
                return TargetSpec(
                    name,
                    ValueType.I32,
                    False,
                    None,
                    (Comparison.DECREASED, Comparison.INCREASED),
                    -2_147_483_648,
                    2_147_483_647,
                    True,
                    "Find a stable integer displayed by the selected game without a fixed address.",
                    "Leave this value visible while automatic learning observes and verifies it.",
                )
            if lowered.startswith("screen unsigned value: "):
                return TargetSpec(
                    name,
                    ValueType.U32,
                    False,
                    None,
                    (Comparison.DECREASED, Comparison.INCREASED),
                    0,
                    4_294_967_295,
                    True,
                    "Find a stable unsigned integer displayed by the selected game.",
                    "Leave this value visible while automatic learning observes and verifies it.",
                )
            if lowered.startswith("screen wide value: "):
                return TargetSpec(
                    name,
                    ValueType.U64,
                    False,
                    None,
                    (Comparison.DECREASED, Comparison.INCREASED),
                    0,
                    18_446_744_073_709_551_615,
                    True,
                    "Find a stable large integer displayed by the selected game.",
                    "Leave this value visible while automatic learning observes and verifies it.",
                )
            if lowered.endswith(" percent") or lowered.endswith(" charge points"):
                return TargetSpec(
                    name,
                    ValueType.I32,
                    False,
                    None,
                    (Comparison.DECREASED, Comparison.INCREASED),
                    0,
                    100,
                    True,
                    "Find the integer representation behind a visible HUD meter.",
                    "Keep the meter visible and make it fall or refill once.",
                )
            if lowered.startswith("screen meter: "):
                return TargetSpec(
                    name,
                    ValueType.F32,
                    True,
                    None,
                    (Comparison.DECREASED, Comparison.INCREASED),
                    0,
                    1,
                    True,
                    "Find a stable displayed meter without assuming a game-specific label.",
                    "Keep the meter visible and make it fall or refill once.",
                )
            if lowered.startswith("screen percent: "):
                return TargetSpec(
                    name,
                    ValueType.F32,
                    True,
                    None,
                    (Comparison.DECREASED, Comparison.INCREASED),
                    0,
                    1,
                    True,
                    "Find a stable percentage displayed by the selected game.",
                    "Leave this percentage visible and change it once during normal play.",
                )
            raise SafetyError(f"unsupported discovery target: {name}") from exc

    def _initial_target_order(
        self,
        session: ProcessSession,
        requested: list[str] | None,
        table,
    ) -> list[str]:
        is_nms = (
            session.process_name.casefold() == "nms.exe"
            or (session.game_key or "").casefold() in {"nms", "no-man-s-sky"}
        )
        base = list(
            requested
            if requested is not None
            else DEFAULT_NMS_TARGET_ORDER if is_nms else DEFAULT_GENERIC_TARGET_ORDER
        )
        seen = {name.casefold() for name in base}
        for entry in [*table.confirmed_features, *table.candidate_features]:
            names = [entry.name, *entry.suggested_features]
            for name in names:
                key = name.casefold()
                if not name or key in seen:
                    continue
                try:
                    self._spec(name)
                except SafetyError:
                    continue
                base.append(name)
                seen.add(key)
        return base

    @staticmethod
    def _target(run: _Run, name: str) -> DiscoveryTargetStatus:
        target = next(
            (item for item in run.status.targets if item.name.casefold() == name.casefold()),
            None,
        )
        if target is None:
            raise NotFoundError(f"discovery target was not found: {name}")
        return target

    def _get(self, run_id: str) -> _Run:
        try:
            return self._runs[run_id]
        except KeyError as exc:
            raise NotFoundError(f"discovery run {run_id} was not found") from exc

    def _run_path(self, game_key: str, run_id: str) -> Path:
        game_key = re.sub(
            r"[^a-z0-9]+",
            "-",
            game_key.casefold(),
        ).strip("-")
        return (
            self.service.settings.game_profile_directory
            / "discovery-runs"
            / (game_key or "game")
            / f"{run_id}.json"
        ).resolve()

    @staticmethod
    def _live_session(run: _Run) -> ProcessSession:
        if run.session is None:
            raise NotFoundError(f"process {run.process_name} is not currently attached")
        return run.session

    @staticmethod
    def _same_process_incarnation(
        status: CheatDiscoveryRunStatus,
        session: ProcessSession,
    ) -> bool:
        if (
            status.pid != session.pid
            or status.process_name.casefold() != session.process_name.casefold()
        ):
            return False
        if status.process_started_at is not None or session.process_started_at is not None:
            return status.process_started_at == session.process_started_at
        return status.session_id == session.id

    def _refresh_save_values(
        self,
        run: _Run,
        *,
        force: bool,
        initial: bool,
    ) -> bool:
        """Check the selected game's save adapter and requeue every mapped value."""

        status = run.status
        provider_name = self.save_evidence_registry.provider_name(run.game_key)
        status.save_provider_checked = True
        status.save_provider_name = provider_name
        if provider_name is None:
            if force and not initial:
                requeued = self._requeue_known_exact_values(
                    status,
                    "Manual rescan queued every known exact value; this game has no save "
                    "adapter registered yet.",
                )
                if requeued:
                    status.save_rescan_count += 1
                return requeued > 0
            return False
        try:
            snapshot = self.save_evidence_registry.read(run.game_key)
        except Exception as exc:  # noqa: BLE001 - corrupt saves must not stop discovery
            warning = f"Could not read {provider_name} values safely: {exc}"
            if warning not in status.warnings:
                status.warnings.append(warning)
                status.warnings = status.warnings[-20:]
            return
        if snapshot is None:
            if force and not initial:
                requeued = self._requeue_known_exact_values(
                    status,
                    f"Manual rescan queued every known exact value; {provider_name} did not "
                    "return a current snapshot.",
                )
                if requeued:
                    status.save_rescan_count += 1
                return requeued > 0
            return False
        if not force and snapshot.snapshot_id == status.save_snapshot_id:
            seeded = 0
            for target in status.targets:
                value = snapshot.values.get(target.name)
                if value is None or target.exact_value is not None:
                    continue
                target.exact_value = value
                target.exact_value_source = "save_snapshot"
                if self._requeue_target_for_save(
                    target,
                    "Seeded from the selected game's read-only save adapter.",
                ):
                    seeded += 1
            return seeded > 0

        previous_snapshot_id = status.save_snapshot_id
        snapshot_changed = previous_snapshot_id not in {None, snapshot.snapshot_id}
        requeued = 0
        for target in status.targets:
            value = snapshot.values.get(target.name)
            if value is None:
                if force and not initial and target.exact_value is not None:
                    if self._requeue_target_for_save(
                        target,
                        "Manual all-values rescan queued this known exact value.",
                    ):
                        requeued += 1
                continue
            explicit_source = target.exact_value_source in {
                "user",
                "screen",
                "user_write_test",
                "screen_write_test",
                SAME_PROCESS_LAYOUT_SOURCE,
            }
            if not explicit_source:
                target.exact_value = value
                target.exact_value_source = "save_snapshot"
            if force or snapshot_changed or target.scan_id is None:
                reason = (
                    "A changed save snapshot queued a fresh full-value rescan and preserved "
                    "the previous candidate generation for rollback."
                    if snapshot_changed
                    else "Seeded from the selected game's read-only save adapter."
                )
                if self._requeue_target_for_save(target, reason):
                    requeued += 1
            for evidence in snapshot.evidence.get(target.name, []):
                if evidence not in target.notes:
                    target.notes.append(evidence)
        status.save_snapshot_id = snapshot.snapshot_id
        if not initial and (snapshot_changed or force) and requeued:
            status.save_rescan_count += 1
        return snapshot_changed or requeued > 0

    def _requeue_known_exact_values(
        self,
        status: CheatDiscoveryRunStatus,
        reason: str,
    ) -> int:
        requeued = 0
        for target in status.targets:
            if target.exact_value is None:
                continue
            if self._requeue_target_for_save(target, reason):
                requeued += 1
        return requeued

    @staticmethod
    def _requeue_target_for_save(target: DiscoveryTargetStatus, reason: str) -> bool:
        confirmed = [
            candidate
            for candidate in target.candidates
            if candidate.write_test_status == "confirmed"
        ]
        if confirmed:
            target.state = (
                DiscoveryTargetState.CONFIRMED
                if any(candidate.promoted for candidate in confirmed)
                else DiscoveryTargetState.LOCKED
            )
            target.revisit_after = None
            retained = (
                "Saved write-confirmation evidence remains locked; only contradictory live "
                "evidence can retire it."
            )
            if not target.notes or target.notes[-1] != retained:
                target.notes.append(retained)
            target.notes = target.notes[-20:]
            return False
        if target.scan_id is not None and target.scan_id not in target.rollback_scan_ids:
            target.rollback_scan_ids = [*target.rollback_scan_ids, target.scan_id][-3:]
        target.scan_id = None
        target.scanned_exact_value = None
        target.failed_exact_value = None
        target.generation = 0
        target.state = DiscoveryTargetState.QUEUED
        target.revisit_after = None
        if not target.notes or target.notes[-1] != reason:
            target.notes.append(reason)
        return True

    @staticmethod
    def _persist(run: _Run) -> None:
        if not run.status.saved_path:
            return
        path = Path(run.status.saved_path)
        path.parent.mkdir(parents=True, exist_ok=True)
        temporary = path.with_suffix(".tmp")
        temporary.write_text(run.status.model_dump_json(indent=2), encoding="utf-8")
        temporary.replace(path)
