from __future__ import annotations

import asyncio
import re
import sys
import threading
from dataclasses import dataclass
from io import BytesIO
from pathlib import Path
from typing import Any

from gtp_games.errors import BackendError
from gtp_games.models import (
    InventoryScreenResult,
    InventoryStackDetection,
    ValueType,
    VisibleValueDetection,
)
from gtp_games.screen_capture import (
    _capture_pause_reason,
    _largest_window_for_pid,
    _overlay_exclusion_regions,
)

NMS_ITEM_GUIDE_URL = "https://nmshandbook.com/items/"
_STACK_PATTERN = re.compile(r"(?<!\d)(\d[\d,]*)\s*/\s*(\d[\d,]*)(?!\d)")
_COUNT_PATTERN = re.compile(r"^\s*(\d[\d,]*)\s*$")
_VISIBLE_NUMBER_PATTERN = re.compile(
    r"(?<![\d:.])(?P<number>-?\d[\d,]*(?:\.\d+)?)\s*(?P<percent>%?)(?![\d:.])"
)
_VISIBLE_VALUE_EXCLUSIONS = {
    "fps",
    "frame",
    "frametime",
    "latency",
    "ping",
    "version",
    "build",
    "resolution",
}
_ITEM_LABEL_EXCLUSIONS = {
    "CARGO",
    "EXOSUIT",
    "FREIGHTER",
    "MULTI-TOOL",
    "STARSHIP",
    "TECHNOLOGY",
    "QUICK TRANSFER",
    "MOVE AND STACK",
    "DISCARD",
}


@dataclass(frozen=True)
class OcrLineBox:
    text: str
    x: int
    y: int
    width: int
    height: int


def smoke_inventory_image(source: Path) -> dict[str, Any]:
    """Exercise the packaged OCR stack against one existing image without game access."""

    from PIL import Image

    with Image.open(source) as loaded:
        image = loaded.convert("RGB")
    lines = recognize_inventory_ocr(image)
    menu_detected, selected_item_label, detections = analyze_inventory_ocr_lines(
        lines,
        image_width=image.width,
        image_height=image.height,
    )
    selected = next((item for item in detections if item.selected), None)
    return {
        "menu_detected": menu_detected,
        "selected_item_label": selected_item_label,
        "selected_current": selected.current_value if selected else None,
        "selected_maximum": selected.maximum_value if selected else None,
        "detection_count": len(detections),
        "image_width": image.width,
        "image_height": image.height,
        "screenshot_saved": False,
        "memory_write_performed": False,
    }


def capture_and_read_inventory(session_id: str, pid: int) -> InventoryScreenResult:
    """Read inventory labels and counts locally; captured pixels are never persisted."""

    if sys.platform != "win32":
        raise BackendError("inventory-window capture requires Windows")
    try:
        from PIL import ImageGrab
    except ImportError as exc:  # pragma: no cover - dependency is packaged on Windows
        raise BackendError("inventory-window capture requires Pillow") from exc

    window, title, bounds = _largest_window_for_pid(pid)
    if not window:
        return InventoryScreenResult(
            session_id=session_id,
            pid=pid,
            window_title="",
            image_width=1,
            image_height=1,
            capture_status="paused",
            message=(
                "The selected game window is not visible. Inventory learning is waiting for "
                "the game to reopen or become visible."
            ),
        )
    left, top, right, bottom = bounds
    pause_reason = _capture_pause_reason(window, pid)
    if pause_reason is not None:
        return InventoryScreenResult(
            session_id=session_id,
            pid=pid,
            window_title=title,
            image_width=max(1, right - left),
            image_height=max(1, bottom - top),
            capture_status="paused",
            message=pause_reason,
        )

    image = ImageGrab.grab(bbox=(left, top, right, bottom), all_screens=True).convert("RGB")
    excluded_regions = _overlay_exclusion_regions(bounds)
    for x, y, width, height in excluded_regions:
        image.paste((0, 0, 0), (x, y, x + width, y + height))
    try:
        lines = recognize_inventory_ocr(image)
    except Exception as exc:  # noqa: BLE001 - return a usable local-only diagnostic
        return InventoryScreenResult(
            session_id=session_id,
            pid=pid,
            window_title=title,
            image_width=image.width,
            image_height=image.height,
            capture_status="unavailable",
            message=f"Local Windows text recognition is unavailable: {exc}",
            excluded_regions=excluded_regions,
        )
    menu_detected, selected_item_label, detections = analyze_inventory_ocr_lines(
        lines,
        image_width=image.width,
        image_height=image.height,
    )
    if not menu_detected:
        return InventoryScreenResult(
            session_id=session_id,
            pid=pid,
            window_title=title,
            image_width=image.width,
            image_height=image.height,
            capture_status="paused",
            message="Open the selected game's inventory and leave one item highlighted.",
            excluded_regions=excluded_regions,
        )
    message = (
        "Inventory is visible. Highlight one stack, capture a baseline, change that stack, "
        "then capture again."
    )
    if not any(item.selected for item in detections):
        message = (
            "Inventory is visible, but no selected current/max stack was readable. "
            "Highlight a stack whose count is visible and capture again."
        )
    return InventoryScreenResult(
        session_id=session_id,
        pid=pid,
        window_title=title,
        image_width=image.width,
        image_height=image.height,
        message=message,
        menu_detected=True,
        selected_item_label=selected_item_label,
        guide_url=NMS_ITEM_GUIDE_URL,
        excluded_regions=excluded_regions,
        detections=detections,
    )


def analyze_inventory_ocr_lines(
    lines: list[OcrLineBox],
    *,
    image_width: int,
    image_height: int,
) -> tuple[bool, str | None, list[InventoryStackDetection]]:
    """Turn local OCR geometry into conservative inventory stack observations."""

    normalized_text = " ".join(line.text.casefold() for line in lines)
    nms_menu = "exosuit" in normalized_text and (
        "cargo" in normalized_text or "technology" in normalized_text
    )
    stack_line_count = sum(1 for line in lines if _STACK_PATTERN.search(line.text))
    generic_menu = any(
        marker in normalized_text
        for marker in ("inventory", "backpack", "items", "storage", "stash", "cargo")
    ) and stack_line_count >= 1
    menu_detected = nms_menu or generic_menu or stack_line_count >= 3
    if not menu_detected:
        return False, None, []
    selected_item = _choose_selected_item_line(
        lines,
        image_width=image_width,
        image_height=image_height,
    )
    selected_item_label = selected_item[1] if selected_item is not None else None
    stack_lines = [line for line in lines if _STACK_PATTERN.search(line.text)]
    select_single_generic_stack = generic_menu and not nms_menu and len(stack_lines) == 1
    selected_stack_line = _choose_selected_stack_line(
        stack_lines,
        selected_item[0] if selected_item is not None else None,
        nms_menu=nms_menu,
        image_width=image_width,
        image_height=image_height,
    )
    detections: list[InventoryStackDetection] = []
    for line in lines:
        stack_match = _STACK_PATTERN.search(line.text)
        if stack_match is not None:
            current = int(stack_match.group(1).replace(",", ""))
            maximum = int(stack_match.group(2).replace(",", ""))
            if maximum < current or maximum > 10_000_000:
                continue
            selected = line is selected_stack_line or (
                select_single_generic_stack and line is stack_lines[0]
            )
            detections.append(
                InventoryStackDetection(
                    x=line.x,
                    y=line.y,
                    width=max(1, line.width),
                    height=max(1, line.height),
                    current_value=current,
                    maximum_value=maximum,
                    confidence=0.92 if selected else 0.78,
                    selected=selected,
                    item_label=selected_item_label if selected else None,
                )
            )
            continue
        count_match = _COUNT_PATTERN.fullmatch(line.text)
        if count_match is None:
            continue
        if not (
            image_width * 0.42 <= line.x <= image_width * 0.72
            and image_height * 0.38 <= line.y <= image_height * 0.88
        ):
            continue
        current = int(count_match.group(1).replace(",", ""))
        if current > 10_000_000:
            continue
        detections.append(
            InventoryStackDetection(
                x=line.x,
                y=line.y,
                width=max(1, line.width),
                height=max(1, line.height),
                current_value=current,
                confidence=0.58,
            )
        )
    detections.sort(key=lambda item: (not item.selected, -item.confidence, item.y, item.x))
    return True, selected_item_label, detections[:16]


def analyze_visible_value_ocr_lines(
    lines: list[OcrLineBox],
    *,
    image_width: int,
    image_height: int,
) -> list[VisibleValueDetection]:
    """Extract stable, named HUD numbers without treating diagnostics as game values."""

    detections: list[VisibleValueDetection] = []
    for line in lines:
        text = " ".join(line.text.strip().split())
        lowered = text.casefold()
        if not text or any(word in lowered for word in _VISIBLE_VALUE_EXCLUSIONS):
            continue
        if re.search(r"\b\d{1,2}:\d{2}(?::\d{2})?\b", text):
            continue
        match = _VISIBLE_NUMBER_PATTERN.search(text)
        if match is None:
            continue
        raw_number = match.group("number").replace(",", "")
        try:
            current_value: int | float = (
                float(raw_number) if "." in raw_number else int(raw_number)
            )
        except ValueError:
            continue
        if abs(float(current_value)) > 9_223_372_036_854_775_807:
            continue
        label = _visible_value_label(text, match, lines, line)
        percent = bool(match.group("percent"))
        target = _visible_value_target(
            label,
            percent=percent,
            value=current_value,
            x=line.x,
            y=line.y,
            image_width=image_width,
            image_height=image_height,
        )
        if not target:
            continue
        normalized = percent or target.casefold() in {
            "health",
            "shield",
            "stamina",
            "hazard protection",
            "life support",
        }
        scan_value: int | float = (
            round(float(current_value) / 100.0, 4) if normalized else current_value
        )
        value_type = ValueType.F32 if normalized else _integer_value_type(int(current_value))
        zone = _value_screen_zone(
            line.x,
            line.y,
            line.width,
            line.height,
            image_width=image_width,
            image_height=image_height,
        )
        confidence = 0.9 if _known_visible_target(label) else 0.76 if label else 0.6
        detections.append(
            VisibleValueDetection(
                x=max(0, line.x),
                y=max(0, line.y),
                width=max(1, line.width),
                height=max(1, line.height),
                current_value=current_value,
                scan_value=scan_value,
                value_type=value_type,
                normalized=normalized,
                confidence=confidence,
                target=target,
                label=label or target.removeprefix("screen value: ").title(),
                zone=zone,
            )
        )
    unique: dict[tuple[str, int, int], VisibleValueDetection] = {}
    for detection in detections:
        key = (
            detection.target.casefold(),
            round(detection.x / max(1, image_width) * 20),
            round(detection.y / max(1, image_height) * 20),
        )
        previous = unique.get(key)
        if previous is None or detection.confidence > previous.confidence:
            unique[key] = detection
    return sorted(unique.values(), key=lambda item: (-item.confidence, item.y, item.x))[:20]


def _visible_value_label(
    text: str,
    match: re.Match[str],
    lines: list[OcrLineBox],
    number_line: OcrLineBox,
) -> str:
    inline = " ".join(
        re.sub(r"[^A-Za-z0-9' -]", " ", f"{text[:match.start()]} {text[match.end():]}")
        .strip()
        .split()
    )
    inline = re.sub(r"\b(?:x|of|max|total)\b", " ", inline, flags=re.IGNORECASE).strip()
    if any(character.isalpha() for character in inline) and 2 <= len(inline) <= 48:
        return inline
    center_y = number_line.y + number_line.height / 2
    nearby: list[tuple[float, str]] = []
    for candidate in lines:
        if candidate is number_line or _VISIBLE_NUMBER_PATTERN.search(candidate.text):
            continue
        clean = " ".join(re.sub(r"[^A-Za-z0-9' -]", " ", candidate.text).split())
        if not any(character.isalpha() for character in clean) or not 2 <= len(clean) <= 48:
            continue
        candidate_center_y = candidate.y + candidate.height / 2
        vertical = abs(candidate_center_y - center_y)
        horizontal = abs((candidate.x + candidate.width) - number_line.x)
        if vertical <= max(40, number_line.height * 2.5) and horizontal <= 240:
            nearby.append((vertical * 2 + horizontal, clean))
        elif 0 <= number_line.y - (candidate.y + candidate.height) <= 55:
            nearby.append((80 + abs(candidate.x - number_line.x), clean))
    return min(nearby, default=(0.0, ""))[1]


def _known_visible_target(label: str) -> str | None:
    lowered = label.casefold()
    keyword_targets = (
        (("nanite",), "Nanites"),
        (("quicksilver",), "Quicksilver"),
        (("unit",), "Units"),
        (("health", "hit point"), "health"),
        (("shield", "armor", "armour"), "shield"),
        (("hazard",), "hazard protection"),
        (("life support",), "life support"),
        (("stamina",), "stamina"),
        (("ammo", "round", "bullet"), "weapon heat/ammo"),
        (("stack", "quantity"), "inventory item quantity"),
    )
    for keywords, target in keyword_targets:
        if any(keyword in lowered for keyword in keywords):
            return target
    if re.search(r"(?:^|\W)hp(?:$|\W)", lowered):
        return "health"
    return None


def _visible_value_target(
    label: str,
    *,
    percent: bool,
    value: int | float,
    x: int,
    y: int,
    image_width: int,
    image_height: int,
) -> str:
    known = _known_visible_target(label)
    normalized_targets = {"health", "shield", "hazard protection", "life support", "stamina"}
    if known in normalized_targets and not percent:
        known = None
    if known:
        return known
    clean = " ".join(re.sub(r"[^A-Za-z0-9' -]", " ", label).split()).strip(" -")
    if clean:
        if percent:
            prefix = "screen percent"
        elif float(value) > 4_294_967_295:
            prefix = "screen wide value"
        elif float(value) > 2_147_483_647:
            prefix = "screen unsigned value"
        else:
            prefix = "screen value"
        return f"{prefix}: {clean[:48].title()}"
    zone = _value_screen_zone(
        x,
        y,
        1,
        1,
        image_width=image_width,
        image_height=image_height,
    ).replace("_", " ")
    grid_x = round(x / max(1, image_width) * 10)
    grid_y = round(y / max(1, image_height) * 10)
    if percent:
        prefix = "screen percent"
    elif float(value) > 4_294_967_295:
        prefix = "screen wide value"
    elif float(value) > 2_147_483_647:
        prefix = "screen unsigned value"
    else:
        prefix = "screen value"
    return f"{prefix}: {zone} {grid_x}-{grid_y}"


def _integer_value_type(value: int) -> ValueType:
    if value < 0:
        return ValueType.I32 if value >= -2_147_483_648 else ValueType.I64
    return ValueType.I32 if value <= 2_147_483_647 else ValueType.U32


def _value_screen_zone(
    x: int,
    y: int,
    width: int,
    height: int,
    *,
    image_width: int,
    image_height: int,
) -> str:
    center_x = (x + width / 2) / max(1, image_width)
    center_y = (y + height / 2) / max(1, image_height)
    horizontal = "left" if center_x < 0.4 else "right" if center_x > 0.6 else "center"
    vertical = "top" if center_y < 0.4 else "bottom" if center_y > 0.6 else "middle"
    return f"{vertical}_{horizontal}"


def correlate_inventory_matrix_observations(
    baseline: dict[str, Any],
    changed: dict[str, Any],
    entries: list[dict[str, Any]],
) -> tuple[dict[str, str], dict[str, str]]:
    """Match unique odd screen deltas to candidates without guessing ambiguous rows."""

    before_items = sorted(
        [item for item in baseline.get("detections", []) if isinstance(item, dict)],
        key=lambda item: (int(item.get("y", 0)), int(item.get("x", 0))),
    )
    after_items = [
        item for item in changed.get("detections", []) if isinstance(item, dict)
    ]
    observed_by_delta: dict[int, list[tuple[int, dict[str, Any], dict[str, Any]]]] = {}
    used_after: set[int] = set()
    for slot_index, before in enumerate(before_items):
        nearest: tuple[float, int, dict[str, Any]] | None = None
        before_x = int(before.get("x", 0)) + int(before.get("width", 1)) / 2
        before_y = int(before.get("y", 0)) + int(before.get("height", 1)) / 2
        for after_index, after in enumerate(after_items):
            if after_index in used_after:
                continue
            after_x = int(after.get("x", 0)) + int(after.get("width", 1)) / 2
            after_y = int(after.get("y", 0)) + int(after.get("height", 1)) / 2
            distance = abs(before_x - after_x) + abs(before_y - after_y)
            tolerance = max(
                40,
                int(before.get("width", 1)) + int(before.get("height", 1)),
            )
            if distance <= tolerance and (nearest is None or distance < nearest[0]):
                nearest = (distance, after_index, after)
        if nearest is None:
            continue
        _, after_index, after = nearest
        used_after.add(after_index)
        delta = int(after.get("current_value", 0)) - int(before.get("current_value", 0))
        observed_by_delta.setdefault(delta, []).append((slot_index, before, after))

    matches: dict[str, str] = {}
    reference_urls: dict[str, str] = {}
    for entry in entries:
        candidate_id = str(entry.get("candidate_id") or "")
        delta = int(entry.get("delta") or 0)
        observations = observed_by_delta.get(delta, [])
        if not candidate_id or len(observations) != 1:
            continue
        slot_index, before, after = observations[0]
        if int(before.get("current_value", 0)) != int(entry.get("original_value", 0)):
            continue
        label = str(
            after.get("item_label")
            or before.get("item_label")
            or f"Inventory slot {slot_index + 1}"
        ).strip()
        matches[candidate_id] = label
        reference_url = str(after.get("reference_url") or before.get("reference_url") or "")
        if reference_url:
            reference_urls[candidate_id] = reference_url
    return matches, reference_urls


def _choose_selected_item_line(
    lines: list[OcrLineBox],
    *,
    image_width: int,
    image_height: int,
) -> tuple[OcrLineBox, str] | None:
    candidates: list[tuple[float, OcrLineBox, str]] = []
    for line in lines:
        text = " ".join(line.text.strip().split())
        clean = re.sub(r"[^A-Za-z0-9' -]", "", text).strip(" -")
        if not 4 <= len(clean) <= 48 or clean.upper() in _ITEM_LABEL_EXCLUSIONS:
            continue
        letters = [character for character in clean if character.isalpha()]
        if not letters:
            continue
        uppercase_ratio = sum(character.isupper() for character in letters) / len(letters)
        if uppercase_ratio < 0.72:
            continue
        x_ratio = line.x / image_width
        y_ratio = line.y / image_height
        if not (0.20 <= x_ratio <= 0.55 and 0.42 <= y_ratio <= 0.67):
            continue
        score = uppercase_ratio + (0.25 if " " in clean else 0.0) - abs(y_ratio - 0.52)
        candidates.append((score, line, clean.title()))
    if not candidates:
        return None
    _, line, label = max(candidates, key=lambda item: item[0])
    return line, label


def _choose_selected_item_label(
    lines: list[OcrLineBox],
    *,
    image_width: int,
    image_height: int,
) -> str | None:
    selected = _choose_selected_item_line(
        lines,
        image_width=image_width,
        image_height=image_height,
    )
    return selected[1] if selected is not None else None


def _choose_selected_stack_line(
    stacks: list[OcrLineBox],
    label: OcrLineBox | None,
    *,
    nms_menu: bool,
    image_width: int,
    image_height: int,
) -> OcrLineBox | None:
    """Associate the detail card with its originating tile, including NMS popup offset."""

    if label is None or not stacks:
        return None
    label_center = label.x + label.width / 2
    if nms_menu:
        expected_x = label.x - image_width * 0.135
        expected_y = label.y + image_height * 0.28
    else:
        expected_x = label_center
        expected_y = label.y + label.height * 2
    ranked = sorted(
        (
            (
                abs((stack.x + stack.width / 2) - expected_x)
                + abs((stack.y + stack.height / 2) - expected_y) * 1.5,
                stack,
            )
            for stack in stacks
        ),
        key=lambda item: item[0],
    )
    distance, selected = ranked[0]
    tolerance = image_width * (0.18 if nms_menu else 0.12) + image_height * 0.12
    return selected if distance <= tolerance else None


def recognize_inventory_ocr(image) -> list[OcrLineBox]:
    """Read the full menu, then enlarge likely detail panels when stack text is tiny."""

    full_lines = recognize_windows_ocr(image)
    menu_detected, _label, detections = analyze_inventory_ocr_lines(
        full_lines,
        image_width=image.width,
        image_height=image.height,
    )
    if not menu_detected or any(item.selected for item in detections):
        return full_lines

    from PIL import Image

    combined = list(full_lines)
    regions = (
        (0.12, 0.32, 0.72, 0.98),
        (0.52, 0.28, 0.99, 0.98),
    )
    scale = 1.75
    for left_ratio, top_ratio, right_ratio, bottom_ratio in regions:
        left = int(image.width * left_ratio)
        top = int(image.height * top_ratio)
        right = int(image.width * right_ratio)
        bottom = int(image.height * bottom_ratio)
        cropped = image.crop((left, top, right, bottom))
        enlarged = cropped.resize(
            (int(cropped.width * scale), int(cropped.height * scale)),
            Image.Resampling.LANCZOS,
        )
        for line in recognize_windows_ocr(enlarged):
            combined.append(
                OcrLineBox(
                    text=line.text,
                    x=left + int(round(line.x / scale)),
                    y=top + int(round(line.y / scale)),
                    width=max(1, int(round(line.width / scale))),
                    height=max(1, int(round(line.height / scale))),
                )
            )

    unique: dict[tuple[str, int, int], OcrLineBox] = {}
    for line in combined:
        key = (
            " ".join(line.text.casefold().split()),
            round(line.x / 16),
            round(line.y / 12),
        )
        previous = unique.get(key)
        if previous is None or line.width * line.height > previous.width * previous.height:
            unique[key] = line
    return list(unique.values())


def recognize_windows_ocr(image) -> list[OcrLineBox]:
    """Run the Windows on-device OCR engine without retaining or uploading the frame."""

    async def recognize() -> list[OcrLineBox]:
        from winrt.windows.graphics.imaging import BitmapDecoder
        from winrt.windows.media.ocr import OcrEngine
        from winrt.windows.storage.streams import DataWriter, InMemoryRandomAccessStream

        encoded = BytesIO()
        image.save(encoded, format="PNG")
        stream = InMemoryRandomAccessStream()
        writer = DataWriter(stream)
        writer.write_bytes(encoded.getvalue())
        await writer.store_async()
        await writer.flush_async()
        writer.detach_stream()
        stream.seek(0)
        decoder = await BitmapDecoder.create_async(stream)
        bitmap = await decoder.get_software_bitmap_async()
        engine = OcrEngine.try_create_from_user_profile_languages()
        if engine is None:
            raise RuntimeError("no Windows OCR language is installed")
        result = await engine.recognize_async(bitmap)
        recognized: list[OcrLineBox] = []
        for line in result.lines:
            words = list(line.words)
            if not words:
                continue
            left = min(int(round(word.bounding_rect.x)) for word in words)
            top = min(int(round(word.bounding_rect.y)) for word in words)
            right = max(
                int(round(word.bounding_rect.x + word.bounding_rect.width)) for word in words
            )
            bottom = max(
                int(round(word.bounding_rect.y + word.bounding_rect.height)) for word in words
            )
            recognized.append(
                OcrLineBox(
                    text=" ".join(word.text for word in words),
                    x=max(0, left),
                    y=max(0, top),
                    width=max(1, right - left),
                    height=max(1, bottom - top),
                )
            )
        return recognized

    try:
        asyncio.get_running_loop()
    except RuntimeError:
        return asyncio.run(recognize())
    result: list[OcrLineBox] | None = None
    error: BaseException | None = None

    def worker() -> None:
        nonlocal result, error
        try:
            result = asyncio.run(recognize())
        except BaseException as exc:  # pragma: no cover - defensive event-loop bridge
            error = exc

    thread = threading.Thread(target=worker, name="gtp-windows-ocr", daemon=True)
    thread.start()
    thread.join(timeout=12)
    if thread.is_alive():
        raise TimeoutError("Windows OCR did not finish within 12 seconds")
    if error is not None:
        raise error
    return result or []
