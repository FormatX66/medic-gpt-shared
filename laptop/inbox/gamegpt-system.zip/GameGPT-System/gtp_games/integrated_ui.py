from __future__ import annotations

import time
import webbrowser
from collections import deque
from collections.abc import Callable
from pathlib import Path
from typing import Any

from gtp_games.codec import encode_value
from gtp_games.errors import GTPError
from gtp_games.integrated import (
    CapabilityAction,
    CapabilityRow,
    CapabilityState,
    IntegratedStateStore,
    ValuePriorityMap,
    build_capability_rows,
    build_ct_value_priority_map,
    normalize_hotkey,
    parse_multi_use_input,
)
from gtp_games.inventory_capture import correlate_inventory_matrix_observations
from gtp_games.models import ValueType
from gtp_games.overlay import (
    WindowsGlobalHotkey,
    find_game_window,
    keep_overlay_topmost,
    make_overlay_click_through,
    process_is_running,
    sparkline_points,
)
from gtp_games.script_lab import (
    NativeScriptKind,
    ScriptLabStore,
    build_native_script,
    translate_ct_script_reference,
)

DIRECT_DISCOVERY_TARGETS = (
    "Units",
    "Nanites",
    "Quicksilver",
    "health",
    "shield",
    "hazard protection",
    "life support",
    "stamina",
    "jetpack",
    "inventory item quantity",
    "inventory capacity",
    "movement speed",
    "jump height",
    "launch thrusters",
    "pulse/hyperdrive",
    "weapon heat/ammo",
    "scanner",
)

INTEGER_VALUE_BOUNDS = {
    ValueType.I8: (-(2**7), 2**7 - 1),
    ValueType.U8: (0, 2**8 - 1),
    ValueType.I16: (-(2**15), 2**15 - 1),
    ValueType.U16: (0, 2**16 - 1),
    ValueType.I32: (-(2**31), 2**31 - 1),
    ValueType.U32: (0, 2**32 - 1),
    ValueType.I64: (-(2**63), 2**63 - 1),
    ValueType.U64: (0, 2**64 - 1),
}


class IntegratedPanel:
    """Compact local controls; all game-memory mutation stays in the companion service."""

    def __init__(
        self,
        *,
        root,
        tk,
        ttk,
        capabilities_parent,
        script_parent,
        history_parent,
        controller,
        data_directory: Path,
        run_background: Callable,
        get_active_session: Callable[[], dict[str, Any] | None],
        get_discovery_run_id: Callable[[], str | None],
        open_discovery: Callable[[], None],
        show_script_lab: Callable[[], None],
        set_status: Callable[[str], None],
        enable_global_hotkeys: bool = True,
    ) -> None:
        self.root = root
        self.tk = tk
        self.ttk = ttk
        self.controller = controller
        self.run_background = run_background
        self.get_active_session = get_active_session
        self.get_discovery_run_id = get_discovery_run_id
        self.open_discovery = open_discovery
        self.show_script_lab = show_script_lab
        self.set_status = set_status
        self.enable_global_hotkeys = enable_global_hotkeys
        self.state_store = IntegratedStateStore(data_directory / "integrated-ui.json")
        self.state = self.state_store.load()
        self.script_store = ScriptLabStore(data_directory / "script-lab.json")
        self.scripts = self.script_store.load()
        self.overlay_window = None
        self.overlay_frame = None
        self.overlay_hotkey_manager: WindowsGlobalHotkey | None = None
        self.learning_hotkeys = {
            "baseline": "<F9>",
            "changed": "<F10>",
            "rescan": "<Control-F11>",
        }
        self.learning_hotkey_managers: dict[str, WindowsGlobalHotkey] = {}
        self._overlay_tick_after = None
        self._last_overlay_geometry: str | None = None
        self._last_overlay_topmost_refresh = 0.0
        self._overlay_samples: dict[str, deque[float]] = {}
        self._layout_mode = "standard"
        self.rows: list[CapabilityRow] = []
        self._screen_rows: dict[str, CapabilityRow] = {}
        self._screen_observation_counts: dict[str, int] = {}
        self._screen_confidence_totals: dict[str, float] = {}
        self._screen_bar_max_widths: dict[str, int] = {}
        self._screen_last_values: dict[str, float] = {}
        self._inventory_rows: dict[str, CapabilityRow] = {}
        self._inventory_observation_counts: dict[str, int] = {}
        self._inventory_consecutive_values: dict[str, tuple[int, int | None, int]] = {}
        self._learning_targets_by_row: dict[str, str] = {}
        self._confirmed_learning_targets: set[str] = set()
        self._inventory_capture_busy = False
        self._inventory_matrix_baseline: dict[str, Any] | None = None
        self._inventory_matrix_probe: dict[str, Any] | None = None
        self._last_inventory_seed: tuple[str, int, int | None] | None = None
        self._last_inventory_result: dict[str, Any] | None = None
        self._inventory_auto_map_attempts: set[tuple[str, int, tuple[str, ...]]] = set()
        self._inventory_auto_map_signature: tuple[str, int, tuple[str, ...]] | None = None
        self._inventory_guide_url = ""
        self._candidate_test_positions: dict[str, int] = {}
        self.row_by_item: dict[str, CapabilityRow] = {}
        self.command_var = tk.StringVar()
        self.hunt_target_var = tk.StringVar(value=DIRECT_DISCOVERY_TARGETS[0])
        self.hunt_value_var = tk.StringVar()
        self.edit_value_var = tk.StringVar()
        self.overlay_button_var = tk.StringVar()
        self.command_status_var = tk.StringVar(
            value="Choose exactly what to find, or select a found row to test and edit it."
        )
        self.capability_status_var = tk.StringVar(
            value="Pick a running game to load saved controls and begin learning."
        )
        self.learning_status_var = tk.StringVar(
            value="Learning guide: choose a running game above."
        )
        self.script_status_var = tk.StringVar(
            value="Candidates stay inert until every verification gate passes."
        )
        self.history_status_var = tk.StringVar(value="Local UI history; no game writes.")
        self.script_name_var = tk.StringVar(value="New game script")
        self.script_target_var = tk.StringVar(value="health")
        self.script_kind_var = tk.StringVar(value=NativeScriptKind.VALUE.value)
        self.script_operation_var = tk.StringVar(value="freeze")
        self.capability_detail_var = tk.StringVar(
            value="Choose a learned control to see its evidence and safe next action."
        )
        self._primary_action: CapabilityAction | None = None
        self._secondary_action: CapabilityAction | None = None
        self._focused_run_id: str | None = None
        self._editing_row_id: str | None = None
        self._build_capabilities(capabilities_parent)
        self._build_script_lab(script_parent)
        self._build_history(history_parent)
        self.render_capabilities()
        self.render_scripts()
        self.render_history()
        self._bind_saved_hotkeys()
        self._start_overlay_runtime()
        self.render_overlay()

    def _build_capabilities(self, parent) -> None:
        ttk = self.ttk
        shell = ttk.Frame(parent)
        shell.pack(fill="both", expand=True)
        self.capability_canvas = self.tk.Canvas(
            shell,
            highlightthickness=0,
            borderwidth=0,
            background="#0b1220",
        )
        self.capability_page_scrollbar = ttk.Scrollbar(
            shell,
            orient="vertical",
            command=self.capability_canvas.yview,
        )
        self.capability_canvas.configure(yscrollcommand=self.capability_page_scrollbar.set)
        self.capability_canvas.pack(side="left", fill="both", expand=True)
        self.capability_page_scrollbar.pack(side="right", fill="y")
        frame = ttk.Frame(self.capability_canvas, padding=(0, 2, 8, 4))
        self.capability_content = frame
        self._capability_canvas_window = self.capability_canvas.create_window(
            0,
            0,
            anchor="nw",
            window=frame,
        )

        def update_scroll_region(_event=None) -> None:
            self.capability_canvas.configure(scrollregion=self.capability_canvas.bbox("all"))

        def fit_content_width(event) -> None:
            self.capability_canvas.itemconfigure(
                self._capability_canvas_window,
                width=max(1, int(event.width)),
            )

        frame.bind("<Configure>", update_scroll_region, add="+")
        self.capability_canvas.bind("<Configure>", fit_content_width, add="+")
        heading = ttk.Frame(frame)
        heading.pack(fill="x")
        ttk.Label(
            heading,
            text="Find or change a value",
            style="Heading.TLabel",
        ).pack(side="left")
        self.overlay_key_button = ttk.Button(
            heading,
            text="Key",
            command=self.configure_overlay_hotkey,
        )
        self.overlay_key_button.pack(side="right", padx=(5, 0))
        self.overlay_button = ttk.Button(
            heading,
            textvariable=self.overlay_button_var,
            command=self.toggle_overlay_visibility,
        )
        self.overlay_button.pack(side="right")
        self._update_overlay_button()
        hunt_row = ttk.Frame(frame)
        self.hunt_row = hunt_row
        hunt_row.pack(fill="x", pady=(5, 0))
        self.hunt_target_label = ttk.Label(hunt_row, text="Find")
        self.hunt_target_label.grid(row=0, column=0, sticky="w")
        self.hunt_target_combo = ttk.Combobox(
            hunt_row,
            textvariable=self.hunt_target_var,
            values=DIRECT_DISCOVERY_TARGETS,
            state="readonly",
            width=23,
        )
        self.hunt_target_combo.grid(row=0, column=1, sticky="ew", padx=(6, 8))
        self.hunt_value_label = ttk.Label(hunt_row, text="Current value")
        self.hunt_value_label.grid(row=0, column=2, sticky="w")
        self.hunt_value_entry = ttk.Entry(
            hunt_row,
            textvariable=self.hunt_value_var,
            width=14,
        )
        self.hunt_value_entry.grid(row=0, column=3, sticky="ew", padx=(6, 8), ipady=3)
        self.hunt_value_entry.bind("<Return>", self.focus_hunt_target)
        self.hunt_button = ttk.Button(
            hunt_row,
            text="Start / Update",
            command=self.focus_hunt_target,
            style="Primary.TButton",
        )
        self.hunt_button.grid(row=0, column=4, sticky="e")
        hunt_row.columnconfigure(1, weight=1)
        hunt_row.columnconfigure(3, weight=1)
        self.hunt_help_label = ttk.Label(
            frame,
            text=(
                "Enter the number shown in the game when there is one. Leave it blank for "
                "guided health, shield, stamina, movement, or jump learning."
            ),
            style="Muted.TLabel",
        )
        self.hunt_help_label.pack(anchor="w", pady=(3, 4))

        inventory_row = ttk.Frame(frame)
        self.inventory_row = inventory_row
        inventory_row.pack(fill="x", pady=(0, 5))
        self.inventory_observe_button = ttk.Button(
            inventory_row,
            text="Observe inventory (F9)",
            command=lambda: self.capture_inventory_learning_sample("baseline"),
        )
        self.inventory_observe_button.grid(row=0, column=0, sticky="ew")
        self.inventory_changed_button = ttk.Button(
            inventory_row,
            text="Stack changed (F10)",
            command=lambda: self.capture_inventory_learning_sample("changed"),
        )
        self.inventory_changed_button.grid(row=0, column=1, sticky="ew", padx=(6, 0))
        self.inventory_matrix_button = ttk.Button(
            inventory_row,
            text="Auto-map stacks",
            command=self.start_inventory_matrix_learning,
        )
        self.inventory_matrix_button.grid(row=0, column=2, sticky="ew", padx=(6, 0))
        inventory_tools_row = ttk.Frame(frame)
        self.inventory_tools_row = inventory_tools_row
        inventory_tools_row.pack(fill="x", pady=(0, 5))
        self.rescan_values_button = ttk.Button(
            inventory_tools_row,
            text="Rescan saved values",
            command=self.rescan_all_saved_values,
        )
        self.rescan_values_button.grid(row=0, column=0, sticky="w")
        self.inventory_guide_button = ttk.Button(
            inventory_tools_row,
            text="Online item guide",
            command=self.open_inventory_guide,
        )
        self.inventory_guide_button.grid(row=0, column=1, sticky="w", padx=(6, 0))
        self.inventory_hint_label = ttk.Label(
            inventory_tools_row,
            text="Highlight a stack; mapping probes +1, +3, +5 and restores it.",
            style="Muted.TLabel",
        )
        self.inventory_hint_label.grid(row=0, column=2, sticky="w", padx=(10, 0))

        self.quick_section = ttk.Frame(frame)
        self.quick_section.pack(fill="x")
        input_row = ttk.Frame(self.quick_section)
        input_row.pack(fill="x", pady=(5, 0))
        ttk.Label(input_row, text="Quick command").pack(side="left", padx=(0, 6))
        entry = ttk.Entry(input_row, textvariable=self.command_var)
        entry.pack(side="left", fill="x", expand=True, ipady=4)
        entry.bind("<Return>", self.submit_input)
        ttk.Button(
            input_row,
            text="Go",
            command=self.submit_input,
            style="Primary.TButton",
        ).pack(
            side="left",
            padx=(8, 0),
        )
        ttk.Label(
            self.quick_section,
            text="Try: set Units to 999999  ·  health decreased  ·  watch shields",
            style="Muted.TLabel",
        ).pack(anchor="w", pady=(4, 1))
        ttk.Label(
            self.quick_section,
            textvariable=self.command_status_var,
            style="Muted.TLabel",
        ).pack(
            anchor="w",
            pady=(0, 7),
        )
        self.learning_status_label = ttk.Label(
            frame,
            textvariable=self.learning_status_var,
            style="Card.TLabel",
            wraplength=620,
        )
        self.learning_status_label.pack(fill="x", pady=(0, 7))

        toolbar = ttk.Frame(frame)
        toolbar.pack(fill="x", pady=(0, 5))
        ttk.Label(toolbar, text="Learned controls", style="Heading.TLabel").pack(side="left")
        ttk.Button(toolbar, text="Import CT…", command=self.import_ct_reference).pack(
            side="right"
        )
        ttk.Label(frame, textvariable=self.capability_status_var, style="Muted.TLabel").pack(
            anchor="w", pady=(0, 5)
        )

        tree_frame = ttk.Frame(frame)
        self.capability_tree_frame = tree_frame
        tree_frame.pack(fill="both", expand=True)
        self.capability_tree = ttk.Treeview(
            tree_frame,
            columns=("name", "value", "state", "actions"),
            show="headings",
            selectmode="browse",
            height=7,
        )
        for name, label, width, stretch in (
            ("name", "Control", 220, True),
            ("value", "Current", 90, False),
            ("state", "Evidence", 95, False),
            ("actions", "Next", 130, True),
        ):
            self.capability_tree.heading(name, text=label)
            self.capability_tree.column(name, width=width, minwidth=70, stretch=stretch)
        scrollbar = ttk.Scrollbar(
            tree_frame,
            orient="vertical",
            command=self.capability_tree.yview,
        )
        self.capability_tree.configure(yscrollcommand=scrollbar.set)
        self.capability_tree.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
        self.capability_tree.tag_configure("verified", foreground="#17643a")
        self.capability_tree.tag_configure("locked", foreground="#157a73")
        self.capability_tree.tag_configure("candidate", foreground="#8a5400")
        self.capability_tree.tag_configure("reference", foreground="#565d66")
        self.capability_tree.tag_configure("blocked", foreground="#8b2635")
        self.capability_tree.bind("<<TreeviewSelect>>", self._selection_changed)

        detail = ttk.Frame(frame, style="Card.TFrame", padding=9)
        self.capability_detail_frame = detail
        self.capability_detail_label = ttk.Label(
            detail,
            textvariable=self.capability_detail_var,
            style="Card.TLabel",
            wraplength=540,
        )
        self.capability_detail_label.pack(anchor="w")
        editor = ttk.Frame(detail, style="Card.TFrame")
        self.capability_editor_frame = editor
        editor.pack(fill="x", pady=(7, 0))
        ttk.Label(editor, text="New / test value", style="Card.TLabel").pack(side="left")
        self.edit_value_entry = ttk.Entry(
            editor,
            textvariable=self.edit_value_var,
            width=18,
        )
        self.edit_value_entry.pack(side="left", fill="x", expand=True, padx=(7, 7), ipady=3)
        self.edit_value_entry.bind("<Return>", self.apply_entered_value)
        self.edit_value_button = ttk.Button(
            editor,
            text="Select a control",
            command=self.apply_entered_value,
            state="disabled",
            style="Primary.TButton",
        )
        self.edit_value_button.pack(side="right")
        actions = ttk.Frame(detail, style="Card.TFrame")
        self.capability_actions_frame = actions
        actions.pack(fill="x", pady=(7, 0))
        self.primary_button = ttk.Button(
            actions,
            text="Select a control",
            command=self._run_primary_action,
            state="disabled",
            style="Primary.TButton",
        )
        self.primary_button.pack(side="left")
        self.secondary_button = ttk.Button(
            actions,
            text="Watch",
            command=self._run_secondary_action,
            state="disabled",
        )
        self.secondary_button.pack(side="left", padx=(6, 0))
        self.more_menu = self.tk.Menu(self.root, tearoff=False)
        self._more_menu_entries: dict[CapabilityAction, int] = {}
        for label, action, command in (
            ("Watch", CapabilityAction.WATCH, self.watch_selected),
            ("Show in overlay", CapabilityAction.OVERLAY, self.overlay_selected),
            ("Create hotkey", CapabilityAction.HOTKEY, self.hotkey_selected),
            ("Open in Script Lab", CapabilityAction.SCRIPT, self.script_selected),
            ("Pin to top", CapabilityAction.PIN, self.pin_selected),
            ("Restore local preference", CapabilityAction.RESTORE, self.restore_latest_selected),
        ):
            self.more_menu.add_command(label=label, command=command)
            self._more_menu_entries[action] = self.more_menu.index("end")
        self.more_button = ttk.Menubutton(actions, text="More", menu=self.more_menu)
        self.more_button.pack(side="right")
        self._selection_changed()

    def _build_script_lab(self, parent) -> None:
        ttk = self.ttk
        frame = ttk.Frame(parent, padding=12)
        frame.pack(fill="both", expand=True)
        builder = ttk.LabelFrame(frame, text="Native Script Builder", padding=10)
        builder.pack(fill="x")
        fields = (
            ("Name", self.script_name_var),
            ("Target", self.script_target_var),
        )
        for column, (label, variable) in enumerate(fields):
            ttk.Label(builder, text=label).grid(row=0, column=column * 2, sticky="w")
            ttk.Entry(builder, textvariable=variable, width=28).grid(
                row=0,
                column=column * 2 + 1,
                sticky="ew",
                padx=(6, 12),
            )
        ttk.Label(builder, text="Kind").grid(row=1, column=0, sticky="w", pady=(8, 0))
        ttk.Combobox(
            builder,
            textvariable=self.script_kind_var,
            values=tuple(item.value for item in NativeScriptKind),
            state="readonly",
            width=16,
        ).grid(row=1, column=1, sticky="w", padx=(6, 12), pady=(8, 0))
        ttk.Label(builder, text="Operation").grid(row=1, column=2, sticky="w", pady=(8, 0))
        ttk.Entry(builder, textvariable=self.script_operation_var, width=22).grid(
            row=1,
            column=3,
            sticky="w",
            padx=(6, 12),
            pady=(8, 0),
        )
        ttk.Button(builder, text="Build inert candidate", command=self.build_script).grid(
            row=1,
            column=4,
            sticky="e",
            pady=(8, 0),
        )
        builder.columnconfigure(1, weight=1)
        builder.columnconfigure(3, weight=1)

        ttk.Label(frame, textvariable=self.script_status_var, foreground="#565d66").pack(
            anchor="w",
            pady=(6, 8),
        )
        self.script_tree = ttk.Treeview(
            frame,
            columns=("name", "target", "kind", "source", "status"),
            show="headings",
            height=12,
        )
        for name, label, width in (
            ("name", "Script", 230),
            ("target", "Target", 170),
            ("kind", "Kind", 90),
            ("source", "Source", 140),
            ("status", "Gate", 360),
        ):
            self.script_tree.heading(name, text=label)
            self.script_tree.column(name, width=width, minwidth=70)
        self.script_tree.pack(fill="both", expand=True)

    def _build_history(self, parent) -> None:
        ttk = self.ttk
        frame = ttk.Frame(parent, padding=12)
        frame.pack(fill="both", expand=True)
        ttk.Label(frame, textvariable=self.history_status_var).pack(anchor="w", pady=(0, 8))
        self.history_tree = ttk.Treeview(
            frame,
            columns=("time", "capability", "action", "before", "after"),
            show="headings",
            height=15,
        )
        for name, label, width in (
            ("time", "Time", 160),
            ("capability", "Capability", 220),
            ("action", "Action", 140),
            ("before", "Before", 160),
            ("after", "After", 160),
        ):
            self.history_tree.heading(name, text=label)
            self.history_tree.column(name, width=width, minwidth=70)
        self.history_tree.pack(fill="both", expand=True)
        ttk.Button(
            frame,
            text="Restore selected local preference",
            command=self.restore_history_selection,
        ).pack(anchor="e", pady=(8, 0))

    def update_catalog(self, catalog: dict[str, Any], *, write_enabled: bool) -> None:
        mounted_rows = build_capability_rows(catalog, write_enabled=write_enabled)
        mounted_targets = {
            row.name.casefold()
            for row in mounted_rows
            if row.discovery_candidate_ids or row.write_actions_unlocked
        }
        learning_rows = [
            row
            for row in [*self._screen_rows.values(), *self._inventory_rows.values()]
            if self._learning_targets_by_row.get(row.id, "") not in mounted_targets
        ]
        self.rows = [
            *mounted_rows,
            *learning_rows,
        ]
        locked = sum(row.state is CapabilityState.LOCKED for row in self.rows)
        editable = sum(
            bool(row.discovery_candidate_ids or row.write_actions_unlocked) for row in self.rows
        )
        self.capability_status_var.set(
            f"{len(self.rows)} controls mounted; {editable} ready to edit or test; "
            f"{locked} learned this run. Discovery continues automatically."
        )
        self._record_overlay_samples()
        self.render_capabilities()
        self.render_overlay()

    def add_screen_observations(self, result: dict[str, Any]) -> list[dict[str, Any]]:
        """Merge named bars and OCR values into stable, local-only learning rows."""

        if not hasattr(self, "_learning_targets_by_row"):
            self._learning_targets_by_row = {}
        if not hasattr(self, "_screen_last_values"):
            self._screen_last_values = {}
        stable: list[dict[str, Any]] = []
        for detection in result.get("detections") or []:
            confidence = float(detection.get("confidence") or 0.0)
            if confidence < 0.55:
                continue
            target = str(detection.get("hud_target") or "").strip()
            if not target:
                continue
            label = str(detection.get("hud_label") or target.title())
            zone = str(detection.get("zone") or "unknown")
            x = int(detection.get("x") or 0)
            y = int(detection.get("y") or 0)
            width = int(detection.get("width") or 0)
            height = int(detection.get("height") or 0)
            raw_filled_width = detection.get("filled_width")
            filled_width = (
                int(raw_filled_width)
                if raw_filled_width is not None
                else max(
                    1,
                    round(width * float(detection.get("percent") or 100.0) / 100.0),
                )
            )
            key = f"{target.casefold()}:{zone}:{x // 32}:{y // 24}:{max(1, height // 8)}"
            row_id = f"screen:{key}"
            if not hasattr(self, "_screen_bar_max_widths"):
                self._screen_bar_max_widths = {}
            known_width = max(
                self._screen_bar_max_widths.get(row_id, 0),
                width,
                filled_width,
            )
            self._screen_bar_max_widths[row_id] = known_width
            measured_percent = (
                round(float(detection.get("percent") or 0.0), 1)
                if raw_filled_width is None
                else round(
                    max(0.0, min(100.0, filled_width * 100 / max(1, known_width))),
                    1,
                )
            )
            previous_percent = self._screen_last_values.get(row_id)
            if previous_percent is None:
                comparison = "baseline"
            elif measured_percent > previous_percent + 0.5:
                comparison = "increased"
            elif measured_percent < previous_percent - 0.5:
                comparison = "decreased"
            else:
                comparison = "unchanged"
            self._screen_last_values[row_id] = measured_percent
            samples = self._screen_observation_counts.get(row_id, 0) + 1
            total_confidence = self._screen_confidence_totals.get(row_id, 0.0) + confidence
            self._screen_observation_counts[row_id] = samples
            self._screen_confidence_totals[row_id] = total_confidence
            average_confidence = total_confidence / samples
            locked = samples >= 3 and average_confidence >= 0.7
            screen_position = zone.replace("_", "-")
            self._screen_rows[row_id] = CapabilityRow(
                id=row_id,
                name=f"{label} ({screen_position})",
                current_value=measured_percent,
                maximum_value=100.0,
                state=CapabilityState.LOCKED if locked else CapabilityState.CANDIDATE,
                source="local_screen_burst",
                priority=70 if locked else 58,
                actions=(
                    [
                        CapabilityAction.WATCH,
                        CapabilityAction.HISTORY,
                        CapabilityAction.REVERIFY,
                        CapabilityAction.PIN,
                    ]
                    if locked
                    else [
                        CapabilityAction.VERIFY,
                        CapabilityAction.HISTORY,
                        CapabilityAction.PIN,
                    ]
                ),
                evidence=[
                    f"Observed in {samples} local game-window frame(s).",
                    "Each screenshot was discarded immediately and was never uploaded.",
                    str(
                        detection.get("classification_reason")
                        or "HUD identity used screen position; color alone was not trusted."
                    ),
                    (
                        "Stable screen location is locked for this run only."
                        if locked
                        else "Two more consistent observations are required to lock this row."
                    ),
                ],
            )
            self._learning_targets_by_row[row_id] = target.casefold()
            if locked:
                stable.append(
                    {
                        "target": target,
                        "value": round(
                            measured_percent / 100.0,
                            4,
                        ),
                        "percent": measured_percent,
                        "confidence": average_confidence,
                        "samples": samples,
                        "value_type": "f32",
                        "normalized": True,
                        "x": x,
                        "y": y,
                        "width": known_width,
                        "height": height,
                        "zone": zone,
                        "comparison": comparison,
                        "previous_value": (
                            round(previous_percent / 100.0, 4)
                            if previous_percent is not None
                            else None
                        ),
                    }
                )
        for detection in result.get("visible_values") or []:
            confidence = float(detection.get("confidence") or 0.0)
            target = str(detection.get("target") or "").strip()
            if confidence < 0.55 or not target:
                continue
            label = str(detection.get("label") or target).strip()
            zone = str(detection.get("zone") or "unknown")
            x = int(detection.get("x") or 0)
            y = int(detection.get("y") or 0)
            width = int(detection.get("width") or 0)
            height = int(detection.get("height") or 0)
            key = f"value:{target.casefold()}:{zone}:{x // 32}:{y // 24}"
            row_id = f"screen:{key}"
            samples = self._screen_observation_counts.get(row_id, 0) + 1
            total_confidence = self._screen_confidence_totals.get(row_id, 0.0) + confidence
            self._screen_observation_counts[row_id] = samples
            self._screen_confidence_totals[row_id] = total_confidence
            average_confidence = total_confidence / samples
            locked = samples >= 2 and average_confidence >= 0.7
            current = detection.get("current_value")
            scan_value = float(detection.get("scan_value", current))
            previous_scan_value = self._screen_last_values.get(row_id)
            threshold = 0.005 if bool(detection.get("normalized")) else 0.0
            if previous_scan_value is None:
                comparison = "baseline"
            elif scan_value > previous_scan_value + threshold:
                comparison = "increased"
            elif scan_value < previous_scan_value - threshold:
                comparison = "decreased"
            else:
                comparison = "unchanged"
            self._screen_last_values[row_id] = scan_value
            self._screen_rows[row_id] = CapabilityRow(
                id=row_id,
                name=label,
                current_value=current,
                state=CapabilityState.LOCKED if locked else CapabilityState.CANDIDATE,
                source="local_screen_ocr",
                priority=82 if locked else 64,
                actions=(
                    [CapabilityAction.HISTORY, CapabilityAction.REVERIFY, CapabilityAction.PIN]
                    if locked
                    else [CapabilityAction.VERIFY, CapabilityAction.HISTORY, CapabilityAction.PIN]
                ),
                evidence=[
                    f"Read from {samples} matching foreground game frame(s) with on-device OCR.",
                    "The screenshot was discarded immediately and was never uploaded.",
                    (
                        "Stable screen value is feeding the exact RAM scan automatically."
                        if locked
                        else "One more matching screen observation is required before scanning."
                    ),
                ],
            )
            self._learning_targets_by_row[row_id] = target.casefold()
            if locked:
                stable.append(
                    {
                        "target": target,
                        "label": label,
                        "value": detection.get("scan_value", current),
                        "display_value": current,
                        "value_type": str(detection.get("value_type") or "i32"),
                        "normalized": bool(detection.get("normalized")),
                        "confidence": average_confidence,
                        "samples": samples,
                        "x": x,
                        "y": y,
                        "width": width,
                        "height": height,
                        "zone": zone,
                        "comparison": comparison,
                        "previous_value": previous_scan_value,
                    }
                )
        mounted = [row for row in self.rows if not row.id.startswith("screen:")]
        self.rows = [*mounted, *self._screen_rows.values()]
        self._record_overlay_samples()
        self.render_capabilities()
        self.render_overlay()
        return stable

    def add_inventory_observations(self, result: dict[str, Any]) -> list[dict[str, Any]]:
        """Merge menu-aware, local-OCR inventory counts into learning rows."""

        if not hasattr(self, "_learning_targets_by_row"):
            self._learning_targets_by_row = {}
        if not hasattr(self, "_inventory_consecutive_values"):
            self._inventory_consecutive_values = {}
        stable: list[dict[str, Any]] = []
        default_label = str(result.get("selected_item_label") or "Inventory stack")
        self._inventory_guide_url = str(result.get("guide_url") or "")
        for detection in result.get("detections") or []:
            confidence = float(detection.get("confidence") or 0.0)
            if confidence < 0.55:
                continue
            current = int(detection.get("current_value") or 0)
            maximum_raw = detection.get("maximum_value")
            maximum = int(maximum_raw) if maximum_raw is not None else None
            selected = bool(detection.get("selected"))
            x = int(detection.get("x") or 0)
            y = int(detection.get("y") or 0)
            label = str(detection.get("item_label") or default_label)
            reference_url = str(detection.get("reference_url") or "")
            key = f"{x // 48}:{y // 36}:{maximum or 0}:{'selected' if selected else 'visible'}"
            row_id = f"inventory-screen:{key}"
            samples = self._inventory_observation_counts.get(row_id, 0) + 1
            self._inventory_observation_counts[row_id] = samples
            previous_value = self._inventory_consecutive_values.get(row_id)
            consecutive = (
                previous_value[2] + 1
                if previous_value is not None
                and previous_value[:2] == (current, maximum)
                else 1
            )
            self._inventory_consecutive_values[row_id] = (current, maximum, consecutive)
            locked = consecutive >= 2 and confidence >= 0.75
            self._inventory_rows[row_id] = CapabilityRow(
                id=row_id,
                name=f"{label} inventory count",
                current_value=current,
                maximum_value=maximum,
                state=CapabilityState.LOCKED if locked else CapabilityState.CANDIDATE,
                source="local_inventory_ocr",
                priority=88 if selected else 52,
                actions=(
                    [CapabilityAction.REVERIFY, CapabilityAction.HISTORY, CapabilityAction.PIN]
                    if locked
                    else [CapabilityAction.VERIFY, CapabilityAction.HISTORY, CapabilityAction.PIN]
                ),
                evidence=[
                    f"Read from {samples} foreground inventory frame(s) with on-device OCR.",
                    "The game-window pixels were discarded immediately and never uploaded.",
                    (
                        "Selected current/max stack is eligible to seed the exact RAM scan."
                        if selected and maximum is not None
                        else "Visible neighbor count is context only until deliberately selected."
                    ),
                    *(
                        [
                            f"Canonical item name matched to {reference_url}; the raw screen "
                            "label remains observation evidence."
                        ]
                        if reference_url
                        else []
                    ),
                ],
            )
            self._learning_targets_by_row[row_id] = "inventory item quantity"
            if (
                selected
                and maximum is not None
                and confidence >= 0.85
                and consecutive >= 2
            ):
                stable.append(
                    {
                        "target": "inventory item quantity",
                        "label": label,
                        "value": current,
                        "maximum": maximum,
                        "confidence": confidence,
                    }
                )
        mounted = [
            row
            for row in self.rows
            if not row.id.startswith("inventory-screen:")
        ]
        self.rows = [*mounted, *self._inventory_rows.values()]
        self._record_overlay_samples()
        self.render_capabilities()
        self.render_overlay()
        return stable

    def set_learning_status(self, message: str) -> None:
        self.learning_status_var.set(message)

    def clear_screen_observations(self) -> None:
        self._screen_rows.clear()
        self._screen_observation_counts.clear()
        self._screen_confidence_totals.clear()
        self._screen_bar_max_widths.clear()
        getattr(self, "_screen_last_values", {}).clear()
        self._inventory_rows.clear()
        self._inventory_observation_counts.clear()
        getattr(self, "_inventory_consecutive_values", {}).clear()
        self._learning_targets_by_row.clear()
        self._confirmed_learning_targets.clear()
        self._last_inventory_seed = None
        self._last_inventory_result = None
        self._inventory_auto_map_signature = None
        self.rows = [
            row
            for row in self.rows
            if not row.id.startswith(("screen:", "inventory-screen:"))
        ]
        self.render_capabilities()
        self.render_overlay()

    def set_confirmed_learning_targets(self, targets: list[str]) -> None:
        confirmed = {target.casefold() for target in targets}
        self._confirmed_learning_targets = confirmed
        removed_ids = {
            row_id
            for row_id, target in self._learning_targets_by_row.items()
            if target in confirmed
        }
        for row_id in removed_ids:
            getattr(self, "_screen_rows", {}).pop(row_id, None)
            getattr(self, "_inventory_rows", {}).pop(row_id, None)
            self._learning_targets_by_row.pop(row_id, None)
        if removed_ids:
            self.rows = [row for row in self.rows if row.id not in removed_ids]
            self.render_capabilities()
        self.render_overlay()

    def open_inventory_guide(self) -> None:
        if not self._inventory_guide_url:
            self.command_status_var.set(
                "No trusted item reference is registered for this game yet."
            )
            return
        try:
            opened = webbrowser.open(self._inventory_guide_url, new=2)
        except Exception:  # noqa: BLE001 - leave a copyable URL when no browser is available
            opened = False
        if not opened:
            self.command_status_var.set(
                f"Open this item guide in a browser: {self._inventory_guide_url}"
            )

    def capture_inventory_learning_sample(self, phase: str = "observe") -> None:
        session = self.get_active_session()
        if session is None:
            self.command_status_var.set("Choose a running game before observing inventory.")
            return
        if self._inventory_capture_busy:
            return
        self._inventory_capture_busy = True
        self.command_status_var.set(
            "Reading the highlighted inventory stack locally..."
            if phase != "changed"
            else "Reading the changed stack and narrowing its RAM candidates..."
        )
        session_id = str(session.get("session_id") or "")

        def inspect() -> dict[str, Any]:
            try:
                return self.controller.inspect_inventory(session_id)
            except Exception as exc:  # noqa: BLE001 - surface errors and release the busy guard
                return {
                    "capture_status": "unavailable",
                    "message": f"Inventory observation failed: {exc}",
                }

        self.run_background(
            inspect,
            lambda result: self._inventory_capture_finished(phase, result),
        )

    def _inventory_capture_finished(self, phase: str, result: dict[str, Any]) -> None:
        self._inventory_capture_busy = False
        if str(result.get("capture_status") or "captured") != "captured":
            self.learning_status_var.set(
                f"Learning guide: {result.get('message') or 'Open inventory and try again.'}"
            )
            return
        self._last_inventory_result = dict(result)
        observations = self.add_inventory_observations(result)
        if not observations:
            self.learning_status_var.set(
                f"Learning guide: {result.get('message') or 'Highlight a counted stack.'}"
            )
            return
        selected = observations[0]
        label = str(selected.get("label") or "Inventory stack")
        value = int(selected["value"])
        maximum = int(selected["maximum"])
        seed = (label.casefold(), value, maximum)
        if seed == self._last_inventory_seed:
            self.learning_status_var.set(
                f"Learning guide: Watching {label} at {value}/{maximum}; RAM narrowing and "
                "automatic odd-marker verification are active."
            )
        self._last_inventory_seed = seed
        target = "inventory item quantity"
        run_id = self.get_discovery_run_id() or self._focused_run_id
        if run_id:
            self.run_background(
                lambda: self.controller.set_autonomous_discovery_value(
                    run_id,
                    target,
                    value,
                    source="screen",
                ),
                lambda status: self._inventory_value_applied(
                    phase,
                    label,
                    value,
                    maximum,
                    status,
                ),
            )
            return
        session = self.get_active_session() or {}
        self.run_background(
            lambda: self.controller.start_autonomous_discovery(
                session_id=str(session.get("session_id") or ""),
                process_name=str(session.get("process_name") or "NMS.exe"),
                target_order=[
                    target,
                    *(name for name in DIRECT_DISCOVERY_TARGETS if name != target),
                ],
            ),
            lambda status: self._inventory_run_started(
                phase,
                label,
                value,
                maximum,
                status,
            ),
        )

    def _inventory_run_started(
        self,
        phase: str,
        label: str,
        value: int,
        maximum: int,
        status: dict[str, Any],
    ) -> None:
        run_id = str(status.get("id") or "")
        if not run_id:
            self.command_status_var.set("The inventory learner did not return a usable run.")
            return
        self._focused_run_id = run_id
        self.run_background(
            lambda: self.controller.set_autonomous_discovery_value(
                run_id,
                "inventory item quantity",
                value,
                source="screen",
            ),
            lambda updated: self._inventory_value_applied(
                phase,
                label,
                value,
                maximum,
                updated,
            ),
        )

    def _inventory_value_applied(
        self,
        phase: str,
        label: str,
        value: int,
        maximum: int,
        status: dict[str, Any],
    ) -> None:
        target = self._target_status(status, "inventory item quantity")
        count = int(target.get("candidate_count") or 0)
        verb = "Baseline" if phase != "changed" else "Changed value"
        self.command_status_var.set(
            f"{verb}: {label} {value}/{maximum}; {count} RAM candidates remain."
        )
        self.learning_status_var.set(
            f"Learning guide: Change only {label}, then press F10. Confirmed inventory values "
            "leave the overlay automatically."
        )
        candidates = target.get("candidates") or []
        if phase in {"changed", "automatic"} and 1 <= count <= 5 and candidates:
            self.maybe_start_inventory_matrix(status)

    def maybe_start_inventory_matrix(self, status: dict[str, Any]) -> None:
        """Start one automatic odd-delta map when inventory and 1-5 candidates are ready."""

        session = self.get_active_session()
        last_result = self._last_inventory_result or {}
        if (
            session is None
            or not bool(session.get("write_enabled"))
            or self._inventory_capture_busy
            or self._inventory_auto_map_signature is not None
            or not last_result.get("detections")
        ):
            return
        target = self._target_status(status, "inventory item quantity")
        ready = tuple(
            sorted(
                str(candidate.get("id") or "")
                for candidate in target.get("candidates") or []
                if str(candidate.get("write_test_status") or "") in {"ready", "confirmed"}
                and str(candidate.get("id") or "")
            )
        )
        if not 1 <= len(ready) <= 5:
            return
        signature = (
            str(status.get("id") or self.get_discovery_run_id() or ""),
            int(target.get("generation") or 0),
            ready,
        )
        if not signature[0] or signature in self._inventory_auto_map_attempts:
            return
        self._inventory_auto_map_signature = signature
        self.root.after(100, lambda: self.start_inventory_matrix_learning(automatic=True))

    def rescan_all_saved_values(self) -> None:
        run_id = self.get_discovery_run_id() or self._focused_run_id
        if not run_id:
            self.command_status_var.set("Choose a running game before rescanning its values.")
            return
        self.command_status_var.set(
            "Refreshing save evidence and queuing every known value again..."
        )
        self.run_background(
            lambda: self.controller.rescan_autonomous_discovery_values(run_id),
            self._all_values_rescan_finished,
        )

    def _all_values_rescan_finished(self, status: dict[str, Any]) -> None:
        count = int(status.get("save_rescan_count") or 0)
        provider = str(status.get("save_provider_name") or "current learned values")
        self.command_status_var.set(
            f"All known values were requeued from {provider}; rescan generation {count}."
        )
        self.learning_status_var.set(
            "Learning guide: previous scan generations were preserved for rollback."
        )

    def start_inventory_matrix_learning(self, automatic: bool = False) -> None:
        session = self.get_active_session()
        run_id = self.get_discovery_run_id() or self._focused_run_id
        if session is None or not run_id:
            self._inventory_auto_map_signature = None
            self.command_status_var.set("Choose a running game and start inventory learning first.")
            return
        if not bool(session.get("write_enabled")):
            self._inventory_auto_map_signature = None
            self.command_status_var.set(
                "Inventory mapping needs value editing enabled for this selected offline game."
            )
            return
        if self._inventory_capture_busy:
            if automatic:
                self._inventory_auto_map_signature = None
            return
        self._inventory_capture_busy = True
        self.command_status_var.set("Capturing the visible inventory before the matrix probe...")
        session_id = str(session.get("session_id") or "")

        def capture() -> dict[str, Any]:
            try:
                return self.controller.inspect_inventory(session_id)
            except Exception as exc:  # noqa: BLE001 - no write has happened yet
                return {"capture_status": "unavailable", "message": str(exc)}

        self.run_background(
            capture,
            lambda result: self._inventory_matrix_baseline_finished(run_id, result),
        )

    def _inventory_matrix_baseline_finished(
        self,
        run_id: str,
        baseline: dict[str, Any],
    ) -> None:
        if (
            str(baseline.get("capture_status") or "captured") != "captured"
            or not baseline.get("detections")
        ):
            self._inventory_capture_busy = False
            self._inventory_auto_map_signature = None
            self._last_inventory_result = None
            self.command_status_var.set(
                f"Open the inventory and try Auto-map again: "
                f"{baseline.get('message') or 'no counted stack is visible'}"
            )
            return
        self._inventory_matrix_baseline = baseline

        def prepare() -> dict[str, Any]:
            try:
                return self.controller.prepare_inventory_matrix_probe(run_id)
            except Exception as exc:  # noqa: BLE001 - preparation performs no write
                return {"error": str(exc)}

        self.run_background(prepare, self._inventory_matrix_prepared)

    def _inventory_matrix_prepared(self, probe: dict[str, Any]) -> None:
        if probe.get("error"):
            self._inventory_capture_busy = False
            if self._inventory_auto_map_signature is not None:
                self._inventory_auto_map_attempts.add(self._inventory_auto_map_signature)
            self._inventory_auto_map_signature = None
            self.command_status_var.set(f"Inventory matrix is not ready: {probe['error']}")
            return
        self._inventory_matrix_probe = probe
        deltas = ", ".join(f"{int(item.get('delta', 0)):+d}" for item in probe.get("entries", []))
        self.command_status_var.set(f"Applying short inventory markers {deltas}...")

        def apply() -> dict[str, Any]:
            try:
                return self.controller.apply_inventory_matrix_probe(
                    str(probe.get("probe_id") or "")
                )
            except Exception as exc:  # noqa: BLE001 - backend restores partial application
                return {"error": str(exc)}

        self.run_background(apply, self._inventory_matrix_applied)

    def _inventory_matrix_applied(self, result: dict[str, Any]) -> None:
        if result.get("error"):
            self._inventory_capture_busy = False
            self._inventory_matrix_probe = None
            if self._inventory_auto_map_signature is not None:
                self._inventory_auto_map_attempts.add(self._inventory_auto_map_signature)
            self._inventory_auto_map_signature = None
            self.command_status_var.set(f"Inventory matrix stopped safely: {result['error']}")
            return
        self.command_status_var.set(
            "Odd markers are visible briefly; observing the changed stacks now..."
        )
        self.root.after(1500, self._capture_changed_inventory_matrix)

    def _capture_changed_inventory_matrix(self) -> None:
        session = self.get_active_session() or {}
        session_id = str(session.get("session_id") or "")

        def capture() -> dict[str, Any]:
            try:
                return self.controller.inspect_inventory(session_id)
            except Exception as exc:  # noqa: BLE001 - restore runs even without a screenshot
                return {"capture_status": "unavailable", "message": str(exc)}

        self.run_background(capture, self._inventory_matrix_observed)

    def _inventory_matrix_observed(self, changed: dict[str, Any]) -> None:
        probe = self._inventory_matrix_probe or {}
        baseline = self._inventory_matrix_baseline or {}
        matches: dict[str, str] = {}
        reference_urls: dict[str, str] = {}
        if str(changed.get("capture_status") or "captured") == "captured":
            matches, reference_urls = correlate_inventory_matrix_observations(
                baseline,
                changed,
                list(probe.get("entries") or []),
            )
        probe_id = str(probe.get("probe_id") or "")

        def restore() -> dict[str, Any]:
            try:
                return self.controller.restore_inventory_matrix_probe(
                    probe_id,
                    matches,
                    reference_urls,
                )
            except Exception as exc:  # noqa: BLE001 - make any restore gap explicit
                return {"error": str(exc)}

        self.run_background(restore, self._inventory_matrix_restored)

    def _inventory_matrix_restored(self, result: dict[str, Any]) -> None:
        self._inventory_capture_busy = False
        self._inventory_matrix_probe = None
        self._inventory_matrix_baseline = None
        signature = self._inventory_auto_map_signature
        self._inventory_auto_map_signature = None
        if signature is not None:
            self._inventory_auto_map_attempts.add(signature)
        if result.get("error"):
            self.command_status_var.set(f"Inventory restore needs attention: {result['error']}")
            return
        matches = result.get("matched_candidates") or {}
        if matches:
            names = ", ".join(dict.fromkeys(str(name) for name in matches.values()))
            self.command_status_var.set(
                f"Mapped and restored {len(matches)} inventory value(s): {names}."
            )
            self.learning_status_var.set(
                "Learning guide: canonical item names are saved with the verified slot locators."
            )
        else:
            self.command_status_var.set(
                "All original stack values were restored; no unambiguous screen match was saved."
            )

    def add_priority_map(self, priority_map: ValuePriorityMap) -> None:
        existing = {row.id: row for row in self.rows}
        for index, entry in enumerate(priority_map.entries):
            item_id = f"ct:{priority_map.source_sha256[:12]}:{index}"
            existing[item_id] = CapabilityRow(
                id=item_id,
                name=entry.name,
                state=CapabilityState.REFERENCE,
                source=entry.source,
                priority=entry.priority,
                actions=[
                    CapabilityAction.VERIFY,
                    CapabilityAction.HISTORY,
                    CapabilityAction.PIN,
                ],
                evidence=entry.evidence,
            )
        self.rows = sorted(
            existing.values(),
            key=lambda item: (item.id in self.state.pinned, item.priority),
            reverse=True,
        )
        self.capability_status_var.set(
            f"Imported {len(priority_map.entries)} CT references; all remain inert."
        )
        self.render_capabilities()

    @staticmethod
    def _parse_numeric_text(raw: str) -> int | float:
        normalized = raw.strip().replace(",", "")
        if not normalized:
            raise ValueError("Enter the value exactly as it appears in the game.")
        try:
            if any(token in normalized for token in (".", "e", "E")):
                return float(normalized)
            return int(normalized)
        except ValueError as exc:
            raise ValueError("Enter a number exactly as it appears in the game.") from exc

    @staticmethod
    def _editor_value_error(row: CapabilityRow, value: int | float) -> str | None:
        if row.value_type is None:
            return None
        try:
            encode_value(row.value_type, value)
        except GTPError:
            bounds = INTEGER_VALUE_BOUNDS.get(row.value_type)
            if bounds is not None:
                minimum, maximum = bounds
                return (
                    f"{row.name} must be a whole number from {minimum:,} to {maximum:,} "
                    f"for this {row.value_type} value."
                )
            return f"{row.name} must be a finite number supported by this {row.value_type} value."
        return None

    def focus_hunt_target(self, _event=None) -> None:
        session = self.get_active_session()
        if session is None:
            self.command_status_var.set("Choose a running game first.")
            return
        target = self.hunt_target_var.get().strip()
        raw_value = self.hunt_value_var.get().strip()
        try:
            value = self._parse_numeric_text(raw_value) if raw_value else None
        except ValueError as exc:
            self.command_status_var.set(str(exc))
            return
        self.command_status_var.set(f"Moving {target} to the front of the live learner...")
        target_order = [
            target,
            *(
                name
                for name in DIRECT_DISCOVERY_TARGETS
                if name.casefold() != target.casefold()
            ),
        ]
        self.run_background(
            lambda: self.controller.start_autonomous_discovery(
                session_id=str(session.get("session_id") or ""),
                process_name=str(session.get("process_name") or "NMS.exe"),
                target_order=target_order,
            ),
            lambda status: self._hunt_target_started(target, value, status),
        )

    def _hunt_target_started(
        self,
        target: str,
        value: int | float | None,
        status: dict[str, Any],
    ) -> None:
        run_id = str(status.get("id") or "")
        if not run_id:
            self.command_status_var.set("The learner did not return a usable run.")
            return
        self._focused_run_id = run_id
        if value is not None:
            self.command_status_var.set(f"Using {target} = {value:g} in the live scan...")
            self.run_background(
                lambda: self.controller.set_autonomous_discovery_value(
                    run_id,
                    target,
                    value,
                    source="user",
                ),
                lambda updated: self._hunt_value_applied(target, value, updated),
            )
            return
        matching = self._target_status(status, target)
        prompt = str(
            matching.get("experiment_prompt")
            or f"Change {target} once in the game while the learner watches."
        )
        self.command_status_var.set(f"{target} is now first in the learning queue.")
        self.learning_status_var.set(f"Learning guide: {prompt}")

    def _hunt_value_applied(
        self,
        target: str,
        value: int | float,
        status: dict[str, Any],
    ) -> None:
        self.hunt_value_var.set("")
        matching = self._target_status(status, target)
        count = int(matching.get("candidate_count") or 0)
        self.command_status_var.set(
            f"{target} = {value:g} is now the directed scan; {count} candidates remain."
        )
        prompt = str(
            matching.get("experiment_prompt")
            or f"Change {target} once, then enter the new displayed value."
        )
        self.learning_status_var.set(f"Learning guide: {prompt}")

    @staticmethod
    def _target_status(status: dict[str, Any], target: str) -> dict[str, Any]:
        return next(
            (
                item
                for item in status.get("targets", [])
                if str(item.get("name") or "").casefold() == target.casefold()
            ),
            {},
        )

    def render_capabilities(self) -> None:
        selected = self.selected_row()
        selected_capability_id = selected.id if selected is not None else None
        self.capability_tree.delete(*self.capability_tree.get_children())
        self.row_by_item.clear()
        ordered = sorted(
            self.rows,
            key=lambda item: (item.id in self.state.pinned, item.priority),
            reverse=True,
        )
        selected_item_id = None
        for index, row in enumerate(ordered):
            item_id = f"capability-{index}"
            current = "—" if row.current_value is None else str(row.current_value)
            if row.maximum_value is not None:
                current = f"{current} / {row.maximum_value}"
            self.capability_tree.insert(
                "",
                "end",
                iid=item_id,
                values=(
                    f"★ {row.name}" if row.id in self.state.pinned else row.name,
                    current,
                    row.state.value.replace("_", " ").title(),
                    self._next_action_label(row),
                ),
                tags=(row.state.value,),
            )
            self.row_by_item[item_id] = row
            if row.id == selected_capability_id:
                selected_item_id = item_id
        if not ordered:
            self.capability_tree.insert(
                "",
                "end",
                iid="empty",
                values=("No controls learned yet", "—", "Waiting", "Choose a running game"),
                tags=("reference",),
            )
        if selected_item_id is not None:
            self.capability_tree.selection_set(selected_item_id)
            self.capability_tree.see(selected_item_id)
        self._selection_changed()

    @staticmethod
    def _next_action_label(row: CapabilityRow) -> str:
        if row.discovery_candidate_ids or row.write_actions_unlocked:
            return "Apply value"
        if row.state in {
            CapabilityState.CANDIDATE,
            CapabilityState.REFERENCE,
        }:
            return "Verify first"
        preferred = [
            action
            for action in row.actions
            if action
            in {
                CapabilityAction.SET,
                CapabilityAction.ADJUST,
                CapabilityAction.FREEZE,
                CapabilityAction.WATCH,
                CapabilityAction.REVERIFY,
            }
        ]
        return " · ".join(action.value.title() for action in preferred[:2]) or "View evidence"

    def submit_input(self, _event=None) -> None:
        row = self.selected_row()
        try:
            plan = parse_multi_use_input(
                self.command_var.get(),
                selected_target=row.name if row else None,
            )
        except ValueError as exc:
            self.command_status_var.set(str(exc))
            return
        self.state_store.record(
            self.state,
            action=f"input:{plan.kind.value}",
            capability_id=row.id if row else None,
            after=plan.raw,
        )
        if plan.kind.value == "value":
            run_id = self.get_discovery_run_id() or self._focused_run_id
            if not run_id:
                self.command_status_var.set("Pick a running game before entering a value.")
            elif not plan.target:
                self.command_status_var.set(
                    "Select the control this number belongs to, then enter it again."
                )
            else:
                value = plan.value or 0.0
                target = plan.target
                self.command_status_var.set(
                    f"Applying {value:g} to the live {target} first/next scan..."
                )
                self.run_background(
                    lambda: self.controller.set_autonomous_discovery_value(
                        run_id,
                        target,
                        value,
                        source="user",
                    ),
                    lambda status: self._visible_value_applied(target, value, status),
                )
        elif plan.kind.value == "direction":
            self.command_status_var.set(
                f"Recorded {plan.direction} event evidence; earlier generations are preserved."
            )
        elif plan.kind.value == "action":
            target_row = self._select_row_named(plan.target or "")
            if target_row is None:
                self.command_status_var.set(
                    f"{plan.target or 'That control'} has not been found yet. "
                    "Choose it in Find first."
                )
                self.render_history()
                return
            if (
                plan.action in {CapabilityAction.SET, CapabilityAction.ADJUST}
                and plan.value is not None
            ):
                self.edit_value_var.set(f"{plan.value:g}")
                self.apply_entered_value()
                self.render_history()
                return
            qualifier = (
                "ready to apply from the value editor"
                if plan.requires_write
                else "ready as a safe local/read-only action"
            )
            self.command_status_var.set(f"{plan.action.value.title()} {plan.target}: {qualifier}.")
            self._run_selected_action(plan.action)
        else:
            self.command_status_var.set(
                "GPT request classified for the existing assistant; it grants no write authority."
            )
        self.render_history()

    def _visible_value_applied(
        self,
        target: str,
        value: int | float,
        status: dict[str, Any],
    ) -> None:
        self.command_var.set("")
        matching = next(
            (
                item
                for item in status.get("targets", [])
                if str(item.get("name") or "").casefold() == target.casefold()
            ),
            {},
        )
        count = int(matching.get("candidate_count") or 0)
        self.command_status_var.set(
            f"{target} = {value:g} is active in the live scan; {count} candidates remain."
        )
        self.set_learning_status(
            f"Learning guide: change {target} once in the game, then enter the new value here."
        )

    def import_ct_reference(self) -> None:
        from tkinter import filedialog

        selected = filedialog.askopenfilename(
            parent=self.root,
            title="Import CT as reference only",
            filetypes=(("Cheat Engine table", "*.CT"), ("All files", "*.*")),
        )
        if not selected:
            return
        self.capability_status_var.set("Parsing CT as inert data...")
        self.run_background(
            lambda: self.controller.import_ct_reference(selected),
            self._ct_import_finished,
        )

    def _ct_import_finished(self, result: dict[str, Any]) -> None:
        from gtp_games.models import CheatTableResult

        parsed = CheatTableResult.model_validate(result)
        priority_map = build_ct_value_priority_map(parsed)
        self.add_priority_map(priority_map)
        for finding in parsed.script_findings:
            self.scripts.append(
                translate_ct_script_reference(
                    finding,
                    table_sha256=parsed.source_sha256,
                )
            )
        self.script_store.save(self.scripts)
        self.render_scripts()

    def selected_row(self) -> CapabilityRow | None:
        selected = self.capability_tree.selection()
        return self.row_by_item.get(selected[0]) if selected else None

    def _select_row_named(self, name: str) -> CapabilityRow | None:
        normalized = name.casefold().strip()
        singular = normalized[:-1] if normalized.endswith("s") else normalized
        for item_id, row in self.row_by_item.items():
            row_name = row.name.casefold().strip()
            row_singular = row_name[:-1] if row_name.endswith("s") else row_name
            if normalized == row_name or singular == row_singular:
                self.capability_tree.selection_set(item_id)
                self.capability_tree.see(item_id)
                self._selection_changed()
                return row
        return None

    def _selection_changed(self, _event=None) -> None:
        row = self.selected_row()
        if row is None:
            self.capability_detail_frame.pack_forget()
            self._editing_row_id = None
            self._primary_action = None
            self._secondary_action = None
            self.primary_button.configure(text="Select a control", state="disabled")
            self.secondary_button.configure(text="Watch", state="disabled")
            self.more_button.configure(state="disabled")
            self.edit_value_button.configure(text="Select a control", state="disabled")
            self.capability_detail_var.set(
                "Choose a learned control to see its evidence and safe next action."
            )
            return

        self._show_capability_detail()

        actions = list(row.actions)
        action_set = set(actions)
        primary_order = (
            CapabilityAction.VERIFY,
            CapabilityAction.REVERIFY,
            CapabilityAction.SET,
            CapabilityAction.ADJUST,
            CapabilityAction.FREEZE,
            CapabilityAction.WATCH,
        )
        self._primary_action = next(
            (action for action in primary_order if action in action_set),
            None,
        )
        self._secondary_action = next(
            (
                action
                for action in (CapabilityAction.WATCH, CapabilityAction.OVERLAY)
                if action in action_set and action is not self._primary_action
            ),
            None,
        )
        if self._primary_action is None:
            self.primary_button.configure(text="View evidence", state="disabled")
        else:
            self.primary_button.configure(
                text=self._primary_action.value.title(),
                state="normal",
            )
        if self._secondary_action is None:
            self.secondary_button.configure(text="More actions", state="disabled")
        else:
            self.secondary_button.configure(
                text=self._secondary_action.value.title(),
                state="normal",
            )

        local_history = any(item.capability_id == row.id for item in self.state.history)
        for action, index in self._more_menu_entries.items():
            enabled = action in action_set
            if action is CapabilityAction.RESTORE:
                enabled = local_history
            self.more_menu.entryconfigure(index, state="normal" if enabled else "disabled")
        self.more_button.configure(
            state="normal" if action_set or local_history else "disabled"
        )
        current = "unknown" if row.current_value is None else str(row.current_value)
        if row.maximum_value is not None:
            current = f"{current} / {row.maximum_value}"
        evidence = "; ".join(row.evidence[:2]) or "No behavioral evidence recorded yet."
        self.capability_detail_var.set(
            f"{row.name}  ·  {row.state.value.replace('_', ' ').title()}  ·  Current: {current}\n"
            f"Source: {row.source}  ·  Priority: {row.priority}  ·  {evidence}"
        )
        if self._editing_row_id != row.id:
            self._editing_row_id = row.id
            suggested = row.current_value
            if (
                row.discovery_candidate_ids
                and not row.write_actions_unlocked
                and isinstance(suggested, (int, float))
            ):
                suggested += 1
            self.edit_value_var.set("" if suggested is None else str(suggested))
        session = self.get_active_session()
        writes_enabled = bool(session and session.get("write_enabled"))
        if row.discovery_candidate_ids and not row.write_actions_unlocked:
            self.edit_value_button.configure(
                text="Apply value",
                state="normal" if writes_enabled else "disabled",
            )
        elif row.write_actions_unlocked:
            self.edit_value_button.configure(
                text="Apply value",
                state="normal" if writes_enabled else "disabled",
            )
        else:
            self.edit_value_button.configure(text="Needs a live locator", state="disabled")

    def _run_primary_action(self) -> None:
        self._run_selected_action(self._primary_action)

    def _run_secondary_action(self) -> None:
        self._run_selected_action(self._secondary_action)

    def _run_selected_action(self, action: CapabilityAction | None) -> None:
        handlers = {
            CapabilityAction.VERIFY: self.verify_selected,
            CapabilityAction.REVERIFY: self.verify_selected,
            CapabilityAction.WATCH: self.watch_selected,
            CapabilityAction.SET: lambda: self.change_selected_value(CapabilityAction.SET),
            CapabilityAction.ADJUST: lambda: self.change_selected_value(CapabilityAction.SET),
            CapabilityAction.FREEZE: lambda: self.change_selected_value(CapabilityAction.FREEZE),
            CapabilityAction.OVERLAY: self.overlay_selected,
            CapabilityAction.HOTKEY: self.hotkey_selected,
            CapabilityAction.SCRIPT: self.script_selected,
            CapabilityAction.PIN: self.pin_selected,
            CapabilityAction.RESTORE: self.restore_latest_selected,
        }
        handler = handlers.get(action)
        if handler is not None:
            handler()
            return
        if action is not None:
            row = self.selected_row()
            target = row.name if row else "the selected control"
            self.set_status(
                f"{action.value.title()} for {target} remains locked until the write gates pass."
            )

    def apply_entered_value(self, _event=None) -> None:
        row = self.selected_row()
        session = self.get_active_session()
        if row is None or session is None:
            self.set_status("Choose a found control in the list first.")
            return
        if not bool(session.get("write_enabled")):
            self.set_status("Value testing is not enabled for this selected offline game.")
            return
        try:
            selected = self._parse_numeric_text(self.edit_value_var.get())
        except ValueError as exc:
            self.set_status(str(exc))
            return
        value_error = self._editor_value_error(row, selected)
        if value_error is not None:
            self.set_status(value_error)
            return
        if row.discovery_run_id and row.discovery_candidate_ids and not row.write_actions_unlocked:
            untested = [
                item
                for item in row.discovery_candidate_ids
                if item not in row.write_tested_candidate_ids
            ]
            candidates = untested or row.discovery_candidate_ids
            position = self._candidate_test_positions.get(row.id, 0) % len(candidates)
            candidate_id = candidates[position]
            self._candidate_test_positions[row.id] = position + 1
            self._prepare_candidate_value_change(
                row,
                candidate_id,
                selected,
                ask_visible_confirmation=True,
            )
            return
        if not row.write_actions_unlocked:
            self.set_status(
                f"{row.name} needs a live candidate before it can be tested or changed."
            )
            return
        self._change_selected_to(row, CapabilityAction.SET, selected)

    def change_selected_value(self, action: CapabilityAction) -> None:
        from tkinter import simpledialog

        row = self.selected_row()
        session = self.get_active_session()
        if row is None or session is None:
            self.set_status("Choose and attach a running game first.")
            return
        if not row.write_actions_unlocked or not bool(session.get("write_enabled")):
            self.set_status(
                f"{row.name} cannot be changed until its live locator is verified for this build."
            )
            return
        if isinstance(row.current_value, int):
            selected = simpledialog.askinteger(
                f"{action.value.title()} {row.name}",
                f"New {row.name} value:",
                initialvalue=row.current_value,
                parent=self.root,
            )
        else:
            selected = simpledialog.askfloat(
                f"{action.value.title()} {row.name}",
                f"New {row.name} value:",
                initialvalue=row.current_value,
                parent=self.root,
            )
        if selected is None:
            return
        self._change_selected_to(row, action, selected)

    def _change_selected_to(
        self,
        row: CapabilityRow,
        action: CapabilityAction,
        selected: int | float,
    ) -> None:
        session = self.get_active_session()
        if session is None or not bool(session.get("write_enabled")):
            self.set_status("Value changes are not enabled for this selected offline game.")
            return
        if row.write_tested_candidate_ids and row.discovery_run_id:
            candidate_id = row.write_tested_candidate_ids[0]
            self._prepare_candidate_value_change(
                row,
                candidate_id,
                selected,
                ask_visible_confirmation=False,
            )
            return
        service_action = "hold" if action is CapabilityAction.FREEZE else "set"
        self.set_status(
            f"Checking the live {row.name} value before applying the change..."
        )
        self.run_background(
            lambda: self.controller.prepare_game_cheat_action(
                str(session.get("session_id") or ""),
                row.id,
                service_action,
                selected,
            ),
            lambda result: self._game_action_prepared(row, action, selected, result),
        )

    def _game_action_prepared(
        self,
        row: CapabilityRow,
        action: CapabilityAction,
        selected: float,
        result: dict[str, Any],
    ) -> None:
        intent_id = str(result.get("intent_id") or "")
        if not intent_id:
            self.set_status("The game value check did not produce a write review.")
            return
        self.set_status(f"Applying {row.name} now...")
        self.run_background(
            lambda: self.controller.apply_game_cheat_action(intent_id),
            lambda confirmed: self._game_action_finished(row, action, selected, confirmed),
        )

    def _game_action_finished(
        self,
        row: CapabilityRow,
        action: CapabilityAction,
        selected: float,
        result: dict[str, Any],
    ) -> None:
        before = row.current_value
        write = result.get("write") or {}
        hold = result.get("hold") or {}
        row.current_value = write.get("new_value", hold.get("hold_value", selected))
        self.edit_value_var.set(str(row.current_value))
        self.state_store.record(
            self.state,
            action=f"game:{action.value}",
            capability_id=row.id,
            before=before,
            after=row.current_value,
        )
        self.set_status(
            f"{row.name} changed to {row.current_value}; the service verified the live readback."
        )
        self.render_capabilities()
        self.render_history()

    def verify_selected(self) -> None:
        from tkinter import simpledialog

        row = self.selected_row()
        if row is None:
            return
        session = self.get_active_session()
        if row.discovery_run_id and row.discovery_candidate_ids:
            if session is None or not bool(session.get("write_enabled")):
                self.set_status(
                    "Value editing is not enabled for this offline game yet."
                )
                return
            untested = [
                item
                for item in row.discovery_candidate_ids
                if item not in row.write_tested_candidate_ids
            ]
            candidates = untested or row.discovery_candidate_ids
            position = self._candidate_test_positions.get(row.id, 0) % len(candidates)
            candidate_id = candidates[position]
            self._candidate_test_positions[row.id] = position + 1
            current = row.current_value
            initial = (
                current + 1
                if isinstance(current, int)
                else round(float(current or 0) + 1.0, 4)
            )
            if isinstance(current, int):
                selected = simpledialog.askinteger(
                    f"Test {row.name}",
                    (
                        f"Candidate {position + 1} of {len(candidates)}. Enter a temporary "
                        "value you can recognize in the game:"
                    ),
                    initialvalue=int(initial),
                    parent=self.root,
                )
            else:
                selected = simpledialog.askfloat(
                    f"Test {row.name}",
                    (
                        f"Candidate {position + 1} of {len(candidates)}. Enter a temporary "
                        "value you can recognize in the game:"
                    ),
                    initialvalue=float(initial),
                    parent=self.root,
                )
            if selected is None:
                return
            self._prepare_candidate_value_change(
                row,
                candidate_id,
                selected,
                ask_visible_confirmation=True,
            )
            return
        self.set_status(f"Starting read-only verification for {row.name}.")
        self.open_discovery()

    def _prepare_candidate_value_change(
        self,
        row: CapabilityRow,
        candidate_id: str,
        selected: int | float,
        *,
        ask_visible_confirmation: bool,
    ) -> None:
        if not row.discovery_run_id:
            self.set_status("This learned value is missing its live discovery run.")
            return
        self.set_status(
            f"Checking one {row.name} candidate before applying the change..."
        )
        self.run_background(
            lambda: self.controller.prepare_discovery_candidate_test(
                row.discovery_run_id or "",
                row.name,
                candidate_id,
                selected,
            ),
            lambda result: self._candidate_value_prepared(
                row,
                selected,
                ask_visible_confirmation,
                result,
            ),
        )

    def _candidate_value_prepared(
        self,
        row: CapabilityRow,
        selected: int | float,
        ask_visible_confirmation: bool,
        result: dict[str, Any],
    ) -> None:
        intent_id = str(result.get("intent_id") or "")
        if not intent_id:
            self.set_status("The candidate check did not produce a value change.")
            return
        original = result.get("original_value", row.current_value)
        index = result.get("candidate_index", 1)
        count = result.get("candidate_count", len(row.discovery_candidate_ids))
        self.set_status(f"Applying {row.name} candidate {index}/{count} now...")
        self.run_background(
            lambda: self.controller.apply_prepared_write(intent_id),
            lambda _confirmed: self._candidate_value_written(
                row,
                intent_id,
                selected,
                original,
                ask_visible_confirmation,
            ),
        )

    def _candidate_value_written(
        self,
        row: CapabilityRow,
        intent_id: str,
        selected: int | float,
        original: int | float | None,
        ask_visible_confirmation: bool,
    ) -> None:
        matched = True
        if ask_visible_confirmation:
            from tkinter import messagebox

            matched = messagebox.askyesno(
                f"Did {row.name} change?",
                (
                    f"Look at the game now. Did the visible {row.name} value change to "
                    f"{selected}?\n\nYes locks this candidate. No automatically restores "
                    "the original value and tries the next candidate."
                ),
                parent=self.root,
            )
        self.set_status(
            f"Locking the confirmed {row.name} candidate..."
            if matched
            else f"Restoring and rejecting this {row.name} candidate..."
        )
        self.run_background(
            lambda: self.controller.finalize_discovery_candidate_test(intent_id, matched),
            lambda result: self._candidate_value_finished(
                row,
                selected,
                original,
                result,
            ),
        )

    def _candidate_value_finished(
        self,
        row: CapabilityRow,
        selected: int | float,
        original: int | float | None,
        result: dict[str, Any],
    ) -> None:
        matched = bool(result.get("matched_in_game"))
        row.current_value = selected if matched else original
        self.state_store.record(
            self.state,
            action="candidate:confirmed" if matched else "candidate:rejected-restored",
            capability_id=row.id,
            before=original,
            after=row.current_value,
        )
        if matched:
            self.set_status(
                f"{row.name} matched in the game and is now an editable verified control."
            )
        else:
            self.set_status(
                f"That {row.name} candidate was restored and rejected; try the next match."
            )
        self.render_history()
        self._refresh_capability_catalog()

    def _refresh_capability_catalog(self) -> None:
        session = self.get_active_session()
        if session is None:
            return
        session_id = str(session.get("session_id") or "")
        write_enabled = bool(session.get("write_enabled"))
        if not session_id:
            return
        self.run_background(
            lambda: self.controller.game_cheat_catalog(session_id),
            lambda catalog: self.update_catalog(catalog, write_enabled=write_enabled),
        )

    def watch_selected(self) -> None:
        row = self.selected_row()
        if row:
            self.set_status(f"Read-only watch selected for {row.name}; no write action was armed.")

    def overlay_selected(self) -> None:
        row = self.selected_row()
        if row is None:
            return
        before = self.state.overlays.get(row.id, False)
        self.state.overlays[row.id] = not before
        if not before:
            self.state.overlay_visible = True
        self.state_store.record(
            self.state,
            action="overlay",
            capability_id=row.id,
            before=before,
            after=not before,
        )
        self.set_status(
            f"{row.name} overlay {'enabled' if not before else 'disabled'} locally."
        )
        self._update_overlay_button()
        self.render_overlay()
        self.render_history()

    def toggle_overlay_visibility(self) -> None:
        if not self.state.overlay_visible and self.get_active_session() is None:
            self.set_status("Pick a running game before opening its overlay.")
            return
        self.state.overlay_visible = not self.state.overlay_visible
        self.state_store.save(self.state)
        self._update_overlay_button()
        self.render_overlay()

    def configure_overlay_hotkey(self) -> None:
        from tkinter import simpledialog

        selected = simpledialog.askstring(
            "Game overlay shortcut",
            "Shortcut to show or hide the read-only game overlay:",
            initialvalue=self.state.overlay_hotkey.strip("<>"),
            parent=self.root,
        )
        if selected is None:
            return
        try:
            normalized = normalize_hotkey(selected)
        except ValueError as exc:
            self.set_status(str(exc))
            return
        if normalized in self.state.hotkeys.values():
            self.set_status(
                f"{normalized} already toggles a capability. Choose another overlay shortcut."
            )
            return
        self.state.overlay_hotkey = normalized
        self.state_store.save(self.state)
        self._register_overlay_hotkey()
        self._update_overlay_button()
        if self.overlay_hotkey_manager and self.overlay_hotkey_manager.registered:
            self.set_status(f"{normalized} now shows or hides the read-only game overlay.")

    def hotkey_selected(self) -> None:
        from tkinter import simpledialog

        row = self.selected_row()
        if row is None:
            return
        before = self.state.hotkeys.get(row.id)
        selected = simpledialog.askstring(
            "Capability hotkey",
            f"Hotkey label for {row.name}:",
            initialvalue=before or "",
            parent=self.root,
        )
        if selected is None:
            return
        try:
            normalized = normalize_hotkey(selected)
        except ValueError as exc:
            self.set_status(str(exc))
            return
        if normalized == self.state.overlay_hotkey:
            self.set_status(
                f"{normalized} is reserved for the game overlay. Choose another shortcut."
            )
            return
        if before:
            self.root.unbind(before)
        self.state.hotkeys[row.id] = normalized
        self.root.bind(
            normalized,
            lambda _event, capability_id=row.id: self._hotkey_toggle_overlay(capability_id),
            add="+",
        )
        self.state_store.record(
            self.state,
            action="hotkey",
            capability_id=row.id,
            before=before,
            after=normalized,
        )
        self.set_status(f"Bound {normalized} to toggle the local {row.name} overlay.")
        self.render_history()

    def pin_selected(self) -> None:
        row = self.selected_row()
        if row is None:
            return
        before = row.id in self.state.pinned
        if before:
            self.state.pinned = [item for item in self.state.pinned if item != row.id]
        else:
            self.state.pinned.append(row.id)
        self.state_store.record(
            self.state,
            action="pin",
            capability_id=row.id,
            before=before,
            after=not before,
        )
        self.render_capabilities()
        self.render_overlay()
        self.render_history()

    def script_selected(self) -> None:
        row = self.selected_row()
        if row is None:
            return
        self.script_name_var.set(f"{row.name} script")
        self.script_target_var.set(row.name)
        self.script_status_var.set(
            f"Prepared the builder for {row.name}; creating it will not execute anything."
        )
        self.show_script_lab()

    def _show_capability_detail(self) -> None:
        """Keep the value editor visible before the table on short windows."""
        self.capability_detail_frame.pack_forget()
        if self._layout_mode == "compact":
            self.capability_detail_frame.pack(
                fill="x",
                pady=(0, 6),
                before=self.capability_tree_frame,
            )
        else:
            self.capability_detail_frame.pack(
                fill="x",
                pady=(7, 0),
                after=self.capability_tree_frame,
            )

    def apply_layout_policy(self, policy) -> None:
        self._layout_mode = policy.mode
        compact = policy.mode == "compact"
        rows = {"compact": 7, "standard": 10, "wide": 12}.get(policy.mode, 10)
        self.capability_tree.configure(height=rows)
        self.capability_detail_label.configure(wraplength=max(360, policy.wraplength - 40))
        self.learning_status_label.configure(wraplength=max(360, policy.wraplength - 20))
        self._layout_learning_inputs(compact=compact)
        if compact:
            if self.capability_detail_frame.winfo_manager():
                self._show_capability_detail()
            return
        if self.capability_detail_frame.winfo_manager():
            self._show_capability_detail()

    def _layout_learning_inputs(self, *, compact: bool) -> None:
        for widget in (
            self.hunt_target_label,
            self.hunt_target_combo,
            self.hunt_value_label,
            self.hunt_value_entry,
            self.hunt_button,
        ):
            widget.grid_forget()
        if compact:
            self.hunt_target_label.grid(row=0, column=0, sticky="w")
            self.hunt_target_combo.grid(
                row=0,
                column=1,
                columnspan=2,
                sticky="ew",
                padx=(6, 0),
            )
            self.hunt_value_label.grid(row=1, column=0, sticky="w", pady=(6, 0))
            self.hunt_value_entry.grid(
                row=1,
                column=1,
                sticky="ew",
                padx=(6, 8),
                pady=(6, 0),
                ipady=3,
            )
            self.hunt_button.grid(row=1, column=2, sticky="e", pady=(6, 0))
        else:
            self.hunt_target_label.grid(row=0, column=0, sticky="w")
            self.hunt_target_combo.grid(row=0, column=1, sticky="ew", padx=(6, 8))
            self.hunt_value_label.grid(row=0, column=2, sticky="w")
            self.hunt_value_entry.grid(
                row=0,
                column=3,
                sticky="ew",
                padx=(6, 8),
                ipady=3,
            )
            self.hunt_button.grid(row=0, column=4, sticky="e")

        for widget in (
            self.inventory_observe_button,
            self.inventory_changed_button,
            self.inventory_matrix_button,
        ):
            widget.grid_forget()
        if compact:
            self.inventory_observe_button.grid(row=0, column=0, sticky="ew")
            self.inventory_changed_button.grid(row=0, column=1, sticky="ew", padx=(6, 0))
            self.inventory_matrix_button.grid(
                row=1,
                column=0,
                columnspan=2,
                sticky="ew",
                pady=(6, 0),
            )
            self.inventory_row.columnconfigure(0, weight=1)
            self.inventory_row.columnconfigure(1, weight=1)
        else:
            self.inventory_observe_button.grid(row=0, column=0, sticky="ew")
            self.inventory_changed_button.grid(row=0, column=1, sticky="ew", padx=(6, 0))
            self.inventory_matrix_button.grid(row=0, column=2, sticky="ew", padx=(6, 0))

        for widget in (
            self.rescan_values_button,
            self.inventory_guide_button,
            self.inventory_hint_label,
        ):
            widget.grid_forget()
        self.rescan_values_button.grid(row=0, column=0, sticky="w")
        self.inventory_guide_button.grid(row=0, column=1, sticky="w", padx=(6, 0))
        if compact:
            self.inventory_hint_label.grid(
                row=1,
                column=0,
                columnspan=2,
                sticky="w",
                pady=(4, 0),
            )
        else:
            self.inventory_hint_label.grid(row=0, column=2, sticky="w", padx=(10, 0))

    def build_script(self) -> None:
        try:
            candidate = build_native_script(
                name=self.script_name_var.get(),
                target=self.script_target_var.get(),
                kind=NativeScriptKind(self.script_kind_var.get()),
                operation=self.script_operation_var.get(),
            )
        except ValueError as exc:
            self.script_status_var.set(str(exc))
            return
        self.scripts.append(candidate)
        self.script_store.save(self.scripts)
        self.script_status_var.set(
            "Inert candidate built; exact build, unique locator, behavior, "
            "and rollback are pending."
        )
        self.render_scripts()

    def render_scripts(self) -> None:
        self.script_tree.delete(*self.script_tree.get_children())
        for index, item in enumerate(self.scripts):
            self.script_tree.insert(
                "",
                "end",
                iid=f"script-{index}",
                values=(
                    item.name,
                    item.target,
                    item.kind.value,
                    item.source_kind,
                    "reference only — cannot execute",
                ),
            )

    def render_history(self) -> None:
        self.history_tree.delete(*self.history_tree.get_children())
        for item in reversed(self.state.history[-500:]):
            self.history_tree.insert(
                "",
                "end",
                iid=item.id,
                values=(
                    item.created_at.astimezone().strftime("%Y-%m-%d %H:%M:%S"),
                    item.capability_id or "general",
                    item.action,
                    "—" if item.before is None else str(item.before),
                    "—" if item.after is None else str(item.after),
                ),
            )

    def restore_latest_selected(self) -> None:
        row = self.selected_row()
        if row is None:
            return
        event = next(
            (
                item
                for item in reversed(self.state.history)
                if item.capability_id == row.id and item.action in {"overlay", "hotkey", "pin"}
            ),
            None,
        )
        if event is None:
            self.set_status("No restorable local preference exists for this capability.")
            return
        self._restore_event(event.id)

    def restore_history_selection(self) -> None:
        selected = self.history_tree.selection()
        if selected:
            self._restore_event(selected[0])

    def _restore_event(self, event_id: str) -> None:
        try:
            event = self.state_store.restore_local_preference(self.state, event_id)
        except (KeyError, ValueError) as exc:
            self.history_status_var.set(str(exc))
            return
        self.history_status_var.set(
            f"Restored {event.capability_id or 'local preference'}; game memory was untouched."
        )
        self.render_capabilities()
        self._bind_saved_hotkeys()
        self.render_overlay()
        self.render_history()

    def _bind_saved_hotkeys(self) -> None:
        for capability_id, sequence in self.state.hotkeys.items():
            try:
                normalized = normalize_hotkey(sequence)
            except ValueError:
                continue
            self.root.bind(
                normalized,
                lambda _event, item=capability_id: self._hotkey_toggle_overlay(item),
                add="+",
            )

    def _hotkey_toggle_overlay(self, capability_id: str) -> None:
        before = self.state.overlays.get(capability_id, False)
        self.state.overlays[capability_id] = not before
        if not before:
            self.state.overlay_visible = True
        self.state_store.record(
            self.state,
            action="overlay",
            capability_id=capability_id,
            before=before,
            after=not before,
        )
        self._update_overlay_button()
        self.render_overlay()
        self.render_history()

    def _start_overlay_runtime(self) -> None:
        if not self.enable_global_hotkeys:
            return
        self._register_overlay_hotkey()
        self._register_learning_hotkeys()
        self.root.bind("<Destroy>", self._overlay_root_destroyed, add="+")
        self._overlay_tick_after = self.root.after(125, self._overlay_tick)

    def _register_learning_hotkeys(self) -> None:
        for manager in self.learning_hotkey_managers.values():
            manager.close()
        self.learning_hotkey_managers = {}
        for phase, sequence in self.learning_hotkeys.items():
            manager = WindowsGlobalHotkey(sequence)
            if manager.start():
                self.learning_hotkey_managers[phase] = manager

    def _register_overlay_hotkey(self) -> None:
        if self.overlay_hotkey_manager is not None:
            self.overlay_hotkey_manager.close()
            self.overlay_hotkey_manager = None
        if not self.enable_global_hotkeys:
            return
        if self.state.overlay_hotkey in self.state.hotkeys.values():
            self.command_status_var.set(
                f"{self.state.overlay_hotkey} is also assigned to a capability; "
                "use Key to choose a different overlay shortcut."
            )
            return
        manager = WindowsGlobalHotkey(self.state.overlay_hotkey)
        self.overlay_hotkey_manager = manager
        if not manager.start():
            self.command_status_var.set(
                f"Overlay button ready, but {self.state.overlay_hotkey} could not be registered: "
                f"{manager.error or 'unknown Windows shortcut error'}."
            )

    def _overlay_tick(self) -> None:
        manager = self.overlay_hotkey_manager
        if manager is not None and manager.pending_presses() % 2 == 1:
            self.toggle_overlay_visibility()
        for phase, learning_manager in self.learning_hotkey_managers.items():
            if learning_manager.pending_presses():
                if phase == "rescan":
                    self.rescan_all_saved_values()
                else:
                    self.capture_inventory_learning_sample(phase)
        if self.state.overlay_visible:
            self._position_overlay()
        try:
            self._overlay_tick_after = self.root.after(125, self._overlay_tick)
        except Exception:
            self._overlay_tick_after = None

    def _overlay_root_destroyed(self, event) -> None:
        if getattr(event, "widget", None) is not self.root:
            return
        if self.overlay_hotkey_manager is not None:
            self.overlay_hotkey_manager.close()
            self.overlay_hotkey_manager = None
        for manager in self.learning_hotkey_managers.values():
            manager.close()
        self.learning_hotkey_managers = {}

    def _update_overlay_button(self) -> None:
        shortcut = self.state.overlay_hotkey.strip("<>")
        text = "Hide overlay" if self.state.overlay_visible else f"Overlay {shortcut}"
        self.overlay_button_var.set(text)

    def _hide_overlay(self) -> None:
        self.state.overlay_visible = False
        self.state_store.save(self.state)
        self._update_overlay_button()
        self.render_overlay()

    def _overlay_rows(self) -> list[CapabilityRow]:
        learning_states = {CapabilityState.CANDIDATE, CapabilityState.LOCKED}
        learning_targets = getattr(self, "_learning_targets_by_row", {})
        confirmed_targets = getattr(self, "_confirmed_learning_targets", set())
        eligible = [
            row
            for row in self.rows
            if row.state in learning_states
            and learning_targets.get(row.id, "") not in confirmed_targets
        ]
        explicit = [row for row in eligible if self.state.overlays.get(row.id, False)]
        if explicit:
            return explicit[:8]
        state_rank = {
            CapabilityState.LOCKED: 2,
            CapabilityState.CANDIDATE: 1,
        }
        ordered = sorted(
            eligible,
            key=lambda row: (
                row.id in self.state.pinned,
                row.current_value is not None,
                state_rank[row.state],
                row.priority,
            ),
            reverse=True,
        )
        return ordered[:4]

    def _record_overlay_samples(self) -> None:
        if not hasattr(self, "_overlay_samples"):
            self._overlay_samples = {}
        current_ids = {row.id for row in self.rows}
        for row_id in list(self._overlay_samples):
            if row_id not in current_ids:
                self._overlay_samples.pop(row_id, None)
        for row in self.rows:
            value = row.current_value
            if isinstance(value, bool) or not isinstance(value, (int, float)):
                continue
            samples = self._overlay_samples.setdefault(row.id, deque(maxlen=60))
            samples.append(float(value))

    @staticmethod
    def _overlay_row_status(row: CapabilityRow) -> str:
        return {
            CapabilityState.VERIFIED: "Ready",
            CapabilityState.LOCKED: "Awaiting proof",
            CapabilityState.CANDIDATE: "Scanning",
            CapabilityState.REFERENCE: "Needs verification",
            CapabilityState.BLOCKED: "Blocked",
        }[row.state]

    def render_overlay(self) -> None:
        session = self.get_active_session()
        if not self.state.overlay_visible or session is None:
            if self.overlay_window is not None and self.overlay_window.winfo_exists():
                self.overlay_window.destroy()
            self.overlay_window = None
            self.overlay_frame = None
            return
        selected = self._overlay_rows()
        created = self.overlay_window is None or not self.overlay_window.winfo_exists()
        if created:
            self.overlay_window = self.tk.Toplevel(self.root)
            self.overlay_window.withdraw()
            self.overlay_window.title("GTP Games Overlay")
            self.overlay_window.attributes("-topmost", True)
            self.overlay_window.attributes("-alpha", 0.94)
            self.overlay_window.resizable(False, False)
            self.overlay_window.protocol("WM_DELETE_WINDOW", self._hide_overlay)
            self.overlay_frame = self.ttk.Frame(
                self.overlay_window,
                padding=12,
                style="Card.TFrame",
            )
            self.overlay_frame.pack(fill="both", expand=True)
        assert self.overlay_frame is not None
        for child in self.overlay_frame.winfo_children():
            child.destroy()
        self.ttk.Label(
            self.overlay_frame,
            text="GTP GAMES  ·  LEARNING OVERLAY",
            style="Card.TLabel",
            font=("Segoe UI Semibold", 11),
        ).grid(row=0, column=0, columnspan=4, sticky="w")
        process_name = str(session.get("process_name") or "Selected game")
        pid = int(session.get("pid") or 0)
        identity = f"{process_name}  ·  PID {pid}" if pid else process_name
        self.ttk.Label(
            self.overlay_frame,
            text=identity,
            style="Card.TLabel",
        ).grid(row=1, column=0, columnspan=4, sticky="w", pady=(2, 8))
        write_enabled = bool(session.get("write_enabled"))
        learning_mode = (
            "AUTO LEARNING ON  ·  small verification changes restore immediately"
            if write_enabled
            else "AUTO LEARNING ON  ·  observing screen and RAM read-only"
        )
        self.ttk.Label(
            self.overlay_frame,
            text=learning_mode,
            style="Card.TLabel",
            font=("Segoe UI Semibold", 9),
        ).grid(row=2, column=0, columnspan=4, sticky="w", pady=(0, 8))
        if not selected:
            self.ttk.Label(
                self.overlay_frame,
                text="Learning values — useful results will appear here automatically.",
                style="Card.TLabel",
            ).grid(row=3, column=0, columnspan=4, sticky="w")
        for index, row in enumerate(selected, start=1):
            value = "unavailable" if row.current_value is None else str(row.current_value)
            if row.maximum_value is not None:
                value = f"{value} / {row.maximum_value}"
            self.ttk.Label(self.overlay_frame, text=row.name).grid(
                row=index + 2,
                column=0,
                sticky="w",
                padx=(0, 16),
            )
            self.ttk.Label(self.overlay_frame, text=value).grid(
                row=index + 2,
                column=1,
                sticky="e",
                padx=(0, 10),
            )
            samples = list(self._overlay_samples.get(row.id, ()))
            chart = self.tk.Canvas(
                self.overlay_frame,
                width=112,
                height=26,
                background="#172033",
                highlightthickness=0,
            )
            chart.grid(row=index + 2, column=2, sticky="e", padx=(0, 10))
            points = sparkline_points(samples)
            if len(points) >= 4:
                chart.create_line(*points, fill="#6ee7b7", width=2, smooth=True)
            elif len(points) == 2:
                x, y = points
                chart.create_oval(x - 2, y - 2, x + 2, y + 2, fill="#6ee7b7", outline="")
            self.ttk.Label(
                self.overlay_frame,
                text=self._overlay_row_status(row),
                style="Card.TLabel",
            ).grid(
                row=index + 2,
                column=3,
                sticky="e",
            )
        guide_row = max(4, len(selected) + 3)
        guide = self.learning_status_var.get().removeprefix("Learning guide:").strip()
        if guide:
            self.ttk.Label(
                self.overlay_frame,
                text=f"NEXT: {guide}",
                style="Card.TLabel",
                wraplength=390,
            ).grid(row=guide_row, column=0, columnspan=4, sticky="w", pady=(9, 0))
        footer_row = guide_row + 1
        self.ttk.Label(
            self.overlay_frame,
            text=(
                f"{self.state.overlay_hotkey.strip('<>')} hides this overlay  ·  "
                "F9 observe inventory  ·  F10 stack changed  ·  Ctrl+F11 rescan"
            ),
            style="Card.TLabel",
            font=("Segoe UI", 8),
        ).grid(row=footer_row, column=0, columnspan=4, sticky="w", pady=(9, 0))
        self._position_overlay()
        if created:
            make_overlay_click_through(int(self.overlay_window.winfo_id()))
            self.overlay_window.deiconify()
            self._refresh_overlay_topmost(force=True)

    def _position_overlay(self) -> None:
        window = self.overlay_window
        session = self.get_active_session()
        if window is None or not window.winfo_exists() or session is None:
            return
        pid = int(session.get("pid") or 0)
        if pid and not process_is_running(pid):
            self.state.overlay_visible = False
            self.state_store.save(self.state)
            self._update_overlay_button()
            window.destroy()
            self.overlay_window = None
            self.overlay_frame = None
            self.set_status("The selected game closed; its overlay detached automatically.")
            return
        window.update_idletasks()
        width = max(340, int(window.winfo_reqwidth()))
        height = max(150, int(window.winfo_reqheight()))
        bounds = find_game_window(pid)
        if bounds is not None:
            x, y = bounds.overlay_origin(width, height)
        else:
            x = max(16, int(window.winfo_screenwidth()) - width - 24)
            y = 24
        geometry = f"{width}x{height}+{x}+{y}"
        if geometry != self._last_overlay_geometry:
            window.geometry(geometry)
            self._last_overlay_geometry = geometry
        self._refresh_overlay_topmost()

    def _refresh_overlay_topmost(self, *, force: bool = False) -> None:
        window = self.overlay_window
        if window is None or not window.winfo_exists():
            return
        now = time.monotonic()
        if not force and now - self._last_overlay_topmost_refresh < 0.75:
            return
        window.attributes("-topmost", True)
        keep_overlay_topmost(int(window.winfo_id()))
        self._last_overlay_topmost_refresh = now
