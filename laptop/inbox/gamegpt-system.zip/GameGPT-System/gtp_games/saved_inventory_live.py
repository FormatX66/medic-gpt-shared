from __future__ import annotations

import struct
from collections.abc import Callable
from time import monotonic

from gtp_games.errors import BackendError, SafetyError
from gtp_games.game_identity import executable_build_identity
from gtp_games.inventory_observer import (
    InventoryObservationStore,
    InventorySlotObservationRecord,
)
from gtp_games.memory.base import MemoryBackend
from gtp_games.models import (
    MemoryRegion,
    ProcessSession,
    SavedInventoryLiveCandidate,
    SavedInventoryLiveResolution,
)
from gtp_games.nms_save import NmsInventorySnapshot, NmsInventoryStack

_NMS_INVENTORY_RECORD_SIZE = 0x30
_NMS_COUNT_OFFSET = 0x18
_NMS_MAXIMUM_OFFSET = 0x20
_NMS_TYPE_OFFSET = 0x24
_NMS_FLAG_0_OFFSET = 0x28
_NMS_FLAG_1_OFFSET = 0x29
_MIN_SCAN_CHUNK_BYTES = 8 * 1024 * 1024
_MAX_SCAN_CHUNK_BYTES = 32 * 1024 * 1024
_MAX_HINT_SCAN_BYTES = 2 * 1024 * 1024 * 1024
_MAX_FULL_SCAN_BYTES = 16 * 1024 * 1024 * 1024
_MAX_RAW_ID_MATCHES = 10_000
_STRUCTURAL_RECIPE = "nms-saved-inventory-structure-v1"


class SavedInventoryLiveResolver:
    """Resolve a saved NMS stack inside live RAM without writing game memory."""

    def __init__(
        self,
        memory: MemoryBackend,
        store: InventoryObservationStore,
        *,
        scan_chunk_bytes: int,
        build_identity_resolver: Callable[[str | None], str | None] | None = None,
    ) -> None:
        self.memory = memory
        self.store = store
        self.scan_chunk_bytes = min(
            _MAX_SCAN_CHUNK_BYTES,
            max(_MIN_SCAN_CHUNK_BYTES, scan_chunk_bytes),
        )
        self.build_identity_resolver = build_identity_resolver or executable_build_identity

    def resolve(
        self,
        session: ProcessSession,
        snapshot: NmsInventorySnapshot,
        *,
        item_id: str,
        container_name: str | None,
        stack_size_group: str | None,
        full_scan: bool,
        limit: int,
    ) -> SavedInventoryLiveResolution:
        started = monotonic()
        if not 1 <= limit <= 100:
            raise SafetyError("the live inventory candidate limit must be between 1 and 100")
        self._validate_nms_session(session)
        target = self._select_saved_stack(
            snapshot,
            item_id=item_id,
            container_name=container_name,
            stack_size_group=stack_size_group,
        )
        live_item_id, identity = _live_identity(target.item_id)
        identity_low, identity_high, identity_key = identity
        build_identity = self.build_identity_resolver(session.executable)
        if not build_identity:
            raise SafetyError("the selected game's exact executable build could not be read")

        regions = self.memory.regions(session.backend_handle)
        eligible = [region for region in regions if _eligible_region(region)]
        hints = self._same_process_hints(
            session,
            build_identity=build_identity,
        )
        selected, search_mode, scope_truncated = self._select_regions(
            eligible,
            [record.slot_address for record in hints],
            full_scan=full_scan,
        )
        if not selected:
            return self._result(
                session,
                snapshot,
                target,
                live_item_id=live_item_id,
                build_identity=build_identity,
                search_mode=search_mode,
                hint_count=len(hints),
                selected_region_count=0,
                scanned_bytes=0,
                scope_truncated=scope_truncated,
                elapsed_ms=_elapsed_ms(started),
                candidates=[],
                message=(
                    "No current-process allocation hint is available. Run once with full_scan "
                    "enabled to seed the fast path for this process launch."
                ),
            )

        raw_addresses, scanned_bytes, raw_scope_truncated = self._scan_identity(
            session,
            selected,
            identity_low.to_bytes(8, "little") + identity_high.to_bytes(8, "little"),
        )
        container_stacks = sorted(
            (
                stack
                for stack in snapshot.stacks
                if stack.container_path == target.container_path
                and stack.slot_ordinal is not None
            ),
            key=lambda stack: stack.slot_ordinal or 0,
        )
        candidates = [
            candidate
            for address in raw_addresses
            if (
                candidate := self._validate_candidate(
                    session,
                    address,
                    target=target,
                    live_item_id=live_item_id,
                    container_stacks=container_stacks,
                )
            )
            is not None
        ]
        candidates.sort(key=lambda candidate: candidate.slot_address)
        selection_basis: str | None = None
        saved_count_matches = [
            candidate for candidate in candidates if candidate.saved_amount_match
        ]
        if saved_count_matches:
            saved_count_matches[0].suggested_primary = True
            selection_basis = (
                "Lowest-address exact inventory-array copy that also matches the newest saved "
                "count. Carbon established this array-copy ordering for the current NMS layout; "
                "this item was independently validated by identity, record shape, and adjacent "
                "saved slots. A write still requires expected-current comparison, immediate "
                "readback, and behavioral confirmation."
            )

        game_key = (session.game_key or "no-man-s-sky").casefold()
        known_observations = {
            (
                record.process_name.casefold(),
                record.build_identity,
                record.process_started_at,
                record.identity_low,
                record.identity_high,
                record.slot_address,
                record.count,
                record.maximum,
            )
            for record in self.store.records()
        }
        for candidate in candidates:
            observation_key = (
                session.process_name.casefold(),
                build_identity,
                session.process_started_at,
                identity_low,
                identity_high,
                candidate.slot_address,
                candidate.count,
                candidate.maximum,
            )
            if observation_key in known_observations:
                continue
            self.store.remember(
                InventorySlotObservationRecord(
                    game_key=game_key,
                    process_name=session.process_name,
                    build_identity=build_identity,
                    process_started_at=session.process_started_at,
                    recipe_name=_STRUCTURAL_RECIPE,
                    identity_low=identity_low,
                    identity_high=identity_high,
                    identity_key=identity_key,
                    count=candidate.count,
                    maximum=candidate.maximum,
                    slot_address=candidate.slot_address,
                )
            )
            known_observations.add(observation_key)

        returned = candidates[:limit]
        truncated = scope_truncated or raw_scope_truncated or len(candidates) > len(returned)
        suggested = next(
            (candidate.count_address for candidate in returned if candidate.suggested_primary),
            None,
        )
        message = (
            f"Resolved {len(candidates)} exact live structure copies from saved item identity "
            f"and container neighbors using {search_mode}."
            if candidates
            else (
                "The selected scope contained no exact live structure for the saved stack. "
                "The item may have moved to another allocation; use one explicit full scan."
            )
        )
        return self._result(
            session,
            snapshot,
            target,
            live_item_id=live_item_id,
            build_identity=build_identity,
            search_mode=search_mode,
            hint_count=len(hints),
            selected_region_count=len(selected),
            scanned_bytes=scanned_bytes,
            scope_truncated=truncated,
            elapsed_ms=_elapsed_ms(started),
            candidates=returned,
            candidate_count=len(candidates),
            suggested_primary_count_address=suggested,
            selection_basis=selection_basis,
            message=message,
        )

    @staticmethod
    def _validate_nms_session(session: ProcessSession) -> None:
        game_key = "-".join((session.game_key or "").casefold().replace("'", "").split())
        if session.process_name.casefold() != "nms.exe" and game_key not in {
            "nms",
            "no-man-s-sky",
            "no-mans-sky",
        }:
            raise SafetyError("live saved-inventory resolution is supported only for NMS.exe")

    @staticmethod
    def _select_saved_stack(
        snapshot: NmsInventorySnapshot,
        *,
        item_id: str,
        container_name: str | None,
        stack_size_group: str | None,
    ) -> NmsInventoryStack:
        wanted_id = item_id.strip().lstrip("^").casefold()
        if not wanted_id:
            raise SafetyError("item_id must identify one saved inventory item")
        matches = [
            stack
            for stack in snapshot.stacks
            if stack.item_id.lstrip("^").casefold() == wanted_id
            and (
                container_name is None
                or stack.container_name.casefold() == container_name.strip().casefold()
            )
            and (
                stack_size_group is None
                or (stack.stack_size_group or "").casefold()
                == stack_size_group.strip().casefold()
            )
        ]
        if not matches:
            raise SafetyError("the requested stack was not found in the newest NMS save")
        if len(matches) != 1:
            locations = ", ".join(
                f"{stack.container_name}:{stack.stack_size_group}@"
                f"({stack.index_x},{stack.index_y})"
                for stack in matches[:8]
            )
            raise SafetyError(f"the saved stack selection is ambiguous: {locations}")
        return matches[0]

    def _same_process_hints(
        self,
        session: ProcessSession,
        *,
        build_identity: str,
    ) -> list[InventorySlotObservationRecord]:
        """Return allocation hints from any observed inventory item in this process."""

        return [
            record
            for record in self.store.records()
            if record.process_name.casefold() == session.process_name.casefold()
            and record.build_identity == build_identity
            and record.process_started_at == session.process_started_at
        ]

    @staticmethod
    def _select_regions(
        eligible: list[MemoryRegion],
        hint_addresses: list[int],
        *,
        full_scan: bool,
    ) -> tuple[list[MemoryRegion], str, bool]:
        allocation_bases = {
            region.allocation_base or region.base_address
            for address in hint_addresses
            for region in eligible
            if region.contains(address)
        }
        if allocation_bases:
            candidates = [
                region
                for region in eligible
                if (region.allocation_base or region.base_address) in allocation_bases
            ]
            selected, truncated = _bounded_regions(candidates, _MAX_HINT_SCAN_BYTES)
            return selected, "same-process-allocation", truncated
        if full_scan:
            selected, truncated = _bounded_regions(eligible, _MAX_FULL_SCAN_BYTES)
            return selected, "explicit-bounded-full-scan", truncated
        return [], "no-current-process-hint", False

    def _scan_identity(
        self,
        session: ProcessSession,
        regions: list[MemoryRegion],
        identity: bytes,
    ) -> tuple[list[int], int, bool]:
        matches: set[int] = set()
        scanned_bytes = 0
        truncated = False
        overlap_size = len(identity) - 1
        for region in regions:
            offset = 0
            tail = b""
            while offset < region.size:
                size = min(self.scan_chunk_bytes, region.size - offset)
                address = region.base_address + offset
                try:
                    payload = self.memory.read(session.backend_handle, address, size)
                except (BackendError, OSError):
                    tail = b""
                    offset += size
                    continue
                scanned_bytes += len(payload)
                searchable = tail + payload
                searchable_base = address - len(tail)
                start = 0
                while True:
                    found = searchable.find(identity, start)
                    if found < 0:
                        break
                    matches.add(searchable_base + found)
                    if len(matches) >= _MAX_RAW_ID_MATCHES:
                        truncated = True
                        break
                    start = found + 1
                if truncated:
                    break
                tail = searchable[-overlap_size:] if overlap_size else b""
                offset += size
            if truncated:
                break
        return sorted(matches), scanned_bytes, truncated

    def _validate_candidate(
        self,
        session: ProcessSession,
        slot_address: int,
        *,
        target: NmsInventoryStack,
        live_item_id: str,
        container_stacks: list[NmsInventoryStack],
    ) -> SavedInventoryLiveCandidate | None:
        try:
            data = self.memory.read(
                session.backend_handle,
                slot_address,
                _NMS_INVENTORY_RECORD_SIZE,
            )
        except (BackendError, OSError):
            return None
        if len(data) != _NMS_INVENTORY_RECORD_SIZE:
            return None
        raw_identity = data[:16]
        if raw_identity.rstrip(b"\x00") != live_item_id.encode("ascii"):
            return None
        index_x, index_y, count = struct.unpack_from("<III", data, 0x10)
        maximum = struct.unpack_from("<I", data, _NMS_MAXIMUM_OFFSET)[0]
        item_type = struct.unpack_from("<I", data, _NMS_TYPE_OFFSET)[0]
        flag_0 = data[_NMS_FLAG_0_OFFSET]
        flag_1 = data[_NMS_FLAG_1_OFFSET]
        if (
            index_x > 4096
            or index_y > 4096
            or maximum == 0
            or count > maximum
            or item_type > 64
            or flag_0 > 1
            or flag_1 > 1
        ):
            return None
        neighbor_matches, neighbor_checks = self._neighbor_evidence(
            session,
            slot_address,
            target=target,
            container_stacks=container_stacks,
        )
        coordinate_match = index_x == target.index_x and index_y == target.index_y
        maximum_match = maximum == target.max_amount
        required_neighbor_matches = min(2, neighbor_checks)
        neighbor_shape_match = neighbor_matches >= required_neighbor_matches
        if neighbor_checks > 0:
            valid_shape = neighbor_shape_match
        else:
            valid_shape = coordinate_match and maximum_match
        if not valid_shape:
            return None
        return SavedInventoryLiveCandidate(
            slot_address=slot_address,
            count_address=slot_address + _NMS_COUNT_OFFSET,
            maximum_address=slot_address + _NMS_MAXIMUM_OFFSET,
            slot_address_hex=f"0x{slot_address:X}",
            count_address_hex=f"0x{slot_address + _NMS_COUNT_OFFSET:X}",
            item_id=live_item_id,
            count=count,
            maximum=maximum,
            index_x=index_x,
            index_y=index_y,
            item_type=item_type,
            flag_0=flag_0,
            flag_1=flag_1,
            saved_coordinate_match=coordinate_match,
            saved_amount_match=count == target.amount,
            saved_maximum_match=maximum_match,
            neighbor_matches=neighbor_matches,
            neighbor_checks=neighbor_checks,
        )

    def _neighbor_evidence(
        self,
        session: ProcessSession,
        slot_address: int,
        *,
        target: NmsInventoryStack,
        container_stacks: list[NmsInventoryStack],
    ) -> tuple[int, int]:
        if target.slot_ordinal is None:
            return 0, 0
        matches = 0
        checks = 0
        nearby = [
            stack
            for stack in container_stacks
            if stack.slot_ordinal is not None
            and 0 < abs(stack.slot_ordinal - target.slot_ordinal) <= 2
        ]
        for stack in nearby:
            delta = (stack.slot_ordinal - target.slot_ordinal) * _NMS_INVENTORY_RECORD_SIZE
            try:
                current = self.memory.read(session.backend_handle, slot_address + delta, 16)
                expected, _ = _live_identity(stack.item_id)
            except (BackendError, OSError, SafetyError):
                continue
            checks += 1
            if current.rstrip(b"\x00") == expected.encode("ascii"):
                matches += 1
        return matches, checks

    @staticmethod
    def _result(
        session: ProcessSession,
        snapshot: NmsInventorySnapshot,
        target: NmsInventoryStack,
        *,
        live_item_id: str,
        build_identity: str,
        search_mode: str,
        hint_count: int,
        selected_region_count: int,
        scanned_bytes: int,
        scope_truncated: bool,
        elapsed_ms: int,
        candidates: list[SavedInventoryLiveCandidate],
        message: str,
        candidate_count: int | None = None,
        suggested_primary_count_address: int | None = None,
        selection_basis: str | None = None,
    ) -> SavedInventoryLiveResolution:
        return SavedInventoryLiveResolution(
            session_id=session.id,
            pid=session.pid,
            process_name=session.process_name,
            process_started_at=session.process_started_at,
            build_identity=build_identity,
            save_profile=snapshot.save_path.parent.name,
            save_filename=snapshot.save_path.name,
            save_modified_at=snapshot.modified_at,
            item_id=target.item_id,
            live_item_id=live_item_id,
            container_name=target.container_name,
            stack_size_group=target.stack_size_group,
            saved_count=target.amount,
            saved_maximum=target.max_amount,
            saved_index_x=target.index_x,
            saved_index_y=target.index_y,
            saved_slot_ordinal=target.slot_ordinal,
            search_mode=search_mode,
            same_process_hint_count=hint_count,
            selected_region_count=selected_region_count,
            scanned_bytes=scanned_bytes,
            scope_truncated=scope_truncated,
            elapsed_ms=elapsed_ms,
            candidate_count=len(candidates) if candidate_count is None else candidate_count,
            returned_candidate_count=len(candidates),
            suggested_primary_count_address=suggested_primary_count_address,
            selection_basis=selection_basis,
            message=message,
            candidates=candidates,
        )


def _live_identity(item_id: str) -> tuple[str, tuple[int, int, str]]:
    live_item_id = item_id.strip().lstrip("^")
    try:
        encoded = live_item_id.encode("ascii")
    except UnicodeEncodeError as exc:
        raise SafetyError("the saved item ID is not an ASCII NMS runtime identity") from exc
    if not 1 <= len(encoded) <= 16:
        raise SafetyError("the saved item ID does not fit the 16-byte NMS runtime identity")
    padded = encoded.ljust(16, b"\x00")
    low = int.from_bytes(padded[:8], "little")
    high = int.from_bytes(padded[8:], "little")
    return live_item_id, (low, high, f"{low:016X}:{high:016X}")


def _eligible_region(region: MemoryRegion) -> bool:
    return (
        region.committed
        and region.readable
        and region.writable
        and not region.executable
        and not region.guarded
    )


def _bounded_regions(
    regions: list[MemoryRegion],
    maximum_bytes: int,
) -> tuple[list[MemoryRegion], bool]:
    selected: list[MemoryRegion] = []
    remaining = maximum_bytes
    total = sum(region.size for region in regions)
    for region in sorted(regions, key=lambda item: item.base_address):
        if remaining <= 0:
            break
        size = min(region.size, remaining)
        selected.append(region.model_copy(update={"size": size}))
        remaining -= size
    return selected, sum(region.size for region in selected) < total


def _elapsed_ms(started: float) -> int:
    return max(0, round((monotonic() - started) * 1000))
