from __future__ import annotations

from datetime import UTC, datetime
from enum import StrEnum
from uuid import uuid4

from pydantic import BaseModel, Field


class EventDirection(StrEnum):
    UNCHANGED = "unchanged"
    CHANGED = "changed"
    INCREASED = "increased"
    DECREASED = "decreased"
    NEGATIVE_CONTROL = "negative_control"


class TemporalSnapshot(BaseModel):
    id: str = Field(default_factory=lambda: uuid4().hex)
    label: str
    direction: EventDirection
    values: dict[str, float]
    captured_at: datetime = Field(default_factory=lambda: datetime.now(UTC))


class TemporalCandidate(BaseModel):
    address: str
    current_value: float
    score: int = 0
    observations: int = 0
    matches: int = 0
    contradictions: int = 0
    active: bool = True
    evidence: list[str] = Field(default_factory=list)


class CandidateGeneration(BaseModel):
    id: str = Field(default_factory=lambda: uuid4().hex)
    number: int = Field(ge=0)
    parent_id: str | None = None
    snapshot_id: str
    candidates: list[TemporalCandidate]
    active_count: int = Field(ge=0)
    discarded_count: int = Field(ge=0)
    created_at: datetime = Field(default_factory=lambda: datetime.now(UTC))


class TemporalCorrelationSession(BaseModel):
    id: str = Field(default_factory=lambda: uuid4().hex)
    target: str
    value_type: str
    read_only: bool = True
    snapshots: list[TemporalSnapshot]
    generations: list[CandidateGeneration]
    current_generation_id: str
    created_at: datetime = Field(default_factory=lambda: datetime.now(UTC))

    @property
    def current_generation(self) -> CandidateGeneration:
        return next(item for item in self.generations if item.id == self.current_generation_id)


class TemporalCorrelationScanner:
    """Evidence-score value changes without destroying an earlier candidate generation."""

    def __init__(self, *, inactive_below: int = -2, equality_tolerance: float = 1e-6) -> None:
        self.inactive_below = inactive_below
        self.equality_tolerance = equality_tolerance

    def start(
        self,
        target: str,
        values: dict[int | str, int | float],
        *,
        value_type: str = "unknown",
        label: str = "baseline",
    ) -> TemporalCorrelationSession:
        normalized = self._normalize_values(values)
        if not target.strip():
            raise ValueError("a temporal scan target is required")
        if not normalized:
            raise ValueError("the baseline must contain at least one candidate")
        snapshot = TemporalSnapshot(
            label=label.strip() or "baseline",
            direction=EventDirection.UNCHANGED,
            values=normalized,
        )
        candidates = [
            TemporalCandidate(address=address, current_value=value)
            for address, value in sorted(normalized.items())
        ]
        generation = CandidateGeneration(
            number=0,
            snapshot_id=snapshot.id,
            candidates=candidates,
            active_count=len(candidates),
            discarded_count=0,
        )
        return TemporalCorrelationSession(
            target=target.strip(),
            value_type=value_type,
            snapshots=[snapshot],
            generations=[generation],
            current_generation_id=generation.id,
        )

    def capture(
        self,
        session: TemporalCorrelationSession,
        values: dict[int | str, int | float],
        *,
        direction: EventDirection,
        label: str,
    ) -> CandidateGeneration:
        normalized = self._normalize_values(values)
        parent = session.current_generation
        if not normalized:
            raise ValueError("a temporal snapshot must contain at least one candidate")
        snapshot = TemporalSnapshot(
            label=label.strip() or direction.value.replace("_", " "),
            direction=direction,
            values=normalized,
        )
        candidates: list[TemporalCandidate] = []
        for prior in parent.candidates:
            observed = normalized.get(prior.address)
            if observed is None:
                candidates.append(
                    prior.model_copy(
                        update={
                            "active": False,
                            "contradictions": prior.contradictions + 1,
                            "evidence": [
                                *prior.evidence,
                                f"{snapshot.label}: candidate was unreadable",
                            ][-20:],
                        }
                    )
                )
                continue
            matched = self._matches(prior.current_value, observed, direction)
            delta = self._score_delta(direction, matched)
            score = prior.score + delta
            candidates.append(
                prior.model_copy(
                    update={
                        "current_value": observed,
                        "score": score,
                        "observations": prior.observations + 1,
                        "matches": prior.matches + int(matched),
                        "contradictions": prior.contradictions + int(not matched),
                        "active": score >= self.inactive_below,
                        "evidence": [
                            *prior.evidence,
                            (
                                f"{snapshot.label}: {direction.value} "
                                f"{'matched' if matched else 'contradicted'}"
                            ),
                        ][-20:],
                    }
                )
            )
        generation = CandidateGeneration(
            number=max(item.number for item in session.generations) + 1,
            parent_id=parent.id,
            snapshot_id=snapshot.id,
            candidates=sorted(
                candidates,
                key=lambda item: (item.active, item.score, item.matches),
                reverse=True,
            ),
            active_count=sum(item.active for item in candidates),
            discarded_count=sum(not item.active for item in candidates),
        )
        session.snapshots.append(snapshot)
        session.generations.append(generation)
        session.current_generation_id = generation.id
        return generation

    @staticmethod
    def rollback(
        session: TemporalCorrelationSession,
        generation_id: str,
    ) -> CandidateGeneration:
        generation = next(
            (item for item in session.generations if item.id == generation_id),
            None,
        )
        if generation is None:
            raise KeyError(f"temporal generation {generation_id} was not found")
        session.current_generation_id = generation.id
        return generation

    def _matches(self, before: float, after: float, direction: EventDirection) -> bool:
        equal = abs(after - before) <= self.equality_tolerance
        if direction in {EventDirection.UNCHANGED, EventDirection.NEGATIVE_CONTROL}:
            return equal
        if direction is EventDirection.CHANGED:
            return not equal
        if direction is EventDirection.INCREASED:
            return after > before + self.equality_tolerance
        return after < before - self.equality_tolerance

    @staticmethod
    def _score_delta(direction: EventDirection, matched: bool) -> int:
        if direction is EventDirection.NEGATIVE_CONTROL:
            return 3 if matched else -3
        return 2 if matched else -2

    @staticmethod
    def _normalize_values(
        values: dict[int | str, int | float],
    ) -> dict[str, float]:
        normalized: dict[str, float] = {}
        for address, value in values.items():
            key = f"0x{address:X}" if isinstance(address, int) else str(address).strip()
            if not key:
                raise ValueError("candidate addresses cannot be empty")
            normalized[key] = float(value)
        return normalized
