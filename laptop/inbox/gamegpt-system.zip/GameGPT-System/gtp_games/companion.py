from __future__ import annotations

import asyncio
import ctypes
import json
import os
import re
import shutil
import socket
import subprocess
import sys
import time
from ctypes import wintypes
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any

import psutil
from httpx import TransportError

from gtp_games.config import Settings
from gtp_games.control import CONTROL_API, CONTROL_PROTOCOL_VERSIONS
from gtp_games.errors import SafetyError
from gtp_games.game_library import GameLibrarySnapshot, discover_game_library
from gtp_games.memory.windows import WindowsMemoryBackend
from gtp_games.models import ProcessInfo
from gtp_games.safety import SafetyPolicy

_LOOPBACK_HOSTS = {"127.0.0.1", "localhost", "::1"}
_SECRET_PATTERN = re.compile(r"(?:sk|sess)-[A-Za-z0-9_-]+", re.IGNORECASE)


@dataclass
class LauncherConfig:
    backend: str = "windows" if sys.platform == "win32" else "simulated"
    game_process: str = ""
    allow_writes: bool = False
    mcp_host: str = "127.0.0.1"
    mcp_port: int = 8000
    tunnel_client_path: str = ""
    tunnel_profile_dir: str = ""
    tunnel_profile: str = "gtp-games"
    tunnel_alias: str = "gtp-games"
    tunnel_id: str = ""
    organization_id: str = ""
    selected_game_id: str = ""
    selected_table_path: str = ""
    game_history: dict[str, str] = field(default_factory=dict)

    @property
    def mcp_url(self) -> str:
        return f"http://{self.mcp_host}:{self.mcp_port}/mcp"

    @property
    def has_tunnel_setup(self) -> bool:
        return all(
            (
                self.tunnel_client_path,
                self.tunnel_profile_dir,
                self.tunnel_profile,
                self.tunnel_alias,
                self.tunnel_id,
            )
        )

    def validate(self) -> None:
        if self.backend not in {"windows", "simulated"}:
            raise ValueError("backend must be windows or simulated")
        if self.mcp_host not in _LOOPBACK_HOSTS:
            raise ValueError("the companion must bind only to this PC")
        if not 1 <= self.mcp_port <= 65535:
            raise ValueError("MCP port must be between 1 and 65535")
        if self.allow_writes and not self.game_process.strip():
            raise ValueError("choose one offline game before enabling controlled writes")
        if not isinstance(self.game_history, dict):
            raise ValueError("game history must be a local game-to-date mapping")

    @classmethod
    def from_dict(cls, values: dict[str, Any]) -> LauncherConfig:
        known = {field_name for field_name in cls.__dataclass_fields__}
        config = cls(**{key: value for key, value in values.items() if key in known})
        config.validate()
        return config


@dataclass(frozen=True)
class CompanionStatus:
    companion_running: bool
    companion_pid: int | None
    tunnel_running: bool
    tunnel_ready: bool
    writes_enabled: bool
    scan_activity: dict[str, Any] | None
    detail: str
    health: str
    product_version: str | None
    control_protocol_version: str | None
    instance_id: str | None
    duplicate_companion_pids: tuple[int, ...]
    reconnect_attempts: int


def default_config_path() -> Path:
    override = os.getenv("GTP_LAUNCHER_CONFIG", "").strip()
    if override:
        return Path(override).expanduser().resolve()
    local_app_data = os.getenv("LOCALAPPDATA", "").strip()
    if local_app_data:
        return Path(local_app_data) / "GTP Games" / "launcher.json"
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent / "data" / "launcher.json"
    return Path.cwd() / "data" / "launcher.json"


def load_launcher_config(path: Path | None = None) -> LauncherConfig:
    config_path = path or default_config_path()
    if getattr(sys, "frozen", False):
        try:
            uses_default_path = config_path.resolve() == default_config_path().resolve()
        except OSError:
            uses_default_path = False
        if uses_default_path:
            _copy_missing_legacy_runtime_data(config_path.parent)
    if config_path.exists():
        return LauncherConfig.from_dict(json.loads(config_path.read_text(encoding="utf-8")))
    return LauncherConfig(
        tunnel_client_path=os.getenv("GTP_TUNNEL_CLIENT_PATH", ""),
        tunnel_profile_dir=os.getenv("GTP_TUNNEL_PROFILE_DIR", ""),
        tunnel_profile=os.getenv("GTP_TUNNEL_PROFILE", "gtp-games"),
        tunnel_alias=os.getenv("GTP_TUNNEL_ALIAS", "gtp-games"),
        tunnel_id=os.getenv("GTP_TUNNEL_ID", ""),
        organization_id=os.getenv("GTP_TUNNEL_ORGANIZATION_ID", ""),
    )


def _copy_missing_legacy_runtime_data(destination: Path) -> None:
    """Copy portable single-file state once; never overwrite or delete prior evidence."""

    source = Path(sys.executable).resolve().parent / "data"
    try:
        if not source.is_dir() or source.resolve() == destination.resolve():
            return
    except OSError:
        return
    destination.mkdir(parents=True, exist_ok=True)
    for item in source.rglob("*"):
        relative = item.relative_to(source)
        if relative.parts and relative.parts[0].casefold() == "scan_cache":
            continue
        target = destination / relative
        if item.is_dir():
            target.mkdir(parents=True, exist_ok=True)
        elif item.is_file() and not target.exists():
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(item, target)


def save_launcher_config(config: LauncherConfig, path: Path | None = None) -> Path:
    config.validate()
    config_path = path or default_config_path()
    config_path.parent.mkdir(parents=True, exist_ok=True)
    config_path.write_text(json.dumps(asdict(config), indent=2) + "\n", encoding="utf-8")
    return config_path


class CompanionController:
    def __init__(
        self,
        config: LauncherConfig,
        *,
        config_path: Path | None = None,
    ) -> None:
        config.validate()
        self.config = config
        self.config_path = config_path or default_config_path()
        self._companion_process: subprocess.Popen[bytes] | None = None
        self._reconnect_attempts = 0

    def list_game_processes(self) -> list[ProcessInfo]:
        if sys.platform != "win32":
            return []
        settings = Settings(backend="windows", allow_writes=False)
        policy = SafetyPolicy(settings)
        visible_pids = self._visible_window_process_ids()
        processes: list[ProcessInfo] = []
        for process in WindowsMemoryBackend().list_processes(
            pids=visible_pids,
            include_gpu=False,
        ):
            try:
                policy.validate_process(process, write_enabled=False)
            except SafetyError as exc:
                process = process.model_copy(
                    update={
                        "attachable": False,
                        "blocked_reason": str(exc),
                        "likely_game": False,
                    }
                )
            processes.append(process)
        return processes

    def discover_game_library(
        self,
        processes: list[ProcessInfo] | None = None,
    ) -> GameLibrarySnapshot:
        return discover_game_library(
            processes if processes is not None else self.list_game_processes(),
            table_roots=self._game_table_roots(),
            history=self.config.game_history,
        )

    def _game_table_roots(self) -> list[Path]:
        candidates = [
            self.config_path.parent / "exports",
            Path.cwd() / "data" / "exports",
        ]
        if getattr(sys, "frozen", False):
            candidates.append(Path(sys.executable).resolve().parent / "data" / "exports")
        roots: list[Path] = []
        seen: set[str] = set()
        for candidate in candidates:
            try:
                resolved = candidate.resolve()
            except OSError:
                continue
            normalized = os.path.normcase(str(resolved))
            if normalized not in seen:
                seen.add(normalized)
                roots.append(resolved)
        return roots

    @staticmethod
    def _visible_window_process_ids() -> set[int]:
        if sys.platform != "win32":
            return set()
        user32 = ctypes.WinDLL("user32", use_last_error=True)
        process_ids: set[int] = set()
        callback_type = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)

        def visit(window, _parameter) -> bool:
            if not user32.IsWindowVisible(window) or user32.GetWindowTextLengthW(window) <= 0:
                return True
            process_id = wintypes.DWORD()
            user32.GetWindowThreadProcessId(window, ctypes.byref(process_id))
            if process_id.value:
                process_ids.add(int(process_id.value))
            return True

        callback = callback_type(visit)
        user32.EnumWindows(callback, 0)
        return process_ids

    def attach_process(
        self,
        pid: int,
        *,
        write_enabled: bool = False,
        game_key: str | None = None,
        game_name: str | None = None,
        table_path: str | None = None,
    ) -> dict[str, Any]:
        if pid <= 0:
            raise ValueError("choose a running process before attaching")
        if write_enabled and not self.config.allow_writes:
            raise SafetyError("controlled writes must be enabled for this launch before attaching")
        # Attaching to a local game must not depend on the optional private
        # ChatGPT tunnel.  A tunnel outage previously left the healthy local
        # service running but aborted auto-mount before a session was created.
        self.ensure_runtime()
        arguments: dict[str, Any] = {"pid": pid, "write_enabled": write_enabled}
        if game_key:
            arguments["game_key"] = game_key
        if game_name:
            arguments["game_name"] = game_name
        if table_path:
            arguments["table_path"] = table_path
        return self._call_companion_tool(
            "attach_game_process",
            arguments,
        )

    def attach_read_only(
        self,
        pid: int,
        *,
        game_key: str | None = None,
        game_name: str | None = None,
        table_path: str | None = None,
    ) -> dict[str, Any]:
        return self.attach_process(
            pid,
            write_enabled=False,
            game_key=game_key,
            game_name=game_name,
            table_path=table_path,
        )

    @staticmethod
    def launch_game(launch_target: str) -> None:
        target = launch_target.strip()
        lowered = target.casefold()
        allowed_uri = lowered.startswith("steam://rungameid/") or lowered.startswith(
            "com.epicgames.launcher://apps/"
        )
        executable = Path(target).expanduser() if not allowed_uri else None
        if not allowed_uri and (
            executable is None or executable.suffix.casefold() != ".exe" or not executable.is_file()
        ):
            raise SafetyError("this game does not have a safe local launch target")
        if sys.platform != "win32" or not hasattr(os, "startfile"):
            raise OSError("game launching is available only in the Windows companion")
        os.startfile(target)  # type: ignore[attr-defined]

    def detach_session(self, session_id: str) -> dict[str, Any]:
        if not session_id:
            raise ValueError("no process session is selected")
        return self._call_companion_tool(
            "detach_game_process",
            {"session_id": session_id},
        )

    def export_game_value_table(self, session_id: str) -> dict[str, Any]:
        if not session_id:
            raise ValueError("no process session is selected")
        return self._call_companion_tool(
            "export_game_value_table",
            {"session_id": session_id},
        )

    def game_cheat_catalog(self, session_id: str) -> dict[str, Any]:
        if not session_id:
            raise ValueError("no process session is selected")
        return self._call_companion_tool(
            "get_game_cheat_catalog",
            {"session_id": session_id},
        )

    def estimate_health_bars(self, session_id: str, *, limit: int = 8) -> dict[str, Any]:
        if not session_id:
            raise ValueError("no process session is selected")
        return self._call_companion_tool(
            "estimate_health_bar",
            {"session_id": session_id, "limit": limit},
        )

    def inspect_inventory(self, session_id: str) -> dict[str, Any]:
        if not session_id:
            raise ValueError("no process session is selected")
        return self._call_companion_tool(
            "inspect_inventory_screen",
            {"session_id": session_id},
        )

    def import_ct_reference(self, source: str) -> dict[str, Any]:
        selected = Path(source).expanduser()
        if selected.suffix.casefold() != ".ct" or not selected.is_file():
            raise SafetyError("choose an existing local Cheat Engine .CT file")
        return self._call_companion_tool(
            "import_cheat_engine_reference",
            {"source": str(selected.resolve()), "query": "", "limit": 200},
        )

    def compare_nms_saves(
        self,
        older_filename: str | None = None,
        newer_filename: str | None = None,
        *,
        limit: int = 250,
    ) -> dict[str, Any]:
        arguments: dict[str, Any] = {"limit": limit}
        if older_filename:
            arguments["older_filename"] = older_filename
        if newer_filename:
            arguments["newer_filename"] = newer_filename
        return self._call_companion_tool("compare_nms_save_snapshots", arguments)

    def prepare_game_cheat_action(
        self,
        session_id: str,
        feature_id: str,
        action: str,
        value: int | float,
    ) -> dict[str, Any]:
        if not session_id:
            raise ValueError("no selected game session is attached")
        return self._call_companion_tool(
            "prepare_game_cheat_action",
            {
                "session_id": session_id,
                "feature_id": feature_id,
                "action": action,
                "value": value,
            },
        )

    def confirm_game_cheat_action_locally(self, intent_id: str) -> dict[str, Any]:
        if not intent_id:
            raise ValueError("no prepared game value change is selected")
        return self._call_companion_tool(
            "confirm_game_cheat_action_locally",
            {"intent_id": intent_id},
        )

    def apply_game_cheat_action(self, intent_id: str) -> dict[str, Any]:
        if not intent_id:
            raise ValueError("no prepared game value change is selected")
        return self._call_companion_tool(
            "apply_game_cheat_action",
            {"intent_id": intent_id},
        )

    def prepare_discovery_candidate_test(
        self,
        run_id: str,
        target_name: str,
        candidate_id: str,
        test_value: int | float,
    ) -> dict[str, Any]:
        if not run_id or not candidate_id:
            raise ValueError("no learned-value candidate is selected")
        return self._call_companion_tool(
            "prepare_discovery_candidate_test",
            {
                "run_id": run_id,
                "target_name": target_name,
                "candidate_id": candidate_id,
                "test_value": test_value,
            },
        )

    def confirm_prepared_write_locally(self, intent_id: str) -> dict[str, Any]:
        if not intent_id:
            raise ValueError("no prepared value test is selected")
        return self._call_companion_tool(
            "confirm_prepared_write_locally",
            {"intent_id": intent_id},
        )

    def apply_prepared_write(self, intent_id: str) -> dict[str, Any]:
        if not intent_id:
            raise ValueError("no prepared value change is selected")
        return self._call_companion_tool(
            "apply_prepared_write",
            {"intent_id": intent_id},
        )

    def finalize_discovery_candidate_test(
        self,
        intent_id: str,
        matched_in_game: bool,
        *,
        restore_after_test: bool = False,
        verification_source: str = "user",
    ) -> dict[str, Any]:
        if not intent_id:
            raise ValueError("no candidate value test is awaiting a result")
        arguments: dict[str, Any] = {
            "intent_id": intent_id,
            "matched_in_game": matched_in_game,
        }
        if restore_after_test:
            arguments["restore_after_test"] = True
        if verification_source != "user":
            arguments["verification_source"] = verification_source
        return self._call_companion_tool(
            "finalize_discovery_candidate_test",
            arguments,
        )

    def prepare_inventory_matrix_probe(
        self,
        run_id: str,
        target_name: str = "inventory item quantity",
    ) -> dict[str, Any]:
        if not run_id:
            raise ValueError("start inventory learning before mapping stacks")
        return self._call_companion_tool(
            "prepare_inventory_matrix_probe",
            {"run_id": run_id, "target_name": target_name},
        )

    def apply_inventory_matrix_probe(self, probe_id: str) -> dict[str, Any]:
        if not probe_id:
            raise ValueError("no prepared inventory matrix is selected")
        return self._call_companion_tool(
            "apply_inventory_matrix_probe",
            {"probe_id": probe_id},
        )

    def restore_inventory_matrix_probe(
        self,
        probe_id: str,
        matched_candidates: dict[str, str] | None = None,
        reference_urls: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        if not probe_id:
            raise ValueError("no active inventory matrix is selected")
        return self._call_companion_tool(
            "restore_inventory_matrix_probe",
            {
                "probe_id": probe_id,
                "matched_candidates": matched_candidates or {},
                "reference_urls": reference_urls or {},
            },
        )

    def start_autonomous_discovery(
        self,
        *,
        session_id: str | None = None,
        process_name: str = "NMS.exe",
        target_order: list[str] | None = None,
        interval_seconds: float = 2.0,
        observation_seconds: float = 10.0,
        revisit_seconds: float = 30.0,
    ) -> dict[str, Any]:
        arguments: dict[str, Any] = {
            "process_name": process_name,
            "interval_seconds": interval_seconds,
            "observation_seconds": observation_seconds,
            "revisit_seconds": revisit_seconds,
        }
        if session_id:
            arguments["session_id"] = session_id
        if target_order:
            arguments["target_order"] = target_order
        return self._call_companion_tool("start_autonomous_cheat_discovery", arguments)

    def autonomous_discovery_status(self, run_id: str) -> dict[str, Any]:
        if not run_id:
            raise ValueError("no cheat-learning run is selected")
        return self._call_companion_tool(
            "get_autonomous_cheat_discovery",
            {"run_id": run_id},
        )

    def set_autonomous_discovery_value(
        self,
        run_id: str,
        target_name: str,
        value: int | float,
        *,
        source: str = "user",
    ) -> dict[str, Any]:
        if not run_id:
            raise ValueError("start learning before entering a visible value")
        return self._call_companion_tool(
            "set_autonomous_cheat_discovery_value",
            {
                "run_id": run_id,
                "target_name": target_name,
                "value": value,
                "source": source,
            },
        )

    def record_autonomous_discovery_screen_comparison(
        self,
        run_id: str,
        target_name: str,
        comparison: str,
        screen_value: int | float,
    ) -> dict[str, Any]:
        return self._call_companion_tool(
            "record_autonomous_cheat_screen_comparison",
            {
                "run_id": run_id,
                "target_name": target_name,
                "comparison": comparison,
                "screen_value": screen_value,
            },
        )

    def rescan_autonomous_discovery_values(self, run_id: str) -> dict[str, Any]:
        if not run_id:
            raise ValueError("start learning before rescanning saved values")
        return self._call_companion_tool(
            "rescan_all_saved_game_values",
            {"run_id": run_id},
        )

    def capture_autonomous_discovery_behavior(
        self,
        run_id: str,
        target_name: str,
        phase: str,
        label: str = "",
    ) -> dict[str, Any]:
        if not run_id:
            raise ValueError("start learning before capturing a gameplay action")
        return self._call_companion_tool(
            "capture_autonomous_cheat_behavior",
            {
                "run_id": run_id,
                "target_name": target_name,
                "phase": phase,
                "label": label,
            },
        )

    def stop_autonomous_discovery(self, run_id: str) -> dict[str, Any]:
        if not run_id:
            raise ValueError("no cheat-learning run is selected")
        return self._call_companion_tool(
            "stop_autonomous_cheat_discovery",
            {"run_id": run_id},
        )

    def save(self) -> Path:
        return save_launcher_config(self.config, self.config_path)

    def status(self) -> CompanionStatus:
        companion_pid = self._find_companion_pid()
        runtime_status = self._live_companion_status() if companion_pid else None
        protocol_version = self._negotiated_protocol(runtime_status or {})
        compatible = bool(runtime_status and self._runtime_matches_config(runtime_status))
        companion_pids = self._companion_process_pids()
        duplicate_pids = tuple(pid for pid in companion_pids if pid != companion_pid)
        tunnel_running, tunnel_ready = self._tunnel_status()
        if companion_pid and not compatible:
            detail = "Companion running; control protocol or configuration is incompatible"
        elif companion_pid and tunnel_ready:
            detail = "ChatGPT connection ready"
        elif companion_pid:
            detail = "Companion running; private connection is offline"
        elif tunnel_running:
            detail = "Private connection running; companion is offline"
        else:
            detail = (
                "Canonical companion stopped; duplicate non-listening companions detected"
                if duplicate_pids
                else "Stopped"
            )
        return CompanionStatus(
            companion_running=companion_pid is not None,
            companion_pid=companion_pid,
            tunnel_running=tunnel_running,
            tunnel_ready=tunnel_ready,
            writes_enabled=bool(runtime_status and runtime_status.get("writes_available", False)),
            scan_activity=(runtime_status.get("scan_activity") if runtime_status else None),
            detail=detail,
            health=(
                "ready"
                if compatible
                else "degraded"
                if companion_pid or duplicate_pids
                else "stopped"
            ),
            product_version=(str(runtime_status.get("version")) if runtime_status else None),
            control_protocol_version=protocol_version,
            instance_id=(str(runtime_status.get("instance_id")) if runtime_status else None),
            duplicate_companion_pids=duplicate_pids,
            reconnect_attempts=self._reconnect_attempts,
        )

    def start(self) -> CompanionStatus:
        self.ensure_runtime()
        if self.config.has_tunnel_setup:
            _, tunnel_ready = self._tunnel_status()
            if not tunnel_ready:
                self._start_tunnel()
        return self.status()

    def ensure_runtime(self) -> CompanionStatus:
        """Start or reconfigure only the local companion needed for game mounting."""

        self.config.validate()
        self.save()
        companion_pid = self._find_companion_pid()
        if companion_pid is not None:
            runtime_status = self._live_companion_status()
            if runtime_status is None:
                raise RuntimeError("the running companion configuration could not be verified")
            if not self._runtime_matches_config(runtime_status):
                self._stop_process_tree(companion_pid)
                self._wait_for_port_closed()
                companion_pid = None
        if companion_pid is None:
            if self._port_open():
                raise RuntimeError(
                    f"port {self.config.mcp_port} is already used by another application"
                )
            self._start_companion()
        return self.status()

    def _live_companion_status(self) -> dict[str, Any] | None:
        try:
            return self._call_companion_tool("get_companion_status", {})
        except Exception:
            return None

    def _runtime_matches_config(self, runtime_status: dict[str, Any]) -> bool:
        if runtime_status.get("control_api") != CONTROL_API:
            return False
        if self._negotiated_protocol(runtime_status) is None:
            return False
        if runtime_status.get("canonical_role") != "gamegpt-companion":
            return False
        running_writes = bool(runtime_status.get("writes_available", False))
        if running_writes != self.config.allow_writes:
            return False
        if not self.config.allow_writes:
            return True
        desired = {
            item.strip().casefold() for item in self.config.game_process.split(",") if item.strip()
        }
        running = {
            str(item).strip().casefold()
            for item in runtime_status.get("write_process_allowlist", [])
            if str(item).strip()
        }
        return running == desired

    @staticmethod
    def _negotiated_protocol(runtime_status: dict[str, Any]) -> str | None:
        server_versions = {
            str(item).strip()
            for item in runtime_status.get("control_protocol_versions", [])
            if str(item).strip()
        }
        return next(
            (version for version in CONTROL_PROTOCOL_VERSIONS if version in server_versions),
            None,
        )

    def _wait_for_port_closed(self) -> None:
        deadline = time.monotonic() + 5
        while time.monotonic() < deadline:
            if not self._port_open():
                return
            time.sleep(0.1)
        raise RuntimeError("the previous companion did not stop cleanly")

    def stop(self) -> CompanionStatus:
        self._stop_tunnel()
        companion_pid = self._find_companion_pid()
        if companion_pid is not None:
            self._stop_process_tree(companion_pid)
        self._companion_process = None
        return self.status()

    def _start_companion(self) -> None:
        command = self._companion_command()
        self._companion_process = subprocess.Popen(
            command,
            env=self._child_environment(),
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            creationflags=self._creation_flags(),
        )
        deadline = time.monotonic() + 15
        while time.monotonic() < deadline:
            if self._companion_process.poll() is not None:
                raise RuntimeError("the local companion stopped during startup")
            if self._port_open():
                return
            time.sleep(0.2)
        self._stop_process_tree(self._companion_process.pid)
        raise RuntimeError("the local companion did not become ready in time")

    def _start_tunnel(self) -> None:
        executable = self._tunnel_executable()
        environment = self._child_environment()
        command = [
            str(executable),
            "runtimes",
            "connect",
            "--alias",
            self.config.tunnel_alias,
            "--profile",
            self.config.tunnel_profile,
            "--profile-dir",
            self.config.tunnel_profile_dir,
            "--tunnel-id",
            self.config.tunnel_id,
            "--mcp-server-url",
            self.config.mcp_url,
            "--json",
        ]
        if environment.get("OPENAI_API_KEY"):
            command.extend(["--runtime-api-key", "env:OPENAI_API_KEY"])
        if self.config.organization_id:
            command.extend(["--organization-id", self.config.organization_id])
        result = subprocess.run(
            command,
            capture_output=True,
            env=environment,
            timeout=60,
            creationflags=self._creation_flags(),
        )
        if result.returncode != 0:
            raise RuntimeError(self._safe_error("private connection failed", result.stderr))
        deadline = time.monotonic() + 20
        while time.monotonic() < deadline:
            _, ready = self._tunnel_status()
            if ready:
                return
            time.sleep(0.5)
        raise RuntimeError("the private connection did not become ready in time")

    def _stop_tunnel(self) -> None:
        if not self.config.tunnel_client_path or not self.config.tunnel_alias:
            return
        executable = Path(self.config.tunnel_client_path)
        if not executable.is_file():
            return
        result = subprocess.run(
            [str(executable), "runtimes", "stop", self.config.tunnel_alias],
            capture_output=True,
            env=self._child_environment(),
            timeout=20,
            creationflags=self._creation_flags(),
        )
        if result.returncode != 0:
            raise RuntimeError(self._safe_error("could not stop private connection", result.stderr))

    def _tunnel_status(self) -> tuple[bool, bool]:
        if not self.config.tunnel_client_path or not self.config.tunnel_alias:
            return False, False
        executable = Path(self.config.tunnel_client_path)
        if not executable.is_file():
            return False, False
        try:
            result = subprocess.run(
                [
                    str(executable),
                    "runtimes",
                    "status",
                    self.config.tunnel_alias,
                    "--json",
                ],
                capture_output=True,
                env=self._child_environment(),
                timeout=5,
                creationflags=self._creation_flags(),
            )
            if result.returncode != 0:
                return False, False
            payload = json.loads(result.stdout.decode("utf-8"))
            return bool(payload.get("process_running")), bool(payload.get("ready"))
        except (OSError, subprocess.SubprocessError, UnicodeDecodeError, json.JSONDecodeError):
            return False, False

    def _child_environment(self) -> dict[str, str]:
        environment = os.environ.copy()
        settings = Settings()
        if not environment.get("OPENAI_API_KEY") and settings.openai_api_key is not None:
            environment["OPENAI_API_KEY"] = settings.openai_api_key.get_secret_value()
        environment.update(
            {
                "GTP_BACKEND": self.config.backend,
                "GTP_ALLOW_WRITES": str(self.config.allow_writes).lower(),
                "GTP_ALLOWED_PROCESSES": self.config.game_process,
                "GTP_MCP_HOST": self.config.mcp_host,
                "GTP_MCP_PORT": str(self.config.mcp_port),
                "GTP_AUDIT_LOG_PATH": str(self.config_path.parent / "audit.jsonl"),
                "GTP_GAME_PROFILE_DIRECTORY": str(self.config_path.parent / "game_profiles"),
                "GTP_GAME_TABLE_EXPORT_DIRECTORY": str(self.config_path.parent / "exports"),
                "GTP_WEB_DISCOVERY_CACHE_DIRECTORY": str(self.config_path.parent / "web_cache"),
                "GTP_SCAN_CACHE_DIRECTORY": str(self.config_path.parent / "scan_cache"),
            }
        )
        return environment

    def _companion_command(self) -> list[str]:
        if getattr(sys, "frozen", False):
            return [sys.executable, "--serve"]
        return [sys.executable, "-m", "gtp_games.launcher", "--serve"]

    def _call_companion_tool(self, name: str, arguments: dict[str, Any]) -> dict[str, Any]:
        reconnect_safe = name in {"get_companion_status", "negotiate_gamegpt_control"}
        attempts = 2 if reconnect_safe else 1
        for attempt in range(attempts):
            try:
                return self._call_companion_tool_once(name, arguments)
            except (OSError, ConnectionError, TimeoutError, TransportError):
                if attempt + 1 >= attempts:
                    raise
                self._reconnect_attempts += 1
                time.sleep(0.1)
        raise RuntimeError(f"companion tool {name} did not complete")

    def _call_companion_tool_once(self, name: str, arguments: dict[str, Any]) -> dict[str, Any]:
        async def call() -> dict[str, Any]:
            from mcp import ClientSession
            from mcp.client.streamable_http import streamable_http_client

            async with streamable_http_client(self.config.mcp_url) as streams:
                read_stream, write_stream, _ = streams
                async with ClientSession(read_stream, write_stream) as session:
                    await session.initialize()
                    result = await session.call_tool(name, arguments)
            if result.isError:
                detail = next(
                    (item.text for item in result.content if getattr(item, "type", None) == "text"),
                    f"companion tool {name} failed",
                )
                raise RuntimeError(detail)
            if result.structuredContent is None:
                raise RuntimeError(f"companion tool {name} returned no result")
            return result.structuredContent

        return asyncio.run(call())

    def _companion_process_pids(self) -> list[int]:
        pids: list[int] = []
        for process in psutil.process_iter(attrs=["pid"]):
            try:
                pid = int(process.info["pid"])
            except (KeyError, TypeError, ValueError):
                continue
            if self._is_companion_process(pid):
                pids.append(pid)
        return sorted(set(pids))

    def _find_companion_pid(self) -> int | None:
        try:
            connections = psutil.net_connections(kind="tcp")
        except (psutil.AccessDenied, OSError):
            return None
        for connection in connections:
            local = connection.laddr
            if not local or local.port != self.config.mcp_port:
                continue
            if connection.status != psutil.CONN_LISTEN or connection.pid is None:
                continue
            if self._is_companion_process(connection.pid):
                return connection.pid
        return None

    @staticmethod
    def _is_companion_process(pid: int) -> bool:
        if pid == os.getpid():
            return False
        try:
            process = psutil.Process(pid)
            name = process.name().lower()
            arguments = [str(item).lower() for item in process.cmdline()]
        except (psutil.AccessDenied, psutil.NoSuchProcess, psutil.ZombieProcess):
            return False
        command = " ".join(arguments)
        if "gtp-games-plugin" in name or "gtp-games-raw-plugin" in name:
            return True
        if "gtp games companion" in name and "--serve" in arguments:
            return True
        return (
            "-m gtp_games.mcp_server" in command
            or "-m gtp_games.raw_mcp_server" in command
            or "-m gtp_games.launcher --serve" in command
        )

    def _port_open(self) -> bool:
        try:
            with socket.create_connection(
                (self.config.mcp_host, self.config.mcp_port), timeout=0.25
            ):
                return True
        except OSError:
            return False

    @staticmethod
    def _stop_process_tree(pid: int) -> None:
        try:
            process = psutil.Process(pid)
            children = process.children(recursive=True)
            for child in children:
                child.terminate()
            process.terminate()
            _, alive = psutil.wait_procs([*children, process], timeout=4)
            for remaining in alive:
                remaining.kill()
        except psutil.NoSuchProcess:
            return

    def _tunnel_executable(self) -> Path:
        configured = Path(self.config.tunnel_client_path)
        if configured.is_file():
            return configured
        discovered = shutil.which("tunnel-client") or shutil.which("tunnel-client.exe")
        if discovered:
            self.config.tunnel_client_path = discovered
            return Path(discovered)
        raise RuntimeError("choose the OpenAI tunnel-client program in Connection settings")

    @staticmethod
    def _creation_flags() -> int:
        return int(getattr(subprocess, "CREATE_NO_WINDOW", 0))

    @staticmethod
    def _safe_error(prefix: str, stderr: bytes) -> str:
        message = stderr.decode("utf-8", errors="replace").strip().splitlines()
        detail = message[-1] if message else "unknown error"
        return f"{prefix}: {_SECRET_PATTERN.sub('[redacted]', detail)}"
