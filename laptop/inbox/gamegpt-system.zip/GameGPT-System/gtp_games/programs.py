"""GameGPT program layer above the frozen relay plugin.

This module deliberately contains policy and state, not process-memory primitives.
The relay remains the narrow executor for already-authorized actions.
"""

from __future__ import annotations

import re
import time
from collections.abc import Callable, Iterable
from dataclasses import dataclass, field
from enum import StrEnum
from typing import Any, Literal


class CompanionState(StrEnum):
    MUTED = "muted"
    LISTENING = "listening"
    WAITING = "waiting"
    EXECUTING = "executing"
    SUCCESS = "success"
    ERROR = "error"
    QUARANTINED = "quarantined"


class Route(StrEnum):
    FAST = "fast"
    PROCEDURAL = "procedural"
    REJECTED = "rejected"


@dataclass(frozen=True)
class GateSnapshot:
    state: CompanionState
    local_capture_enabled: bool
    quick_voice_enabled: bool
    procedural_voice_enabled: bool
    tape_visible: bool
    state_label: str
    generation: int


class MicrophoneGate:
    """One source of truth for both audio lanes and the visible mute layer."""

    def __init__(self, *, start_muted: bool = True) -> None:
        self._muted = start_muted
        self._paused = False
        self._executing = False
        self._terminal_state: CompanionState | None = None
        self._generation = 0

    @property
    def snapshot(self) -> GateSnapshot:
        if self._muted:
            state = CompanionState.MUTED
        elif self._paused:
            state = CompanionState.WAITING
        elif self._executing:
            state = CompanionState.EXECUTING
        elif self._terminal_state:
            state = self._terminal_state
        else:
            state = CompanionState.LISTENING
        enabled = state == CompanionState.LISTENING
        return GateSnapshot(
            state=state,
            local_capture_enabled=enabled,
            quick_voice_enabled=enabled,
            procedural_voice_enabled=enabled,
            tape_visible=state == CompanionState.MUTED,
            state_label=state.value.replace("_", " ").title(),
            generation=self._generation,
        )

    def mute(self) -> GateSnapshot:
        self._muted = True
        self._executing = False
        self._terminal_state = None
        self._generation += 1
        return self.snapshot

    def unmute(self) -> GateSnapshot:
        self._muted = False
        self._terminal_state = None
        self._generation += 1
        return self.snapshot

    def wait(self) -> GateSnapshot:
        self._paused = True
        self._executing = False
        self._generation += 1
        return self.snapshot

    def resume(self) -> GateSnapshot:
        self._paused = False
        self._terminal_state = None
        self._generation += 1
        return self.snapshot

    def begin_execution(self) -> GateSnapshot:
        if not self.snapshot.local_capture_enabled:
            raise RuntimeError("voice execution is unavailable while muted or waiting")
        self._executing = True
        self._terminal_state = None
        self._generation += 1
        return self.snapshot

    def finish(self, *, success: bool, quarantined: bool = False) -> GateSnapshot:
        self._executing = False
        self._terminal_state = (
            CompanionState.QUARANTINED
            if quarantined
            else CompanionState.SUCCESS
            if success
            else CompanionState.ERROR
        )
        self._generation += 1
        return self.snapshot


@dataclass(frozen=True)
class ActionBinding:
    id: str
    game_id: str
    current_build: str
    promoted: bool
    verified: bool
    mutates_state: bool = False
    rollback_available: bool = False

    @property
    def fast_eligible(self) -> bool:
        return self.promoted and self.verified and bool(self.current_build)


@dataclass
class FastCommand:
    phrase: str
    action_id: str
    enabled: bool = True
    cooldown_seconds: float = 1.0
    last_triggered_at: float | None = None


@dataclass(frozen=True)
class RouteDecision:
    route: Route
    reason: str
    action_id: str | None = None


class FastCommandRegistry:
    def __init__(self, actions: Iterable[ActionBinding] = ()) -> None:
        self.actions = {action.id: action for action in actions}
        self.commands: dict[str, FastCommand] = {}
        self.kill_switch = False
        self.quarantined = False
        self.quarantined_actions: set[str] = set()

    @staticmethod
    def normalize(phrase: str) -> str:
        return re.sub(r"\s+", " ", re.sub(r"[^a-z0-9 ]+", " ", phrase.lower())).strip()

    def add(self, command: FastCommand) -> None:
        phrase = self.normalize(command.phrase)
        if not phrase:
            raise ValueError("fast command phrase is empty")
        if phrase in self.commands:
            raise ValueError("fast command phrase already exists")
        self.commands[phrase] = command

    def edit(self, phrase: str, replacement: FastCommand) -> None:
        original = self.normalize(phrase)
        if original not in self.commands:
            raise KeyError(original)
        del self.commands[original]
        self.add(replacement)

    def disable(self, phrase: str) -> None:
        self.commands[self.normalize(phrase)].enabled = False

    def view(self) -> list[FastCommand]:
        return [self.commands[key] for key in sorted(self.commands)]

    def quarantine_action(self, action_id: str) -> None:
        self.quarantined_actions.add(action_id)

    def clear_action_quarantine(self, action_id: str) -> None:
        self.quarantined_actions.discard(action_id)

    def test(self, phrase: str, *, now: float | None = None) -> RouteDecision:
        return self.route(phrase, now=now, commit=False)

    def route(
        self, phrase: str, *, now: float | None = None, commit: bool = True
    ) -> RouteDecision:
        if self.kill_switch:
            return RouteDecision(Route.REJECTED, "quick-action kill switch is active")
        if self.quarantined:
            return RouteDecision(Route.PROCEDURAL, "quick-action lane is quarantined")
        normalized = self.normalize(phrase)
        command = self.commands.get(normalized)
        if command is None or not command.enabled:
            return RouteDecision(Route.PROCEDURAL, "no exact enabled trigger")
        action = self.actions.get(command.action_id)
        if action is None:
            return RouteDecision(Route.PROCEDURAL, "referenced action is unavailable")
        if action.id in self.quarantined_actions:
            return RouteDecision(Route.PROCEDURAL, "this action is quarantined")
        if not action.fast_eligible:
            return RouteDecision(Route.PROCEDURAL, "action is not promoted and build-current")
        current = time.monotonic() if now is None else now
        if (
            command.last_triggered_at is not None
            and current - command.last_triggered_at < command.cooldown_seconds
        ):
            return RouteDecision(Route.REJECTED, "duplicate suppressed by cooldown")
        if commit:
            command.last_triggered_at = current
        return RouteDecision(Route.FAST, "exact promoted trigger", action.id)


@dataclass(frozen=True)
class MacroStep:
    action_id: str
    arguments: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class MacroReceipt:
    status: Literal["dry-run", "success", "failed", "rejected"]
    completed: tuple[str, ...]
    rolled_back: tuple[str, ...]
    message: str


class MacroRunner:
    def __init__(self, registry: FastCommandRegistry) -> None:
        self.registry = registry

    def preflight(self, steps: Iterable[MacroStep]) -> tuple[bool, str]:
        materialized = tuple(steps)
        if not materialized:
            return False, "macro has no steps"
        for step in materialized:
            action = self.registry.actions.get(step.action_id)
            if action is None or not action.fast_eligible:
                return False, f"{step.action_id} is not a current promoted action"
            if action.mutates_state and not action.rollback_available:
                return False, f"{step.action_id} has no rollback"
        return True, "all steps passed preflight"

    def run(
        self,
        steps: Iterable[MacroStep],
        *,
        dry_run: bool,
        execute: Callable[[MacroStep], bool],
        rollback: Callable[[MacroStep], bool],
    ) -> MacroReceipt:
        materialized = tuple(steps)
        valid, reason = self.preflight(materialized)
        if not valid:
            return MacroReceipt("rejected", (), (), reason)
        if dry_run:
            return MacroReceipt("dry-run", (), (), reason)
        completed: list[MacroStep] = []
        for step in materialized:
            if execute(step):
                completed.append(step)
                continue
            rolled_back: list[str] = []
            for prior in reversed(completed):
                action = self.registry.actions[prior.action_id]
                if action.mutates_state and rollback(prior):
                    rolled_back.append(prior.action_id)
            return MacroReceipt(
                "failed",
                tuple(item.action_id for item in completed),
                tuple(rolled_back),
                f"stopped at {step.action_id}; rollback attempted",
            )
        return MacroReceipt(
            "success",
            tuple(item.action_id for item in completed),
            (),
            f"completed {len(completed)} step(s)",
        )


@dataclass(frozen=True)
class Point:
    x: float
    y: float


@dataclass(frozen=True)
class Rect:
    left: float
    top: float
    right: float
    bottom: float

    @property
    def width(self) -> float:
        return max(0.0, self.right - self.left)

    @property
    def height(self) -> float:
        return max(0.0, self.bottom - self.top)

    @property
    def center(self) -> Point:
        return Point((self.left + self.right) / 2, (self.top + self.bottom) / 2)

    def clamp(self, point: Point, margin: float = 0) -> Point:
        return Point(
            min(max(point.x, self.left + margin), self.right - margin),
            min(max(point.y, self.top + margin), self.bottom - margin),
        )


class MovementScope(StrEnum):
    GAME = "active_game_window"
    MONITOR = "current_monitor"
    DESKTOP = "virtual_desktop"


@dataclass(frozen=True)
class PointingPlan:
    pet_position: Point
    target: Point
    label: str
    facing: Literal["left", "right"]
    click_count: Literal[0] = 0
    write_authority: Literal[False] = False


class OverlayNavigator:
    def __init__(
        self,
        *,
        virtual_desktop: Rect,
        monitors: tuple[Rect, ...],
        active_game: Rect | None = None,
        dpi_scale: float = 1.0,
        reduced_motion: bool = False,
    ) -> None:
        self.virtual_desktop = virtual_desktop
        self.monitors = monitors
        self.active_game = active_game
        self.dpi_scale = dpi_scale
        self.reduced_motion = reduced_motion
        self.scope = MovementScope.GAME if active_game else MovementScope.MONITOR
        self.position = virtual_desktop.center
        self.visible = True
        self.killed = False

    def bounds(self) -> Rect:
        if self.scope == MovementScope.GAME and self.active_game:
            return self.active_game
        if self.scope == MovementScope.MONITOR:
            for monitor in self.monitors:
                if (
                    monitor.left <= self.position.x <= monitor.right
                    and monitor.top <= self.position.y <= monitor.bottom
                ):
                    return monitor
            return self.monitors[0]
        return self.virtual_desktop

    def set_scope(self, scope: MovementScope) -> None:
        if scope == MovementScope.GAME and self.active_game is None:
            raise RuntimeError("no active game window")
        self.scope = scope
        self.position = self.bounds().clamp(self.position, margin=16 * self.dpi_scale)

    def move_to(self, target: Point) -> Point:
        if self.killed:
            raise RuntimeError("overlay kill switch is active")
        self.position = self.bounds().clamp(target, margin=16 * self.dpi_scale)
        return self.position

    def point_at(self, target: Rect | Point, label: str) -> PointingPlan:
        point = target.center if isinstance(target, Rect) else target
        safe_target = self.bounds().clamp(point)
        offset = 96 * self.dpi_scale
        candidate = Point(safe_target.x - offset, safe_target.y)
        position = self.move_to(candidate)
        return PointingPlan(
            pet_position=position,
            target=safe_target,
            label=label[:80],
            facing="right" if safe_target.x >= position.x else "left",
        )

    def recall(self) -> Point:
        bounds = self.bounds()
        self.visible = True
        return self.move_to(Point(bounds.right - 72, bounds.bottom - 72))

    def hide(self) -> None:
        self.visible = False

    def show(self) -> None:
        if not self.killed:
            self.visible = True

    def kill(self) -> None:
        self.visible = False
        self.killed = True

    @staticmethod
    def supports_overlay(*, exclusive_fullscreen: bool) -> bool:
        return not exclusive_fullscreen


class ResearchState(StrEnum):
    QUEUED = "queued"
    RESEARCHING = "researching"
    PROPOSED = "proposed"
    VERIFYING = "verifying"
    PROMOTED = "promoted"
    QUARANTINED = "quarantined"
    STALE = "stale"


@dataclass
class ResearchMission:
    id: str
    game_id: str
    request: str
    state: ResearchState = ResearchState.QUEUED
    evidence_ids: list[str] = field(default_factory=list)
    contradiction_ids: list[str] = field(default_factory=list)
    proposer_complete: bool = False
    verifier_complete: bool = False
    exact_build_current: bool = False
    rollback_proven: bool = False


class ResearchBuilder:
    """Small durable state machine for research-to-promotion handoff."""

    def __init__(self) -> None:
        self.missions: dict[str, ResearchMission] = {}

    def enqueue(self, mission: ResearchMission) -> None:
        if mission.id in self.missions:
            raise ValueError("research mission already exists")
        self.missions[mission.id] = mission

    def transition(self, mission_id: str, state: ResearchState) -> ResearchMission:
        mission = self.missions[mission_id]
        allowed = {
            ResearchState.QUEUED: {ResearchState.RESEARCHING},
            ResearchState.RESEARCHING: {
                ResearchState.PROPOSED,
                ResearchState.QUARANTINED,
            },
            ResearchState.PROPOSED: {
                ResearchState.VERIFYING,
                ResearchState.QUARANTINED,
            },
            ResearchState.VERIFYING: {
                ResearchState.PROMOTED,
                ResearchState.QUARANTINED,
            },
            ResearchState.PROMOTED: {ResearchState.STALE},
            ResearchState.STALE: {ResearchState.RESEARCHING},
            ResearchState.QUARANTINED: {ResearchState.RESEARCHING},
        }
        if state not in allowed.get(mission.state, set()):
            raise ValueError(f"invalid research transition: {mission.state} -> {state}")
        if state == ResearchState.PROPOSED and not mission.proposer_complete:
            raise ValueError("proposal evidence is incomplete")
        if state == ResearchState.PROMOTED and not (
            mission.proposer_complete
            and mission.verifier_complete
            and mission.exact_build_current
            and mission.rollback_proven
            and not mission.contradiction_ids
        ):
            raise ValueError("promotion gates are incomplete")
        mission.state = state
        return mission


@dataclass(frozen=True)
class InventoryRecordIdentity:
    item_id: str
    container: str
    stack_group: str
    slot: tuple[int, int]
    count_type: str
    maximum: int
    shape_fingerprint: str


@dataclass(frozen=True)
class SessionLocator:
    process_identity: str
    build_fingerprint: str
    resolved_address: int
    record: InventoryRecordIdentity


class SessionLocatorCache:
    """Caches a verified pointer result only for one exact process incarnation."""

    def __init__(self) -> None:
        self._entries: dict[str, SessionLocator] = {}

    def store(self, action_id: str, locator: SessionLocator) -> None:
        if not locator.process_identity or not locator.build_fingerprint:
            raise ValueError("process and build identity are required")
        self._entries[action_id] = locator

    def require(
        self,
        action_id: str,
        *,
        process_identity: str,
        build_fingerprint: str,
        record: InventoryRecordIdentity,
    ) -> SessionLocator:
        locator = self._entries.get(action_id)
        if locator is None:
            raise RuntimeError("no session locator; route to structural validation")
        if (
            locator.process_identity != process_identity
            or locator.build_fingerprint != build_fingerprint
        ):
            self._entries.pop(action_id, None)
            raise RuntimeError("stale session locator rejected")
        if locator.record != record:
            raise RuntimeError("record identity mismatch; quarantine action")
        return locator

    def discard_process(self, process_identity: str) -> None:
        self._entries = {
            action_id: locator
            for action_id, locator in self._entries.items()
            if locator.process_identity != process_identity
        }
