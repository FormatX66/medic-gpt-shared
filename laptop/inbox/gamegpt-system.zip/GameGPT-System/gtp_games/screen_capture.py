from __future__ import annotations

import colorsys
import ctypes
import sys
from ctypes import wintypes

from gtp_games.errors import BackendError
from gtp_games.models import HealthBarDetection, HealthBarResult


def capture_and_detect_health_bars(
    session_id: str,
    pid: int,
    *,
    region: tuple[int, int, int, int] | None = None,
    limit: int = 5,
) -> HealthBarResult:
    """Capture only the selected process window and estimate colored health bars."""

    if sys.platform != "win32":
        raise BackendError("game-window capture requires Windows")
    try:
        from PIL import ImageGrab
    except ImportError as exc:  # pragma: no cover - dependency is packaged on Windows
        raise BackendError("game-window capture requires Pillow") from exc

    window, title, bounds = _largest_window_for_pid(pid)
    if not window:
        return HealthBarResult(
            session_id=session_id,
            pid=pid,
            window_title="",
            image_width=1,
            image_height=1,
            capture_status="paused",
            message=(
                "The selected game window is not visible. Learning is waiting for the game "
                "to reopen or become visible."
            ),
        )
    left, top, right, bottom = bounds
    pause_reason = _capture_pause_reason(window, pid)
    if pause_reason is not None:
        return HealthBarResult(
            session_id=session_id,
            pid=pid,
            window_title=title,
            image_width=max(1, right - left),
            image_height=max(1, bottom - top),
            capture_status="paused",
            message=pause_reason,
        )
    image = ImageGrab.grab(bbox=(left, top, right, bottom), all_screens=True).convert("RGB")
    excluded_regions = _overlay_exclusion_regions(bounds)
    detections = detect_health_bars(
        image,
        region=region,
        limit=limit,
        excluded_regions=excluded_regions,
        game_hint=title,
    )
    visible_values = []
    inventory_menu_detected = False
    try:
        from gtp_games.inventory_capture import (
            analyze_inventory_ocr_lines,
            analyze_visible_value_ocr_lines,
            recognize_windows_ocr,
        )

        ocr_lines = recognize_windows_ocr(image)
        visible_values = analyze_visible_value_ocr_lines(
            ocr_lines,
            image_width=image.width,
            image_height=image.height,
        )
        inventory_menu_detected, _, _ = analyze_inventory_ocr_lines(
            ocr_lines,
            image_width=image.width,
            image_height=image.height,
        )
    except Exception:  # noqa: BLE001 - colored HUD learning remains usable without OCR
        visible_values = []
    nms_colored_menu = (
        "no mans sky" in title.casefold().replace("'", "")
        and _looks_like_full_screen_menu(
            detections,
            image_width=image.width,
            image_height=image.height,
        )
    )
    if inventory_menu_detected or nms_colored_menu:
        return HealthBarResult(
            session_id=session_id,
            pid=pid,
            window_title=title,
            image_width=image.width,
            image_height=image.height,
            capture_status="inventory",
            message=(
                "Inventory/menu detected. Gameplay HUD learning is paused while the separate "
                "inventory learner reads visible stacks."
            ),
            excluded_regions=excluded_regions,
        )
    return HealthBarResult(
        session_id=session_id,
        pid=pid,
        window_title=title,
        image_width=image.width,
        image_height=image.height,
        excluded_regions=excluded_regions,
        detections=detections,
        visible_values=visible_values,
    )


def detect_health_bars(
    image,
    *,
    region: tuple[int, int, int, int] | None = None,
    limit: int = 5,
    excluded_regions: list[tuple[int, int, int, int]] | None = None,
    game_hint: str | None = None,
) -> list[HealthBarDetection]:
    """Detect compact colored or bright horizontal meters at multiple UI scales."""

    if not 1 <= limit <= 20:
        raise ValueError("limit must be between 1 and 20")
    rgb = image.convert("RGB")
    for excluded in excluded_regions or []:
        x, y, width, height = _validated_region(excluded, rgb.width, rgb.height)
        rgb.paste((0, 0, 0), (x, y, x + width, y + height))
    if region is not None:
        x, y, width, height = _validated_region(region, rgb.width, rgb.height)
        detection = _measure_bar(rgb.crop((x, y, x + width, y + height)), x=x, y=y)
        detections = [detection] if detection is not None else []
        return _classify_hud_detections(
            detections,
            image_width=rgb.width,
            image_height=rgb.height,
            game_hint=game_hint,
        )

    candidates: list[HealthBarDetection] = []
    minimum_run = max(28, min(90, rgb.width // 80))
    row_step = max(1, rgb.height // 720)
    for y in range(0, rgb.height, row_step):
        run_start: int | None = None
        run_colors: list[str] = []
        for x in range(rgb.width):
            color = _health_color(rgb.getpixel((x, y)))
            if color is not None:
                if run_start is None:
                    run_start = x
                    run_colors = []
                run_colors.append(color)
            elif run_start is not None:
                if x - run_start >= minimum_run:
                    candidates.append(_auto_detection(rgb, run_start, x, y, row_step, run_colors))
                run_start = None
        if run_start is not None and rgb.width - run_start >= minimum_run:
            candidates.append(_auto_detection(rgb, run_start, rgb.width, y, row_step, run_colors))

    deduplicated: list[HealthBarDetection] = []
    for candidate in sorted(candidates, key=lambda item: item.confidence, reverse=True):
        if any(
            abs(candidate.x - existing.x) < 24
            and abs(candidate.y - existing.y) < 24
            and candidate.color == existing.color
            for existing in deduplicated
        ):
            continue
        deduplicated.append(candidate)
        if len(deduplicated) >= limit:
            break
    return _classify_hud_detections(
        deduplicated,
        image_width=rgb.width,
        image_height=rgb.height,
        game_hint=game_hint,
    )


def _validated_region(
    region: tuple[int, int, int, int],
    image_width: int,
    image_height: int,
) -> tuple[int, int, int, int]:
    x, y, width, height = region
    if x < 0 or y < 0 or width <= 0 or height <= 0:
        raise ValueError("health-bar region must have non-negative x/y and positive size")
    if x + width > image_width or y + height > image_height:
        raise ValueError("health-bar region extends outside the game window")
    return x, y, width, height


def _classify_hud_detections(
    detections: list[HealthBarDetection],
    *,
    image_width: int,
    image_height: int,
    game_hint: str | None,
) -> list[HealthBarDetection]:
    zoned = [
        detection.model_copy(
            update={
                "zone": _screen_zone(
                    detection,
                    image_width=image_width,
                    image_height=image_height,
                )
            }
        )
        for detection in detections
    ]
    normalized_hint = (game_hint or "").casefold().replace("'", "")
    if "no mans sky" not in normalized_hint:
        zone_counts: dict[str, int] = {}
        generic: list[HealthBarDetection] = []
        for detection in zoned:
            zone_counts[detection.zone] = zone_counts.get(detection.zone, 0) + 1
            number = zone_counts[detection.zone]
            readable_zone = detection.zone.replace("_", "-")
            generic.append(
                detection.model_copy(
                    update={
                        "hud_target": f"screen meter: {detection.zone} {number}",
                        "hud_label": f"HUD meter {readable_zone} {number}",
                        "classification_reason": (
                            "Generic meter identity uses stable screen geometry; its name "
                            "remains provisional until game-specific evidence identifies it."
                        ),
                    }
                )
            )
        return generic

    top_left = sorted(
        (item for item in zoned if item.zone == "top_left"),
        key=lambda item: item.y,
    )
    bottom_left = sorted(
        (item for item in zoned if item.zone == "bottom_left"),
        key=lambda item: item.y,
    )
    updates: dict[tuple[int, int, int, int], dict[str, str]] = {}
    if len(top_left) >= 2:
        shield = top_left[0]
        health = top_left[-1]
        updates[_detection_key(shield)] = {
            "hud_target": "shield",
            "hud_label": "Exosuit shield",
            "classification_reason": "Upper meter in the No Man's Sky top-left survival group.",
        }
        updates[_detection_key(health)] = {
            "hud_target": "health",
            "hud_label": "Core health",
            "classification_reason": "Lower meter in the No Man's Sky top-left survival group.",
        }
    elif top_left:
        candidate = top_left[0]
        is_health = candidate.color == "red"
        updates[_detection_key(candidate)] = {
            "hud_target": "health" if is_health else "shield",
            "hud_label": "Core health" if is_health else "Exosuit shield",
            "classification_reason": (
                "Red meter in the No Man's Sky top-left survival area."
                if is_health
                else "No Man's Sky upper-left shield area."
            ),
        }
    if len(bottom_left) >= 2:
        hazard = bottom_left[0]
        life_support = bottom_left[-1]
        updates[_detection_key(hazard)] = {
            "hud_target": "hazard protection",
            "hud_label": "Hazard protection",
            "classification_reason": "Upper meter in No Man's Sky lower-left survival group.",
        }
        updates[_detection_key(life_support)] = {
            "hud_target": "life support",
            "hud_label": "Life support",
            "classification_reason": "Lower meter in No Man's Sky lower-left survival group.",
        }
    elif bottom_left:
        candidate = bottom_left[0]
        if candidate.y + candidate.height / 2 < image_height * 0.82:
            updates[_detection_key(candidate)] = {
                "hud_target": "hazard protection",
                "hud_label": "Hazard protection",
                "classification_reason": "No Man's Sky lower-left hazard area.",
            }
        else:
            updates[_detection_key(candidate)] = {
                "hud_target": "life support",
                "hud_label": "Life support",
                "classification_reason": "No Man's Sky bottom-left life-support area.",
            }
    bottom_right = sorted(
        (item for item in zoned if item.zone == "bottom_right"),
        key=lambda item: item.y,
    )
    if bottom_right:
        jetpack = bottom_right[-1]
        updates[_detection_key(jetpack)] = {
            "hud_target": "jetpack",
            "hud_label": "Jetpack charge",
            "classification_reason": "No Man's Sky lower-right temporary charge meter.",
        }
        if len(bottom_right) >= 2:
            stamina = bottom_right[0]
            updates[_detection_key(stamina)] = {
                "hud_target": "stamina",
                "hud_label": "Sprint stamina",
                "classification_reason": "Upper temporary meter in the lower-right HUD group.",
            }

    classified: list[HealthBarDetection] = []
    zone_counts: dict[str, int] = {}
    for detection in zoned:
        update = updates.get(_detection_key(detection))
        if update is None:
            zone_counts[detection.zone] = zone_counts.get(detection.zone, 0) + 1
            number = zone_counts[detection.zone]
            readable_zone = detection.zone.replace("_", "-")
            update = {
                "hud_target": f"screen meter: {detection.zone} {number}",
                "hud_label": f"HUD meter {readable_zone} {number}",
                "classification_reason": (
                    "Generic meter identity uses stable screen geometry; its game-specific "
                    "name remains provisional until correlated evidence identifies it."
                ),
            }
        classified.append(detection.model_copy(update=update))
    return classified


def _screen_zone(
    detection: HealthBarDetection,
    *,
    image_width: int,
    image_height: int,
) -> str:
    center_x = (detection.x + detection.width / 2) / max(1, image_width)
    center_y = (detection.y + detection.height / 2) / max(1, image_height)
    horizontal = "left" if center_x < 0.4 else "right" if center_x > 0.6 else "center"
    vertical = "top" if center_y < 0.4 else "bottom" if center_y > 0.6 else "middle"
    return f"{vertical}_{horizontal}"


def _detection_key(detection: HealthBarDetection) -> tuple[int, int, int, int]:
    return detection.x, detection.y, detection.width, detection.height


def _measure_bar(image, *, x: int, y: int) -> HealthBarDetection | None:
    active_columns: list[int] = []
    color_counts: dict[str, int] = {}
    threshold = max(1, image.height // 5)
    for column in range(image.width):
        hits = 0
        for row in range(image.height):
            color = _health_color(image.getpixel((column, row)))
            if color is None:
                continue
            hits += 1
            color_counts[color] = color_counts.get(color, 0) + 1
        if hits >= threshold:
            active_columns.append(column)
    if not active_columns:
        return None
    first = min(active_columns)
    last = max(active_columns)
    filled_width = last - first + 1
    percent = max(0.0, min(100.0, filled_width * 100 / image.width))
    starts_near_left = 1.0 - min(1.0, first / max(1, image.width * 0.2))
    density = min(1.0, len(active_columns) / max(1, filled_width))
    confidence = max(0.0, min(1.0, 0.45 + 0.3 * starts_near_left + 0.25 * density))
    color = max(color_counts, key=color_counts.get)
    return HealthBarDetection(
        x=x,
        y=y,
        width=image.width,
        filled_width=filled_width,
        height=image.height,
        percent=percent,
        confidence=confidence,
        color=color,
    )


def _auto_detection(image, start: int, end: int, y: int, height: int, colors: list[str]):
    color = max(set(colors), key=colors.count)
    filled_width = end - start
    container_end = end
    dark_budget = min(image.width - end, max(40, filled_width))
    background = image.getpixel((max(0, start - 3), y))
    background_luma = sum(background) / 3
    for x in range(end, end + dark_budget):
        red, green, blue = image.getpixel((x, y))
        luma = (red + green + blue) / 3
        if max(red, green, blue) <= 120 and abs(luma - background_luma) >= 7:
            container_end = x + 1
            continue
        break
    container_width = max(filled_width, container_end - start)
    percent = max(0.0, min(100.0, filled_width * 100 / container_width))
    aspect = filled_width / max(1, height)
    edge_bonus = 0.1 if y < image.height * 0.3 or y > image.height * 0.7 else 0.0
    confidence = min(0.9, 0.35 + min(0.35, aspect / 40) + edge_bonus)
    return HealthBarDetection(
        x=start,
        y=y,
        width=container_width,
        filled_width=filled_width,
        height=max(2, height),
        percent=percent,
        confidence=confidence,
        color=color,
    )


def _health_color(pixel: tuple[int, int, int]) -> str | None:
    red, green, blue = pixel
    hue, saturation, value = colorsys.rgb_to_hsv(red / 255, green / 255, blue / 255)
    if value < 0.18 or value > 0.995:
        return None
    if saturation < 0.24:
        return "white" if value >= 0.55 else None
    if saturation < 0.38:
        return None
    degrees = hue * 360
    if degrees < 25 or degrees >= 335:
        return "red"
    if 35 <= degrees < 75:
        return "yellow"
    if 75 <= degrees < 170:
        return "green"
    if 170 <= degrees < 260:
        return "blue"
    return None


def _capture_pause_reason(window: int, pid: int) -> str | None:
    user32 = ctypes.WinDLL("user32", use_last_error=True)
    if user32.IsIconic(window):
        return "Bring the selected game out of the taskbar so HUD learning can see it."
    foreground = int(user32.GetForegroundWindow())
    foreground_pid = wintypes.DWORD()
    if foreground:
        user32.GetWindowThreadProcessId(foreground, ctypes.byref(foreground_pid))
    return _foreground_capture_pause_reason(
        game_pid=pid,
        foreground_pid=int(foreground_pid.value),
    )


def _foreground_capture_pause_reason(*, game_pid: int, foreground_pid: int) -> str | None:
    if foreground_pid == game_pid:
        return None
    return "Bring the selected game to the front; other windows are never used for HUD learning."


def _looks_like_full_screen_menu(
    detections: list[HealthBarDetection],
    *,
    image_width: int,
    image_height: int,
) -> bool:
    """Reject NMS inventory/menu chrome before any colored line reaches learning."""

    return any(
        detection.y < image_height * 0.25 and detection.width > image_width * 0.55
        for detection in detections
    )


def _overlay_exclusion_regions(
    game_bounds: tuple[int, int, int, int],
) -> list[tuple[int, int, int, int]]:
    regions: list[tuple[int, int, int, int]] = []
    for overlay_bounds in _visible_window_bounds("GTP Games Overlay"):
        relative = _relative_intersection(game_bounds, overlay_bounds, padding=12)
        if relative is not None:
            regions.append(relative)
    return regions


def _relative_intersection(
    outer: tuple[int, int, int, int],
    inner: tuple[int, int, int, int],
    *,
    padding: int = 0,
) -> tuple[int, int, int, int] | None:
    outer_left, outer_top, outer_right, outer_bottom = outer
    inner_left, inner_top, inner_right, inner_bottom = inner
    left = max(outer_left, inner_left - padding)
    top = max(outer_top, inner_top - padding)
    right = min(outer_right, inner_right + padding)
    bottom = min(outer_bottom, inner_bottom + padding)
    if right <= left or bottom <= top:
        return None
    return left - outer_left, top - outer_top, right - left, bottom - top


def _visible_window_bounds(title: str) -> list[tuple[int, int, int, int]]:
    user32 = ctypes.WinDLL("user32", use_last_error=True)

    class RECT(ctypes.Structure):
        _fields_ = [
            ("left", wintypes.LONG),
            ("top", wintypes.LONG),
            ("right", wintypes.LONG),
            ("bottom", wintypes.LONG),
        ]

    matches: list[tuple[int, int, int, int]] = []
    callback_type = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)

    def visit(window, _parameter) -> bool:
        if not user32.IsWindowVisible(window):
            return True
        length = user32.GetWindowTextLengthW(window)
        if length <= 0:
            return True
        title_buffer = ctypes.create_unicode_buffer(length + 1)
        user32.GetWindowTextW(window, title_buffer, len(title_buffer))
        if title_buffer.value != title:
            return True
        rect = RECT()
        if user32.GetWindowRect(window, ctypes.byref(rect)):
            matches.append(
                (int(rect.left), int(rect.top), int(rect.right), int(rect.bottom))
            )
        return True

    callback = callback_type(visit)
    user32.EnumWindows(callback, 0)
    return matches


def _largest_window_for_pid(pid: int) -> tuple[int, str, tuple[int, int, int, int]]:
    user32 = ctypes.WinDLL("user32", use_last_error=True)

    class RECT(ctypes.Structure):
        _fields_ = [
            ("left", wintypes.LONG),
            ("top", wintypes.LONG),
            ("right", wintypes.LONG),
            ("bottom", wintypes.LONG),
        ]

    candidates: list[tuple[int, int, str, tuple[int, int, int, int]]] = []
    callback_type = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)

    def visit(window, _parameter) -> bool:
        if not user32.IsWindowVisible(window) or user32.GetWindowTextLengthW(window) <= 0:
            return True
        process_id = wintypes.DWORD()
        user32.GetWindowThreadProcessId(window, ctypes.byref(process_id))
        if int(process_id.value) != pid:
            return True
        rect = RECT()
        if not user32.GetWindowRect(window, ctypes.byref(rect)):
            return True
        width = max(0, int(rect.right - rect.left))
        height = max(0, int(rect.bottom - rect.top))
        if width < 100 or height < 100:
            return True
        title_buffer = ctypes.create_unicode_buffer(user32.GetWindowTextLengthW(window) + 1)
        user32.GetWindowTextW(window, title_buffer, len(title_buffer))
        candidates.append(
            (
                width * height,
                int(window),
                title_buffer.value,
                (int(rect.left), int(rect.top), int(rect.right), int(rect.bottom)),
            )
        )
        return True

    callback = callback_type(visit)
    user32.EnumWindows(callback, 0)
    if not candidates:
        return 0, "", (0, 0, 0, 0)
    _, window, title, bounds = max(candidates)
    return window, title, bounds
