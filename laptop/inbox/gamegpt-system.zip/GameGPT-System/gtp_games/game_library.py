from __future__ import annotations

import hashlib
import json
import os
import re
from collections.abc import Iterable
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path

from gtp_games.models import PortableGameValueTable, ProcessInfo


@dataclass(frozen=True)
class GameTableChoice:
    path: str
    game_key: str
    process_name: str
    game_build_identity: str | None
    confirmed_count: int
    candidate_count: int

    @property
    def feature_count(self) -> int:
        return self.confirmed_count + self.candidate_count


@dataclass
class DiscoveredGame:
    id: str
    game_key: str
    name: str
    launcher: str
    install_path: str | None = None
    launch_target: str | None = None
    executable_names: list[str] = field(default_factory=list)
    running_pids: list[int] = field(default_factory=list)
    tables: list[GameTableChoice] = field(default_factory=list)
    last_played_at: datetime | None = None

    @property
    def status(self) -> str:
        if self.running_pids:
            return "Playing now"
        if self.install_path or self.launch_target:
            return "Installed"
        if self.tables:
            return "Saved table only"
        return "Known game"


@dataclass(frozen=True)
class GameLibrarySnapshot:
    games: list[DiscoveredGame]
    scanned_sources: list[str]
    warnings: list[str]


def discover_game_library(
    processes: Iterable[ProcessInfo],
    *,
    table_roots: Iterable[Path],
    history: dict[str, str] | None = None,
    steam_roots: Iterable[Path] | None = None,
    epic_manifest_roots: Iterable[Path] | None = None,
) -> GameLibrarySnapshot:
    """Build one local catalog from launchers, running games, and saved GTP tables."""

    warnings: list[str] = []
    sources: list[str] = []
    games: list[DiscoveredGame] = []

    resolved_steam_roots = list(steam_roots or _windows_steam_roots())
    if resolved_steam_roots:
        sources.append("Steam")
    for candidate in discover_steam_games(resolved_steam_roots, warnings=warnings):
        _merge_game(games, candidate)

    resolved_epic_roots = list(epic_manifest_roots or _windows_epic_manifest_roots())
    if resolved_epic_roots:
        sources.append("Epic Games")
    for candidate in discover_epic_games(resolved_epic_roots, warnings=warnings):
        _merge_game(games, candidate)

    gog_games = discover_gog_games(warnings=warnings)
    if gog_games:
        sources.append("GOG")
    for candidate in gog_games:
        _merge_game(games, candidate)

    tables = discover_portable_tables(table_roots, warnings=warnings)
    if tables:
        sources.append("GTP tables")
    for table in tables:
        game = _find_game_for_table(games, table)
        if game is None:
            name = _friendly_name(table.process_name, table.game_key)
            game = DiscoveredGame(
                id=_game_id(table.game_key),
                game_key=table.game_key,
                name=name,
                launcher="Saved table",
                executable_names=[table.process_name],
            )
            games.append(game)
        if table not in game.tables:
            game.tables.append(table)
        _append_unique(game.executable_names, table.process_name)

    live_processes = [
        process
        for process in processes
        if process.attachable and (process.likely_game or _matches_any_game(process, games))
    ]
    if live_processes:
        sources.append("Running games")
    for process in live_processes:
        game = _find_game_for_process(games, process)
        if game is None:
            game_key = normalize_game_key(process.name)
            game = DiscoveredGame(
                id=_game_id(game_key),
                game_key=game_key,
                name=_friendly_name(process.name, game_key),
                launcher="Running game",
                install_path=_parent_directory(process.executable),
                executable_names=[process.name],
            )
            games.append(game)
        _append_unique(game.running_pids, process.pid)
        _append_unique(game.executable_names, process.name)

    _consolidate_saved_table_aliases(games)

    for game in games:
        game.tables = _deduplicate_table_choices(game)
        game.tables.sort(
            key=lambda table: (
                -table.confirmed_count,
                -table.candidate_count,
                table.game_build_identity or "",
            )
        )
        if history:
            game.last_played_at = _parse_history_time(history.get(game.id))

    games.sort(
        key=lambda game: (
            0 if game.running_pids else 1,
            -(game.last_played_at.timestamp() if game.last_played_at else 0),
            game.name.casefold(),
        )
    )
    return GameLibrarySnapshot(
        games=games,
        scanned_sources=list(dict.fromkeys(sources)),
        warnings=warnings[:20],
    )


def discover_portable_tables(
    roots: Iterable[Path],
    *,
    warnings: list[str] | None = None,
) -> list[GameTableChoice]:
    results: list[GameTableChoice] = []
    seen: set[str] = set()
    for root in roots:
        try:
            resolved = root.expanduser().resolve()
        except OSError:
            continue
        if not resolved.is_dir():
            continue
        try:
            paths = sorted(resolved.rglob("*.gtp-table.json"))[:1000]
        except OSError as exc:
            if warnings is not None:
                warnings.append(f"Could not inspect table folder {resolved}: {exc}")
            continue
        for path in paths:
            normalized_path = os.path.normcase(str(path.resolve()))
            if normalized_path in seen:
                continue
            seen.add(normalized_path)
            try:
                table = PortableGameValueTable.model_validate_json(path.read_text(encoding="utf-8"))
                if (
                    table.contains_raw_addresses
                    or table.contains_executable_scripts
                    or table.contains_machine_paths
                ):
                    raise ValueError("portable safety flags are not clear")
            except (OSError, ValueError) as exc:
                if warnings is not None:
                    warnings.append(f"Skipped invalid portable table {path.name}: {exc}")
                continue
            results.append(
                GameTableChoice(
                    path=str(path.resolve()),
                    game_key=table.game_key,
                    process_name=table.process_name,
                    game_build_identity=table.game_build_identity,
                    confirmed_count=len(table.confirmed_features),
                    candidate_count=len(table.candidate_features),
                )
            )
    return results


def discover_steam_games(
    steam_roots: Iterable[Path],
    *,
    warnings: list[str] | None = None,
) -> list[DiscoveredGame]:
    libraries: list[Path] = []
    for root in steam_roots:
        root = root.expanduser()
        _append_unique_path(libraries, root)
        library_file = root / "steamapps" / "libraryfolders.vdf"
        try:
            text = library_file.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        for value in re.findall(r'"path"\s+"([^"]+)"', text, flags=re.IGNORECASE):
            _append_unique_path(libraries, Path(value.replace("\\\\", "\\")))

    games: list[DiscoveredGame] = []
    seen_apps: set[str] = set()
    for library in libraries:
        manifest_root = library / "steamapps"
        try:
            manifests = sorted(manifest_root.glob("appmanifest_*.acf"))
        except OSError:
            continue
        for manifest in manifests:
            try:
                text = manifest.read_text(encoding="utf-8", errors="replace")
                app_id = _vdf_value(text, "appid") or manifest.stem.removeprefix("appmanifest_")
                name = _vdf_value(text, "name")
                install_dir = _vdf_value(text, "installdir")
                if (
                    not name
                    or not install_dir
                    or app_id in seen_apps
                    or _is_steam_support_tool(name)
                ):
                    continue
                seen_apps.add(app_id)
                game_key = normalize_game_key(name)
                games.append(
                    DiscoveredGame(
                        id=_game_id(game_key),
                        game_key=game_key,
                        name=name,
                        launcher="Steam",
                        install_path=str((manifest_root / "common" / install_dir).resolve()),
                        launch_target=f"steam://rungameid/{app_id}",
                    )
                )
            except OSError as exc:
                if warnings is not None:
                    warnings.append(f"Could not read {manifest.name}: {exc}")
    return games


def discover_epic_games(
    manifest_roots: Iterable[Path],
    *,
    warnings: list[str] | None = None,
) -> list[DiscoveredGame]:
    games: list[DiscoveredGame] = []
    seen: set[str] = set()
    for root in manifest_roots:
        if not root.is_dir():
            continue
        try:
            manifests = sorted(root.glob("*.item"))
        except OSError:
            continue
        for path in manifests:
            try:
                payload = json.loads(path.read_text(encoding="utf-8"))
                name = str(payload.get("DisplayName") or "").strip()
                install_path = str(payload.get("InstallLocation") or "").strip()
                app_name = str(
                    payload.get("AppName") or payload.get("CatalogItemId") or path.stem
                ).strip()
                launch_executable = str(payload.get("LaunchExecutable") or "").strip()
                if not name or not app_name or app_name.casefold() in seen:
                    continue
                seen.add(app_name.casefold())
                executable_names = [Path(launch_executable).name] if launch_executable else []
                game_key = normalize_game_key(name)
                games.append(
                    DiscoveredGame(
                        id=_game_id(game_key),
                        game_key=game_key,
                        name=name,
                        launcher="Epic Games",
                        install_path=install_path or None,
                        launch_target=(
                            f"com.epicgames.launcher://apps/{app_name}?action=launch&silent=true"
                        ),
                        executable_names=executable_names,
                    )
                )
            except (OSError, ValueError, TypeError) as exc:
                if warnings is not None:
                    warnings.append(f"Could not read {path.name}: {exc}")
    return games


def discover_gog_games(*, warnings: list[str] | None = None) -> list[DiscoveredGame]:
    if os.name != "nt":
        return []
    try:
        import winreg
    except ImportError:
        return []
    games: list[DiscoveredGame] = []
    registry_paths = (
        r"SOFTWARE\GOG.com\Games",
        r"SOFTWARE\WOW6432Node\GOG.com\Games",
    )
    for hive in (winreg.HKEY_LOCAL_MACHINE, winreg.HKEY_CURRENT_USER):
        for registry_path in registry_paths:
            try:
                root = winreg.OpenKey(hive, registry_path)
            except OSError:
                continue
            with root:
                index = 0
                while True:
                    try:
                        game_id = winreg.EnumKey(root, index)
                    except OSError:
                        break
                    index += 1
                    try:
                        with winreg.OpenKey(root, game_id) as key:
                            name = _registry_value(winreg, key, "gameName")
                            install_path = _registry_value(winreg, key, "path")
                            executable = _registry_value(winreg, key, "exe")
                    except OSError as exc:
                        if warnings is not None:
                            warnings.append(f"Could not read one GOG game entry: {exc}")
                        continue
                    if not name:
                        continue
                    game_key = normalize_game_key(name)
                    games.append(
                        DiscoveredGame(
                            id=_game_id(game_key),
                            game_key=game_key,
                            name=name,
                            launcher="GOG",
                            install_path=install_path or None,
                            launch_target=executable or None,
                            executable_names=[Path(executable).name] if executable else [],
                        )
                    )
    return games


def normalize_game_key(value: str) -> str:
    basename = Path(value.replace("\\", "/")).name.casefold()
    basename = re.sub(r"\.exe$", "", basename)
    basename = re.sub(r"(?:-win64-shipping|_win64_shipping|win64shipping)$", "", basename)
    normalized = re.sub(r"[^a-z0-9]+", "-", basename).strip("-")
    return normalized or "unknown-game"


def canonical_game_identity(value: str) -> str:
    return re.sub(r"[^a-z0-9]+", "", normalize_game_key(value))


def _merge_game(games: list[DiscoveredGame], candidate: DiscoveredGame) -> None:
    existing = _find_game(games, candidate)
    if existing is None:
        games.append(candidate)
        return
    if existing.launcher in {"Saved table", "Running game"}:
        existing.launcher = candidate.launcher
    existing.install_path = existing.install_path or candidate.install_path
    existing.launch_target = existing.launch_target or candidate.launch_target
    if candidate.name and existing.launcher != "Saved table":
        existing.name = candidate.name
    for name in candidate.executable_names:
        _append_unique(existing.executable_names, name)


def _find_game(games: list[DiscoveredGame], candidate: DiscoveredGame) -> DiscoveredGame | None:
    candidate_identity = canonical_game_identity(candidate.game_key or candidate.name)
    candidate_path = _normalized_path(candidate.install_path)
    for game in games:
        if candidate_path and candidate_path == _normalized_path(game.install_path):
            return game
        identities = {
            canonical_game_identity(game.game_key),
            canonical_game_identity(game.name),
            *(canonical_game_identity(name) for name in game.executable_names),
        }
        if candidate_identity and candidate_identity in identities:
            return game
    return None


def _find_game_for_table(
    games: list[DiscoveredGame], table: GameTableChoice
) -> DiscoveredGame | None:
    identities = {
        canonical_game_identity(table.game_key),
        canonical_game_identity(table.process_name),
    }
    for game in games:
        game_identities = {
            canonical_game_identity(game.game_key),
            canonical_game_identity(game.name),
            *(canonical_game_identity(name) for name in game.executable_names),
        }
        if identities & game_identities:
            return game
    process_identity = canonical_game_identity(table.process_name)
    abbreviation_matches = [
        game
        for game in games
        if game.launcher != "Saved table"
        and process_identity
        and process_identity == _abbreviation_identity(game.name)
    ]
    if len(abbreviation_matches) == 1:
        return abbreviation_matches[0]
    return None


def _find_game_for_process(
    games: list[DiscoveredGame], process: ProcessInfo
) -> DiscoveredGame | None:
    executable = _normalized_path(process.executable)
    process_identity = canonical_game_identity(process.name)
    for game in games:
        install_path = _normalized_path(game.install_path)
        if executable and install_path and _path_is_within(executable, install_path):
            return game
        identities = {
            canonical_game_identity(game.game_key),
            canonical_game_identity(game.name),
            *(canonical_game_identity(name) for name in game.executable_names),
        }
        if process_identity in identities:
            return game
    return None


def _matches_any_game(process: ProcessInfo, games: list[DiscoveredGame]) -> bool:
    return _find_game_for_process(games, process) is not None


def _consolidate_saved_table_aliases(games: list[DiscoveredGame]) -> None:
    """Fold table-only aliases into a launcher game once a live process proves identity."""

    for source in list(games):
        if source.launcher != "Saved table":
            continue
        source_identities = {
            canonical_game_identity(source.game_key),
            *(canonical_game_identity(name) for name in source.executable_names),
        }
        target = next(
            (
                game
                for game in games
                if game is not source
                and game.launcher != "Saved table"
                and source_identities
                & {
                    canonical_game_identity(game.game_key),
                    canonical_game_identity(game.name),
                    *(canonical_game_identity(name) for name in game.executable_names),
                }
            ),
            None,
        )
        if target is None:
            continue
        for table in source.tables:
            if table not in target.tables:
                target.tables.append(table)
        for name in source.executable_names:
            _append_unique(target.executable_names, name)
        games.remove(source)


def _abbreviation_identity(value: str) -> str:
    without_possessives = re.sub(r"[\'’]s\b", "", value.casefold())
    words = re.findall(r"[a-z0-9]+", without_possessives)
    return "".join(word[0] for word in words) if len(words) > 1 else ""


def _deduplicate_table_choices(game: DiscoveredGame) -> list[GameTableChoice]:
    selected: dict[tuple[str, str], GameTableChoice] = {}
    game_identity = canonical_game_identity(game.game_key)
    for table in game.tables:
        key = (table.process_name.casefold(), table.game_build_identity or "unknown-build")
        current = selected.get(key)
        if current is None:
            selected[key] = table
            continue
        table_rank = (
            canonical_game_identity(table.game_key) == game_identity,
            table.feature_count,
        )
        current_rank = (
            canonical_game_identity(current.game_key) == game_identity,
            current.feature_count,
        )
        if table_rank > current_rank:
            selected[key] = table
    return list(selected.values())


def _game_id(game_key: str) -> str:
    identity = canonical_game_identity(game_key)
    if identity:
        return f"game-{identity}"
    return "game-" + hashlib.sha256(game_key.encode()).hexdigest()[:16]


def _friendly_name(process_name: str, fallback: str) -> str:
    stem = Path(process_name).stem
    stem = re.sub(r"(?:-Win64-Shipping|_Win64_Shipping)$", "", stem, flags=re.I)
    words = re.sub(r"(?<=[a-z])(?=[A-Z])|[_-]+", " ", stem).strip()
    return words or fallback.replace("-", " ").title()


def _vdf_value(text: str, key: str) -> str | None:
    match = re.search(
        rf'"{re.escape(key)}"\s+"([^"]*)"',
        text,
        flags=re.IGNORECASE,
    )
    return match.group(1) if match else None


def _is_steam_support_tool(name: str) -> bool:
    normalized = name.casefold().strip()
    return (
        normalized
        in {
            "steamworks common redistributables",
            "geck - new vegas edition",
        }
        or "dedicated server" in normalized
        or normalized.endswith((" sdk", " development kit"))
    )


def _windows_steam_roots() -> list[Path]:
    roots: list[Path] = []
    if os.name != "nt":
        return roots
    try:
        import winreg
    except ImportError:
        return roots
    for hive, registry_path in (
        (winreg.HKEY_CURRENT_USER, r"SOFTWARE\Valve\Steam"),
        (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\WOW6432Node\Valve\Steam"),
    ):
        try:
            with winreg.OpenKey(hive, registry_path) as key:
                for value_name in ("SteamPath", "InstallPath"):
                    try:
                        value, _kind = winreg.QueryValueEx(key, value_name)
                    except OSError:
                        continue
                    _append_unique_path(roots, Path(str(value)))
        except OSError:
            continue
    return roots


def _windows_epic_manifest_roots() -> list[Path]:
    program_data = os.getenv("PROGRAMDATA", "").strip()
    if not program_data:
        return []
    return [Path(program_data) / "Epic" / "EpicGamesLauncher" / "Data" / "Manifests"]


def _registry_value(winreg, key, name: str) -> str:
    try:
        value, _kind = winreg.QueryValueEx(key, name)
    except OSError:
        return ""
    return str(value).strip()


def _parse_history_time(value: str | None) -> datetime | None:
    if not value:
        return None
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None


def _parent_directory(executable: str | None) -> str | None:
    return str(Path(executable).parent) if executable else None


def _normalized_path(value: str | None) -> str:
    if not value:
        return ""
    return os.path.normcase(os.path.abspath(value)).rstrip("\\/")


def _path_is_within(path: str, parent: str) -> bool:
    try:
        return os.path.commonpath((path, parent)) == parent
    except ValueError:
        return False


def _append_unique(values: list, value) -> None:
    if value not in values:
        values.append(value)


def _append_unique_path(values: list[Path], value: Path) -> None:
    normalized = os.path.normcase(str(value.expanduser().resolve()))
    if all(os.path.normcase(str(item.expanduser().resolve())) != normalized for item in values):
        values.append(value)
