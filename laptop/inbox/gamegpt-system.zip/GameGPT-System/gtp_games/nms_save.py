from __future__ import annotations

import hashlib
import json
import os
import re
import struct
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path

from gtp_games.errors import SafetyError
from gtp_games.models import (
    NmsSaveComparisonReport,
    NmsSaveFieldChange,
    NmsSaveSnapshotInfo,
)

_CHUNK_MAGIC = 0xFEEDA1E5
_CHUNK_HEADER = struct.Struct("<4I")
_MAX_COMPRESSED_CHUNK = 16 * 1024 * 1024
_MAX_DECOMPRESSED_CHUNK = 8 * 1024 * 1024
_MAX_DECOMPRESSED_SAVE = 32 * 1024 * 1024
_SAVE_NAME = re.compile(r"save\d+\.hg", re.IGNORECASE)
_ANY_SAVE_NAME = re.compile(r"save\d*\.hg", re.IGNORECASE)
_MAX_SAVE_DIFF_FIELDS = 100_000
_MAX_SAVE_DIFF_DEPTH = 64
_MAX_INVENTORY_NODES = 250_000
_MAX_INVENTORY_STACKS = 10_000
_CURRENCY_KEYS = {
    "Units": (b"wGS", b"Units"),
    "Nanites": (b"7QL", b"Nanites"),
    "Quicksilver": (b"kN;", b"Specials", b"Quicksilver"),
}
_INVENTORY_KEYS = {
    "slots": ("Slots", ":No"),
    "type": ("Type", "Vn8"),
    "inventory_type": ("InventoryType", "elv"),
    "special_slot_type": ("InventorySpecialSlotType", "QA1"),
    "item_id": ("Id", "b2n"),
    "amount": ("Amount", "1o9"),
    "max_amount": ("MaxAmount", "F9q"),
    "index": ("Index", "3ZH"),
    "x": ("X", ">Qh"),
    "y": ("Y", "XJ>"),
    "valid_slots": ("ValidSlotIndices", "hl?"),
    "stack_group": ("StackSizeGroup", "WA4"),
    "stack_group_value": ("InventoryStackSizeGroup", "rri"),
    "width": ("Width", "=Tb"),
    "height": ("Height", "N9>"),
    "substance_multiplier": ("SubstanceMaxStorageMultiplier", "0H2"),
    "product_multiplier": ("ProductMaxStorageMultiplier", "cTY"),
}
_INVENTORY_PATH_NAMES = {
    "6f=": "PlayerStateData",
    ";l5": "Inventory",
    "PMT": "Inventory_TechOnly",
    "gan": "Inventory_Cargo",
    "6<E": "ShipInventory",
    "Kgt": "WeaponInventory",
    "4eu": "GraveInventory",
    "8ZP": "FreighterInventory",
    "0wS": "FreighterInventory_TechOnly",
    "FdP": "FreighterInventory_Cargo",
    "P;m": "VehicleOwnership",
    "3Nc": "Chest1Inventory",
    "IDc": "Chest2Inventory",
    "M=:": "Chest3Inventory",
    "iYp": "Chest4Inventory",
    "<IP": "Chest5Inventory",
    "qYJ": "Chest6Inventory",
    "@e5": "Chest7Inventory",
    "5uh": "Chest8Inventory",
    "5Tg": "Chest9Inventory",
    "Bq<": "Chest10Inventory",
    ";?C": "ChestMagicInventory",
    "fCh": "ChestMagic2Inventory",
    "Kha": "CookingIngredientsInventory",
    "V86": "RocketLockerInventory",
    "Pug": "SeasonTransferInventory",
    "KQ<": "FishPlatformInventory",
    "rBK": "FishBaitBoxInventory",
    "nHK": "FoodUnitInventory",
    "wem": "CorvetteStorageInventory",
    "FA8": "VehicleCargo",
}
_INVENTORY_TRAVERSAL_SKIP_KEYS = frozenset(
    key for alias in ("slots", "valid_slots") for key in _INVENTORY_KEYS[alias]
)


@dataclass(frozen=True)
class NmsCurrencySnapshot:
    values: dict[str, int]
    save_path: Path
    modified_at: datetime


@dataclass(frozen=True)
class NmsInventoryStack:
    container_path: str
    container_name: str
    container_kind: str
    stack_size_group: str | None
    valid_slot_count: int
    width: int | None
    height: int | None
    substance_storage_multiplier: int | float | None
    product_storage_multiplier: int | float | None
    item_type: str
    item_id: str
    amount: int
    max_amount: int
    index_x: int
    index_y: int
    slot_ordinal: int | None = None


@dataclass(frozen=True)
class NmsInventorySnapshot:
    stacks: tuple[NmsInventoryStack, ...]
    save_path: Path
    modified_at: datetime
    visited_nodes: int
    truncated: bool = False


def newest_save(root: Path | None = None) -> Path | None:
    """Return the newest numbered NMS save without reading or changing it."""

    base = root or _default_save_root()
    if base is None or not base.is_dir():
        return None
    candidates = [
        path
        for profile in base.glob("st_*")
        if profile.is_dir()
        for path in profile.iterdir()
        if path.is_file() and _SAVE_NAME.fullmatch(path.name)
    ]
    return max(candidates, key=lambda path: path.stat().st_mtime, default=None)


def read_currency_snapshot(root: Path | None = None) -> NmsCurrencySnapshot | None:
    """Read exact currencies from the newest local NMS save, never writing it."""

    path = newest_save(root)
    if path is None:
        return None
    payload = decompress_save(path.read_bytes())
    values: dict[str, int] = {}
    for name, keys in _CURRENCY_KEYS.items():
        value = _find_integer(payload, keys)
        if value is not None:
            values[name] = value
    if not values:
        return None
    return NmsCurrencySnapshot(
        values=values,
        save_path=path,
        modified_at=datetime.fromtimestamp(path.stat().st_mtime, UTC),
    )


def read_inventory_snapshot(root: Path | None = None) -> NmsInventorySnapshot | None:
    """Read bounded slot semantics from the newest local NMS save without changing it."""

    path = newest_save(root)
    if path is None:
        return None
    payload = decompress_save(path.read_bytes())
    root_value = _decode_save_json(payload)
    stacks, visited_nodes, truncated = _inventory_stacks(root_value)
    return NmsInventorySnapshot(
        stacks=tuple(stacks),
        save_path=path,
        modified_at=datetime.fromtimestamp(path.stat().st_mtime, UTC),
        visited_nodes=visited_nodes,
        truncated=truncated,
    )


def compare_save_files(
    root: Path | None = None,
    *,
    older_filename: str | None = None,
    newer_filename: str | None = None,
    limit: int = 250,
) -> NmsSaveComparisonReport:
    """Compare two local NMS saves without changing or copying either original file."""

    if not 1 <= limit <= 2_000:
        raise SafetyError("the NMS save comparison limit must be between 1 and 2000")
    base = root or _default_save_root()
    if base is None or not base.is_dir():
        raise SafetyError("the local NMS save directory was not found")
    base = base.resolve()
    candidates = _save_candidates(base)
    if len(candidates) < 2:
        raise SafetyError("at least two local NMS save files are required")

    newer = _select_save(candidates, newer_filename, newest=True)
    older_pool = [path for path in candidates if path != newer]
    older = _select_save(older_pool, older_filename, newest=True)
    if older.stat().st_mtime > newer.stat().st_mtime:
        older, newer = newer, older

    older_payload = decompress_save(older.read_bytes())
    newer_payload = decompress_save(newer.read_bytes())
    older_json = _decode_save_json(older_payload)
    newer_json = _decode_save_json(newer_payload)
    changes: list[NmsSaveFieldChange] = []
    truncated = _collect_changes(older_json, newer_json, "$", changes, depth=0)

    currency_changes: dict[str, int] = {}
    known_deltas: dict[int, str] = {}
    for name, keys in _CURRENCY_KEYS.items():
        before = _find_integer(older_payload, keys)
        after = _find_integer(newer_payload, keys)
        if before is None or after is None or before == after:
            continue
        delta = after - before
        currency_changes[name] = delta
        known_deltas[delta] = name

    for change in changes:
        if change.numeric_delta is None:
            continue
        numeric_delta = change.numeric_delta
        if numeric_delta in known_deltas:
            label = known_deltas[int(numeric_delta)]
            change.labels.append(f"matches {label} delta")
            change.score += 100
        if abs(float(numeric_delta)) >= 1 and float(numeric_delta).is_integer():
            change.score += 10
        leaf = change.path.rsplit("/", 1)[-1]
        if any(
            key.decode("ascii", "ignore") == leaf
            for keys in _CURRENCY_KEYS.values()
            for key in keys
        ):
            change.score += 200
    changes.sort(key=lambda item: (-item.score, item.path))
    returned = changes[:limit]
    warnings: list[str] = []
    if truncated:
        warnings.append(
            f"The comparison stopped after {_MAX_SAVE_DIFF_FIELDS} changed fields for safety."
        )
    if len(changes) > limit:
        warnings.append(f"Showing the {limit} highest-ranked changes out of {len(changes)}.")
    return NmsSaveComparisonReport(
        older=_snapshot_info(older, older_payload),
        newer=_snapshot_info(newer, newer_payload),
        total_changed_fields=len(changes),
        returned_changed_fields=len(returned),
        currency_changes=currency_changes,
        changes=returned,
        warnings=warnings,
    )


def _save_candidates(base: Path) -> list[Path]:
    candidates = [
        path.resolve()
        for profile in base.glob("st_*")
        if profile.is_dir()
        for path in profile.iterdir()
        if path.is_file() and _ANY_SAVE_NAME.fullmatch(path.name)
    ]
    return sorted(candidates, key=lambda path: path.stat().st_mtime, reverse=True)


def _select_save(candidates: list[Path], filename: str | None, *, newest: bool) -> Path:
    if filename is None:
        if not candidates:
            raise SafetyError("the requested NMS save file was not found")
        return candidates[0] if newest else candidates[-1]
    normalized = filename.strip().casefold()
    matches = [
        path
        for path in candidates
        if path.name.casefold() == normalized
        or f"{path.parent.name}/{path.name}".casefold() == normalized
    ]
    if len(matches) != 1:
        raise SafetyError("the requested NMS save name is missing or ambiguous")
    return matches[0]


def _decode_save_json(payload: bytes) -> object:
    try:
        return json.loads(payload.rstrip(b"\x00").decode("utf-8", errors="replace"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise SafetyError("the NMS save does not contain supported JSON data") from exc


def _snapshot_info(path: Path, payload: bytes) -> NmsSaveSnapshotInfo:
    currencies = {
        name: value
        for name, keys in _CURRENCY_KEYS.items()
        if (value := _find_integer(payload, keys)) is not None
    }
    return NmsSaveSnapshotInfo(
        profile=path.parent.name,
        filename=path.name,
        modified_at=datetime.fromtimestamp(path.stat().st_mtime, UTC),
        size_bytes=path.stat().st_size,
        sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
        currencies=currencies,
    )


def _collect_changes(
    before: object,
    after: object,
    path: str,
    output: list[NmsSaveFieldChange],
    *,
    depth: int,
) -> bool:
    if len(output) >= _MAX_SAVE_DIFF_FIELDS:
        return True
    if depth > _MAX_SAVE_DIFF_DEPTH:
        raise SafetyError("the NMS save nesting depth exceeds the safe comparison limit")
    if type(before) is not type(after):
        output.append(NmsSaveFieldChange(path=path, before=before, after=after, score=1))
        return False
    if isinstance(before, dict):
        keys = sorted(set(before) | set(after))
        for key in keys:
            child = f"{path}/{key}"
            if key not in before or key not in after:
                output.append(
                    NmsSaveFieldChange(
                        path=child,
                        before=before.get(key),
                        after=after.get(key),
                        score=1,
                    )
                )
            elif _collect_changes(before[key], after[key], child, output, depth=depth + 1):
                return True
            if len(output) >= _MAX_SAVE_DIFF_FIELDS:
                return True
        return False
    if isinstance(before, list):
        if len(before) != len(after):
            output.append(
                NmsSaveFieldChange(
                    path=f"{path}/#length",
                    before=len(before),
                    after=len(after),
                    numeric_delta=len(after) - len(before),
                    score=5,
                )
            )
        for index, (old_item, new_item) in enumerate(zip(before, after, strict=False)):
            if _collect_changes(
                old_item,
                new_item,
                f"{path}/{index}",
                output,
                depth=depth + 1,
            ):
                return True
        return False
    if before == after:
        return False
    delta: int | float | None = None
    if (
        isinstance(before, (int, float))
        and not isinstance(before, bool)
        and isinstance(after, (int, float))
        and not isinstance(after, bool)
    ):
        delta = after - before
    output.append(
        NmsSaveFieldChange(
            path=path,
            before=before,
            after=after,
            numeric_delta=delta,
            score=1,
        )
    )
    return False


def _inventory_stacks(root: object) -> tuple[list[NmsInventoryStack], int, bool]:
    """Extract standard slot objects using semantic and current obfuscated save keys.

    The field aliases come from the inert NMSSaveEditor 1.21.0 resource map at upstream
    commit 6047315f47321e2a8400d38bf8d904bcca88bb8d. The independent nmsmc taxonomy at
    commit a44308e8d6ea6cc0c05869b8ac473a61fdbd3a7c corroborates container group names,
    but its modded example values are intentionally not copied as vanilla limits.
    """

    output: list[NmsInventoryStack] = []
    pending: list[tuple[str, object]] = [("$", root)]
    visited_nodes = 0
    truncated = False
    while pending:
        if visited_nodes >= _MAX_INVENTORY_NODES:
            truncated = True
            break
        path, node = pending.pop()
        visited_nodes += 1
        if isinstance(node, dict):
            slots = _inventory_value(node, "slots")
            if isinstance(slots, list):
                container_name = path.rsplit("/", 1)[-1]
                stack_group = _inventory_value(node, "stack_group")
                if isinstance(stack_group, dict):
                    stack_group = _inventory_value(stack_group, "stack_group_value")
                if not isinstance(stack_group, str):
                    stack_group = None
                valid_slots = _inventory_value(node, "valid_slots")
                valid_slot_count = len(valid_slots) if isinstance(valid_slots, list) else 0
                width = _bounded_nonnegative_int(_inventory_value(node, "width"))
                height = _bounded_nonnegative_int(_inventory_value(node, "height"))
                substance_multiplier = _finite_number(
                    _inventory_value(node, "substance_multiplier")
                )
                product_multiplier = _finite_number(
                    _inventory_value(node, "product_multiplier")
                )
                for slot_ordinal, slot in enumerate(slots):
                    parsed = _parse_inventory_slot(
                        slot,
                        container_path=path,
                        container_name=container_name,
                        stack_size_group=stack_group,
                        valid_slot_count=valid_slot_count,
                        width=width,
                        height=height,
                        substance_storage_multiplier=substance_multiplier,
                        product_storage_multiplier=product_multiplier,
                        slot_ordinal=slot_ordinal,
                    )
                    if parsed is not None:
                        output.append(parsed)
                    if len(output) >= _MAX_INVENTORY_STACKS:
                        return output, visited_nodes, True
            for key, value in node.items():
                if key in _INVENTORY_TRAVERSAL_SKIP_KEYS or not isinstance(
                    value, (dict, list)
                ):
                    continue
                label = _INVENTORY_PATH_NAMES.get(str(key), str(key))
                pending.append((f"{path}/{label}", value))
        elif isinstance(node, list):
            for index, value in enumerate(node):
                if isinstance(value, (dict, list)):
                    pending.append((f"{path}/{index}", value))
    output.sort(
        key=lambda item: (
            item.container_path,
            item.index_y,
            item.index_x,
            item.item_id,
        )
    )
    return output, visited_nodes, truncated


def _parse_inventory_slot(
    slot: object,
    *,
    container_path: str,
    container_name: str,
    stack_size_group: str | None,
    valid_slot_count: int,
    width: int | None,
    height: int | None,
    substance_storage_multiplier: int | float | None,
    product_storage_multiplier: int | float | None,
    slot_ordinal: int,
) -> NmsInventoryStack | None:
    if not isinstance(slot, dict):
        return None
    type_value = _inventory_value(slot, "type")
    item_type = _inventory_value(type_value, "inventory_type")
    if not isinstance(item_type, str):
        return None
    item_id = _inventory_value(slot, "item_id")
    amount = _inventory_value(slot, "amount")
    max_amount = _inventory_value(slot, "max_amount")
    index = _inventory_value(slot, "index")
    index_x = _inventory_value(index, "x")
    index_y = _inventory_value(index, "y")
    if not isinstance(item_id, str) or not 1 <= len(item_id) <= 256:
        return None
    if not _bounded_inventory_integer(amount, minimum=-1):
        return None
    if not _bounded_inventory_integer(max_amount, minimum=0):
        return None
    if not _bounded_coordinate(index_x) or not _bounded_coordinate(index_y):
        return None
    return NmsInventoryStack(
        container_path=container_path,
        container_name=container_name,
        container_kind=_inventory_container_kind(container_name),
        stack_size_group=stack_size_group,
        valid_slot_count=valid_slot_count,
        width=width,
        height=height,
        substance_storage_multiplier=substance_storage_multiplier,
        product_storage_multiplier=product_storage_multiplier,
        item_type=item_type,
        item_id=item_id,
        amount=amount,
        max_amount=max_amount,
        index_x=index_x,
        index_y=index_y,
        slot_ordinal=slot_ordinal,
    )


def _inventory_value(value: object, name: str) -> object | None:
    if not isinstance(value, dict):
        return None
    for key in _INVENTORY_KEYS[name]:
        if key in value:
            return value[key]
    return None


def _inventory_container_kind(container_name: str) -> str:
    folded = container_name.casefold()
    if "tech" in folded or container_name == "WeaponInventory":
        return "technology"
    if "cargo" in folded:
        return "cargo"
    if "chest" in folded or "storage" in folded:
        return "storage"
    if "vehicle" in folded:
        return "vehicle"
    if "freighter" in folded:
        return "freighter"
    if "ship" in folded:
        return "ship"
    if "grave" in folded:
        return "grave"
    return "general"


def _bounded_inventory_integer(value: object, *, minimum: int) -> bool:
    return isinstance(value, int) and not isinstance(value, bool) and minimum <= value <= 0xFFFFFFFF


def _bounded_coordinate(value: object) -> bool:
    return isinstance(value, int) and not isinstance(value, bool) and 0 <= value <= 4096


def _bounded_nonnegative_int(value: object) -> int | None:
    return value if _bounded_inventory_integer(value, minimum=0) else None


def _finite_number(value: object) -> int | float | None:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return None
    if isinstance(value, float) and (value != value or value in (float("inf"), float("-inf"))):
        return None
    return value


def decompress_save(data: bytes) -> bytes:
    output = bytearray()
    cursor = 0
    while cursor < len(data):
        if len(data) - cursor < _CHUNK_HEADER.size:
            raise SafetyError("the NMS save ends inside a chunk header")
        magic, compressed_size, decompressed_size, _reserved = _CHUNK_HEADER.unpack_from(
            data, cursor
        )
        cursor += _CHUNK_HEADER.size
        if magic != _CHUNK_MAGIC:
            raise SafetyError("the file is not a supported NMS streaming save")
        if not 0 < compressed_size <= _MAX_COMPRESSED_CHUNK:
            raise SafetyError("the NMS save has an unsafe compressed chunk size")
        if not 0 < decompressed_size <= _MAX_DECOMPRESSED_CHUNK:
            raise SafetyError("the NMS save has an unsafe decompressed chunk size")
        end = cursor + compressed_size
        if end > len(data):
            raise SafetyError("the NMS save ends inside compressed data")
        if len(output) + decompressed_size > _MAX_DECOMPRESSED_SAVE:
            raise SafetyError("the NMS save exceeds the safe decompression limit")
        output.extend(_decompress_lz4_block(data[cursor:end], decompressed_size))
        cursor = end
    return bytes(output)


def _decompress_lz4_block(data: bytes, expected_size: int) -> bytes:
    source = memoryview(data)
    output = bytearray()
    cursor = 0
    while cursor < len(source):
        token = source[cursor]
        cursor += 1
        literal_length, cursor = _lz4_length(source, cursor, token >> 4)
        literal_end = cursor + literal_length
        if literal_end > len(source) or len(output) + literal_length > expected_size:
            raise SafetyError("the NMS save contains an invalid LZ4 literal")
        output.extend(source[cursor:literal_end])
        cursor = literal_end
        if cursor == len(source):
            break
        if cursor + 2 > len(source):
            raise SafetyError("the NMS save contains a truncated LZ4 match")
        match_offset = int.from_bytes(source[cursor : cursor + 2], "little")
        cursor += 2
        if match_offset <= 0 or match_offset > len(output):
            raise SafetyError("the NMS save contains an invalid LZ4 match offset")
        match_length, cursor = _lz4_length(source, cursor, token & 0x0F)
        match_length += 4
        if len(output) + match_length > expected_size:
            raise SafetyError("the NMS save LZ4 output exceeds its declared size")
        for _ in range(match_length):
            output.append(output[-match_offset])
    if len(output) != expected_size:
        raise SafetyError("the NMS save LZ4 output size does not match its header")
    return bytes(output)


def _lz4_length(source: memoryview, cursor: int, initial: int) -> tuple[int, int]:
    length = initial
    if initial != 15:
        return length, cursor
    while True:
        if cursor >= len(source):
            raise SafetyError("the NMS save contains a truncated LZ4 length")
        extension = source[cursor]
        cursor += 1
        length += extension
        if extension != 255:
            return length, cursor


def _find_integer(payload: bytes, keys: tuple[bytes, ...]) -> int | None:
    for key in keys:
        match = re.search(rb'"' + re.escape(key) + rb'"\s*:\s*(\d+)', payload)
        if match is not None:
            value = int(match.group(1))
            if 0 <= value <= 0xFFFFFFFF:
                return value
    return None


def _default_save_root() -> Path | None:
    appdata = os.environ.get("APPDATA")
    if not appdata:
        return None
    return Path(appdata) / "HelloGames" / "NMS"
