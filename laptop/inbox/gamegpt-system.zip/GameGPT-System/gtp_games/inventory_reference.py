from __future__ import annotations

import json
import re
from collections.abc import Callable
from dataclasses import dataclass
from difflib import SequenceMatcher
from threading import RLock

import httpx

_MAX_REFERENCE_BYTES = 12 * 1024 * 1024
_NMS_REFERENCE_ROOT = "https://nmshandbook.com"
_NMS_DATASETS = {
    "product": f"{_NMS_REFERENCE_ROOT}/JSON_Files/Product_Table.json",
    "substance": f"{_NMS_REFERENCE_ROOT}/JSON_Files/Substance_Table.json",
}


@dataclass(frozen=True)
class InventoryReferenceMatch:
    canonical_name: str
    reference_url: str
    source: str
    confidence: float


ReferenceLoader = Callable[[], list[tuple[str, str, str]]]


class InventoryReferenceRegistry:
    """Game-neutral name matcher; online data can label values but never authorize writes."""

    def __init__(self) -> None:
        self._loaders: dict[str, tuple[str, ReferenceLoader]] = {}
        self._cache: dict[str, list[tuple[str, str, str]]] = {}
        self._lock = RLock()

    def register(self, game_key: str, source: str, loader: ReferenceLoader) -> None:
        self._loaders[_normalize_game_key(game_key)] = (source, loader)

    def source(self, game_key: str) -> str | None:
        entry = self._loaders.get(_normalize_game_key(game_key))
        return entry[0] if entry is not None else None

    def match(self, game_key: str, raw_label: str) -> InventoryReferenceMatch | None:
        normalized_key = _normalize_game_key(game_key)
        entry = self._loaders.get(normalized_key)
        label_key = _normalize_label(raw_label)
        if entry is None or not label_key:
            return None
        source, loader = entry
        with self._lock:
            records = self._cache.get(normalized_key)
        if records is None:
            records = loader()
            with self._lock:
                self._cache[normalized_key] = records
        exact = [record for record in records if _normalize_label(record[0]) == label_key]
        if len(exact) == 1:
            name, item_id, item_type = exact[0]
            return InventoryReferenceMatch(
                canonical_name=name,
                reference_url=_reference_url(item_id, item_type),
                source=source,
                confidence=1.0,
            )
        ranked = sorted(
            (
                (SequenceMatcher(None, label_key, _normalize_label(name)).ratio(), record)
                for record in records
                for name in [record[0]]
            ),
            reverse=True,
            key=lambda item: item[0],
        )
        if not ranked or ranked[0][0] < 0.90:
            return None
        if len(ranked) > 1 and ranked[0][0] - ranked[1][0] < 0.03:
            return None
        confidence, (name, item_id, item_type) = ranked[0]
        return InventoryReferenceMatch(
            canonical_name=name,
            reference_url=_reference_url(item_id, item_type),
            source=source,
            confidence=round(confidence, 4),
        )

    def match_id(
        self,
        game_key: str,
        item_id: str,
        item_type: str | None = None,
    ) -> InventoryReferenceMatch | None:
        """Resolve one save identifier without guessing from a partial display label."""

        normalized_key = _normalize_game_key(game_key)
        entry = self._loaders.get(normalized_key)
        item_id_key = _normalize_item_id(item_id)
        if entry is None or not item_id_key:
            return None
        source, loader = entry
        with self._lock:
            records = self._cache.get(normalized_key)
        if records is None:
            records = loader()
            with self._lock:
                self._cache[normalized_key] = records
        type_key = item_type.strip().casefold() if isinstance(item_type, str) else None
        matches = [
            record
            for record in records
            if _normalize_item_id(record[1]) == item_id_key
            and (type_key is None or record[2].casefold() == type_key)
        ]
        if len(matches) != 1:
            return None
        name, canonical_id, canonical_type = matches[0]
        return InventoryReferenceMatch(
            canonical_name=name,
            reference_url=_reference_url(canonical_id, canonical_type),
            source=source,
            confidence=1.0,
        )


def build_default_inventory_reference_registry() -> InventoryReferenceRegistry:
    registry = InventoryReferenceRegistry()
    registry.register(
        "no-man-s-sky",
        "No Man's Sky Handbook item catalog",
        _load_nms_records,
    )
    return registry


def _load_nms_records() -> list[tuple[str, str, str]]:
    records: list[tuple[str, str, str]] = []
    with httpx.Client(timeout=2.0, follow_redirects=False) as client:
        for item_type, url in _NMS_DATASETS.items():
            with client.stream("GET", url) as response:
                response.raise_for_status()
                payload = bytearray()
                for chunk in response.iter_bytes():
                    payload.extend(chunk)
                    if len(payload) > _MAX_REFERENCE_BYTES:
                        raise ValueError("online item reference exceeded the bounded size limit")
            data = json.loads(bytes(payload))
            if not isinstance(data, dict):
                continue
            for item_id, item in data.items():
                if not isinstance(item, dict):
                    continue
                name = item.get("NameLower_Text") or item.get("Name_Text") or item.get("Name")
                if isinstance(name, str) and name.strip():
                    records.append((name.strip(), str(item_id), item_type))
    return records


def _reference_url(item_id: str, item_type: str) -> str:
    safe_id = re.sub(r"[^A-Za-z0-9_-]", "", item_id)
    safe_type = "substance" if item_type == "substance" else "product"
    return f"{_NMS_REFERENCE_ROOT}/item/?id={safe_id}&type={safe_type}"


def _normalize_game_key(game_key: str) -> str:
    return "-".join(game_key.strip().casefold().replace("'", "").split())


def _normalize_label(label: str) -> str:
    return " ".join(re.sub(r"[^a-z0-9]+", " ", label.casefold()).split())


def _normalize_item_id(item_id: str) -> str:
    return re.sub(r"[^a-z0-9_-]", "", item_id.casefold().lstrip("^"))
