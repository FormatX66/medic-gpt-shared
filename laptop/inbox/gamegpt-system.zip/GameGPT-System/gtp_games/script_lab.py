from __future__ import annotations

import json
from datetime import UTC, datetime
from enum import StrEnum
from pathlib import Path
from uuid import uuid4

from pydantic import BaseModel, Field

from gtp_games.models import CheatTableScriptFinding


class NativeScriptKind(StrEnum):
    VALUE = "value"
    LOCATOR = "locator"
    PATCH = "patch"
    OVERLAY = "overlay"


class ScriptGate(BaseModel):
    name: str
    passed: bool
    evidence: str


class NativeScriptCandidate(BaseModel):
    schema_version: str = "gtp-native-script/v1"
    id: str = Field(default_factory=lambda: uuid4().hex)
    name: str
    target: str
    kind: NativeScriptKind
    operation: str
    parameters: dict[str, str | int | float | bool] = Field(default_factory=dict)
    locator_kind: str | None = None
    source_kind: str = "native_builder"
    source_sha256: str | None = None
    source_directives: list[str] = Field(default_factory=list)
    native_steps: list[str] = Field(default_factory=list)
    rollback_steps: list[str] = Field(default_factory=list)
    reference_only: bool = True
    imported_code_retained: bool = False
    auto_assembler_executed: bool = False
    lua_executed: bool = False
    created_at: datetime = Field(default_factory=lambda: datetime.now(UTC))


class ScriptVerification(BaseModel):
    candidate_id: str
    gates: list[ScriptGate]
    read_only_checks_complete: bool
    ready_for_local_confirmation: bool
    executable: bool = False
    status: str


_VALUE_OPERATIONS = {"set", "freeze", "clamp", "multiply", "conditional"}
_OVERLAY_OPERATIONS = {"display", "toggle", "alert"}


def build_native_script(
    *,
    name: str,
    target: str,
    kind: NativeScriptKind,
    operation: str,
    parameters: dict[str, str | int | float | bool] | None = None,
    locator_kind: str | None = None,
) -> NativeScriptCandidate:
    normalized = operation.strip().casefold()
    allowed = _OVERLAY_OPERATIONS if kind is NativeScriptKind.OVERLAY else _VALUE_OPERATIONS
    if kind in {NativeScriptKind.LOCATOR, NativeScriptKind.PATCH}:
        allowed = {"resolve", "intercept", "replace"}
    if normalized not in allowed:
        display = normalized or "empty operation"
        raise ValueError(f"{display} is not allowed for {kind.value} scripts")
    if not name.strip() or not target.strip():
        raise ValueError("script name and target are required")
    rollback = (
        ["remove overlay without changing game state"]
        if kind is NativeScriptKind.OVERLAY
        else ["compare current state", "restore captured original state", "verify restoration"]
    )
    return NativeScriptCandidate(
        name=name.strip(),
        target=target.strip(),
        kind=kind,
        operation=normalized,
        parameters=parameters or {},
        locator_kind=locator_kind,
        native_steps=[
            "verify exact game build",
            "resolve one validated locator",
            f"prepare native {normalized} behavior",
        ],
        rollback_steps=rollback,
    )


def translate_ct_script_reference(
    finding: CheatTableScriptFinding,
    *,
    table_sha256: str,
    target: str | None = None,
) -> NativeScriptCandidate:
    """Translate only the inert plan and hash; never retain imported script text."""

    kind = (
        NativeScriptKind.OVERLAY
        if finding.language.casefold() == "lua" and not finding.signatures
        else NativeScriptKind.LOCATOR
    )
    native_steps = [
        step
        for step in finding.read_only_plan
        if not any(token in step.casefold() for token in ("execute", "inject", "write"))
    ][:20]
    return NativeScriptCandidate(
        name=f"Reference: {finding.description}",
        target=(target or finding.description).strip(),
        kind=kind,
        operation="display" if kind is NativeScriptKind.OVERLAY else "resolve",
        locator_kind="aob" if finding.signatures else None,
        source_kind="ct_reference",
        source_sha256=table_sha256,
        source_directives=finding.directives[:20],
        native_steps=native_steps or ["review imported locator intent as inert reference"],
        rollback_steps=["discard candidate; no game state was changed"],
    )


def verify_script_candidate(
    candidate: NativeScriptCandidate,
    *,
    exact_build_match: bool,
    locator_match_count: int | None,
    original_state_captured: bool,
    rollback_verified: bool,
    behavioral_events: int,
) -> ScriptVerification:
    locator_required = candidate.kind is not NativeScriptKind.OVERLAY
    gates = [
        ScriptGate(
            name="exact_build",
            passed=exact_build_match,
            evidence="exact executable identity matched" if exact_build_match else "build mismatch",
        ),
        ScriptGate(
            name="unique_locator",
            passed=not locator_required or locator_match_count == 1,
            evidence=(
                "not required for overlay"
                if not locator_required
                else "locator matches: "
                f"{locator_match_count if locator_match_count is not None else 'none'}"
            ),
        ),
        ScriptGate(
            name="original_state",
            passed=not locator_required or original_state_captured,
            evidence="captured read-only" if original_state_captured else "not captured",
        ),
        ScriptGate(
            name="behavior",
            passed=not locator_required or behavioral_events >= 3,
            evidence=f"validated events: {behavioral_events}",
        ),
        ScriptGate(
            name="rollback",
            passed=rollback_verified,
            evidence="rollback plan verified" if rollback_verified else "rollback not verified",
        ),
    ]
    complete = all(gate.passed for gate in gates)
    return ScriptVerification(
        candidate_id=candidate.id,
        gates=gates,
        read_only_checks_complete=complete,
        ready_for_local_confirmation=complete and not candidate.reference_only,
        status=(
            "verified read-only; local confirmation still required"
            if complete
            else "candidate blocked until every evidence gate passes"
        ),
    )


class ScriptLabStore:
    def __init__(self, path: Path) -> None:
        self.path = path

    def save(self, candidates: list[NativeScriptCandidate]) -> Path:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        payload = {
            "schema": "gtp-script-lab-store/v1",
            "updated_at": datetime.now(UTC).isoformat(),
            "candidates": [item.model_dump(mode="json") for item in candidates],
        }
        temporary = self.path.with_suffix(self.path.suffix + ".tmp")
        temporary.write_text(json.dumps(payload, indent=2), encoding="utf-8")
        temporary.replace(self.path)
        return self.path

    def load(self) -> list[NativeScriptCandidate]:
        if not self.path.is_file():
            return []
        payload = json.loads(self.path.read_text(encoding="utf-8"))
        return [
            NativeScriptCandidate.model_validate(item)
            for item in payload.get("candidates", [])
        ]
