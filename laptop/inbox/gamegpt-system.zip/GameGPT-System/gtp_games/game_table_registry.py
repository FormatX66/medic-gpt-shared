from __future__ import annotations

import hashlib
import json
import os
import re
import subprocess
from datetime import UTC, datetime
from pathlib import Path
from typing import Literal

from pydantic import BaseModel, Field

from gtp_games.errors import SafetyError
from gtp_games.models import LocatorKind, PortableGameValueTable

MAX_REGISTRY_TABLE_BYTES = 10 * 1024 * 1024


class GameTableRegistryStatus(BaseModel):
    action: Literal["status", "pull", "stage", "publish"] = "status"
    enabled: bool
    directory: str | None = None
    repository_ready: bool = False
    remote_url: str | None = None
    branch: str | None = None
    dirty: bool = False
    exact_table_path: str | None = None
    staged_table_path: str | None = None
    commit: str | None = None
    changed: bool = False
    notes: list[str] = Field(default_factory=list)


class GameTableRegistry:
    """Version portable game tables in a local Git checkout without blocking game attach."""

    def __init__(
        self,
        directory: Path | None,
        *,
        remote_url: str = "",
        timeout_seconds: int = 20,
    ) -> None:
        self.directory = directory.expanduser().resolve() if directory else None
        self.remote_url = remote_url.strip()
        self.timeout_seconds = timeout_seconds

    @property
    def enabled(self) -> bool:
        return self.directory is not None

    def find_exact_table(
        self,
        *,
        process_name: str,
        build_identity: str | None,
        game_key: str | None = None,
    ) -> Path | None:
        if self.directory is None or not self.directory.is_dir() or not build_identity:
            return None
        expected_game = _identity(game_key or "")
        expected_process = _identity(process_name)
        matches: list[Path] = []
        for path in sorted(self.directory.glob("tables/**/*.gtp-table.json"))[:5000]:
            try:
                table = self._load_portable(path)
            except SafetyError:
                continue
            game_matches = bool(expected_game and _identity(table.game_key) == expected_game)
            process_matches = _identity(table.process_name) == expected_process
            if table.game_build_identity == build_identity and (game_matches or process_matches):
                matches.append(path.resolve())
        return matches[0] if matches else None

    def stage_export(self, exported_path: str | Path) -> GameTableRegistryStatus:
        if self.directory is None:
            return self.status(notes=["The game-table registry is disabled."])
        source = Path(exported_path).expanduser().resolve()
        table = self._load_portable(source)
        game_key = _safe_key(table.game_key, fallback="unknown-game")
        build_key = _safe_key(table.game_build_identity or "unknown-build")
        target = self.directory / "tables" / game_key / f"{build_key}.gtp-table.json"
        target.parent.mkdir(parents=True, exist_ok=True)
        self.directory.mkdir(parents=True, exist_ok=True)
        temporary = target.with_suffix(target.suffix + ".tmp")
        temporary.write_text(
            table.model_dump_json(indent=2, exclude_none=True),
            encoding="utf-8",
        )
        temporary.replace(target)
        self._update_index(target, table)
        return self.status(
            action="stage",
            staged_table_path=str(target.resolve()),
            changed=True,
            notes=["Portable table copied into the local registry checkout."],
        )

    def pull(self) -> GameTableRegistryStatus:
        ready = self._repository_ready()
        if not ready:
            return self.status(
                action="pull",
                notes=["The registry directory is not a Git repository."],
            )
        if self._git_dirty():
            raise SafetyError("publish or revert local registry changes before pulling")
        before = self._run_git("rev-parse", "HEAD").stdout.strip()
        self._run_git("pull", "--ff-only")
        after = self._run_git("rev-parse", "HEAD").stdout.strip()
        return self.status(
            action="pull",
            changed=before != after,
            notes=[
                "Registry updated with a fast-forward-only pull."
                if before != after
                else "The local registry is already up to date."
            ],
        )

    def publish(self, exported_path: str | Path) -> GameTableRegistryStatus:
        if self._repository_ready() and self._git_staged_files():
            raise SafetyError(
                "commit or unstage existing registry changes before publishing a game table"
            )
        staged = self.stage_export(exported_path)
        if self.directory is None or not self._repository_ready():
            return staged.model_copy(
                update={
                    "action": "publish",
                    "notes": [
                        *staged.notes,
                        (
                            "The table is staged locally; initialize the registry repository "
                            "to push it."
                        ),
                    ],
                }
            )
        target = Path(staged.staged_table_path or "").resolve()
        relative_target = target.relative_to(self.directory)
        self._run_git("add", "--", relative_target.as_posix(), "index.json")
        changed = self._run_git("diff", "--cached", "--quiet", check=False).returncode != 0
        if changed:
            table = self._load_portable(target)
            message = f"Update {table.game_key} table for {_short_build(table.game_build_identity)}"
            self._run_git("commit", "-m", message)
            self._run_git("push", "-u", "origin", "HEAD")
        commit = self._run_git("rev-parse", "HEAD").stdout.strip()
        return self.status(
            action="publish",
            staged_table_path=str(target),
            commit=commit or None,
            changed=changed,
            notes=[
                "Portable table is committed and synchronized with the registry remote."
                if changed
                else "The registry already contains this exact portable table."
            ],
        )

    def status(
        self,
        *,
        action: Literal["status", "pull", "stage", "publish"] = "status",
        exact_table_path: str | None = None,
        staged_table_path: str | None = None,
        commit: str | None = None,
        changed: bool = False,
        notes: list[str] | None = None,
    ) -> GameTableRegistryStatus:
        ready = self._repository_ready()
        remote = self.remote_url or None
        branch = None
        dirty = False
        if ready:
            configured = self._run_git("remote", "get-url", "origin", check=False)
            if configured.returncode == 0 and configured.stdout.strip():
                remote = configured.stdout.strip()
            branch_result = self._run_git(
                "branch", "--show-current", check=False
            )
            branch = branch_result.stdout.strip() or None
            dirty = self._git_dirty()
        return GameTableRegistryStatus(
            action=action,
            enabled=self.enabled,
            directory=str(self.directory) if self.directory else None,
            repository_ready=ready,
            remote_url=remote,
            branch=branch,
            dirty=dirty,
            exact_table_path=exact_table_path,
            staged_table_path=staged_table_path,
            commit=commit,
            changed=changed,
            notes=notes or [],
        )

    def _load_portable(self, path: Path) -> PortableGameValueTable:
        if not path.is_file() or path.stat().st_size > MAX_REGISTRY_TABLE_BYTES:
            raise SafetyError("choose a bounded portable .gtp-table.json file")
        try:
            table = PortableGameValueTable.model_validate_json(path.read_text(encoding="utf-8"))
        except (OSError, ValueError) as exc:
            raise SafetyError(f"portable game table is invalid: {exc}") from exc
        if table.schema_version != "gtp-portable-game-value-table/v1":
            raise SafetyError("portable game table uses an unsupported schema")
        if (
            table.contains_raw_addresses
            or table.contains_executable_scripts
            or table.contains_machine_paths
        ):
            raise SafetyError("unsafe game-table content cannot enter the registry")
        for entry in [*table.confirmed_features, *table.candidate_features]:
            locator = entry.locator
            if locator and (locator.kind is LocatorKind.RAW_ADDRESS or locator.address is not None):
                raise SafetyError("raw memory addresses cannot enter the table registry")
        return table

    def _update_index(self, table_path: Path, table: PortableGameValueTable) -> None:
        assert self.directory is not None
        index_path = self.directory / "index.json"
        try:
            payload = json.loads(index_path.read_text(encoding="utf-8"))
            entries = payload.get("tables", []) if isinstance(payload, dict) else []
        except (OSError, ValueError):
            entries = []
        relative = table_path.relative_to(self.directory).as_posix()
        digest = hashlib.sha256(table_path.read_bytes()).hexdigest()
        record = {
            "game_key": table.game_key,
            "process_name": table.process_name,
            "game_build_identity": table.game_build_identity,
            "path": relative,
            "sha256": digest,
            "confirmed_count": len(table.confirmed_features),
            "candidate_count": len(table.candidate_features),
            "updated_at": datetime.now(UTC).isoformat(),
        }
        filtered = [
            item
            for item in entries
            if not (
                isinstance(item, dict)
                and item.get("game_key") == table.game_key
                and item.get("game_build_identity") == table.game_build_identity
            )
        ]
        filtered.append(record)
        filtered.sort(key=lambda item: (str(item.get("game_key")), str(item.get("path"))))
        output = {
            "schema_version": "gtp-game-table-registry/v1",
            "tables": filtered,
        }
        temporary = index_path.with_suffix(".tmp")
        temporary.write_text(json.dumps(output, indent=2), encoding="utf-8")
        temporary.replace(index_path)

    def _repository_ready(self) -> bool:
        return bool(self.directory and (self.directory / ".git").exists())

    def _git_dirty(self) -> bool:
        return bool(self._run_git("status", "--porcelain").stdout.strip())

    def _git_staged_files(self) -> list[str]:
        result = self._run_git("diff", "--cached", "--name-only")
        return [line for line in result.stdout.splitlines() if line.strip()]

    def _run_git(
        self,
        *args: str,
        check: bool = True,
    ) -> subprocess.CompletedProcess[str]:
        if self.directory is None:
            raise SafetyError("the game-table registry is disabled")
        creation_flags = getattr(subprocess, "CREATE_NO_WINDOW", 0) if os.name == "nt" else 0
        try:
            result = subprocess.run(
                ["git", "-C", str(self.directory), *args],
                stdin=subprocess.DEVNULL,
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace",
                timeout=self.timeout_seconds,
                creationflags=creation_flags,
                check=False,
            )
        except (OSError, subprocess.TimeoutExpired) as exc:
            raise SafetyError("the game-table registry Git operation failed") from exc
        if check and result.returncode != 0:
            message = (result.stderr or result.stdout).strip()
            raise SafetyError(f"game-table registry Git operation failed: {message[:300]}")
        return result


def _safe_key(value: str, *, fallback: str = "unknown-build") -> str:
    normalized = re.sub(r"[^a-zA-Z0-9._-]+", "-", value).strip("-")
    return normalized[-96:] or fallback


def _identity(value: str) -> str:
    return re.sub(r"[^a-z0-9]+", "", value.casefold())


def _short_build(value: str | None) -> str:
    if not value:
        return "unknown build"
    return value.rsplit(":", 1)[-1][:12]
