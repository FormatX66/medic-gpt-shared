from __future__ import annotations

import hashlib
import re
from datetime import UTC, datetime
from threading import RLock, Thread

from gtp_games.cheat_tables import inspect_cheat_table, inspect_cheat_table_url
from gtp_games.config import Settings
from gtp_games.discovery import SAME_PROCESS_LAYOUT_SOURCE
from gtp_games.game_identity import executable_build_identity
from gtp_games.game_tables import (
    ensure_game_value_table,
    game_key_for_session,
    register_confirmed_profile,
)
from gtp_games.memory.base import MemoryBackend
from gtp_games.models import (
    CheatAction,
    CheatDiscoveryRunStatus,
    GameCheatCatalog,
    GameCheatFeature,
    GameValueTable,
    GameValueTableEntry,
    ProcessSession,
    UnrealGasProfile,
)
from gtp_games.unreal import UnrealGasEngine
from gtp_games.web_discovery import WebCheatDiscovery


class GameCatalogManager:
    """Build per-session cheat menus from inert hints and confirmed local profiles."""

    def __init__(
        self,
        backend: MemoryBackend,
        settings: Settings,
        unreal: UnrealGasEngine,
    ) -> None:
        self.backend = backend
        self.settings = settings
        self.unreal = unreal
        self.web = WebCheatDiscovery(settings)
        self._catalogs: dict[str, GameCheatCatalog] = {}
        self._threads: dict[str, Thread] = {}
        self._lock = RLock()

    def begin_first_connection(self, session: ProcessSession) -> GameCheatCatalog:
        game_key = _game_key(session)
        game_name = session.game_name or game_key.replace("-", " ").title()
        catalog = GameCheatCatalog(
            id=hashlib.sha256(f"{session.id}:catalog".encode()).hexdigest()[:32],
            session_id=session.id,
            process_name=session.process_name,
            game_name=game_name,
            executable=session.executable,
            game_key=game_key,
            game_build_identity=executable_build_identity(session.executable),
            status="discovering",
            mount_stage="Checking local tables, profiles, and game engine",
            mount_steps_completed=1,
            web_discovery_status=(
                "searching" if self.settings.auto_web_discovery_on_mount else "disabled"
            ),
            write_enabled=session.write_enabled,
            suggested_research_queries=[
                f'"{game_name}" health stamina mana currency cheat table',
                f'"{game_name}" useful cheats modding forum GitHub',
                f'"{game_name}" current health maximum health game values',
            ],
            notes=[
                "First-connection discovery is read-only.",
                (
                    "Public tables and forum findings remain advisory until live behavior "
                    "confirms them."
                ),
            ],
        )
        thread = Thread(
            target=self._first_connection_worker,
            args=(session,),
            name=f"gtp-catalog-{session.pid}",
            daemon=True,
        )
        with self._lock:
            existing = self._catalogs.get(session.id)
            if existing is not None:
                return existing.model_copy(deep=True)
            self._catalogs[session.id] = catalog
            self._threads[session.id] = thread
        thread.start()
        return catalog.model_copy(deep=True)

    def get(self, session_id: str) -> GameCheatCatalog:
        with self._lock:
            catalog = self._catalogs.get(session_id)
            if catalog is None:
                raise KeyError(session_id)
            return catalog.model_copy(deep=True)

    def sync_game_value_table(
        self,
        session: ProcessSession,
        table: GameValueTable,
        discovery_status: CheatDiscoveryRunStatus | None = None,
    ) -> GameCheatCatalog:
        """Mount the latest read-only learning table into the visible catalog."""

        mounted = _features_from_game_value_table(
            table,
            discovery_status,
            process_started_at=session.process_started_at,
        )
        with self._lock:
            catalog = self._catalogs.get(session.id)
            if catalog is None:
                raise KeyError(session.id)
            catalog.features = [
                feature
                for feature in catalog.features
                if feature.source_kind != "mounted_game_value_table"
            ]
            catalog.features.extend(mounted)
            catalog.game_table_path = table.saved_path
            _refresh_catalog_counts(catalog)
            catalog.refreshed_at = datetime.now(UTC)
            return catalog.model_copy(deep=True)

    def add_sources(
        self,
        session: ProcessSession,
        sources: list[str],
        *,
        query: str,
    ) -> GameCheatCatalog:
        with self._lock:
            catalog = self._catalogs[session.id]
        additions: list[GameCheatFeature] = []
        checked: list[str] = []
        notes: list[str] = []
        ignored_additions = 0
        for source in sources[:10]:
            normalized = source.strip()
            if not normalized:
                continue
            try:
                if normalized.casefold().startswith("https://"):
                    result = inspect_cheat_table_url(
                        normalized,
                        backend=self.backend,
                        session=session,
                        max_bytes=self.settings.max_cheat_table_bytes,
                        max_signature_scan_bytes=self.settings.max_scan_bytes,
                        query=query,
                        limit=200,
                    )
                else:
                    result = inspect_cheat_table(
                        normalized,
                        backend=self.backend,
                        session=session,
                        max_bytes=self.settings.max_cheat_table_bytes,
                        max_signature_scan_bytes=self.settings.max_scan_bytes,
                        query=query,
                        limit=200,
                    )
            except Exception as exc:
                notes.append(f"Could not inspect {normalized}: {exc}")
                continue
            checked.append(normalized)
            checks = {item.description.casefold(): item for item in result.checks}
            for hint in result.hints:
                category, relevance = _feature_classification(hint.description)
                if relevance == "ignored":
                    ignored_additions += 1
                    continue
                check = checks.get(hint.description.casefold())
                status = "advisory"
                confidence = 0.2
                current = None
                evidence = ["Imported as inert table metadata; scripts were not executed."]
                if check is not None:
                    current = check.value
                    evidence.append(check.status)
                    if check.status == "validated read-only hint":
                        status = "live_hint_needs_behavior_confirmation"
                        confidence = 0.55
                if hint.script_present:
                    evidence.append("The original table script was ignored.")
                feature_id = _feature_id(catalog.game_key, normalized, hint.description)
                additions.append(
                    GameCheatFeature(
                        id=feature_id,
                        name=hint.description,
                        description="Candidate feature from untrusted public table metadata.",
                        status=status,
                        source_kind="cheat_table_hint",
                        source=normalized,
                        value_type=hint.value_type,
                        current_value=current,
                        category=category,
                        relevance=relevance,
                        confidence=confidence,
                        evidence=evidence,
                    )
                )
        with self._lock:
            existing_ids = {item.id for item in catalog.features}
            catalog.features.extend(item for item in additions if item.id not in existing_ids)
            catalog.sources_checked.extend(
                item for item in checked if item not in catalog.sources_checked
            )
            catalog.notes.extend(notes)
            catalog.ignored_feature_count += ignored_additions
            _refresh_catalog_counts(catalog)
            catalog.refreshed_at = datetime.now(UTC)
            if catalog.status != "discovering":
                catalog.status = "ready"
            return catalog.model_copy(deep=True)

    def feature(self, session_id: str, feature_id: str) -> GameCheatFeature:
        catalog = self.get(session_id)
        for feature in catalog.features:
            if feature.id == feature_id:
                return feature
        raise KeyError(feature_id)

    def remove_session(self, session_id: str) -> None:
        with self._lock:
            self._catalogs.pop(session_id, None)
            self._threads.pop(session_id, None)

    def _first_connection_worker(self, session: ProcessSession) -> None:
        features: list[GameCheatFeature] = []
        notes: list[str] = []
        ignored_features = 0
        unreal_detected = False
        profile_scan_id = None
        profile_monitor_id = None
        game_table_path = None
        game_table = None
        try:
            game_table = ensure_game_value_table(self.settings, session)
            game_table_path = game_table.saved_path
        except OSError as exc:
            notes.append(f"The per-game value table could not be created: {exc}")
        if _looks_like_unreal(session):
            try:
                discovery = self.unreal.locate(session)
                unreal_detected = discovery.world_address is not None
                if unreal_detected:
                    notes.append(
                        "Unreal GWorld validated; GAS/current-max calibration is available."
                    )
                else:
                    notes.extend(discovery.warnings)
            except Exception as exc:
                notes.append(f"Unreal discovery did not complete: {exc}")
        if unreal_detected and self.settings.auto_profile_on_first_connection:
            try:
                profile_scan = self.unreal.start(session)
                profile_monitor = self.unreal.start_game_profile_monitor(
                    profile_scan.id,
                    session,
                    interval_ms=1000,
                    duration_seconds=min(900, self.settings.max_damage_monitor_seconds),
                    candidate_limit=50,
                )
                profile_scan_id = profile_scan.id
                profile_monitor_id = profile_monitor.id
                notes.append(
                    "One read-only full-game profile pass started automatically; it samples "
                    "only while the game is foreground and saves a local candidate ledger."
                )
            except Exception as exc:
                notes.append(f"Automatic full-game profiling did not start: {exc}")
        elif not unreal_detected:
            notes.append(
                "This engine has no object-aware full-profile adapter yet; blind fields are "
                "not auto-labeled as cheats."
            )

        if game_table is not None and game_table.selected_source_status:
            selected_names: set[str] = set()
            for entry in game_table.candidate_features:
                if entry.source_kind != "selected_portable_table":
                    continue
                category, relevance = (
                    (entry.category, entry.relevance)
                    if entry.relevance != "unknown"
                    else _feature_classification(entry.name)
                )
                if relevance == "ignored":
                    ignored_features += 1
                    continue
                normalized_name = entry.name.casefold()
                if normalized_name in selected_names:
                    continue
                selected_names.add(normalized_name)
                features.append(
                    GameCheatFeature(
                        id=_feature_id(
                            _game_key(session),
                            "selected-portable-table",
                            entry.name,
                        ),
                        name=entry.name,
                        description=("Feature suggested by the selected portable game table."),
                        status="selected_table_needs_runtime_validation",
                        source_kind="selected_portable_table",
                        value_type=entry.value_type,
                        confidence=entry.confidence,
                        category=category,
                        relevance=relevance,
                        available_actions=[],
                        evidence=entry.evidence,
                    )
                )
                if len(selected_names) >= 25:
                    break
            notes.append(
                "The selected portable table is active as read-only discovery guidance; "
                "its features have no set or hold actions until live validation succeeds."
            )

        for profile in self._saved_profiles(session):
            try:
                resolved = self.unreal.read_profile(session, profile.id)
            except Exception as exc:
                category, relevance = _feature_classification(profile.name)
                features.append(
                    GameCheatFeature(
                        id=_feature_id(_game_key(session), "profile", profile.id),
                        name=profile.name,
                        description="Saved local feature profile.",
                        status="saved_profile_needs_recalibration",
                        source_kind="confirmed_local_profile",
                        source=profile.saved_path,
                        profile_id=profile.id,
                        value_type=profile.value_type,
                        category=category,
                        relevance=relevance,
                        confidence=0.4,
                        evidence=[str(exc)],
                    )
                )
                continue
            features.append(
                GameCheatFeature(
                    id=_feature_id(_game_key(session), "profile", profile.id),
                    name=profile.name,
                    description="Confirmed restart-stable local value profile.",
                    status="ready" if session.write_enabled else "ready_read_only",
                    source_kind="confirmed_local_profile",
                    source=profile.saved_path,
                    profile_id=profile.id,
                    value_type=profile.value_type,
                    current_value=resolved.value,
                    maximum_value=resolved.likely_max_value,
                    category=_feature_classification(profile.name)[0],
                    relevance=_feature_classification(profile.name)[1],
                    confidence=0.95,
                    available_actions=(
                        [CheatAction.SET, CheatAction.HOLD]
                        if session.write_enabled and self.settings.allow_writes
                        else []
                    ),
                    evidence=[
                        "GWorld and every saved object-path step validated in this launch.",
                        "Game memory has not been changed.",
                    ],
                )
            )
            try:
                table = register_confirmed_profile(
                    self.settings,
                    session,
                    profile,
                    current_value=resolved.value,
                    maximum_value=resolved.likely_max_value,
                )
                game_table_path = table.saved_path
            except OSError as exc:
                notes.append(f"Could not index profile {profile.name} in its game table: {exc}")
        if unreal_detected and not any(item.profile_id for item in features):
            features.append(
                GameCheatFeature(
                    id=_feature_id(_game_key(session), "unreal", "health-calibration"),
                    name="Health / maximum health",
                    description=(
                        "Run stable → damaged → stable → healed snapshots to build this cheat."
                    ),
                    status="needs_behavior_calibration",
                    source_kind="unreal_gas_discovery",
                    confidence=0.35,
                    evidence=["GWorld validated; no confirmed health profile exists yet."],
                )
            )
        with self._lock:
            catalog = self._catalogs.get(session.id)
            if catalog is None:
                return
            catalog.features = features
            catalog.notes.extend(notes)
            catalog.profile_scan_id = profile_scan_id
            catalog.profile_monitor_id = profile_monitor_id
            catalog.game_table_path = game_table_path
            catalog.status = "ready"
            catalog.mount_steps_completed = 2
            catalog.mount_stage = (
                "Searching public tables, forums, GitHub, and code"
                if self.settings.auto_web_discovery_on_mount
                else "Ready"
            )
            catalog.ignored_feature_count += ignored_features
            if not self.settings.auto_web_discovery_on_mount:
                catalog.mount_steps_completed = catalog.mount_steps_total
            _refresh_catalog_counts(catalog)
            catalog.refreshed_at = datetime.now(UTC)
        try:
            if self.settings.auto_web_discovery_on_mount:
                self._mount_web_sources(session)
        finally:
            with self._lock:
                self._threads.pop(session.id, None)

    def _mount_web_sources(self, session: ProcessSession) -> None:
        game_key = _game_key(session)
        game_name = session.game_name or game_key.replace("-", " ").title()
        try:
            result = self.web.discover(
                game_name=game_name,
                game_key=game_key,
                game_build_identity=executable_build_identity(session.executable),
            )
        except Exception as exc:  # noqa: BLE001 - web failure must never break mounting
            with self._lock:
                catalog = self._catalogs.get(session.id)
                if catalog is None:
                    return
                catalog.web_discovery_status = "failed"
                catalog.notes.append(f"Automatic public-source discovery failed safely: {exc}")
                catalog.mount_steps_completed = catalog.mount_steps_total
                catalog.mount_stage = "Ready with a public-source warning"
                catalog.refreshed_at = datetime.now(UTC)
            return

        grouped: dict[str, list] = {}
        for source in result.sources:
            for hint in source.feature_hints:
                grouped.setdefault(hint, []).append(source)
        web_features: list[GameCheatFeature] = []
        ignored_web_features = 0
        for name, sources in grouped.items():
            category, relevance = _feature_classification(name)
            if relevance == "ignored":
                ignored_web_features += 1
                continue
            evidence = [
                "Public web metadata/code text suggested this feature; nothing was executed.",
                *[f"{source.source_kind}: {source.title}" for source in sources[:4]],
            ]
            web_features.append(
                GameCheatFeature(
                    id=_feature_id(game_key, "automatic-web-discovery", name),
                    name=name,
                    description=(
                        "Feature idea collected automatically from public tables, forums, "
                        "mods, or repository text."
                    ),
                    status="web_hint_needs_local_validation",
                    source_kind="automatic_web_discovery",
                    source=sources[0].url,
                    category=category,
                    relevance=relevance,
                    confidence=min(0.45, 0.15 + 0.1 * len(sources)),
                    available_actions=[],
                    evidence=evidence,
                )
            )

        with self._lock:
            catalog = self._catalogs.get(session.id)
            if catalog is None:
                return
            existing_ids = {feature.id for feature in catalog.features}
            catalog.features.extend(
                feature for feature in web_features if feature.id not in existing_ids
            )
            catalog.web_sources = result.sources
            catalog.web_discovery_status = result.status
            catalog.ignored_feature_count += ignored_web_features
            catalog.notes.extend(result.notes)
            catalog.notes.append(
                f"Automatic mount discovery indexed {len(result.sources)} public source(s); "
                "all findings remain non-write-ready."
            )
            catalog.mount_stage = (
                "Inspecting discovered table files"
                if any(source.direct_table for source in result.sources)
                else "Ready"
            )
            if not any(source.direct_table for source in result.sources):
                catalog.mount_steps_completed = catalog.mount_steps_total
            _refresh_catalog_counts(catalog)
            catalog.refreshed_at = datetime.now(UTC)

        direct_tables = [source.url for source in result.sources if source.direct_table][:5]
        if direct_tables:
            try:
                self.add_sources(
                    session,
                    direct_tables,
                    query=(
                        "health stamina mana money currency ammo inventory movement jump cooldown"
                    ),
                )
            except Exception as exc:  # noqa: BLE001 - direct-table failure stays advisory
                with self._lock:
                    catalog = self._catalogs.get(session.id)
                    if catalog is not None:
                        catalog.notes.append(
                            f"One or more discovered table files could not be inspected: {exc}"
                        )
            finally:
                with self._lock:
                    catalog = self._catalogs.get(session.id)
                    if catalog is not None:
                        catalog.mount_steps_completed = catalog.mount_steps_total
                        catalog.mount_stage = "Ready"
                        _refresh_catalog_counts(catalog)
                        catalog.refreshed_at = datetime.now(UTC)

    def _saved_profiles(self, session: ProcessSession) -> list[UnrealGasProfile]:
        profiles: list[UnrealGasProfile] = []
        directory = self.settings.game_profile_directory
        if not directory.is_dir():
            return profiles
        for path in sorted(directory.glob("*.json"))[:100]:
            if re.fullmatch(r"[0-9a-f]{32}\.json", path.name) is None:
                continue
            try:
                profile = UnrealGasProfile.model_validate_json(path.read_text(encoding="utf-8"))
            except (OSError, ValueError):
                continue
            same_name = profile.process_name.casefold() == session.process_name.casefold()
            same_build = (
                profile.game_build_identity is not None
                and profile.game_build_identity == executable_build_identity(session.executable)
            )
            if same_name or same_build:
                profiles.append(profile)
        return profiles


def _game_key(session: ProcessSession) -> str:
    return game_key_for_session(session)


def _looks_like_unreal(session: ProcessSession) -> bool:
    value = (session.executable or session.process_name).replace("/", "\\").casefold()
    return "\\binaries\\win64\\" in value or "-win64-shipping" in value


def _feature_id(game_key: str, source: str, name: str) -> str:
    payload = f"{game_key}\0{source}\0{name.casefold()}".encode()
    return hashlib.sha256(payload).hexdigest()[:24]


def _features_from_game_value_table(
    table: GameValueTable,
    discovery_status: CheatDiscoveryRunStatus | None = None,
    *,
    process_started_at: float | None = None,
) -> list[GameCheatFeature]:
    def valid_for_current_process(entry: GameValueTableEntry) -> bool:
        if entry.status == "confirmed":
            return True
        return (
            entry.status == "locked_read_only"
            and process_started_at is not None
            and process_started_at in entry.validated_process_starts
        )

    grouped: dict[str, list[GameValueTableEntry]] = {}
    for entry in [*table.confirmed_features, *table.candidate_features]:
        if entry.profile_id:
            continue
        grouped.setdefault(entry.name.casefold(), []).append(entry)
    observed = (
        {
            target.name.casefold(): target
            for target in discovery_status.targets
            if target.exact_value is not None
            and target.exact_value_source
            in {
                "nms_save",
                "user",
                "screen",
                "user_write_test",
                SAME_PROCESS_LAYOUT_SOURCE,
            }
        }
        if discovery_status is not None
        else {}
    )

    features: list[GameCheatFeature] = []
    for entries in grouped.values():
        entries.sort(
            key=lambda entry: (
                valid_for_current_process(entry),
                entry.confidence,
                entry.validated_launches,
                entry.validated_events,
                entry.updated_at,
            ),
            reverse=True,
        )
        selected = entries[0]
        target = observed.get(selected.name.casefold())
        ready_candidate_ids = (
            [
                candidate.id
                for candidate in target.candidates
                if candidate.write_test_status in {"ready", "confirmed"}
                and candidate.id not in target.rejected_candidate_ids
            ]
            if target
            else []
        )
        write_tested_candidate_ids = (
            [
                candidate.id
                for candidate in target.candidates
                if candidate.write_test_status == "confirmed"
            ]
            if target
            else []
        )
        locked_entries = [
            entry
            for entry in entries
            if entry.status == "locked_read_only" and valid_for_current_process(entry)
        ]
        confirmed_entries = [entry for entry in entries if entry.status == "confirmed"]
        locked = valid_for_current_process(selected) or bool(
            target and target.state.value == "locked"
        )
        unambiguous = locked or len(entries) == 1
        category, relevance = (
            (selected.category, selected.relevance)
            if selected.relevance != "unknown"
            else _feature_classification(selected.name)
        )
        evidence = [
            *selected.evidence[-6:],
            *(
                [
                    "Displayed value came from the newest local NMS save and may trail "
                    "unsaved gameplay."
                ]
                if target and target.exact_value_source == "nms_save"
                else [
                    "Displayed value was refreshed from the verified currency layout in "
                    "this same running game process."
                ]
                if target and target.exact_value_source == SAME_PROCESS_LAYOUT_SOURCE
                else ["Displayed value was supplied as visible read-only evidence."]
                if target
                else []
            ),
            (
                f"{len(write_tested_candidate_ids)} candidate locator(s) changed the visible "
                "game value in a controlled write test."
                if write_tested_candidate_ids
                else f"{len(ready_candidate_ids)} exact candidate locator(s) are ready for "
                "separate reversible in-game tests."
                if ready_candidate_ids
                else f"{len(locked_entries)} matching candidate locator(s) are locked as an "
                "equivalent read-only group for this run. Each locator remains separate for "
                "restart and write verification."
                if selected.status == "locked_read_only" and valid_for_current_process(selected)
                else f"{len(confirmed_entries)} locator(s) passed restart validation and "
                "remain separately tracked."
                if selected.status == "confirmed"
                else "A prior-run read-only lock is being revalidated for this game process."
                if selected.status == "locked_read_only"
                else f"{len(entries)} candidate locator(s) remain under read-only learning."
            ),
            "The mounted learning table grants no game-memory write authority.",
        ]
        features.append(
            GameCheatFeature(
                id=_feature_id(table.game_key, "value-table", selected.name),
                name=selected.name,
                description="Live value learned from this build's read-only game table.",
                status=(
                    "write_tested"
                    if write_tested_candidate_ids
                    else "locked_read_only"
                    if locked
                    else "test_ready"
                    if ready_candidate_ids
                    else "learning_candidate"
                ),
                source_kind="mounted_game_value_table",
                value_type=selected.value_type,
                current_value=(
                    target.exact_value
                    if target is not None
                    else selected.current_value
                    if unambiguous
                    else None
                ),
                maximum_value=selected.maximum_value if unambiguous else None,
                category=category,
                relevance=relevance,
                confidence=selected.confidence,
                available_actions=[],
                discovery_run_id=discovery_status.id if target and discovery_status else None,
                discovery_candidate_ids=ready_candidate_ids,
                write_tested_candidate_ids=write_tested_candidate_ids,
                evidence=evidence,
            )
        )
    for key, target in observed.items():
        if key in grouped:
            continue
        category, relevance = _feature_classification(target.name)
        source_label = (
            "newest local NMS save"
            if target.exact_value_source == "nms_save"
            else "verified same-process currency layout"
            if target.exact_value_source == SAME_PROCESS_LAYOUT_SOURCE
            else "visible input"
        )
        features.append(
            GameCheatFeature(
                id=_feature_id(table.game_key, "observed-value", target.name),
                name=target.name,
                description="Observed value mounted while its memory locator keeps learning.",
                status="observed_value_learning",
                source_kind="mounted_game_value_table",
                value_type=target.value_type,
                current_value=target.exact_value,
                category=category,
                relevance=relevance,
                confidence=0.5,
                available_actions=[],
                evidence=[
                    f"Read-only value source: {source_label}.",
                    "No memory locator is locked yet and no write action is available.",
                    "The mounted learning table grants no game-memory write authority.",
                ],
            )
        )
    return features


_IRRELEVANT_FEATURE = re.compile(
    r"render|shader|texture|material|lighting|mesh|\blod\b|particle|animation|"
    r"camera|viewport|transform|position|rotation|world.?stream|level.?stream|"
    r"navigation|navmesh|collision|audio|sound|area.?volume|zone.?volume",
    re.IGNORECASE,
)
_SECONDARY_FEATURE = re.compile(
    r"movement|speed|jump|gravity|flight|traversal|locomotion|sprint|jetpack",
    re.IGNORECASE,
)


def _feature_classification(name: str) -> tuple[str, str]:
    if _IRRELEVANT_FEATURE.search(name):
        return "engine_plumbing", "ignored"
    if _SECONDARY_FEATURE.search(name):
        return "movement_tuning", "secondary"
    return "player_resource", "useful"


def _refresh_catalog_counts(catalog: GameCheatCatalog) -> None:
    catalog.useful_feature_count = sum(
        feature.relevance == "useful" for feature in catalog.features
    )
    catalog.secondary_feature_count = sum(
        feature.relevance == "secondary" for feature in catalog.features
    )
