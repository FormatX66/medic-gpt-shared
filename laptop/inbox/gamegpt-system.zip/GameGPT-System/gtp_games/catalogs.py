"""Strict, cross-file validation for GameGPT's durable knowledge catalogs."""

from __future__ import annotations

import json
from datetime import date
from enum import StrEnum
from pathlib import Path
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator


class StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid")


class EvidenceState(StrEnum):
    HYPOTHESIS = "hypothesis"
    VERIFIED = "verified"
    QUARANTINED = "quarantined"
    STALE = "stale"


class PromotionState(StrEnum):
    HELD = "held"
    CANDIDATE = "candidate"
    PROMOTED = "promoted"
    RETIRED = "retired"


class BuildBinding(StrictModel):
    game_build: str = Field(min_length=1)
    fingerprint_kind: Literal[
        "executable_sha256", "sample_sha256", "platform_build", "runtime_required"
    ]
    fingerprint: str = Field(min_length=1)
    process_name: str = Field(min_length=1)
    process_identity_required: bool = True

    @model_validator(mode="after")
    def process_guard_is_required(self) -> BuildBinding:
        if not self.process_identity_required:
            raise ValueError("catalog build bindings must require process identity")
        return self


class EvidenceReference(StrictModel):
    research_id: str = Field(min_length=1)
    role: Literal["source", "observation", "reproduction", "independent_verification"]


class ProductArea(StrictModel):
    id: Literal[
        "relay_plugin",
        "desktop_workbench",
        "onscreen_companion",
        "rd_learning_engine",
        "fast_trigger_engine",
    ]
    name: str
    owns: list[str] = Field(min_length=1)
    may_consume: list[str] = Field(default_factory=list)
    forbidden: list[str] = Field(min_length=1)


class DataFlow(StrictModel):
    source: str
    destination: str
    payload: str
    gate: str


class EntrySurface(StrictModel):
    id: Literal["desktop_workbench", "onscreen_companion", "fast_trigger_engine"]
    inputs: list[str] = Field(min_length=1)
    may_discover: bool
    may_grant_write_authority: bool


class WorkflowTransition(StrictModel):
    from_state: str
    to_state: str
    condition: str
    actor: str
    requirements: list[str] = Field(min_length=1)
    failure_target: str | None = None


class WorkflowDefinition(StrictModel):
    schema_version: Literal["gamegpt.workflow.v1"]
    entry_surfaces: list[EntrySurface] = Field(min_length=3, max_length=3)
    normalized_request_fields: list[str] = Field(min_length=6)
    states: list[str] = Field(min_length=1)
    transitions: list[WorkflowTransition] = Field(min_length=1)
    invariants: list[str] = Field(min_length=1)

    @model_validator(mode="after")
    def enforce_entry_authority(self) -> WorkflowDefinition:
        surfaces = {item.id: item for item in self.entry_surfaces}
        if set(surfaces) != {
            "desktop_workbench",
            "onscreen_companion",
            "fast_trigger_engine",
        }:
            raise ValueError("the three request entry surfaces must appear exactly once")
        if surfaces["fast_trigger_engine"].may_discover:
            raise ValueError("Quick Call performs no discovery")
        if surfaces["onscreen_companion"].may_grant_write_authority:
            raise ValueError("overlay observations never grant write authority")
        if any(item.may_grant_write_authority for item in self.entry_surfaces):
            raise ValueError("entry surfaces request actions; they do not grant write authority")
        return self


class ProductDefinition(StrictModel):
    schema_version: Literal["gamegpt.product.v1"]
    product_name: Literal["GameGPT"]
    baseline_program: dict[str, str]
    product_areas: list[ProductArea] = Field(min_length=5, max_length=5)
    data_flows: list[DataFlow] = Field(min_length=1)
    solution_router_order: list[str] = Field(min_length=5, max_length=5)
    allowed_contexts: list[str] = Field(min_length=1)
    prohibited_contexts: list[str] = Field(min_length=1)

    @model_validator(mode="after")
    def all_areas_are_unique(self) -> ProductDefinition:
        ids = [area.id for area in self.product_areas]
        if len(set(ids)) != 5:
            raise ValueError("the five GameGPT product areas must appear exactly once")
        return self


class GameBuild(StrictModel):
    binding: BuildBinding
    state: EvidenceState
    notes: str


class GameProfile(StrictModel):
    id: str
    name: str
    platform_ids: dict[str, str] = Field(default_factory=dict)
    executable_names: list[str] = Field(min_length=1)
    builds: list[GameBuild] = Field(min_length=1)
    profile_state: EvidenceState
    evidence: list[EvidenceReference] = Field(min_length=1)


class GamesCatalog(StrictModel):
    schema_version: Literal["gamegpt.games.v1"]
    games: list[GameProfile]


LocatorType = Literal[
    "raw_address",
    "module_offset",
    "pointer_chain",
    "aob_signature",
    "rip_relative",
    "structural_locator",
    "behavior_control",
]


class LocatorModification(StrictModel):
    id: str
    game_id: str
    capability: str
    locator_type: LocatorType
    build_bindings: list[BuildBinding] = Field(min_length=1)
    verification_state: EvidenceState
    promotion_state: PromotionState
    mutates_state: bool
    portable_across_restart: bool
    raw_address: str | None = None
    allocation_hint: str | None = None
    locator_payload: dict[str, Any]
    preconditions: list[str] = Field(min_length=1)
    expected_current: str | None = None
    action: str
    immediate_readback: str | None = None
    delayed_readback: str | None = None
    independent_game_confirmation: str | None = None
    original_value: str | None = None
    rollback: str | None = None
    restart_behavior: str
    evidence: list[EvidenceReference] = Field(min_length=1)
    notes: str

    @model_validator(mode="after")
    def mutation_has_guards(self) -> LocatorModification:
        if self.locator_type == "raw_address" and self.portable_across_restart:
            raise ValueError("raw addresses never carry across restarts")
        if self.raw_address is not None and self.portable_across_restart:
            raise ValueError("records containing raw addresses cannot be portable")
        if self.allocation_hint is not None and self.portable_across_restart:
            raise ValueError("allocation hints never carry across restarts")
        if self.mutates_state:
            required = {
                "expected_current": self.expected_current,
                "immediate_readback": self.immediate_readback,
                "delayed_readback": self.delayed_readback,
                "original_value": self.original_value,
                "rollback": self.rollback,
            }
            missing = [name for name, value in required.items() if not value]
            if missing:
                raise ValueError(f"mutation is missing safeguards: {', '.join(missing)}")
        return self


class LocatorCatalog(StrictModel):
    schema_version: Literal["gamegpt.locators-modifications.v1"]
    portability_rule: str
    entries: list[LocatorModification]


class ScriptEntry(StrictModel):
    id: str
    source_path: str
    source_sha256: str | None = None
    game_id: str
    supported_builds: list[BuildBinding] = Field(min_length=1)
    capability: str
    parameters: list[str]
    safety_guards: list[str] = Field(min_length=1)
    dry_run_support: bool
    verification: str
    mutates_state: bool
    rollback_restore: str | None = None
    provenance: list[EvidenceReference] = Field(min_length=1)
    promotion_state: PromotionState

    @model_validator(mode="after")
    def mutation_has_rollback(self) -> ScriptEntry:
        if self.mutates_state and not self.rollback_restore:
            raise ValueError("mutating scripts require rollback or restore instructions")
        return self


class ScriptsCatalog(StrictModel):
    schema_version: Literal["gamegpt.scripts.v1"]
    scripts: list[ScriptEntry]


class SaveEditor(StrictModel):
    id: str
    game_id: str
    save_location_detection: str
    format_parser: str
    backup_strategy: str
    parse_supported: bool
    write_supported: bool
    lossless_round_trip_proven: bool
    post_write_reopen_verified: bool
    game_version_compatibility: list[BuildBinding] = Field(min_length=1)
    recovery: str
    verification_state: EvidenceState
    evidence: list[EvidenceReference] = Field(min_length=1)

    @model_validator(mode="after")
    def supported_writes_have_proof(self) -> SaveEditor:
        if self.write_supported and not (
            self.lossless_round_trip_proven and self.post_write_reopen_verified
        ):
            raise ValueError("save writes require lossless round-trip and reopen verification")
        return self


class SaveEditorsCatalog(StrictModel):
    schema_version: Literal["gamegpt.save-editors.v1"]
    editors: list[SaveEditor]


class ResearchEntry(StrictModel):
    id: str
    game_id: str | None = None
    source_reference: str = Field(min_length=1)
    retrieved_date: date | None
    source_type: Literal[
        "repository", "file", "thread", "web", "runtime_observation", "benchmark"
    ]
    claim_or_clue: str = Field(min_length=1)
    build_applicability: list[str] = Field(min_length=1)
    provenance: str = Field(min_length=1)
    reproduction_results: str
    contradictions: list[str]
    contamination_risk: Literal["low", "medium", "high"]
    inert_only: bool
    verification_state: EvidenceState


class ResearchCatalog(StrictModel):
    schema_version: Literal["gamegpt.research.v1"]
    entries: list[ResearchEntry]


class ValidatedAction(StrictModel):
    id: str
    game_id: str
    capability: str
    build_bindings: list[BuildBinding] = Field(min_length=1)
    locator_id: str | None = None
    script_id: str | None = None
    consumers: list[Literal["desktop_workbench", "onscreen_companion", "fast_trigger_engine"]]
    trigger_phrases: list[str]
    preconditions: list[str] = Field(min_length=1)
    action: str
    verification: str
    mutates_state: bool
    rollback: str | None = None
    discovery_at_activation: Literal[False] = False
    verification_state: Literal[EvidenceState.VERIFIED]
    promotion_state: Literal[PromotionState.PROMOTED]
    evidence: list[EvidenceReference] = Field(min_length=1)

    @model_validator(mode="after")
    def promoted_action_is_safe(self) -> ValidatedAction:
        if self.mutates_state and not self.rollback:
            raise ValueError("mutating validated actions require rollback")
        if not any(item.role == "independent_verification" for item in self.evidence):
            raise ValueError("validated actions require independent verification evidence")
        return self


class ValidatedActionsCatalog(StrictModel):
    schema_version: Literal["gamegpt.validated-actions.v1"]
    fast_activation_rule: str
    actions: list[ValidatedAction]


CATALOG_MODELS: dict[str, type[BaseModel]] = {
    "system/product.json": ProductDefinition,
    "system/workflow.json": WorkflowDefinition,
    "catalogs/games.json": GamesCatalog,
    "catalogs/locators-modifications.json": LocatorCatalog,
    "catalogs/scripts.json": ScriptsCatalog,
    "catalogs/save-editors.json": SaveEditorsCatalog,
    "catalogs/research.json": ResearchCatalog,
    "catalogs/validated-actions.json": ValidatedActionsCatalog,
}


def load_and_validate_catalogs(root: Path) -> dict[str, BaseModel]:
    """Validate every catalog independently, then apply cross-catalog gates."""
    parsed: dict[str, BaseModel] = {}
    for relative, model in CATALOG_MODELS.items():
        path = root / relative
        parsed[relative] = model.model_validate_json(path.read_text(encoding="utf-8"))

    games = {item.id for item in parsed["catalogs/games.json"].games}
    research = {item.id for item in parsed["catalogs/research.json"].entries}
    locators = {item.id: item for item in parsed["catalogs/locators-modifications.json"].entries}
    scripts = {item.id: item for item in parsed["catalogs/scripts.json"].scripts}

    referenced_game_ids: list[str] = []
    for relative in (
        "catalogs/locators-modifications.json",
        "catalogs/scripts.json",
        "catalogs/save-editors.json",
        "catalogs/validated-actions.json",
    ):
        collection = next(
            getattr(parsed[relative], name)
            for name in ("entries", "scripts", "editors", "actions")
            if hasattr(parsed[relative], name)
        )
        referenced_game_ids.extend(item.game_id for item in collection)
    unknown_games = sorted(set(referenced_game_ids) - games)
    if unknown_games:
        raise ValueError(f"unknown game references: {unknown_games}")

    evidence_holders: list[Any] = []
    evidence_holders.extend(parsed["catalogs/games.json"].games)
    evidence_holders.extend(parsed["catalogs/locators-modifications.json"].entries)
    evidence_holders.extend(parsed["catalogs/scripts.json"].scripts)
    evidence_holders.extend(parsed["catalogs/save-editors.json"].editors)
    evidence_holders.extend(parsed["catalogs/validated-actions.json"].actions)
    unknown_research = sorted(
        {
            ref.research_id
            for holder in evidence_holders
            for ref in (getattr(holder, "evidence", None) or getattr(holder, "provenance", []))
            if ref.research_id not in research
        }
    )
    if unknown_research:
        raise ValueError(f"unknown research references: {unknown_research}")

    for action in parsed["catalogs/validated-actions.json"].actions:
        if action.locator_id:
            locator = locators.get(action.locator_id)
            if locator is None or locator.verification_state != EvidenceState.VERIFIED:
                raise ValueError(f"action {action.id} references a non-verified locator")
        if action.script_id:
            script = scripts.get(action.script_id)
            if script is None or script.promotion_state != PromotionState.PROMOTED:
                raise ValueError(f"action {action.id} references a non-promoted script")
    return parsed


def export_json_schemas(root: Path) -> None:
    schema_dir = root / "schemas"
    schema_dir.mkdir(parents=True, exist_ok=True)
    for relative, model in CATALOG_MODELS.items():
        filename = relative.replace("/", "-").replace(".json", ".schema.json")
        payload = json.dumps(model.model_json_schema(), indent=2, sort_keys=True) + "\n"
        (schema_dir / filename).write_text(payload, encoding="utf-8")
