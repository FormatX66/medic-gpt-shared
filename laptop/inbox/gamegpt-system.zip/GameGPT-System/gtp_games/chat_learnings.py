from __future__ import annotations

import hashlib
from datetime import UTC, datetime
from pathlib import Path
from threading import RLock
from typing import Literal

from pydantic import BaseModel, Field

from gtp_games.models import ValueType


class LearnedAddress(BaseModel):
    address: int = Field(ge=0)
    address_hex: str
    value_type: ValueType
    observed_value: int | float
    current_value: int | float | None = None
    live_readable: bool = False
    verification: Literal["exact_match", "behavior_verified", "write_verified"]


class LearnedGameValue(BaseModel):
    id: str
    label: str
    game_key: str
    process_name: str
    executable: str | None = None
    game_build_identity: str | None = None
    process_started_at: float | None = None
    scan_id: str
    scan_generation: int = Field(ge=0)
    verification: Literal["exact_match", "behavior_verified", "write_verified"]
    addresses: list[LearnedAddress] = Field(default_factory=list)
    evidence: list[str] = Field(default_factory=list)
    learned_at: datetime = Field(default_factory=lambda: datetime.now(UTC))
    last_validated_at: datetime = Field(default_factory=lambda: datetime.now(UTC))
    same_build: bool = False
    same_process_incarnation: bool = False
    requires_revalidation: bool = True


class LearnedValueLedger(BaseModel):
    schema_version: str = "gtp-chat-learned-values/v1"
    records: list[LearnedGameValue] = Field(default_factory=list)


class ChatLearningStore:
    """Durable, data-only observations from conversational value scans."""

    def __init__(self, path: Path) -> None:
        self.path = path
        self._lock = RLock()

    def records(self) -> list[LearnedGameValue]:
        with self._lock:
            return [item.model_copy(deep=True) for item in self._load().records]

    def remember(
        self,
        *,
        label: str,
        game_key: str,
        process_name: str,
        executable: str | None,
        game_build_identity: str | None,
        process_started_at: float | None,
        scan_id: str,
        scan_generation: int,
        addresses: list[LearnedAddress],
        verification: Literal["exact_match", "behavior_verified", "write_verified"],
        evidence: list[str] | None = None,
    ) -> LearnedGameValue:
        normalized_label = " ".join(label.split()).strip()
        if not normalized_label:
            raise ValueError("label must not be empty")
        if len(normalized_label) > 120:
            raise ValueError("label must be at most 120 characters")
        if not addresses:
            raise ValueError("at least one learned address is required")
        if len(addresses) > 20:
            raise ValueError("narrow the scan to at most 20 candidates before remembering it")

        record_id = _record_id(
            game_key,
            game_build_identity,
            normalized_label,
            process_started_at,
        )
        now = datetime.now(UTC)
        record = LearnedGameValue(
            id=record_id,
            label=normalized_label,
            game_key=game_key,
            process_name=process_name,
            executable=executable,
            game_build_identity=game_build_identity,
            process_started_at=process_started_at,
            scan_id=scan_id,
            scan_generation=scan_generation,
            verification=verification,
            addresses=addresses,
            evidence=(evidence or [])[:20],
            learned_at=now,
            last_validated_at=now,
            same_build=True,
            same_process_incarnation=True,
            requires_revalidation=False,
        )
        with self._lock:
            ledger = self._load()
            records = [
                item
                for item in ledger.records
                if item.id != record.id
                and not (
                    item.process_name.casefold() == process_name.casefold()
                    and item.game_build_identity == game_build_identity
                    and item.process_started_at == process_started_at
                    and item.label.casefold() == normalized_label.casefold()
                )
            ]
            records.append(record)
            ledger.records = sorted(records, key=lambda item: item.last_validated_at)[-100:]
            self._write(ledger)
        return record.model_copy(deep=True)

    def _load(self) -> LearnedValueLedger:
        if not self.path.is_file():
            return LearnedValueLedger()
        try:
            return LearnedValueLedger.model_validate_json(self.path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return LearnedValueLedger()

    def _write(self, ledger: LearnedValueLedger) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        temporary = self.path.with_suffix(self.path.suffix + ".tmp")
        temporary.write_text(ledger.model_dump_json(indent=2), encoding="utf-8")
        temporary.replace(self.path)


def _record_id(
    game_key: str,
    build_identity: str | None,
    label: str,
    process_started_at: float | None,
) -> str:
    material = "|".join(
        (
            game_key.casefold(),
            build_identity or "unknown-build",
            label.casefold(),
            str(process_started_at or "unknown-process-start"),
        )
    )
    return hashlib.sha256(material.encode("utf-8")).hexdigest()[:24]
