"""Low-overhead program boundary to the frozen GameGPT relay surfaces."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Protocol

from .programs import FastCommandRegistry, MacroReceipt, MacroRunner, MacroStep, Route


@dataclass(frozen=True)
class RelayReceipt:
    ok: bool
    code: str
    message: str
    readback: dict[str, Any] = field(default_factory=dict)
    rollback_token: str | None = None


class ConversationResearchRelay(Protocol):
    def submit_research(self, request: dict[str, Any]) -> str: ...


class GuardedActuatorRelay(Protocol):
    def execute_validated_action(
        self, action_id: str, arguments: dict[str, Any]
    ) -> RelayReceipt: ...

    def rollback(self, rollback_token: str) -> RelayReceipt: ...


class QuickActionProgram:
    """Local-only fast path. It has no model, key, HTTP, or game-memory API."""

    def __init__(
        self,
        registry: FastCommandRegistry,
        actuator: GuardedActuatorRelay,
        research_relay: ConversationResearchRelay,
    ) -> None:
        self.registry = registry
        self.actuator = actuator
        self.research_relay = research_relay
        self.last_receipt: RelayReceipt | None = None

    def handle_phrase(self, phrase: str) -> RelayReceipt:
        decision = self.registry.route(phrase)
        if decision.route != Route.FAST or decision.action_id is None:
            request_id = self.research_relay.submit_research(
                {
                    "kind": "procedural_fallback",
                    "utterance": phrase,
                    "reason": decision.reason,
                    "authority_granted": False,
                }
            )
            receipt = RelayReceipt(True, "routed", f"sent to Research Builder: {request_id}")
        else:
            receipt = self.actuator.execute_validated_action(decision.action_id, {})
        self.last_receipt = receipt
        return receipt

    def run_macro(self, steps: list[MacroStep], *, dry_run: bool) -> MacroReceipt:
        rollback_tokens: dict[str, str] = {}

        def execute(step: MacroStep) -> bool:
            receipt = self.actuator.execute_validated_action(step.action_id, step.arguments)
            self.last_receipt = receipt
            if receipt.ok and receipt.rollback_token:
                rollback_tokens[step.action_id] = receipt.rollback_token
            return receipt.ok

        def rollback(step: MacroStep) -> bool:
            token = rollback_tokens.get(step.action_id)
            return bool(token and self.actuator.rollback(token).ok)

        return MacroRunner(self.registry).run(
            steps, dry_run=dry_run, execute=execute, rollback=rollback
        )


class ResearchBuilderProgram:
    """Local mission UI/orchestrator; GPT work is reachable only through the relay."""

    def __init__(self, relay: ConversationResearchRelay) -> None:
        self.relay = relay

    def submit(self, *, game_id: str, objective: str, build: str | None) -> str:
        return self.relay.submit_research(
            {
                "kind": "research_mission",
                "game_id": game_id,
                "objective": objective,
                "build": build or "unavailable",
                "authority_granted": False,
                "required_result_fields": [
                    "provenance",
                    "applicability",
                    "reproduction",
                    "contradictions",
                    "contamination_risk",
                    "verification_state",
                ],
            }
        )
