from __future__ import annotations

import csv
import fnmatch
import io
import re
import subprocess
import sys
import time
from dataclasses import dataclass

from gtp_games.models import ProcessInfo

try:
    import win32pdh
except ImportError:  # pragma: no cover - unavailable in Linux/Docker
    win32pdh = None

_PID_PATTERN = re.compile(r"GPU Engine\(pid_(\d+)_", re.IGNORECASE)
_PROCESS_INSTANCE_PATTERN = re.compile(r"\\Process\((.+)\)\\", re.IGNORECASE)
_GAME_PATH_MARKERS = (
    ("/steamapps/common/", 30, "Steam game folder"),
    ("/xboxgames/", 30, "Xbox game folder"),
    ("/epic games/", 25, "Epic game folder"),
    ("/gog games/", 25, "GOG game folder"),
    ("/games/", 15, "game folder"),
)


@dataclass(frozen=True)
class WindowsProcessMetrics:
    gpu_percent_by_pid: dict[int, float] | None
    memory_bytes_by_pid: dict[int, int]
    started_at_by_pid: dict[int, float]


def collect_windows_process_metrics() -> WindowsProcessMetrics:
    """Collect GPU use without running PDH enumeration inside the UI process."""

    if sys.platform != "win32":
        return WindowsProcessMetrics(None, {}, {})
    return WindowsProcessMetrics(collect_windows_gpu_usage(), {}, {})


_NON_GAME_NAME_PATTERNS = (
    "chrome.exe",
    "msedge.exe",
    "firefox.exe",
    "opera.exe",
    "brave.exe",
    "discord.exe",
    "slack.exe",
    "teams.exe",
    "chatgpt.exe",
    "codex*.exe",
    "code.exe",
    "explorer.exe",
    "dwm.exe",
    "searchhost.exe",
    "startmenuexperiencehost.exe",
    "shellexperiencehost.exe",
    "applicationframehost.exe",
    "phoneexperiencehost.exe",
    "docker desktop.exe",
    "nvidia overlay.exe",
    "obs*.exe",
    "steam.exe",
    "steamwebhelper.exe",
    "epicgameslauncher.exe",
    "goggalaxy*.exe",
    "battle.net*.exe",
    "gtp games companion.exe",
    "python*.exe",
    "powershell.exe",
    "pwsh.exe",
    "cmd.exe",
)


def collect_windows_gpu_usage() -> dict[int, float] | None:
    """Return GPU use through a bounded helper process that cannot freeze Tk."""

    if sys.platform != "win32":
        return None
    try:
        result = subprocess.run(
            ["typeperf", r"\GPU Engine(*)\Utilization Percentage", "-sc", "2"],
            capture_output=True,
            text=True,
            timeout=4,
            creationflags=int(getattr(subprocess, "CREATE_NO_WINDOW", 0)),
        )
    except (OSError, subprocess.SubprocessError, UnicodeError):
        return None
    if result.returncode != 0:
        return None
    return parse_typeperf_gpu_output(result.stdout)


def _collect_gpu_usage_with_pdh() -> dict[int, float] | None:
    if win32pdh is None:
        return None
    query = None
    try:
        query = win32pdh.OpenQuery()
        paths = win32pdh.ExpandCounterPath(r"\GPU Engine(*)\Utilization Percentage")
        counters: list[tuple[int, object]] = []
        for path in paths:
            match = _PID_PATTERN.search(path)
            if match is None:
                continue
            try:
                counters.append((int(match.group(1)), win32pdh.AddCounter(query, path)))
            except Exception:
                continue
        if not counters:
            return None
        win32pdh.CollectQueryData(query)
        time.sleep(0.25)
        win32pdh.CollectQueryData(query)
        usage: dict[int, float] = {}
        for pid, counter in counters:
            try:
                _, raw_value = win32pdh.GetFormattedCounterValue(counter, win32pdh.PDH_FMT_DOUBLE)
            except Exception:
                continue
            value = max(0.0, min(100.0, float(raw_value)))
            usage[pid] = max(usage.get(pid, 0.0), value)
        return usage
    except Exception:
        return None
    finally:
        if query is not None:
            try:
                win32pdh.CloseQuery(query)
            except Exception:
                pass


def _collect_process_metrics_with_pdh() -> WindowsProcessMetrics | None:
    if win32pdh is None:
        return None
    query = None
    try:
        query = win32pdh.OpenQuery()
        counters: list[tuple[str, int | str, int, object]] = []
        specs = (
            ("gpu", r"\GPU Engine(*)\Utilization Percentage", win32pdh.PDH_FMT_DOUBLE),
            ("pid", r"\Process(*)\ID Process", win32pdh.PDH_FMT_LARGE),
            (
                "memory",
                r"\Process(*)\Working Set - Private",
                win32pdh.PDH_FMT_LARGE,
            ),
            ("elapsed", r"\Process(*)\Elapsed Time", win32pdh.PDH_FMT_DOUBLE),
        )
        for kind, wildcard, value_format in specs:
            for path in win32pdh.ExpandCounterPath(wildcard):
                if kind == "gpu":
                    match = _PID_PATTERN.search(path)
                    key: int | str | None = int(match.group(1)) if match else None
                else:
                    match = _PROCESS_INSTANCE_PATTERN.search(path)
                    key = match.group(1) if match else None
                if key is None:
                    continue
                try:
                    counter = win32pdh.AddCounter(query, path)
                except Exception:
                    continue
                counters.append((kind, key, value_format, counter))
        if not counters:
            return None

        win32pdh.CollectQueryData(query)
        time.sleep(0.25)
        win32pdh.CollectQueryData(query)
        sampled_at = time.time()
        gpu_usage: dict[int, float] = {}
        instance_pids: dict[str, int] = {}
        instance_memory: dict[str, int] = {}
        instance_elapsed: dict[str, float] = {}
        for kind, key, value_format, counter in counters:
            try:
                _, raw_value = win32pdh.GetFormattedCounterValue(counter, value_format)
                value = float(raw_value)
            except Exception:
                continue
            if kind == "gpu":
                pid = int(key)
                percent = max(0.0, min(100.0, value))
                gpu_usage[pid] = max(gpu_usage.get(pid, 0.0), percent)
            elif kind == "pid":
                instance_pids[str(key)] = int(value)
            elif kind == "memory":
                instance_memory[str(key)] = max(0, int(value))
            else:
                instance_elapsed[str(key)] = max(0.0, value)

        memory_by_pid: dict[int, int] = {}
        started_at_by_pid: dict[int, float] = {}
        for instance, pid in instance_pids.items():
            if instance in instance_memory:
                memory_by_pid[pid] = instance_memory[instance]
            if instance in instance_elapsed:
                started_at_by_pid[pid] = sampled_at - instance_elapsed[instance]
        return WindowsProcessMetrics(gpu_usage, memory_by_pid, started_at_by_pid)
    except Exception:
        return None
    finally:
        if query is not None:
            try:
                win32pdh.CloseQuery(query)
            except Exception:
                pass


def parse_typeperf_gpu_output(output: str) -> dict[int, float]:
    rows = list(csv.reader(io.StringIO(output)))
    for index, header in enumerate(rows[:-1]):
        if not header or not header[0].startswith("(PDH-CSV"):
            continue
        values = next(
            (row for row in reversed(rows[index + 1 :]) if len(row) == len(header)),
            None,
        )
        if values is None:
            return {}
        usage: dict[int, float] = {}
        for counter, raw_value in zip(header[1:], values[1:], strict=True):
            match = _PID_PATTERN.search(counter)
            if match is None:
                continue
            try:
                value = max(0.0, min(100.0, float(raw_value)))
            except ValueError:
                continue
            pid = int(match.group(1))
            usage[pid] = max(usage.get(pid, 0.0), value)
        return usage
    return {}


def classify_process(process: ProcessInfo) -> ProcessInfo:
    score = 0
    reasons: list[str] = []
    gpu = process.gpu_percent or 0.0
    memory_mb = (process.memory_bytes or 0) / (1024 * 1024)

    if gpu >= 40:
        score += 55
        reasons.append(f"heavy GPU use ({gpu:.0f}%)")
    elif gpu >= 15:
        score += 50
        reasons.append(f"high GPU use ({gpu:.0f}%)")
    elif gpu >= 5:
        score += 45
        reasons.append(f"active GPU use ({gpu:.1f}%)")
    elif gpu >= 1:
        score += 35
        reasons.append(f"some GPU use ({gpu:.1f}%)")
    elif gpu >= 0.1:
        score += 18
        reasons.append(f"light GPU use ({gpu:.1f}%)")

    if memory_mb >= 4096:
        score += 30
        reasons.append(f"large RAM use ({memory_mb / 1024:.1f} GB)")
    elif memory_mb >= 2048:
        score += 25
        reasons.append(f"high RAM use ({memory_mb / 1024:.1f} GB)")
    elif memory_mb >= 1024:
        score += 25
        reasons.append(f"high RAM use ({memory_mb / 1024:.1f} GB)")
    elif memory_mb >= 512:
        score += 12
        reasons.append(f"RAM use ({memory_mb:.0f} MB)")
    elif memory_mb >= 256:
        score += 5

    normalized_path = (process.executable or "").replace("\\", "/").casefold()
    for marker, points, reason in _GAME_PATH_MARKERS:
        if marker in normalized_path:
            score += points
            reasons.append(reason)
            break

    normalized_name = process.name.casefold()
    if "shipping.exe" in normalized_name or normalized_name.endswith("-win64.exe"):
        score += 15
        reasons.append("game-style executable name")

    known_non_game = any(
        fnmatch.fnmatch(normalized_name, pattern) for pattern in _NON_GAME_NAME_PATTERNS
    )
    if known_non_game:
        score -= 60
        reasons.append("known desktop or system application")

    score = max(0, min(100, score))
    return process.model_copy(
        update={
            "game_score": score,
            "likely_game": score >= 55 and not known_non_game,
            "game_reasons": reasons,
        }
    )


def enrich_process_metrics(
    processes: list[ProcessInfo],
    gpu_usage: dict[int, float] | None,
) -> list[ProcessInfo]:
    enriched: list[ProcessInfo] = []
    for process in processes:
        gpu_percent = gpu_usage.get(process.pid, 0.0) if gpu_usage is not None else None
        enriched.append(classify_process(process.model_copy(update={"gpu_percent": gpu_percent})))
    return enriched
