from __future__ import annotations

import secrets
import sys
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from threading import Event, Lock, RLock, Thread
from uuid import uuid4

from gtp_games.audit import AuditLogger
from gtp_games.codec import decode_value, encode_value, value_size
from gtp_games.config import Settings
from gtp_games.discovery import DiscoveryManager
from gtp_games.errors import BackendError, ConfigurationError, NotFoundError, SafetyError
from gtp_games.game_accelerators import (
    AcceleratorValueEvidence,
    GameAcceleratorPack,
    builtin_accelerator_sources,
    builtin_instruction_recipes,
)
from gtp_games.game_catalog import GameCatalogManager
from gtp_games.game_identity import executable_build_identity
from gtp_games.game_tables import (
    export_game_value_table,
    load_game_value_table,
    register_discovery_candidates,
    select_portable_game_value_table,
)
from gtp_games.instruction_values import (
    InstructionValueEngine,
    InstructionValueObserverManager,
    InstructionValueObserverStatus,
    InstructionValueRecipe,
)
from gtp_games.inventory_observer import (
    InstructionObservationBackend,
    InventoryInstructionEngine,
    InventoryObservationStore,
    InventoryObserverManager,
    InventoryObserverStatus,
    InventorySlotObservation,
    default_instruction_observer,
)
from gtp_games.inventory_reference import build_default_inventory_reference_registry
from gtp_games.locator_recipes import builtin_signature_pointer_locators
from gtp_games.locators import LocatorEngine
from gtp_games.memory.base import MemoryBackend
from gtp_games.memory.simulated import SimulatedMemoryBackend
from gtp_games.memory.windows import WindowsMemoryBackend
from gtp_games.models import (
    CheatAction,
    CheatDiscoveryRunStatus,
    CheatTableResult,
    CheatTableSourceBuild,
    Comparison,
    DiscoveryCandidate,
    GameCheatCatalog,
    GameCheatFeature,
    GameProfileMonitorStatus,
    GameValueTable,
    GameValueTableExportResult,
    HealthBarResult,
    HoldIntentView,
    HoldStatus,
    InventoryScreenResult,
    LocatorKind,
    MemoryLocator,
    MemoryRegion,
    NmsSaveComparisonReport,
    ProcessInfo,
    ProcessSession,
    RollbackResult,
    SavedInventoryLiveResolution,
    SavedInventoryResult,
    SavedInventoryStack,
    ScanActivity,
    ScanCandidateStability,
    ScanSummary,
    UnrealDiscoveryResult,
    UnrealGasMonitorStatus,
    UnrealGasProfile,
    UnrealGasProfileValue,
    UnrealGasScanSummary,
    UnrealGasTemporalResult,
    UnrealGasWatchResult,
    ValidationRule,
    ValueType,
    WatchResult,
    WebCheatDiscoveryResult,
    WriteIntentView,
    WriteResult,
)
from gtp_games.nms_save import compare_save_files, read_inventory_snapshot
from gtp_games.safety import SafetyPolicy
from gtp_games.save_evidence import build_default_save_evidence_registry
from gtp_games.saved_inventory_live import SavedInventoryLiveResolver
from gtp_games.scanner import ScanEngine
from gtp_games.unreal import UnrealGasEngine
from gtp_games.web_discovery import WebCheatDiscovery


@dataclass
class WriteIntent:
    id: str
    session_id: str
    address: int
    value_type: ValueType
    expected_current: int | float
    new_value: int | float
    expected_bytes: bytes
    new_bytes: bytes
    reason: str
    created_at: datetime
    expires_at: datetime
    confirmation_phrase: str
    profile_id: str | None = None
    used: bool = False

    def view(self) -> WriteIntentView:
        return WriteIntentView(
            id=self.id,
            session_id=self.session_id,
            address=self.address,
            value_type=self.value_type,
            expected_current=self.expected_current,
            new_value=self.new_value,
            reason=self.reason,
            expires_at=self.expires_at,
            confirmation_phrase=self.confirmation_phrase,
        )


@dataclass
class RollbackRecord:
    token: str
    original_receipt_id: str
    operation_id: str
    session_id: str
    pid: int
    process_started_at: float | None
    address: int
    value_type: ValueType
    original_bytes: bytes
    written_bytes: bytes
    used: bool = False


@dataclass
class HoldIntent:
    id: str
    session_id: str
    feature_id: str
    feature_name: str
    profile_id: str
    address: int
    value_type: ValueType
    expected_current: int | float
    hold_value: int | float
    expected_bytes: bytes
    hold_bytes: bytes
    interval_ms: int
    duration_seconds: int
    reason: str
    expires_at: datetime
    confirmation_phrase: str
    used: bool = False

    def view(self) -> HoldIntentView:
        return HoldIntentView(
            id=self.id,
            session_id=self.session_id,
            feature_id=self.feature_id,
            feature_name=self.feature_name,
            address=self.address,
            value_type=self.value_type,
            expected_current=self.expected_current,
            hold_value=self.hold_value,
            interval_ms=self.interval_ms,
            duration_seconds=self.duration_seconds,
            reason=self.reason,
            expires_at=self.expires_at,
            confirmation_phrase=self.confirmation_phrase,
        )


@dataclass
class ActiveHold:
    id: str
    session_id: str
    feature_id: str
    feature_name: str
    profile_id: str
    address: int
    value_type: ValueType
    hold_value: int | float
    hold_bytes: bytes
    interval_ms: int
    started_at: datetime
    expires_at: datetime
    reason: str
    stop_event: Event
    write_count: int = 0
    stopped_reason: str | None = None
    thread: Thread | None = None

    def view(self) -> HoldStatus:
        active = (
            not self.stop_event.is_set()
            and self.stopped_reason is None
            and datetime.now(UTC) < self.expires_at
        )
        return HoldStatus(
            id=self.id,
            session_id=self.session_id,
            feature_id=self.feature_id,
            feature_name=self.feature_name,
            address=self.address,
            value_type=self.value_type,
            hold_value=self.hold_value,
            interval_ms=self.interval_ms,
            started_at=self.started_at,
            expires_at=self.expires_at,
            active=active,
            write_count=self.write_count,
            stopped_reason=self.stopped_reason,
        )


class ApplicationService:
    def __init__(
        self,
        settings: Settings,
        backend: MemoryBackend | None = None,
        *,
        instruction_observer_backend: InstructionObservationBackend | None = None,
    ) -> None:
        self.settings = settings
        self.instance_id = uuid4().hex
        self.started_at = datetime.now(UTC)
        self.backend = backend or self._create_backend(settings)
        self.safety = SafetyPolicy(settings)
        self.audit = AuditLogger(settings.audit_log_path)
        self.scans = ScanEngine(self.backend, settings)
        self.locators = LocatorEngine(
            self.backend,
            max_scan_bytes=settings.max_scan_bytes,
            max_region_bytes=settings.max_scan_region_bytes,
            chunk_bytes=settings.scan_chunk_bytes,
            max_aob_scan_bytes=settings.max_unreal_code_scan_bytes,
        )
        observer_backend = instruction_observer_backend or default_instruction_observer()
        self.inventory_observation_store = InventoryObservationStore(
            settings.inventory_observations_path
        )
        self.inventory_instruction_observer = InventoryInstructionEngine(
            self.backend,
            self.locators,
            observer_backend,
            self.inventory_observation_store,
        )
        self.saved_inventory_live = SavedInventoryLiveResolver(
            self.backend,
            self.inventory_observation_store,
            scan_chunk_bytes=settings.scan_chunk_bytes,
        )
        self.inventory_observers = InventoryObserverManager(
            self.inventory_instruction_observer
        )
        self.instruction_value_engine = InstructionValueEngine(
            self.backend,
            self.locators,
            observer_backend,
        )
        self.instruction_value_observers = InstructionValueObserverManager(
            self.instruction_value_engine
        )
        self.unreal = UnrealGasEngine(self.backend, settings)
        self.catalogs = GameCatalogManager(self.backend, settings, self.unreal)
        self.inventory_references = build_default_inventory_reference_registry()
        self.save_evidence = build_default_save_evidence_registry()
        self._sessions: dict[str, ProcessSession] = {}
        self._intents: dict[str, WriteIntent] = {}
        self._operation_receipts: dict[str, tuple[tuple[object, ...], WriteResult]] = {}
        self._rollback_records: dict[str, RollbackRecord] = {}
        self._hold_intents: dict[str, HoldIntent] = {}
        self._holds: dict[str, ActiveHold] = {}
        self._lock = RLock()
        self._scan_operation_lock = Lock()
        self._scan_activity_lock = RLock()
        self._scan_activity: ScanActivity | None = None
        self.discovery = DiscoveryManager(self)

    @property
    def active_session_count(self) -> int:
        with self._lock:
            return len(self._sessions)

    @property
    def write_receipt_count(self) -> int:
        with self._lock:
            return len(self._rollback_records)

    def list_processes(self) -> list[ProcessInfo]:
        processes: list[ProcessInfo] = []
        for process in self.backend.list_processes():
            try:
                self.safety.validate_process(process, write_enabled=False)
            except SafetyError as exc:
                process = process.model_copy(
                    update={
                        "attachable": False,
                        "blocked_reason": str(exc),
                        "likely_game": False,
                    }
                )
            processes.append(process)
        return processes

    def attach(
        self,
        pid: int,
        *,
        write_enabled: bool = False,
        game_key: str | None = None,
        game_name: str | None = None,
        table_path: str | None = None,
        start_catalog_discovery: bool = True,
    ) -> ProcessSession:
        process = self.backend.find_process(pid)
        if process is None:
            raise NotFoundError(f"process {pid} was not found")
        self.safety.validate_process(process, write_enabled=write_enabled)
        with self._lock:
            session = next(
                (
                    item
                    for item in self._sessions.values()
                    if _same_process_incarnation(item, process)
                    and item.write_enabled == write_enabled
                ),
                None,
            )
            reused = session is not None
            if session is None:
                handle = self.backend.attach(pid, write_enabled=write_enabled)
                session = ProcessSession(
                    id=uuid4().hex,
                    pid=process.pid,
                    process_name=process.name,
                    executable=process.executable,
                    process_started_at=process.started_at,
                    game_key=game_key,
                    game_name=game_name,
                    write_enabled=write_enabled,
                    backend_name=self.backend.name,
                    backend_handle=handle,
                )
                self._sessions[session.id] = session
            else:
                if (
                    session.game_key is not None
                    and game_key is not None
                    and session.game_key.casefold() != game_key.casefold()
                ):
                    raise SafetyError(
                        "the live process already belongs to a different game session"
                    )
                if session.game_key is None and game_key is not None:
                    session.game_key = game_key
                if session.game_name is None and game_name is not None:
                    session.game_name = game_name
        if table_path:
            try:
                selection = select_portable_game_value_table(
                    self.settings,
                    session,
                    table_path,
                )
            except Exception:
                if not reused:
                    with self._lock:
                        self._sessions.pop(session.id, None)
                    self.backend.close(session.backend_handle)
                raise
            session.selected_table_path = selection.selected_path
            session.selected_table_status = selection.status
        if start_catalog_discovery:
            try:
                self.catalogs.get(session.id)
            except KeyError:
                self.catalogs.begin_first_connection(session)
        self.audit.record(
            "process_attach_reused" if reused else "process_attached",
            session_id=session.id,
            pid=session.pid,
            process_name=session.process_name,
            game_key=session.game_key,
            game_name=session.game_name,
            selected_table_path=session.selected_table_path,
            selected_table_status=session.selected_table_status,
            write_enabled=write_enabled,
        )
        return session

    def detach(self, session_id: str) -> None:
        self._detach_session(session_id, stop_discovery=True)

    def release_discovery_session(self, session_id: str) -> None:
        """Release a dead process handle without stopping its supervising run."""

        self._detach_session(session_id, stop_discovery=False)

    def _detach_session(self, session_id: str, *, stop_discovery: bool) -> None:
        self.inventory_observers.cancel_session(session_id)
        self.instruction_value_observers.cancel_session(session_id)
        if stop_discovery:
            self.discovery.stop_session(session_id)
        self._stop_session_holds(session_id, "game session detached")
        self.unreal.stop_session_monitors(session_id)
        with self._lock:
            session = self._get_session(session_id)
            del self._sessions[session_id]
            rollback_tokens = [
                token
                for token, record in self._rollback_records.items()
                if record.session_id == session_id
            ]
            for token in rollback_tokens:
                del self._rollback_records[token]
            operation_ids = [
                operation_id
                for operation_id, (fingerprint, _result) in self._operation_receipts.items()
                if fingerprint[0] == session_id
            ]
            for operation_id in operation_ids:
                del self._operation_receipts[operation_id]
        self.backend.close(session.backend_handle)
        self.scans.remove_session(session_id)
        self.unreal.remove_session(session_id)
        self.catalogs.remove_session(session_id)
        self.audit.record(
            "process_detached",
            session_id=session_id,
            pid=session.pid,
            invalidated_rollback_receipts=len(rollback_tokens),
            invalidated_operation_receipts=len(operation_ids),
        )

    def regions(self, session_id: str) -> list[MemoryRegion]:
        session = self._get_session(session_id)
        return self.backend.regions(session.backend_handle)

    def read_value(
        self,
        session_id: str,
        address: int,
        value_type: ValueType,
    ) -> int | float:
        session = self._get_session(session_id)
        width = value_size(value_type)
        self._region_for(session, address, width, require_readable=True)
        return decode_value(
            value_type,
            self.backend.read(session.backend_handle, address, width),
        )

    def write_direct_value(
        self,
        session_id: str,
        address: int,
        value_type: ValueType,
        new_value: int | float,
        *,
        expected_current: int | float | None = None,
        operation_id: str | None = None,
    ) -> WriteResult:
        """Write one typed scalar to the selected game and verify it immediately."""

        session = self._get_session(session_id)
        new_bytes = encode_value(value_type, new_value)
        normalized_operation_id = operation_id.strip() if operation_id else uuid4().hex
        if not normalized_operation_id:
            raise SafetyError("operation_id must not be blank")
        fingerprint: tuple[object, ...] = (
            session.id,
            session.pid,
            session.process_started_at,
            address,
            value_type.value,
            new_bytes,
            None if expected_current is None else encode_value(value_type, expected_current),
        )
        with self._lock:
            prior = self._operation_receipts.get(normalized_operation_id)
            if prior is not None:
                prior_fingerprint, prior_result = prior
                if prior_fingerprint != fingerprint:
                    raise SafetyError("operation_id was already used for a different write")
                return prior_result.model_copy(update={"replayed": True})
        region = self._region_for(session, address, len(new_bytes), require_readable=True)
        reason = "explicit user-directed raw game value change"
        self.safety.validate_direct_write(
            session,
            region,
            address=address,
            size=len(new_bytes),
            reason=reason,
        )
        actual_bytes = self.backend.read(session.backend_handle, address, len(new_bytes))
        previous_value = decode_value(value_type, actual_bytes)
        if expected_current is not None:
            expected_bytes = encode_value(value_type, expected_current)
            if actual_bytes != expected_bytes:
                raise SafetyError(
                    f"expected current value {expected_current}, but the address now contains "
                    f"{previous_value}"
                )

        write_id = uuid4().hex
        if actual_bytes != new_bytes:
            self.backend.write(session.backend_handle, address, new_bytes)
        verified_bytes = self.backend.read(session.backend_handle, address, len(new_bytes))
        if verified_bytes != new_bytes:
            raise SafetyError("direct write verification failed")
        result = self._write_receipt(
            session=session,
            intent_id=write_id,
            operation_id=normalized_operation_id,
            address=address,
            value_type=value_type,
            original_bytes=actual_bytes,
            written_bytes=verified_bytes,
        )
        with self._lock:
            self._operation_receipts[normalized_operation_id] = (fingerprint, result)
        self.audit.record(
            "direct_raw_value_write_verified",
            intent_id=write_id,
            session_id=session.id,
            pid=session.pid,
            address=f"0x{address:X}",
            value_type=value_type,
            previous_value=previous_value,
            new_value=result.new_value,
            verified=True,
            operation_id=normalized_operation_id,
            receipt_id=result.receipt_id,
            rollback_token=result.rollback_token,
        )
        return result

    def rollback_direct_write(self, rollback_token: str) -> RollbackResult:
        """Restore one verified write after a fresh same-session comparison."""

        token = rollback_token.strip()
        with self._lock:
            record = self._rollback_records.get(token)
            if record is None:
                raise NotFoundError("rollback token was not found")
            if record.used:
                raise SafetyError("this rollback token has already been used")
            session = self._get_session(record.session_id)
            if (
                session.pid != record.pid
                or session.process_started_at != record.process_started_at
            ):
                raise SafetyError("the original game process is no longer attached")
            region = self._region_for(
                session,
                record.address,
                len(record.written_bytes),
                require_readable=True,
            )
            self.safety.validate_direct_write(
                session,
                region,
                address=record.address,
                size=len(record.written_bytes),
                reason="rollback one verified GameGPT write",
            )
            current_bytes = self.backend.read(
                session.backend_handle, record.address, len(record.written_bytes)
            )
            if current_bytes != record.written_bytes:
                current = decode_value(record.value_type, current_bytes)
                expected = decode_value(record.value_type, record.written_bytes)
                raise SafetyError(
                    f"rollback refused because the value changed from {expected} to {current}"
                )
            self.backend.write(session.backend_handle, record.address, record.original_bytes)
            verified_bytes = self.backend.read(
                session.backend_handle, record.address, len(record.original_bytes)
            )
            if verified_bytes != record.original_bytes:
                raise SafetyError("rollback verification failed")
            record.used = True
            cached = self._operation_receipts.get(record.operation_id)
            if cached is not None:
                fingerprint, original = cached
                self._operation_receipts[record.operation_id] = (
                    fingerprint,
                    original.model_copy(
                        update={"status": "rolled_back", "rollback_available": False}
                    ),
                )

        receipt_id = uuid4().hex
        result = RollbackResult(
            receipt_id=receipt_id,
            rollback_token=token,
            original_receipt_id=record.original_receipt_id,
            address=record.address,
            value_type=record.value_type,
            previous_value=decode_value(record.value_type, current_bytes),
            restored_value=decode_value(record.value_type, verified_bytes),
            verified=True,
        )
        self.audit.record(
            "direct_raw_value_rollback_verified",
            receipt_id=receipt_id,
            original_receipt_id=record.original_receipt_id,
            session_id=session.id,
            pid=session.pid,
            address=f"0x{record.address:X}",
            value_type=record.value_type,
            restored_value=result.restored_value,
            verified=True,
        )
        return result

    def _write_receipt(
        self,
        *,
        session: ProcessSession,
        intent_id: str,
        operation_id: str,
        address: int,
        value_type: ValueType,
        original_bytes: bytes,
        written_bytes: bytes,
    ) -> WriteResult:
        receipt_id = uuid4().hex
        rollback_token = uuid4().hex
        with self._lock:
            self._rollback_records[rollback_token] = RollbackRecord(
                token=rollback_token,
                original_receipt_id=receipt_id,
                operation_id=operation_id,
                session_id=session.id,
                pid=session.pid,
                process_started_at=session.process_started_at,
                address=address,
                value_type=value_type,
                original_bytes=original_bytes,
                written_bytes=written_bytes,
            )
        readback = decode_value(value_type, written_bytes)
        return WriteResult(
            intent_id=intent_id,
            operation_id=operation_id,
            receipt_id=receipt_id,
            address=address,
            value_type=value_type,
            previous_value=decode_value(value_type, original_bytes),
            new_value=readback,
            verified=True,
            readback_value=readback,
            rollback_token=rollback_token,
            rollback_available=True,
        )

    def start_scan(
        self,
        session_id: str,
        value_type: ValueType,
        value: int | float,
    ) -> ScanSummary:
        session = self._get_session(session_id)
        summary = self._run_scan_operation(
            session_id,
            "Exact value scan",
            lambda progress: self.scans.initial_exact_scan(
                session,
                value_type,
                value,
                progress=progress,
            ),
        )
        self.audit.record(
            "scan_started",
            session_id=session_id,
            scan_id=summary.id,
            value_type=value_type,
            result_count=summary.result_count,
            truncated=summary.truncated,
        )
        return summary

    def register_targeted_exact_candidates(
        self,
        session_id: str,
        value_type: ValueType,
        value: int | float,
        addresses: list[int],
    ) -> ScanSummary:
        """Validate a small structurally-derived address set without a broad scan."""

        session = self._get_session(session_id)
        summary = self.scans.register_targeted_exact_candidates(
            session,
            value_type,
            value,
            addresses,
        )
        self.audit.record(
            "targeted_exact_candidates_registered",
            session_id=session.id,
            scan_id=summary.id,
            value_type=value_type,
            result_count=summary.result_count,
            scanned_bytes=summary.scanned_bytes,
            game_memory_write=False,
        )
        return summary

    def start_unknown_scan(
        self,
        session_id: str,
        value_type: ValueType,
        *,
        normalized: bool = False,
    ) -> ScanSummary:
        session = self._get_session(session_id)
        summary = self._run_scan_operation(
            session_id,
            "Unknown value scan",
            lambda progress: self.scans.initial_unknown_scan(
                session,
                value_type,
                normalized=normalized,
                progress=progress,
            ),
        )
        self.audit.record(
            "unknown_scan_started",
            session_id=session_id,
            scan_id=summary.id,
            value_type=value_type,
            normalized=normalized,
            result_count=summary.result_count,
            scanned_bytes=summary.scanned_bytes,
            scope_truncated=summary.scope_truncated,
        )
        return summary

    def rescan(
        self,
        scan_id: str,
        comparison: Comparison,
        value: int | float | None = None,
    ) -> ScanSummary:
        existing = self.scans.summary(scan_id, limit=0)
        session = self._get_session(existing.session_id)
        summary = self._run_scan_operation(
            session.id,
            f"Refine scan: {comparison.value}",
            lambda progress: self.scans.rescan(
                scan_id,
                session,
                comparison,
                value,
                progress=progress,
            ),
        )
        self.audit.record(
            "scan_refined",
            session_id=session.id,
            scan_id=scan_id,
            comparison=comparison,
            generation=summary.generation,
            result_count=summary.result_count,
        )
        return summary

    def scan_summary(self, scan_id: str, *, limit: int = 20) -> ScanSummary:
        return self.scans.summary(scan_id, limit=limit)

    def reuse_exact_scan(
        self,
        session_id: str,
        value_type: ValueType,
        value: int | float,
    ) -> ScanSummary | None:
        return self.scans.reuse_exact_scan(
            self._get_session(session_id),
            value_type,
            value,
        )

    def clone_scan(self, scan_id: str) -> ScanSummary:
        existing = self.scans.summary(scan_id, limit=0)
        self._get_session(existing.session_id)
        return self.scans.clone(scan_id, existing.session_id)

    def discard_scan(self, scan_id: str) -> None:
        self.scans.discard(scan_id)

    def scan_candidate_stability(
        self,
        scan_id: str,
        *,
        limit: int = 200,
    ) -> list[ScanCandidateStability]:
        return self.scans.candidate_stability(scan_id, limit=limit)

    def scan_activity(self) -> ScanActivity | None:
        with self._scan_activity_lock:
            return self._scan_activity.model_copy() if self._scan_activity else None

    def _run_scan_operation(self, session_id: str, operation: str, work) -> ScanSummary:
        with self._scan_operation_lock:
            activity = ScanActivity(
                operation_id=uuid4().hex,
                session_id=session_id,
                operation=operation,
                state="loading",
                message=f"{operation} is loading",
            )
            with self._scan_activity_lock:
                self._scan_activity = activity

            def progress(
                processed_bytes: int,
                total_bytes: int,
                processed_regions: int,
                total_regions: int,
                result_count: int,
            ) -> None:
                with self._scan_activity_lock:
                    if self._scan_activity is None:
                        return
                    self._scan_activity.processed_bytes = processed_bytes
                    self._scan_activity.total_bytes = total_bytes
                    self._scan_activity.processed_regions = processed_regions
                    self._scan_activity.total_regions = total_regions
                    self._scan_activity.result_count = result_count
                    self._scan_activity.message = (
                        f"{operation} is loading: {processed_regions}/{total_regions} regions"
                    )

            try:
                summary = work(progress)
            except Exception as exc:
                with self._scan_activity_lock:
                    activity.state = "failed"
                    activity.error = str(exc)
                    activity.message = f"{operation} failed"
                raise
            with self._scan_activity_lock:
                activity.state = "completed"
                activity.total_bytes = activity.total_bytes or summary.scanned_bytes
                activity.processed_bytes = activity.total_bytes
                activity.processed_regions = summary.selected_region_count
                activity.total_regions = summary.selected_region_count
                activity.result_count = summary.result_count
                activity.scan_id = summary.id
                activity.cache_backed = summary.cache_backed
                activity.message = f"{operation} ready: {summary.result_count} candidates" + (
                    "; snapshot cached" if summary.cache_backed else ""
                )
            return summary

    def watch_scan(
        self,
        scan_id: str,
        *,
        sample_count: int = 5,
        interval_ms: int = 500,
        limit: int = 20,
    ) -> WatchResult:
        existing = self.scans.summary(scan_id, limit=0)
        session = self._get_session(existing.session_id)
        return self.scans.watch(
            scan_id,
            session,
            sample_count=sample_count,
            interval_ms=interval_ms,
            limit=limit,
        )

    def detect_health_bars(
        self,
        session_id: str,
        *,
        x: int | None = None,
        y: int | None = None,
        width: int | None = None,
        height: int | None = None,
        limit: int = 5,
    ) -> HealthBarResult:
        session = self._get_session(session_id)
        supplied = (x, y, width, height)
        if any(value is not None for value in supplied) and not all(
            value is not None for value in supplied
        ):
            raise SafetyError("provide x, y, width, and height together")
        region = None if x is None else (x, y, width, height)
        from gtp_games.screen_capture import capture_and_detect_health_bars

        return capture_and_detect_health_bars(
            session_id,
            session.pid,
            region=region,
            limit=limit,
        )

    def read_inventory_screen(self, session_id: str) -> InventoryScreenResult:
        session = self._get_session(session_id)
        from gtp_games.inventory_capture import capture_and_read_inventory

        result = capture_and_read_inventory(session_id, session.pid)
        source = self.inventory_references.source(session.game_key or "")
        if source is None or result.capture_status != "captured":
            if source is None:
                result.guide_url = None
            return result
        result.reference_catalog_checked = True
        result.reference_source = source
        raw_selected_label = result.selected_item_label
        labels = {
            label
            for label in [
                result.selected_item_label,
                *(item.item_label for item in result.detections),
            ]
            if label
        }
        matches = {}
        for label in labels:
            try:
                matches[label] = self.inventory_references.match(session.game_key or "", label)
            except Exception:  # noqa: BLE001 - online naming never blocks local observation
                matches[label] = None
        if raw_selected_label:
            selected_match = matches.get(raw_selected_label)
            if selected_match is not None:
                result.selected_item_label = selected_match.canonical_name
        for detection in result.detections:
            raw_label = detection.item_label
            if raw_label is None and detection.selected:
                raw_label = raw_selected_label
            if raw_label is None:
                continue
            detection.raw_item_label = raw_label
            match = matches.get(raw_label)
            if match is not None:
                detection.item_label = match.canonical_name
                detection.reference_url = match.reference_url
                detection.reference_confidence = match.confidence
        return result

    def read_saved_inventory(
        self,
        session_id: str | None = None,
        *,
        limit: int = 250,
    ) -> SavedInventoryResult:
        """Read structured inventory stacks from the newest local NMS save only."""

        if not 1 <= limit <= 2_000:
            raise SafetyError("the saved inventory limit must be between 1 and 2000")
        session = self._get_session(session_id) if session_id is not None else None
        if session is not None:
            game_key = "-".join((session.game_key or "").casefold().replace("'", "").split())
            if session.process_name.casefold() != "nms.exe" and game_key not in {
                "nms",
                "no-man-s-sky",
                "no-mans-sky",
            }:
                raise SafetyError("saved inventory reading is currently supported only for NMS.exe")
        snapshot = read_inventory_snapshot()
        if snapshot is None:
            raise SafetyError("the newest local No Man's Sky save was not found")
        selected = list(snapshot.stacks[:limit])
        game_key = (session.game_key if session is not None else None) or "no-man-s-sky"
        source = self.inventory_references.source(game_key)
        matches = {}
        catalog_checked = False
        if source is not None:
            try:
                for stack in selected:
                    key = (stack.item_id, stack.item_type)
                    if key not in matches:
                        matches[key] = self.inventory_references.match_id(
                            game_key,
                            stack.item_id,
                            stack.item_type,
                        )
                catalog_checked = True
            except Exception:  # noqa: BLE001 - online naming never blocks local save evidence
                matches = {}
        stacks = []
        for stack in selected:
            match = matches.get((stack.item_id, stack.item_type))
            stacks.append(
                SavedInventoryStack(
                    **stack.__dict__,
                    item_name=match.canonical_name if match is not None else None,
                    reference_url=match.reference_url if match is not None else None,
                    reference_source=match.source if match is not None else None,
                )
            )
        result = SavedInventoryResult(
            session_id=session.id if session is not None else None,
            pid=session.pid if session is not None else None,
            save_profile=snapshot.save_path.parent.name,
            save_filename=snapshot.save_path.name,
            modified_at=snapshot.modified_at,
            total_stacks=len(snapshot.stacks),
            returned_stacks=len(stacks),
            visited_nodes=snapshot.visited_nodes,
            truncated=snapshot.truncated or len(snapshot.stacks) > len(stacks),
            reference_catalog_checked=catalog_checked,
            reference_source=source if catalog_checked else None,
            provenance=[
                (
                    "NMSSaveEditor 1.21.0 commit 6047315f47321e2a8400d38bf8d904bcca88bb8d "
                    "inert jsonmap.txt and slot.json field semantics; no packaged code executed."
                ),
                (
                    "nmsmc commit a44308e8d6ea6cc0c05869b8ac473a61fdbd3a7c "
                    "MIT-licensed container taxonomy only; modded example limits excluded."
                ),
                "Newest local NMS save read without copying or changing it.",
            ],
            stacks=stacks,
        )
        self.audit.record(
            "saved_inventory_read_only",
            session_id=session_id,
            save_profile=result.save_profile,
            save_filename=result.save_filename,
            total_stacks=result.total_stacks,
            returned_stacks=result.returned_stacks,
            game_memory_write=False,
            imported_code_executed=False,
        )
        return result

    def resolve_saved_inventory_stack(
        self,
        session_id: str,
        item_id: str,
        *,
        container_name: str | None = "Inventory",
        stack_size_group: str | None = "Personal",
        full_scan: bool = False,
        limit: int = 20,
    ) -> SavedInventoryLiveResolution:
        """Resolve one saved NMS stack in live RAM using current-process structural hints."""

        session = self._get_session(session_id)
        snapshot = read_inventory_snapshot()
        if snapshot is None:
            raise SafetyError("the newest local No Man's Sky save was not found")
        result = self.saved_inventory_live.resolve(
            session,
            snapshot,
            item_id=item_id,
            container_name=container_name,
            stack_size_group=stack_size_group,
            full_scan=full_scan,
            limit=limit,
        )
        self.audit.record(
            "saved_inventory_live_resolved_read_only",
            session_id=session_id,
            item_id=result.item_id,
            search_mode=result.search_mode,
            scanned_bytes=result.scanned_bytes,
            candidate_count=result.candidate_count,
            scope_truncated=result.scope_truncated,
            game_memory_write=False,
            imported_code_executed=False,
        )
        return result

    def observe_moved_inventory_slot(
        self,
        session_id: str,
        *,
        timeout_seconds: float = 20,
        recipe_name: str | None = None,
    ) -> InventorySlotObservation:
        session = self._get_session(session_id)
        result = self.inventory_instruction_observer.observe(
            session,
            timeout_seconds=timeout_seconds,
            recipe_name=recipe_name,
        )
        self.audit.record(
            "inventory_instruction_observed_read_only",
            session_id=session_id,
            recipe_name=result.recipe_name,
            status=result.status,
            signature_match_count=result.signature_match_count,
            identity_key=result.identity_key,
            count=result.count,
            maximum=result.maximum,
            debugger_detached=result.debugger_detached,
            game_memory_write=False,
        )
        return result

    def start_moved_inventory_observer(
        self,
        session_id: str,
        *,
        timeout_seconds: float = 20,
        recipe_name: str | None = None,
    ) -> InventoryObserverStatus:
        session = self._get_session(session_id)
        result = self.inventory_observers.start(
            session,
            timeout_seconds=timeout_seconds,
            recipe_name=recipe_name,
        )
        try:
            self.audit.record(
                "inventory_observer_armed_read_only",
                session_id=session_id,
                observer_token=result.token,
                recipe_name=result.recipe_name,
                anchor=f"0x{result.anchor_address:X}",
                armed_at=result.armed_at.isoformat() if result.armed_at else None,
                deadline=result.deadline.isoformat() if result.deadline else None,
                game_memory_write=False,
            )
        except Exception:
            self.inventory_observers.cancel(session_id, result.token)
            raise
        return result

    def moved_inventory_observer_status(
        self,
        session_id: str,
        observer_token: str,
        *,
        wait_seconds: float = 0,
    ) -> InventoryObserverStatus:
        return self.inventory_observers.status(
            session_id,
            observer_token,
            wait_seconds=wait_seconds,
        )

    def cancel_moved_inventory_observer(
        self,
        session_id: str,
        observer_token: str,
    ) -> InventoryObserverStatus:
        result = self.inventory_observers.cancel(session_id, observer_token)
        self.audit.record(
            "inventory_observer_cancelled_read_only",
            session_id=session_id,
            observer_token=observer_token,
            state=result.state,
            debugger_detached=bool(result.finished_at),
            game_memory_write=False,
        )
        return result

    def start_instruction_value_observer(
        self,
        session_id: str,
        recipe: InstructionValueRecipe,
        *,
        timeout_seconds: float = 20,
    ) -> InstructionValueObserverStatus:
        session = self._get_session(session_id)
        result = self.instruction_value_observers.start(
            session,
            recipe,
            timeout_seconds=timeout_seconds,
        )
        try:
            self.audit.record(
                "instruction_value_observer_armed_read_only",
                session_id=session_id,
                observer_token=result.token,
                recipe_name=result.recipe_name,
                instruction_address=f"0x{result.instruction_address:X}",
                armed_at=result.armed_at.isoformat() if result.armed_at else None,
                deadline=result.deadline.isoformat() if result.deadline else None,
                source_label=recipe.source_label,
                source_sha256=recipe.source_sha256,
                game_memory_write=False,
                target_code_patched=False,
            )
        except Exception:
            self.instruction_value_observers.cancel(session_id, result.token)
            raise
        return result

    def instruction_value_observer_status(
        self,
        session_id: str,
        observer_token: str,
        *,
        wait_seconds: float = 0,
    ) -> InstructionValueObserverStatus:
        return self.instruction_value_observers.status(
            session_id,
            observer_token,
            wait_seconds=wait_seconds,
        )

    def cancel_instruction_value_observer(
        self,
        session_id: str,
        observer_token: str,
    ) -> InstructionValueObserverStatus:
        result = self.instruction_value_observers.cancel(session_id, observer_token)
        self.audit.record(
            "instruction_value_observer_cancelled_read_only",
            session_id=session_id,
            observer_token=observer_token,
            state=result.state,
            debugger_detached=bool(result.finished_at),
            game_memory_write=False,
            target_code_patched=False,
        )
        return result

    def inspect_cheat_table(
        self,
        session_id: str,
        source: str,
        *,
        query: str = "health",
        limit: int = 50,
        source_build: CheatTableSourceBuild | None = None,
    ) -> CheatTableResult:
        session = self._get_session(session_id)
        normalized_source = source.strip()
        if not normalized_source:
            raise SafetyError("provide a local .CT path or public HTTPS table URL")
        from gtp_games.cheat_tables import inspect_cheat_table, inspect_cheat_table_url

        if normalized_source.casefold().startswith("https://"):
            result = inspect_cheat_table_url(
                normalized_source,
                backend=self.backend,
                session=session,
                max_bytes=self.settings.max_cheat_table_bytes,
                max_signature_scan_bytes=self.settings.max_scan_bytes,
                query=query,
                limit=limit,
                source_build=source_build,
            )
        elif "://" in normalized_source:
            raise SafetyError("remote tables must use a public HTTPS URL")
        else:
            result = inspect_cheat_table(
                normalized_source,
                backend=self.backend,
                session=session,
                max_bytes=self.settings.max_cheat_table_bytes,
                max_signature_scan_bytes=self.settings.max_scan_bytes,
                query=query,
                limit=limit,
                source_build=source_build,
            )
        self.audit.record(
            "cheat_table_inspected_read_only",
            session_id=session_id,
            source_kind=result.source_kind,
            hint_count=result.hint_count,
            ignored_script_count=result.ignored_script_count,
            build_compatibility=result.build_compatibility,
            live_validation_performed=result.live_validation_performed,
            query=query,
        )
        return result

    def import_cheat_table_reference(
        self,
        source: str,
        *,
        query: str = "",
        limit: int = 200,
        source_build: CheatTableSourceBuild | None = None,
    ) -> CheatTableResult:
        normalized_source = source.strip()
        if not normalized_source:
            raise SafetyError("provide a local .CT path or public HTTPS table URL")
        from gtp_games.cheat_tables import (
            import_cheat_table_reference,
            import_cheat_table_reference_url,
        )

        if normalized_source.casefold().startswith("https://"):
            result = import_cheat_table_reference_url(
                normalized_source,
                max_bytes=self.settings.max_cheat_table_bytes,
                query=query,
                limit=limit,
                source_build=source_build,
            )
        elif "://" in normalized_source:
            raise SafetyError("remote tables must use a public HTTPS URL")
        else:
            result = import_cheat_table_reference(
                normalized_source,
                max_bytes=self.settings.max_cheat_table_bytes,
                query=query,
                limit=limit,
                source_build=source_build,
            )
        self.audit.record(
            "cheat_table_imported_reference_only",
            source_kind=result.source_kind,
            source_sha256=result.source_sha256,
            hint_count=result.hint_count,
            ignored_script_count=result.ignored_script_count,
            locator_pattern_count=result.locator_pattern_count,
            game_memory_write=False,
            auto_assembler_executed=False,
            lua_executed=False,
        )
        return result

    def prepare_game_cheat_action(
        self,
        session_id: str,
        feature_id: str,
        action: CheatAction,
        value: int | float | None = None,
        *,
        interval_ms: int = 250,
        duration_seconds: int = 300,
    ) -> WriteIntentView | HoldIntentView:
        session, feature, resolved = self._resolve_confirmed_feature(session_id, feature_id)
        selected_value = value
        if selected_value is None:
            selected_value = resolved.likely_max_value
        if selected_value is None:
            raise SafetyError(
                f"{feature.name} has no confirmed maximum; provide the desired value explicitly"
            )
        self.scans.register_verified_candidate(
            session.id,
            resolved.address,
            resolved.profile.value_type,
            resolved.value,
        )
        reason = f"User-requested local offline-game {feature.name} {action.value}"
        if action is CheatAction.SET:
            return self.prepare_write(
                session.id,
                resolved.address,
                resolved.profile.value_type,
                resolved.value,
                selected_value,
                reason,
                profile_id=feature.profile_id,
            )
        return self._prepare_hold(
            session,
            feature,
            resolved.address,
            resolved.profile.value_type,
            resolved.value,
            selected_value,
            interval_ms=interval_ms,
            duration_seconds=duration_seconds,
            reason=reason,
        )

    def confirm_hold(self, intent_id: str, confirmation_phrase: str) -> HoldStatus:
        with self._lock:
            intent = self._get_hold_intent(intent_id)
            if intent.used:
                raise SafetyError("this hold intent has already been used")
            if datetime.now(UTC) >= intent.expires_at:
                raise SafetyError("this hold intent has expired")
            if not secrets.compare_digest(confirmation_phrase, intent.confirmation_phrase):
                raise SafetyError("the confirmation phrase does not match")
            active_count = sum(item.view().active for item in self._holds.values())
            if active_count >= self.settings.max_active_holds:
                raise SafetyError("the maximum number of active value holds has been reached")
            session = self._get_session(intent.session_id)
            region = self._region_for(
                session, intent.address, len(intent.hold_bytes), require_readable=True
            )
            self.safety.validate_write(
                session,
                region,
                address=intent.address,
                size=len(intent.hold_bytes),
                is_scan_candidate=self.scans.is_candidate(
                    session.id, intent.address, intent.value_type
                ),
                reason=intent.reason,
            )
            actual_bytes = self.backend.read(
                session.backend_handle, intent.address, len(intent.expected_bytes)
            )
            if actual_bytes != intent.expected_bytes:
                raise SafetyError("the value changed after confirmation was prepared; start again")
            intent.used = True

        initial_writes = 0
        if actual_bytes != intent.hold_bytes:
            self.backend.write(session.backend_handle, intent.address, intent.hold_bytes)
            verified = self.backend.read(
                session.backend_handle, intent.address, len(intent.hold_bytes)
            )
            if verified != intent.hold_bytes:
                raise SafetyError("initial hold write verification failed")
            initial_writes = 1
        now = datetime.now(UTC)
        hold = ActiveHold(
            id=uuid4().hex,
            session_id=session.id,
            feature_id=intent.feature_id,
            feature_name=intent.feature_name,
            profile_id=intent.profile_id,
            address=intent.address,
            value_type=intent.value_type,
            hold_value=intent.hold_value,
            hold_bytes=intent.hold_bytes,
            interval_ms=intent.interval_ms,
            started_at=now,
            expires_at=now + timedelta(seconds=intent.duration_seconds),
            reason=intent.reason,
            stop_event=Event(),
            write_count=initial_writes,
        )
        hold.thread = Thread(
            target=self._hold_worker,
            args=(hold,),
            name=f"gtp-hold-{hold.id[:8]}",
            daemon=True,
        )
        with self._lock:
            self._holds[hold.id] = hold
        hold.thread.start()
        self.audit.record(
            "game_cheat_hold_started",
            hold_id=hold.id,
            session_id=session.id,
            feature_id=hold.feature_id,
            feature_name=hold.feature_name,
            address=f"0x{hold.address:X}",
            value_type=hold.value_type,
            hold_value=hold.hold_value,
            interval_ms=hold.interval_ms,
            duration_seconds=intent.duration_seconds,
        )
        return hold.view()

    def list_holds(self, session_id: str) -> list[HoldStatus]:
        self._get_session(session_id)
        with self._lock:
            return [item.view() for item in self._holds.values() if item.session_id == session_id]

    def stop_hold(self, hold_id: str) -> HoldStatus:
        with self._lock:
            hold = self._holds.get(hold_id)
            if hold is None:
                raise NotFoundError(f"value hold {hold_id} was not found")
            if hold.stopped_reason is None:
                hold.stopped_reason = "stopped by local user request"
            hold.stop_event.set()
            result = hold.view()
        self.audit.record(
            "game_cheat_hold_stopped",
            hold_id=hold.id,
            session_id=hold.session_id,
            reason=hold.stopped_reason,
            write_count=hold.write_count,
        )
        return result

    def game_cheat_catalog(self, session_id: str) -> GameCheatCatalog:
        session = self._get_session(session_id)
        try:
            catalog = self.catalogs.get(session_id)
        except KeyError as exc:
            raise NotFoundError("the first-connection game catalog was not found") from exc
        try:
            table = load_game_value_table(self.settings, session)
            discovery_status = self.discovery.latest_status_for_session(
                session_id,
                process_started_at=session.process_started_at,
            )
            return self.catalogs.sync_game_value_table(session, table, discovery_status)
        except OSError:
            return catalog

    def game_value_table(self, session_id: str) -> GameValueTable:
        session = self._get_session(session_id)
        return load_game_value_table(self.settings, session)

    def build_game_accelerator_pack(self, session_id: str) -> GameAcceleratorPack:
        """Mount fast local/source evidence and stage corroborated portable locators."""

        session = self._get_session(session_id)
        build_identity = executable_build_identity(session.executable)
        if not build_identity:
            raise SafetyError("the selected game's exact executable build could not be read")
        recipes = builtin_instruction_recipes(session.process_name, build_identity)
        sources = builtin_accelerator_sources(session.process_name, build_identity)
        game_key = session.game_key or session.process_name
        snapshot = self.save_evidence.read(game_key)
        values: list[AcceleratorValueEvidence] = []
        discovered: list[DiscoveryCandidate] = []
        currency_recipe = next(
            (item for item in recipes if item.name == "nms-currency-block-v1"),
            None,
        )
        if currency_recipe is not None:
            units_field = next(item for item in currency_recipe.fields if item.name == "Units")
            unit_locators = builtin_signature_pointer_locators(session, "Units")
            try:
                units_address = self.locators.resolve(session, unit_locators[0])
            except (BackendError, NotFoundError, SafetyError, IndexError) as exc:
                values.append(
                    AcceleratorValueEvidence(
                        name="NMS currency block",
                        value_type=ValueType.U32,
                        status="locator_not_resolved",
                        evidence=[str(exc)[:300]],
                    )
                )
            else:
                root_address = units_address - units_field.offset
                for field in currency_recipe.fields:
                    address = root_address + field.offset
                    live_value = self.read_value(session_id, address, field.value_type)
                    external_value = (
                        snapshot.values.get(field.name) if snapshot is not None else None
                    )
                    corroborated = external_value is not None and live_value == external_value
                    evidence = [
                        "Resolved from one unique exact-build signature-pointer currency root."
                    ]
                    if corroborated:
                        evidence.append(
                            "The newest read-only local save independently reports the same value."
                        )
                    values.append(
                        AcceleratorValueEvidence(
                            name=field.name,
                            value_type=field.value_type,
                            address=address,
                            address_hex=f"0x{address:X}",
                            live_value=live_value,
                            external_value=external_value,
                            corroborated=corroborated,
                            status=(
                                "live_and_save_corroborated"
                                if corroborated
                                else "live_only_needs_semantic_validation"
                            ),
                            evidence=evidence,
                        )
                    )
                    if not corroborated:
                        continue
                    field_locators = builtin_signature_pointer_locators(session, field.name)
                    if not field_locators:
                        continue
                    discovered.append(
                        DiscoveryCandidate(
                            id=f"accelerator-{field.name.casefold()}-{address:X}",
                            target=field.name,
                            reference_name=field.name,
                            value_type=field.value_type,
                            locator=field_locators[0],
                            current_value=live_value,
                            validation_rule=ValidationRule(
                                minimum_change_events=1,
                                minimum_launches=2,
                                require_unique_aob=True,
                                require_non_raw_locator=True,
                                require_source_correlation=True,
                                notes=[
                                    "Current-launch RAM/save corroboration is complete.",
                                    "A later process launch is still required for promotion.",
                                ],
                            ),
                            confidence=0.88,
                            validated_events=1,
                            validated_launches=1,
                            validated_process_starts=(
                                [session.process_started_at]
                                if session.process_started_at is not None
                                else []
                            ),
                            source_correlated=True,
                            locked_for_run=True,
                            write_test_status="untested",
                            evidence=evidence,
                        )
                    )
        if discovered:
            register_discovery_candidates(self.settings, session, discovered)
        result = GameAcceleratorPack(
            session_id=session.id,
            pid=session.pid,
            process_name=session.process_name,
            game_key=game_key,
            game_name=session.game_name,
            build_identity=build_identity,
            values=values,
            instruction_recipes=recipes,
            sources=sources,
            mounted_candidate_names=[item.reference_name or item.target for item in discovered],
            online_refresh_required=not bool(sources),
            notes=[
                "Local cached/build-bound accelerators mount without waiting on the network.",
                "Public code and CT scripts are reference-only and never executed.",
                "Corroborated locators remain candidates until restart-safe validation completes.",
            ],
        )
        self.audit.record(
            "game_accelerator_pack_mounted_read_only",
            session_id=session_id,
            build_identity=build_identity,
            value_count=len(values),
            corroborated_count=sum(item.corroborated for item in values),
            recipe_count=len(recipes),
            mounted_candidate_names=result.mounted_candidate_names,
            game_memory_write=False,
            imported_code_executed=False,
        )
        return result

    def discover_public_game_sources(self, session_id: str) -> WebCheatDiscoveryResult:
        """Refresh bounded public metadata explicitly; never block the attach path."""

        session = self._get_session(session_id)
        build_identity = executable_build_identity(session.executable)
        game_key = session.game_key or session.process_name
        game_name = session.game_name or session.process_name.removesuffix(".exe")
        result = WebCheatDiscovery(self.settings).discover(
            game_name=game_name,
            game_key=game_key,
            game_build_identity=build_identity,
        )
        self.audit.record(
            "public_game_accelerators_refreshed_reference_only",
            session_id=session_id,
            build_identity=build_identity,
            source_count=len(result.sources),
            status=result.status,
            game_memory_write=False,
            imported_code_executed=False,
        )
        return result

    def resolve_memory_locator(self, session_id: str, locator: MemoryLocator) -> int:
        session = self._get_session(session_id)
        return self.locators.resolve(session, locator)

    def register_verified_persistent_locators(
        self,
        session_id: str,
        *,
        label: str,
        value_type: ValueType,
        addresses: list[int],
    ) -> GameValueTable:
        """Discover stable locators for up to five already write-verified mirrors."""

        session = self._get_session(session_id)
        discovered: list[DiscoveryCandidate] = []
        seen: set[str] = set()
        verified_addresses = list(dict.fromkeys(addresses))[:5]
        recipe_locators = builtin_signature_pointer_locators(session, label)
        recipe_matches: dict[int, list[MemoryLocator]] = {}
        for locator in recipe_locators:
            try:
                resolved = self.locators.resolve(session, locator)
            except (BackendError, NotFoundError, SafetyError):
                continue
            if resolved in verified_addresses:
                recipe_matches.setdefault(resolved, []).append(locator)
        for address in verified_addresses:
            current_value = self.read_value(session_id, address, value_type)
            locators = recipe_matches.get(address, [])
            if not recipe_matches:
                locators = self.locators.find_pointer_chains(
                    session,
                    address,
                    max_depth=3,
                    max_offset=0x100000,
                    max_results=5,
                )
            for locator in locators:
                if locator.kind is LocatorKind.RAW_ADDRESS:
                    continue
                locator_key = locator.model_dump_json()
                if locator_key in seen or self.locators.resolve(session, locator) != address:
                    continue
                seen.add(locator_key)
                process_starts = (
                    [session.process_started_at]
                    if session.process_started_at is not None
                    else []
                )
                discovered.append(
                    DiscoveryCandidate(
                        id=f"write-verified-{address:X}-{len(discovered)}",
                        target=label,
                        reference_name=label,
                        value_type=value_type,
                        locator=locator,
                        current_value=current_value,
                        validation_rule=ValidationRule(
                            minimum_change_events=1,
                            minimum_launches=2,
                            require_non_raw_locator=True,
                            require_source_correlation=False,
                            notes=[
                                "Requires resolution on a later process launch before promotion."
                            ],
                        ),
                        confidence=0.82,
                        validated_events=1,
                        validated_launches=1,
                        validated_process_starts=process_starts,
                        source_correlated=True,
                        locked_for_run=True,
                        write_test_status="confirmed",
                        evidence=[
                            "The target address had prior write/readback verification.",
                            (
                                "A unique code signature decoded a runtime pointer back to "
                                "that address in this launch."
                                if locator.kind is LocatorKind.AOB_POINTER
                                else (
                                    "A non-raw locator resolved back to that address in this "
                                    "launch."
                                )
                            ),
                            "A later process launch must resolve it again before promotion.",
                        ],
                    )
                )
        if discovered:
            table = register_discovery_candidates(
                self.settings,
                session,
                discovered,
                replace_target=label,
            )
        else:
            table = load_game_value_table(self.settings, session)
        self.audit.record(
            "persistent_locators_discovered_read_only",
            session_id=session_id,
            label=label,
            verified_address_count=len(addresses),
            persistent_locator_count=len(discovered),
            game_memory_write=False,
        )
        return table

    def revalidate_persistent_value_locators(self, session_id: str) -> GameValueTable:
        """Resolve fast pointer, module, or signature locators across process launches."""

        session = self._get_session(session_id)
        table = load_game_value_table(self.settings, session)
        discovered: list[DiscoveryCandidate] = []
        for entry in [*table.confirmed_features, *table.candidate_features]:
            locator = entry.locator
            if not locator or locator.kind not in {
                LocatorKind.MODULE_OFFSET,
                LocatorKind.POINTER_CHAIN,
                LocatorKind.AOB_POINTER,
            }:
                continue
            try:
                address = self.locators.resolve(session, locator)
                current_value = self.read_value(session_id, address, entry.value_type)
            except (BackendError, NotFoundError, SafetyError):
                continue
            process_starts = list(dict.fromkeys(entry.validated_process_starts))
            if (
                session.process_started_at is not None
                and session.process_started_at not in process_starts
            ):
                process_starts.append(session.process_started_at)
            launches = max(entry.validated_launches, len(process_starts))
            was_write_verified = entry.write_test_status == "confirmed"
            rule = entry.validation_rule or ValidationRule(
                minimum_change_events=1,
                minimum_launches=2,
                require_non_raw_locator=True,
                require_source_correlation=False,
            )
            discovered.append(
                DiscoveryCandidate(
                    id=f"restart-validation-{entry.id}",
                    target=entry.name,
                    reference_name=entry.name,
                    value_type=entry.value_type,
                    locator=locator,
                    current_value=current_value,
                    validation_rule=rule,
                    confidence=(
                        max(entry.confidence, 0.9)
                        if was_write_verified and launches >= 2
                        else entry.confidence
                    ),
                    validated_events=max(
                        entry.validated_events,
                        1 if was_write_verified else 0,
                    ),
                    validated_launches=launches,
                    validated_process_starts=process_starts,
                    source_correlated=entry.source_correlated or was_write_verified,
                    locked_for_run=True,
                    write_test_status=entry.write_test_status,
                    evidence=[
                        *entry.evidence[-17:],
                        "The saved non-raw locator resolved and was readable this launch.",
                    ],
                )
            )
        if discovered:
            by_target: dict[str, list[DiscoveryCandidate]] = {}
            for item in discovered:
                by_target.setdefault(item.target, []).append(item)
            for target, target_candidates in by_target.items():
                table = register_discovery_candidates(
                    self.settings,
                    session,
                    target_candidates,
                    replace_target=target,
                )
        self.audit.record(
            "persistent_locators_revalidated_read_only",
            session_id=session_id,
            resolved_count=len(discovered),
            game_memory_write=False,
        )
        return table

    def compare_nms_saves(
        self,
        *,
        older_filename: str | None = None,
        newer_filename: str | None = None,
        limit: int = 250,
    ) -> NmsSaveComparisonReport:
        result = compare_save_files(
            older_filename=older_filename,
            newer_filename=newer_filename,
            limit=limit,
        )
        self.audit.record(
            "nms_saves_compared_read_only",
            older=result.older.filename,
            newer=result.newer.filename,
            changed_fields=result.total_changed_fields,
            game_memory_write=False,
            save_file_write=False,
        )
        return result

    def export_game_value_table(self, session_id: str) -> GameValueTableExportResult:
        session = self._get_session(session_id)
        result = export_game_value_table(self.settings, session)
        self.audit.record(
            "game_value_table_exported",
            session_id=session_id,
            game_key=result.table.game_key,
            game_build_identity=result.table.game_build_identity,
            confirmed_count=len(result.table.confirmed_features),
            candidate_count=len(result.table.candidate_features),
            exported_path=result.exported_path,
            game_memory_write=False,
        )
        return result

    def add_game_cheat_sources(
        self,
        session_id: str,
        sources: list[str],
        *,
        query: str = "health stamina mana money gold",
    ) -> GameCheatCatalog:
        session = self._get_session(session_id)
        if not sources:
            raise SafetyError("provide at least one local .CT path or public HTTPS table URL")
        result = self.catalogs.add_sources(session, sources, query=query)
        self.audit.record(
            "game_cheat_sources_inspected_read_only",
            session_id=session_id,
            source_count=len(sources),
            feature_count=len(result.features),
            query=query,
        )
        return result

    def locate_unreal_engine(self, session_id: str) -> UnrealDiscoveryResult:
        session = self._get_session(session_id)
        result = self.unreal.locate(session)
        self.audit.record(
            "unreal_gworld_located_read_only",
            session_id=session_id,
            pattern=result.selected_pattern,
            gworld_slot=f"0x{result.gworld_slot:X}" if result.gworld_slot else None,
            world_address=f"0x{result.world_address:X}" if result.world_address else None,
            scanned_bytes=result.scanned_bytes,
        )
        return result

    def start_unreal_gas_scan(
        self,
        session_id: str,
        value_types: list[ValueType] | None = None,
    ) -> UnrealGasScanSummary:
        session = self._get_session(session_id)
        result = self.unreal.start(session, value_types)
        self.audit.record(
            "unreal_gas_snapshot_started_read_only",
            session_id=session_id,
            scan_id=result.id,
            object_count=result.object_count,
            field_count=result.field_count,
            result_count=result.result_count,
        )
        return result

    def refine_unreal_gas_scan(
        self,
        scan_id: str,
        comparison: Comparison,
        value: int | float | None = None,
    ) -> UnrealGasScanSummary:
        existing = self.unreal.summary(scan_id, limit=0)
        session = self._get_session(existing.session_id)
        result = self.unreal.refine(scan_id, session, comparison, value)
        self.audit.record(
            "unreal_gas_snapshot_refined_read_only",
            session_id=session.id,
            scan_id=scan_id,
            comparison=comparison,
            generation=result.generation,
            result_count=result.result_count,
        )
        return result

    def start_unreal_table_guided_scan(
        self,
        scan_id: str,
        *,
        pawn_pointer_offset: int = 0xD30,
        pointer_radius: int = 0x100,
        health_offset: int = 0x1A4,
        max_health_offset: int = 0xE18,
        nested_state_offset: int = 0x150,
        replica_percent_offset: int = 0x12C,
    ) -> UnrealGasScanSummary:
        existing = self.unreal.summary(scan_id, limit=0)
        session = self._get_session(existing.session_id)
        result = self.unreal.start_table_guided(
            scan_id,
            session,
            pawn_pointer_offset=pawn_pointer_offset,
            pointer_radius=pointer_radius,
            health_offset=health_offset,
            max_health_offset=max_health_offset,
            nested_state_offset=nested_state_offset,
            replica_percent_offset=replica_percent_offset,
        )
        self.audit.record(
            "unreal_table_guided_snapshot_started_read_only",
            session_id=session.id,
            source_scan_id=scan_id,
            scan_id=result.id,
            object_count=result.object_count,
            field_count=result.field_count,
            pawn_pointer_offset=f"0x{pawn_pointer_offset:X}",
            pointer_radius=f"0x{pointer_radius:X}",
        )
        return result

    def unreal_gas_scan_summary(
        self,
        scan_id: str,
        *,
        limit: int = 20,
    ) -> UnrealGasScanSummary:
        return self.unreal.summary(scan_id, limit=limit)

    def watch_unreal_gas_scan(
        self,
        scan_id: str,
        *,
        sample_count: int = 5,
        interval_ms: int = 500,
        limit: int = 20,
    ) -> UnrealGasWatchResult:
        existing = self.unreal.summary(scan_id, limit=0)
        session = self._get_session(existing.session_id)
        return self.unreal.watch(
            scan_id,
            session,
            sample_count=sample_count,
            interval_ms=interval_ms,
            limit=limit,
        )

    def capture_unreal_gas_damage_refill(
        self,
        scan_id: str,
        *,
        sample_count: int = 30,
        interval_ms: int = 500,
        group_limit: int = 10,
    ) -> UnrealGasTemporalResult:
        existing = self.unreal.summary(scan_id, limit=0)
        session = self._get_session(existing.session_id)
        result = self.unreal.capture_damage_refill(
            scan_id,
            session,
            sample_count=sample_count,
            interval_ms=interval_ms,
            group_limit=group_limit,
        )
        self.audit.record(
            "unreal_gas_damage_refill_captured_read_only",
            session_id=session.id,
            scan_id=scan_id,
            sample_count=sample_count,
            sampled_field_count=result.sampled_field_count,
            matched_field_count=result.matched_field_count,
            group_count=result.group_count,
        )
        return result

    def start_unreal_gas_damage_monitor(
        self,
        scan_id: str,
        *,
        interval_ms: int = 500,
        duration_seconds: int = 300,
        group_limit: int = 10,
    ) -> UnrealGasMonitorStatus:
        existing = self.unreal.summary(scan_id, limit=0)
        session = self._get_session(existing.session_id)
        result = self.unreal.start_damage_monitor(
            scan_id,
            session,
            interval_ms=interval_ms,
            duration_seconds=duration_seconds,
            group_limit=group_limit,
        )
        self.audit.record(
            "unreal_gas_damage_monitor_started_read_only",
            session_id=session.id,
            scan_id=scan_id,
            monitor_id=result.id,
            interval_ms=interval_ms,
            duration_seconds=duration_seconds,
        )
        return result

    def unreal_gas_damage_monitor_status(
        self,
        monitor_id: str,
    ) -> UnrealGasMonitorStatus:
        return self.unreal.damage_monitor_status(monitor_id)

    def stop_unreal_gas_damage_monitor(
        self,
        monitor_id: str,
    ) -> UnrealGasMonitorStatus:
        result = self.unreal.stop_damage_monitor(monitor_id)
        self.audit.record(
            "unreal_gas_damage_monitor_stopped_read_only",
            session_id=result.session_id,
            scan_id=result.scan_id,
            monitor_id=result.id,
            matched_field_count=result.matched_field_count,
            group_count=result.group_count,
        )
        return result

    def start_unreal_game_profile_monitor(
        self,
        scan_id: str,
        *,
        interval_ms: int = 1000,
        duration_seconds: int = 900,
        candidate_limit: int = 50,
    ) -> GameProfileMonitorStatus:
        existing = self.unreal.summary(scan_id, limit=0)
        session = self._get_session(existing.session_id)
        result = self.unreal.start_game_profile_monitor(
            scan_id,
            session,
            interval_ms=interval_ms,
            duration_seconds=duration_seconds,
            candidate_limit=candidate_limit,
        )
        self.audit.record(
            "unreal_full_game_profile_monitor_started_read_only",
            session_id=session.id,
            scan_id=scan_id,
            monitor_id=result.id,
            interval_ms=interval_ms,
            duration_seconds=duration_seconds,
            game_memory_write=False,
        )
        return result

    def unreal_game_profile_monitor_status(
        self,
        monitor_id: str,
    ) -> GameProfileMonitorStatus:
        return self.unreal.game_profile_monitor_status(monitor_id)

    def stop_unreal_game_profile_monitor(
        self,
        monitor_id: str,
    ) -> GameProfileMonitorStatus:
        result = self.unreal.stop_game_profile_monitor(monitor_id)
        self.audit.record(
            "unreal_full_game_profile_monitor_stopped_read_only",
            session_id=result.session_id,
            scan_id=result.scan_id,
            monitor_id=result.id,
            sampled_field_count=result.sampled_field_count,
            changed_field_count=result.changed_field_count,
            candidate_count=result.candidate_count,
            saved_path=result.saved_path,
            game_memory_write=False,
        )
        return result

    def save_unreal_gas_profile(
        self,
        scan_id: str,
        address: int,
        value_type: ValueType,
        name: str = "Health",
    ) -> UnrealGasProfile:
        existing = self.unreal.summary(scan_id, limit=0)
        session = self._get_session(existing.session_id)
        result = self.unreal.save_profile(
            scan_id,
            session,
            address,
            value_type,
            name=name,
        )
        self.audit.record(
            "unreal_gas_profile_saved_local",
            session_id=session.id,
            scan_id=scan_id,
            profile_id=result.id,
            address=f"0x{address:X}",
            value_type=value_type,
            saved_path=result.saved_path,
            game_memory_write=False,
        )
        return result

    def read_unreal_gas_profile(
        self,
        session_id: str,
        profile_id: str,
    ) -> UnrealGasProfileValue:
        session = self._get_session(session_id)
        result = self.unreal.read_profile(session, profile_id)
        self.audit.record(
            "unreal_gas_profile_resolved_read_only",
            session_id=session_id,
            profile_id=profile_id,
            address=f"0x{result.address:X}",
            game_memory_write=False,
        )
        return result

    def prepare_write(
        self,
        session_id: str,
        address: int,
        value_type: ValueType,
        expected_current: int | float,
        new_value: int | float,
        reason: str,
        *,
        profile_id: str | None = None,
    ) -> WriteIntentView:
        session = self._get_session(session_id)
        expected_bytes = encode_value(value_type, expected_current)
        new_bytes = encode_value(value_type, new_value)
        region = self._region_for(session, address, len(new_bytes), require_readable=True)
        self.safety.validate_write(
            session,
            region,
            address=address,
            size=len(new_bytes),
            is_scan_candidate=self.scans.is_candidate(session_id, address, value_type),
            reason=reason,
        )
        if expected_bytes == new_bytes:
            raise SafetyError("the requested value is already present")
        actual_bytes = self.backend.read(session.backend_handle, address, len(expected_bytes))
        if actual_bytes != expected_bytes:
            actual = decode_value(value_type, actual_bytes)
            raise SafetyError(
                f"expected current value {expected_current}, but the address now contains {actual}"
            )
        intent_id = uuid4().hex
        now = datetime.now(UTC)
        phrase_value = self._format_value(new_value)
        intent = WriteIntent(
            id=intent_id,
            session_id=session_id,
            address=address,
            value_type=value_type,
            expected_current=expected_current,
            new_value=new_value,
            expected_bytes=expected_bytes,
            new_bytes=new_bytes,
            reason=reason.strip(),
            created_at=now,
            expires_at=now + timedelta(seconds=self.settings.write_intent_ttl_seconds),
            confirmation_phrase=f"WRITE {intent_id[:6].upper()} {phrase_value}",
            profile_id=profile_id,
        )
        with self._lock:
            self._intents[intent.id] = intent
        self.audit.record(
            "write_intent_prepared",
            intent_id=intent.id,
            session_id=session_id,
            pid=session.pid,
            address=f"0x{address:X}",
            value_type=value_type,
            expected_current=expected_current,
            new_value=new_value,
            reason=intent.reason,
        )
        return intent.view()

    def confirm_write(self, intent_id: str, confirmation_phrase: str) -> WriteResult:
        with self._lock:
            intent = self._get_intent(intent_id)
            if intent.used:
                raise SafetyError("this write intent has already been used")
            if datetime.now(UTC) >= intent.expires_at:
                raise SafetyError("this write intent has expired")
            if not secrets.compare_digest(confirmation_phrase, intent.confirmation_phrase):
                raise SafetyError("the confirmation phrase does not match")
            session = self._get_session(intent.session_id)
            if intent.profile_id is not None:
                resolved = self.unreal.read_profile(session, intent.profile_id)
                if resolved.profile.value_type is not intent.value_type:
                    raise SafetyError("the saved feature type changed after preparation")
                if resolved.address != intent.address:
                    raise SafetyError(
                        "the saved feature moved after preparation; review the action again"
                    )
            region = self._region_for(
                session, intent.address, len(intent.new_bytes), require_readable=True
            )
            self.safety.validate_write(
                session,
                region,
                address=intent.address,
                size=len(intent.new_bytes),
                is_scan_candidate=self.scans.is_candidate(
                    session.id, intent.address, intent.value_type
                ),
                reason=intent.reason,
            )
            actual_bytes = self.backend.read(
                session.backend_handle, intent.address, len(intent.expected_bytes)
            )
            if actual_bytes != intent.expected_bytes:
                raise SafetyError("the value changed after confirmation was prepared; start again")
            intent.used = True

        self.backend.write(session.backend_handle, intent.address, intent.new_bytes)
        verified_bytes = self.backend.read(
            session.backend_handle, intent.address, len(intent.new_bytes)
        )
        if verified_bytes != intent.new_bytes:
            raise SafetyError("write verification failed")
        result = self._write_receipt(
            session=session,
            intent_id=intent.id,
            operation_id=intent.id,
            address=intent.address,
            value_type=intent.value_type,
            original_bytes=intent.expected_bytes,
            written_bytes=verified_bytes,
        )
        self.audit.record(
            "write_confirmed",
            intent_id=intent.id,
            session_id=session.id,
            pid=session.pid,
            address=f"0x{intent.address:X}",
            value_type=intent.value_type,
            previous_value=intent.expected_current,
            new_value=result.new_value,
            verified=True,
            operation_id=result.operation_id,
            receipt_id=result.receipt_id,
            rollback_token=result.rollback_token,
        )
        return result

    def mutate_simulator(self, name: str, value: int | float) -> int:
        if not isinstance(self.backend, SimulatedMemoryBackend):
            raise ConfigurationError(
                "simulator controls are available only with the simulated backend"
            )
        return self.backend.set_named_value(name, value)

    def start_autonomous_discovery(
        self,
        session_id: str,
        *,
        target_order: list[str] | None = None,
        interval_seconds: float = 2.0,
        observation_seconds: float = 10.0,
        revisit_seconds: float = 30.0,
        background: bool = True,
    ) -> CheatDiscoveryRunStatus:
        session = self._get_session(session_id)
        result = self.discovery.start(
            session,
            target_order=target_order,
            interval_seconds=interval_seconds,
            observation_seconds=observation_seconds,
            revisit_seconds=revisit_seconds,
            background=background,
        )
        self.audit.record(
            "autonomous_discovery_started",
            run_id=result.id,
            session_id=session.id,
            pid=session.pid,
            process_name=session.process_name,
            target_order=result.target_order,
            write_enabled=session.write_enabled,
        )
        return result

    def start_waiting_autonomous_discovery(
        self,
        *,
        process_name: str = "NMS.exe",
        target_order: list[str] | None = None,
        interval_seconds: float = 2.0,
        observation_seconds: float = 10.0,
        revisit_seconds: float = 30.0,
        background: bool = True,
    ) -> CheatDiscoveryRunStatus:
        result = self.discovery.start_waiting(
            process_name,
            target_order=target_order,
            interval_seconds=interval_seconds,
            observation_seconds=observation_seconds,
            revisit_seconds=revisit_seconds,
            background=background,
        )
        self.audit.record(
            "autonomous_discovery_waiting",
            run_id=result.id,
            process_name=process_name,
            target_order=result.target_order,
            write_enabled=False,
        )
        return result

    def autonomous_discovery_status(self, run_id: str) -> CheatDiscoveryRunStatus:
        return self.discovery.status(run_id)

    def run_autonomous_discovery_cycle(self, run_id: str) -> CheatDiscoveryRunStatus:
        return self.discovery.run_cycle(run_id)

    def supervise_autonomous_discovery(self, run_id: str) -> CheatDiscoveryRunStatus:
        return self.discovery.supervise(run_id)

    def set_autonomous_discovery_value(
        self,
        run_id: str,
        target_name: str,
        value: int | float,
        *,
        source: str = "user",
    ) -> CheatDiscoveryRunStatus:
        return self.discovery.set_exact_value(run_id, target_name, value, source=source)

    def record_autonomous_discovery_screen_comparison(
        self,
        run_id: str,
        target_name: str,
        comparison: str,
        screen_value: int | float,
    ) -> CheatDiscoveryRunStatus:
        result = self.discovery.record_screen_comparison(
            run_id,
            target_name,
            comparison,
            screen_value,
        )
        self.audit.record(
            "autonomous_discovery_screen_comparison",
            run_id=run_id,
            target_name=target_name,
            comparison=comparison,
            screen_value=screen_value,
            candidate_count=next(
                (
                    target.candidate_count
                    for target in result.targets
                    if target.name.casefold() == target_name.casefold()
                ),
                0,
            ),
            game_memory_write=False,
        )
        return result

    def rescan_autonomous_discovery_values(
        self,
        run_id: str,
    ) -> CheatDiscoveryRunStatus:
        result = self.discovery.rescan_saved_values(run_id)
        self.audit.record(
            "autonomous_discovery_all_values_rescanned",
            run_id=run_id,
            save_snapshot_id=result.save_snapshot_id,
            save_rescan_count=result.save_rescan_count,
        )
        return result

    def capture_autonomous_discovery_behavior(
        self,
        run_id: str,
        target_name: str,
        phase: str,
        label: str = "",
    ) -> CheatDiscoveryRunStatus:
        normalized_phase = phase.strip().casefold()
        if normalized_phase == "begin":
            return self.discovery.begin_behavior_capture(run_id, target_name, label)
        if normalized_phase == "complete":
            return self.discovery.complete_behavior_capture(run_id, target_name)
        if normalized_phase == "cancel":
            return self.discovery.cancel_behavior_capture(run_id, target_name)
        raise SafetyError("behavior phase must be begin, complete, or cancel")

    def stop_autonomous_discovery(self, run_id: str) -> CheatDiscoveryRunStatus:
        result = self.discovery.stop(run_id)
        self.audit.record(
            "autonomous_discovery_stopped",
            run_id=run_id,
            session_id=result.session_id,
        )
        return result

    def close(self) -> None:
        self.inventory_observers.close()
        self.instruction_value_observers.close()
        self.discovery.close()
        with self._lock:
            session_ids = list(self._sessions)
        for session_id in session_ids:
            self.detach(session_id)

    def _resolve_confirmed_feature(self, session_id: str, feature_id: str):
        session = self._get_session(session_id)
        try:
            feature = self.catalogs.feature(session_id, feature_id)
        except KeyError as exc:
            raise NotFoundError(f"game cheat feature {feature_id} was not found") from exc
        if feature.source_kind != "confirmed_local_profile" or not feature.profile_id:
            raise SafetyError(
                "this feature is only an advisory hint; confirm its live behavior first"
            )
        resolved = self.unreal.read_profile(session, feature.profile_id)
        if feature.value_type is not None and feature.value_type != resolved.profile.value_type:
            raise SafetyError("the saved feature type no longer matches the live profile")
        return session, feature, resolved

    def _prepare_hold(
        self,
        session: ProcessSession,
        feature: GameCheatFeature,
        address: int,
        value_type: ValueType,
        expected_current: int | float,
        hold_value: int | float,
        *,
        interval_ms: int,
        duration_seconds: int,
        reason: str,
    ) -> HoldIntentView:
        if not 100 <= interval_ms <= 5000:
            raise SafetyError("hold interval must be between 100 and 5000 milliseconds")
        if not 1 <= duration_seconds <= min(self.settings.max_hold_seconds, 3600):
            raise SafetyError(
                f"hold duration must be between 1 and {self.settings.max_hold_seconds} seconds"
            )
        expected_bytes = encode_value(value_type, expected_current)
        hold_bytes = encode_value(value_type, hold_value)
        region = self._region_for(session, address, len(hold_bytes), require_readable=True)
        self.safety.validate_write(
            session,
            region,
            address=address,
            size=len(hold_bytes),
            is_scan_candidate=self.scans.is_candidate(session.id, address, value_type),
            reason=reason,
        )
        actual_bytes = self.backend.read(session.backend_handle, address, len(expected_bytes))
        if actual_bytes != expected_bytes:
            actual = decode_value(value_type, actual_bytes)
            raise SafetyError(
                f"expected current value {expected_current}, but the address now contains {actual}"
            )
        intent_id = uuid4().hex
        now = datetime.now(UTC)
        intent = HoldIntent(
            id=intent_id,
            session_id=session.id,
            feature_id=feature.id,
            feature_name=feature.name,
            profile_id=feature.profile_id,
            address=address,
            value_type=value_type,
            expected_current=expected_current,
            hold_value=hold_value,
            expected_bytes=expected_bytes,
            hold_bytes=hold_bytes,
            interval_ms=interval_ms,
            duration_seconds=duration_seconds,
            reason=reason,
            expires_at=now + timedelta(seconds=self.settings.write_intent_ttl_seconds),
            confirmation_phrase=(f"HOLD {intent_id[:6].upper()} {self._format_value(hold_value)}"),
        )
        with self._lock:
            self._hold_intents[intent.id] = intent
        self.audit.record(
            "game_cheat_hold_intent_prepared",
            intent_id=intent.id,
            session_id=session.id,
            feature_id=feature.id,
            feature_name=feature.name,
            address=f"0x{address:X}",
            value_type=value_type,
            hold_value=hold_value,
            interval_ms=interval_ms,
            duration_seconds=duration_seconds,
        )
        return intent.view()

    def _hold_worker(self, hold: ActiveHold) -> None:
        while not hold.stop_event.wait(hold.interval_ms / 1000):
            if datetime.now(UTC) >= hold.expires_at:
                self._finish_hold(hold, "configured duration completed")
                return
            try:
                with self._lock:
                    session = self._get_session(hold.session_id)
                    resolved = self.unreal.read_profile(session, hold.profile_id)
                    if resolved.profile.value_type is not hold.value_type:
                        raise SafetyError("the saved feature type changed during the value hold")
                    hold.address = resolved.address
                    self.scans.register_verified_candidate(
                        session.id,
                        hold.address,
                        hold.value_type,
                        resolved.value,
                    )
                    region = self._region_for(
                        session, hold.address, len(hold.hold_bytes), require_readable=True
                    )
                    self.safety.validate_write(
                        session,
                        region,
                        address=hold.address,
                        size=len(hold.hold_bytes),
                        is_scan_candidate=self.scans.is_candidate(
                            session.id, hold.address, hold.value_type
                        ),
                        reason=hold.reason,
                    )
                    current = self.backend.read(
                        session.backend_handle, hold.address, len(hold.hold_bytes)
                    )
                    if current == hold.hold_bytes:
                        continue
                    self.backend.write(session.backend_handle, hold.address, hold.hold_bytes)
                    verified = self.backend.read(
                        session.backend_handle, hold.address, len(hold.hold_bytes)
                    )
                    if verified != hold.hold_bytes:
                        raise SafetyError("hold write verification failed")
                    hold.write_count += 1
            except Exception as exc:
                self._finish_hold(hold, f"stopped safely: {exc}")
                return

    def _finish_hold(self, hold: ActiveHold, reason: str) -> None:
        with self._lock:
            if hold.stopped_reason is None:
                hold.stopped_reason = reason
            hold.stop_event.set()
        self.audit.record(
            "game_cheat_hold_finished",
            hold_id=hold.id,
            session_id=hold.session_id,
            reason=hold.stopped_reason,
            write_count=hold.write_count,
        )

    def _stop_session_holds(self, session_id: str, reason: str) -> None:
        with self._lock:
            holds = [item for item in self._holds.values() if item.session_id == session_id]
            for hold in holds:
                if hold.stopped_reason is None:
                    hold.stopped_reason = reason
                hold.stop_event.set()
        for hold in holds:
            if hold.thread is not None and hold.thread.is_alive():
                hold.thread.join(timeout=1)

    def _get_session(self, session_id: str) -> ProcessSession:
        try:
            return self._sessions[session_id]
        except KeyError as exc:
            raise NotFoundError(f"process session {session_id} was not found") from exc

    def _get_intent(self, intent_id: str) -> WriteIntent:
        try:
            return self._intents[intent_id]
        except KeyError as exc:
            raise NotFoundError(f"write intent {intent_id} was not found") from exc

    def _get_hold_intent(self, intent_id: str) -> HoldIntent:
        try:
            return self._hold_intents[intent_id]
        except KeyError as exc:
            raise NotFoundError(f"hold intent {intent_id} was not found") from exc

    def _region_for(
        self,
        session: ProcessSession,
        address: int,
        size: int,
        *,
        require_readable: bool,
    ) -> MemoryRegion:
        for region in self.backend.regions(session.backend_handle):
            if region.contains(address, size):
                if require_readable and not region.readable:
                    raise SafetyError("the target memory region is not readable")
                return region
        raise SafetyError(f"address range 0x{address:X}+{size} is not mapped in this session")

    @staticmethod
    def _format_value(value: int | float) -> str:
        if isinstance(value, float) and value.is_integer():
            return str(int(value))
        return str(value)

    @staticmethod
    def _create_backend(settings: Settings) -> MemoryBackend:
        backend_name = settings.backend
        if backend_name == "auto":
            backend_name = "windows" if sys.platform == "win32" else "simulated"
        if backend_name == "windows":
            return WindowsMemoryBackend()
        if backend_name == "simulated":
            return SimulatedMemoryBackend()
        raise ConfigurationError(f"unsupported backend: {backend_name}")


def _same_process_incarnation(session: ProcessSession, process: ProcessInfo) -> bool:
    """Return true only for two views of the same live OS process."""

    if session.pid != process.pid or session.process_name.casefold() != process.name.casefold():
        return False
    if session.process_started_at is not None or process.started_at is not None:
        return session.process_started_at == process.started_at
    return (session.executable or "").casefold() == (process.executable or "").casefold()
