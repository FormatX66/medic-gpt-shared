from __future__ import annotations

import hashlib
import json
import math
import queue
import shutil
import time
from collections import deque
from collections.abc import Callable
from copy import deepcopy
from dataclasses import dataclass, field
from pathlib import Path
from threading import Event, RLock, Thread
from uuid import uuid4

from gtp_games.codec import (
    decode_value,
    encode_value,
    iter_values,
    value_size,
    values_equal,
)
from gtp_games.config import Settings
from gtp_games.errors import BackendError, NotFoundError, ScanLimitError
from gtp_games.memory.base import MemoryBackend
from gtp_games.models import (
    Comparison,
    MemoryRegion,
    MemoryRegionKind,
    ProcessSession,
    ScanCandidate,
    ScanCandidateStability,
    ScanKind,
    ScanSummary,
    ValueType,
    WatchResult,
    WatchSample,
)


@dataclass
class ScanSegment:
    base_address: int
    size: int
    previous: bytes | None = None
    active: bytearray | None = None
    cache_path: Path | None = None


@dataclass(frozen=True)
class ScanScope:
    regions: list[MemoryRegion]
    eligible_bytes: int
    scope_truncated: bool


@dataclass
class ScanRecord:
    id: str
    session_id: str
    scan_kind: ScanKind
    value_type: ValueType
    comparison: Comparison
    normalized: bool = False
    target_value: int | float | None = None
    candidates: dict[int, int | float] = field(default_factory=dict)
    segments: list[ScanSegment] = field(default_factory=list)
    result_count: int = 0
    generation: int = 0
    truncated: bool = False
    scope_truncated: bool = False
    scanned_bytes: int = 0
    eligible_bytes: int = 0
    selected_region_count: int = 0
    cache_backed: bool = False
    cached_bytes: int = 0
    cache_reused: bool = False
    reused_from_scan_id: str | None = None
    process_pid: int | None = None
    process_started_at: float | None = None
    process_name: str | None = None
    executable: str | None = None
    scope_fingerprint: str | None = None
    stability: dict[int, _CandidateStats] = field(default_factory=dict)


@dataclass
class _CandidateStats:
    first_value: int | float
    current_value: int | float
    observations: int = 0
    changed: int = 0
    unchanged: int = 0
    increased: int = 0
    decreased: int = 0
    values: set[int | float] = field(default_factory=set)


ScanProgress = Callable[[int, int, int, int, int], None]


@dataclass
class _CacheWriteJob:
    path: Path
    data: bytes
    completed: Event = field(default_factory=Event)
    error: Exception | None = None


class _ScanCacheWriter:
    """Serialize scan-cache writes while the scanner fills the other buffer."""

    def __init__(self, directory: Path) -> None:
        directory.mkdir(parents=True, exist_ok=True)
        self.directory = directory
        self._jobs: queue.Queue[_CacheWriteJob | None] = queue.Queue(maxsize=2)
        self._thread = Thread(
            target=self._run,
            name="gtp-scan-cache-writer",
            daemon=True,
        )
        self._closed = False
        self._thread.start()

    def submit(self, path: Path, data: bytes) -> _CacheWriteJob:
        if self._closed:
            raise RuntimeError("scan cache writer is closed")
        job = _CacheWriteJob(path=path, data=data)
        self._jobs.put(job)
        return job

    def close(self) -> None:
        if self._closed:
            return
        self._closed = True
        self._jobs.put(None)
        self._thread.join()

    def _run(self) -> None:
        while True:
            job = self._jobs.get()
            try:
                if job is None:
                    return
                try:
                    _write_bytes_atomically(job.path, job.data)
                except Exception as exc:  # noqa: BLE001 - preserve the in-memory fallback
                    job.error = exc
                finally:
                    job.data = b""
                    job.completed.set()
            finally:
                self._jobs.task_done()


def _write_bytes_atomically(path: Path, data: bytes) -> None:
    temporary = path.with_suffix(".tmp")
    temporary.write_bytes(data)
    temporary.replace(path)


def _find_aligned(data: bytes, needle: bytes, alignment: int):
    """Yield aligned byte matches using the optimized bytes search primitive."""

    start = 0
    while True:
        offset = data.find(needle, start)
        if offset < 0:
            return
        if offset % alignment == 0:
            yield offset
        start = offset + 1


def select_scan_regions(
    regions: list[MemoryRegion],
    *,
    max_bytes: int,
    max_region_bytes: int,
    width: int,
) -> ScanScope:
    """Rank writable game data and return a bounded, aligned scan scope.

    Large regions are sliced instead of discarded. Modern games commonly keep
    mutable state in allocations hundreds of MiB wide, so rejecting a region
    solely because it exceeds the per-segment limit creates a silent blind spot.
    """

    eligible = [
        region
        for region in regions
        if region.committed
        and region.readable
        and region.writable
        and not region.executable
        and not region.guarded
        and region.kind
        in {
            MemoryRegionKind.PRIVATE,
            MemoryRegionKind.MAPPED,
            MemoryRegionKind.IMAGE,
        }
    ]
    eligible_bytes = sum(region.size for region in eligible)
    allocation_sizes: dict[int, int] = {}
    for region in eligible:
        allocation_base = region.allocation_base or region.base_address
        allocation_sizes[allocation_base] = allocation_sizes.get(allocation_base, 0) + region.size
    eligible.sort(key=lambda region: _region_priority(region, allocation_sizes))

    selected: list[MemoryRegion] = []
    remaining = max_bytes
    for region in eligible:
        if remaining < width:
            break
        region_offset = 0
        while region_offset + width <= region.size and remaining >= width:
            selected_size = min(
                region.size - region_offset,
                remaining,
                max_region_bytes,
            )
            selected_size -= selected_size % width
            if selected_size < width:
                break
            selected.append(
                region.model_copy(
                    update={
                        "base_address": region.base_address + region_offset,
                        "size": selected_size,
                    }
                )
            )
            region_offset += selected_size
            remaining -= selected_size
    selected_bytes = sum(region.size for region in selected)
    return ScanScope(
        regions=selected,
        eligible_bytes=eligible_bytes,
        scope_truncated=selected_bytes < eligible_bytes,
    )


def _region_priority(
    region: MemoryRegion,
    allocation_sizes: dict[int, int],
) -> tuple[int, int, int, int]:
    allocation_size = allocation_sizes.get(
        region.allocation_base or region.base_address,
        region.size,
    )
    kind_rank = {
        MemoryRegionKind.PRIVATE: 0,
        MemoryRegionKind.MAPPED: 1,
        MemoryRegionKind.IMAGE: 2,
    }.get(region.kind, 3)
    if region.main_module:
        tier = 0
    elif region.resident is True:
        tier = 1
    elif region.resident is None:
        tier = 2
    else:
        tier = 3
    # Do not demote a large allocation. Games routinely reserve hundreds of MiB
    # for mutable state; stable address order mirrors a conventional first scan.
    return (tier, kind_rank, region.base_address, allocation_size)


class ScanEngine:
    def __init__(self, backend: MemoryBackend, settings: Settings) -> None:
        self.backend = backend
        self.settings = settings
        self._scans: dict[str, ScanRecord] = {}
        self._lock = RLock()

    def register_verified_candidate(
        self,
        session_id: str,
        address: int,
        value_type: ValueType,
        value: int | float,
    ) -> str:
        """Register one live-resolved profile value without broad memory scanning."""

        record = ScanRecord(
            id=uuid4().hex,
            session_id=session_id,
            scan_kind=ScanKind.EXACT,
            value_type=value_type,
            comparison=Comparison.EXACT,
            candidates={address: value},
            result_count=1,
            selected_region_count=1,
        )
        with self._lock:
            self._scans[record.id] = record
        return record.id

    def register_targeted_exact_candidates(
        self,
        session: ProcessSession,
        value_type: ValueType,
        value: int | float,
        addresses: list[int],
    ) -> ScanSummary:
        """Register a bounded set of exact live reads derived from structural evidence."""

        unique_addresses = sorted(set(addresses))
        if not 1 <= len(unique_addresses) <= 32:
            raise ScanLimitError("targeted exact validation requires 1 to 32 addresses")
        expected = decode_value(value_type, encode_value(value_type, value))
        width = value_size(value_type)
        candidates: dict[int, int | float] = {}
        stability: dict[int, _CandidateStats] = {}
        for address in unique_addresses:
            try:
                current = decode_value(
                    value_type,
                    self.backend.read(session.backend_handle, address, width),
                )
            except BackendError:
                continue
            if not values_equal(value_type, current, expected):
                continue
            candidates[address] = current
            stability[address] = _CandidateStats(
                first_value=current,
                current_value=current,
                observations=1,
                unchanged=1,
                values={current},
            )
        record = ScanRecord(
            id=uuid4().hex,
            session_id=session.id,
            scan_kind=ScanKind.EXACT,
            value_type=value_type,
            comparison=Comparison.EXACT,
            target_value=expected,
            candidates=candidates,
            result_count=len(candidates),
            scanned_bytes=len(unique_addresses) * width,
            eligible_bytes=len(unique_addresses) * width,
            selected_region_count=len(unique_addresses),
            process_pid=session.pid,
            process_started_at=session.process_started_at,
            process_name=session.process_name,
            executable=session.executable,
            stability=stability,
        )
        with self._lock:
            self._scans[record.id] = record
        return self.summary(record.id, limit=32)

    def initial_exact_scan(
        self,
        session: ProcessSession,
        value_type: ValueType,
        value: int | float,
        *,
        progress: ScanProgress | None = None,
    ) -> ScanSummary:
        needle = encode_value(value_type, value)
        width = len(needle)
        scope = self._scan_scope(
            session,
            width,
            max_bytes=self.settings.max_exact_scan_bytes,
        )
        candidates: dict[int, int | float] = {}
        scanned_bytes = 0
        truncated = False
        completed_regions = 0
        total_bytes = sum(item.size for item in scope.regions)
        self._report_progress(progress, 0, total_bytes, 0, len(scope.regions), 0)

        for region in scope.regions:
            for address, chunk_size in self._chunk_ranges(region, width):
                scanned_bytes += chunk_size
                try:
                    data = self.backend.read(session.backend_handle, address, chunk_size)
                except BackendError:
                    continue
                for offset in _find_aligned(data, needle, width):
                    candidate_address = address + offset
                    candidates[candidate_address] = decode_value(
                        value_type, data[offset : offset + width]
                    )
                    if len(candidates) >= self.settings.max_scan_results:
                        truncated = True
                        break
                if truncated:
                    break
                self._report_progress(
                    progress,
                    scanned_bytes,
                    total_bytes,
                    completed_regions,
                    len(scope.regions),
                    len(candidates),
                )
            completed_regions += 1
            self._report_progress(
                progress,
                scanned_bytes,
                total_bytes,
                completed_regions,
                len(scope.regions),
                len(candidates),
            )
            if truncated:
                break

        record = ScanRecord(
            id=uuid4().hex,
            session_id=session.id,
            scan_kind=ScanKind.EXACT,
            value_type=value_type,
            comparison=Comparison.EXACT,
            target_value=value,
            candidates=candidates,
            result_count=len(candidates),
            truncated=truncated,
            scope_truncated=scope.scope_truncated,
            scanned_bytes=scanned_bytes,
            eligible_bytes=scope.eligible_bytes,
            selected_region_count=len(scope.regions),
            process_pid=session.pid,
            process_started_at=session.process_started_at,
            process_name=session.process_name,
            executable=session.executable,
            scope_fingerprint=_scope_fingerprint(scope.regions),
        )
        with self._lock:
            self._scans[record.id] = record
        self._cache_record_metadata(record)
        return self.summary(record.id)

    def initial_unknown_scan(
        self,
        session: ProcessSession,
        value_type: ValueType,
        *,
        normalized: bool = False,
        progress: ScanProgress | None = None,
    ) -> ScanSummary:
        if normalized and value_type not in {ValueType.F32, ValueType.F64}:
            raise ScanLimitError("normalized scans require f32 or f64")
        width = value_size(value_type)
        scope = self._scan_scope(session, width)
        record_id = uuid4().hex
        segments: list[ScanSegment] = []
        result_count = 0
        scanned_bytes = 0
        cached_bytes = 0
        completed_regions = 0
        total_bytes = sum(item.size for item in scope.regions)
        self._report_progress(progress, 0, total_bytes, 0, len(scope.regions), 0)
        writer = self._cache_writer(record_id)
        pending: deque[tuple[ScanSegment, _CacheWriteJob]] = deque()
        try:
            for region in scope.regions:
                for address, chunk_size in self._chunk_ranges(region, width):
                    if len(pending) >= 2:
                        cached_bytes += self._finish_cache_write(*pending.popleft())
                    scanned_bytes += chunk_size
                    try:
                        data = self.backend.read(session.backend_handle, address, chunk_size)
                    except BackendError:
                        continue
                    active, active_count = self._initial_active_mask(
                        value_type, data, normalized=normalized
                    )
                    segment = ScanSegment(
                        base_address=address,
                        size=len(data),
                        previous=data,
                        active=active,
                    )
                    segments.append(segment)
                    if writer is not None:
                        path = writer.directory / f"segment-{len(segments) - 1:05d}.bin"
                        pending.append((segment, writer.submit(path, data)))
                    result_count += active_count
                    self._report_progress(
                        progress,
                        scanned_bytes,
                        total_bytes,
                        completed_regions,
                        len(scope.regions),
                        result_count,
                    )
                completed_regions += 1
                self._report_progress(
                    progress,
                    scanned_bytes,
                    total_bytes,
                    completed_regions,
                    len(scope.regions),
                    result_count,
                )
            while pending:
                cached_bytes += self._finish_cache_write(*pending.popleft())
        finally:
            if writer is not None:
                writer.close()

        record = ScanRecord(
            id=record_id,
            session_id=session.id,
            scan_kind=ScanKind.UNKNOWN,
            value_type=value_type,
            comparison=Comparison.UNCHANGED,
            normalized=normalized,
            segments=segments,
            result_count=result_count,
            scope_truncated=scope.scope_truncated,
            scanned_bytes=scanned_bytes,
            eligible_bytes=scope.eligible_bytes,
            selected_region_count=len(scope.regions),
            cache_backed=cached_bytes > 0,
            cached_bytes=cached_bytes,
            process_pid=session.pid,
            process_started_at=session.process_started_at,
            process_name=session.process_name,
            executable=session.executable,
            scope_fingerprint=_scope_fingerprint(scope.regions),
        )
        with self._lock:
            self._scans[record.id] = record
        self._cache_record_metadata(record)
        return self.summary(record.id)

    def rescan(
        self,
        scan_id: str,
        session: ProcessSession,
        comparison: Comparison,
        value: int | float | None = None,
        *,
        progress: ScanProgress | None = None,
    ) -> ScanSummary:
        with self._lock:
            record = self._get(scan_id)
            if record.session_id != session.id:
                raise NotFoundError("scan does not belong to this process session")
            if comparison is Comparison.EXACT and value is None:
                raise ScanLimitError("an exact rescan requires a value")
            if record.scan_kind is ScanKind.UNKNOWN and record.segments:
                self._rescan_segments(record, session, comparison, value, progress)
            else:
                self._rescan_candidates(record, session, comparison, value, progress)
            record.comparison = comparison
            record.generation += 1
            record.truncated = False
            self._cache_record_metadata(record)
        return self.summary(scan_id)

    def watch(
        self,
        scan_id: str,
        session: ProcessSession,
        *,
        sample_count: int,
        interval_ms: int,
        limit: int,
    ) -> WatchResult:
        if not 1 <= sample_count <= 30:
            raise ScanLimitError("sample_count must be between 1 and 30")
        if not 100 <= interval_ms <= 5000:
            raise ScanLimitError("interval_ms must be between 100 and 5000")
        duration = (sample_count - 1) * interval_ms / 1000
        if duration > self.settings.max_watch_seconds:
            raise ScanLimitError(
                f"watch duration exceeds GTP_MAX_WATCH_SECONDS ({self.settings.max_watch_seconds})"
            )
        summary = self.summary(scan_id, limit=limit)
        if summary.session_id != session.id:
            raise NotFoundError("scan does not belong to this process session")
        addresses = [candidate.address for candidate in summary.candidates]
        width = value_size(summary.value_type)
        samples: list[WatchSample] = []
        for sample_index in range(sample_count):
            candidates: list[ScanCandidate] = []
            for address in addresses:
                try:
                    current = decode_value(
                        summary.value_type,
                        self.backend.read(session.backend_handle, address, width),
                    )
                except BackendError:
                    continue
                if self._value_allowed(summary.value_type, current, summary.normalized):
                    candidates.append(ScanCandidate(address=address, value=current))
            samples.append(WatchSample(candidates=candidates))
            if sample_index + 1 < sample_count:
                time.sleep(interval_ms / 1000)
        return WatchResult(
            scan_id=scan_id,
            session_id=session.id,
            value_type=summary.value_type,
            samples=samples,
        )

    def summary(self, scan_id: str, *, limit: int = 20) -> ScanSummary:
        with self._lock:
            record = self._get(scan_id)
            if record.scan_kind is ScanKind.UNKNOWN and record.segments:
                candidates = self._segment_sample(record, max(0, limit))
            else:
                candidates = [
                    ScanCandidate(address=address, value=value)
                    for address, value in sorted(record.candidates.items())[: max(0, limit)]
                ]
            return ScanSummary(
                id=record.id,
                session_id=record.session_id,
                scan_kind=record.scan_kind,
                value_type=record.value_type,
                normalized=record.normalized,
                comparison=record.comparison,
                generation=record.generation,
                result_count=record.result_count,
                truncated=record.truncated,
                scope_truncated=record.scope_truncated,
                scanned_bytes=record.scanned_bytes,
                eligible_bytes=record.eligible_bytes,
                selected_region_count=record.selected_region_count,
                cache_backed=record.cache_backed,
                cached_bytes=record.cached_bytes,
                cache_reused=record.cache_reused,
                reused_from_scan_id=record.reused_from_scan_id,
                candidates=candidates,
            )

    def is_candidate(self, session_id: str, address: int, value_type: ValueType) -> bool:
        with self._lock:
            for record in self._scans.values():
                if record.session_id != session_id or record.value_type != value_type:
                    continue
                if address in record.candidates:
                    return True
                width = value_size(value_type)
                for segment in record.segments:
                    offset = address - segment.base_address
                    if offset < 0 or offset % width or offset + width > segment.size:
                        continue
                    index = offset // width
                    return segment.active is not None and _bit_is_set(segment.active, index)
            return False

    def reuse_exact_scan(
        self,
        session: ProcessSession,
        value_type: ValueType,
        value: int | float,
    ) -> ScanSummary | None:
        """Restore a generation-zero exact scan only when its process scope still matches."""

        encoded = decode_value(value_type, encode_value(value_type, value))
        with self._lock:
            reusable = next(
                (
                    record
                    for record in reversed(list(self._scans.values()))
                    if record.session_id == session.id
                    and record.scan_kind is ScanKind.EXACT
                    and record.value_type is value_type
                    and record.generation == 0
                    and record.target_value is not None
                    and values_equal(value_type, record.target_value, encoded)
                    and record.result_count > 0
                ),
                None,
            )
            clone = self._clone_record(reusable, session.id) if reusable is not None else None
        if clone is not None:
            clone.cache_reused = True
            clone.reused_from_scan_id = reusable.id
            self._rescan_candidates(
                clone,
                session,
                Comparison.EXACT,
                encoded,
                None,
            )
            if clone.result_count > 0:
                with self._lock:
                    self._scans[clone.id] = clone
                self._cache_record_metadata(clone)
                return self.summary(clone.id)

        width = value_size(value_type)
        scope = self._scan_scope(
            session,
            width,
            max_bytes=self.settings.max_exact_scan_bytes,
        )
        expected_fingerprint = _scope_fingerprint(scope.regions)
        manifests = sorted(
            self.settings.scan_cache_directory.glob("*/scan.json"),
            key=lambda path: path.stat().st_mtime,
            reverse=True,
        )
        for manifest in manifests:
            try:
                payload = json.loads(manifest.read_text(encoding="utf-8"))
                if payload.get("scan_kind") != ScanKind.EXACT.value:
                    continue
                if payload.get("value_type") != value_type.value:
                    continue
                if int(payload.get("generation", -1)) != 0:
                    continue
                target = payload.get("target_value")
                if target is None or not values_equal(value_type, target, encoded):
                    continue
                if payload.get("process_pid") != session.pid:
                    continue
                if payload.get("process_started_at") != session.process_started_at:
                    continue
                if payload.get("scope_fingerprint") != expected_fingerprint:
                    continue
                restored_candidates = {
                    int(address): candidate_value
                    for address, candidate_value in payload.get("candidates", [])
                }
            except (OSError, TypeError, ValueError, json.JSONDecodeError):
                continue
            if not restored_candidates:
                continue
            restored = ScanRecord(
                id=uuid4().hex,
                session_id=session.id,
                scan_kind=ScanKind.EXACT,
                value_type=value_type,
                comparison=Comparison.EXACT,
                target_value=encoded,
                candidates=restored_candidates,
                result_count=len(restored_candidates),
                scanned_bytes=int(payload.get("scanned_bytes", 0)),
                eligible_bytes=int(payload.get("eligible_bytes", 0)),
                selected_region_count=int(payload.get("selected_region_count", 0)),
                cache_backed=True,
                cache_reused=True,
                reused_from_scan_id=str(payload.get("scan_id") or manifest.parent.name),
                process_pid=session.pid,
                process_started_at=session.process_started_at,
                process_name=session.process_name,
                executable=session.executable,
                scope_fingerprint=expected_fingerprint,
            )
            self._rescan_candidates(
                restored,
                session,
                Comparison.EXACT,
                encoded,
                None,
            )
            if restored.result_count == 0:
                continue
            with self._lock:
                self._scans[restored.id] = restored
            self._cache_record_metadata(restored)
            return self.summary(restored.id)
        return None

    def clone(self, scan_id: str, session_id: str) -> ScanSummary:
        """Fork a scan so an empty refinement can be discarded safely.

        Unknown scans normally keep their snapshots on disk. Clone those snapshots
        with same-volume hard links (falling back to copies) so temporal HUD scans can
        preserve the previous generation without rereading the whole process.
        """

        with self._lock:
            record = self._get(scan_id)
            if record.session_id != session_id:
                raise NotFoundError("scan does not belong to this process session")
            clone = self._clone_record(record, session_id)
            if record.segments:
                clone_directory = self.settings.scan_cache_directory / clone.id
                try:
                    clone_directory.mkdir(parents=True, exist_ok=False)
                    for index, (source, copied) in enumerate(
                        zip(record.segments, clone.segments, strict=True)
                    ):
                        if source.cache_path is None:
                            copied.previous = bytes(source.previous or b"")
                            copied.cache_path = None
                            continue
                        destination = clone_directory / f"segment-{index:05d}.bin"
                        try:
                            destination.hardlink_to(source.cache_path)
                        except OSError:
                            shutil.copy2(source.cache_path, destination)
                        copied.cache_path = destination
                        copied.previous = None
                    clone.cache_backed = True
                    clone.cached_bytes = record.cached_bytes
                except OSError as exc:
                    shutil.rmtree(clone_directory, ignore_errors=True)
                    raise ScanLimitError("disk-backed scan could not be cloned safely") from exc
            self._scans[clone.id] = clone
        self._cache_record_metadata(clone)
        return self.summary(clone.id)

    def candidate_stability(
        self,
        scan_id: str,
        *,
        limit: int = 200,
    ) -> list[ScanCandidateStability]:
        with self._lock:
            record = self._get(scan_id)
            items = sorted(
                record.stability.items(),
                key=lambda item: (
                    -item[1].changed,
                    -item[1].observations,
                    item[0],
                ),
            )[: max(0, limit)]
            return [
                ScanCandidateStability(
                    address=address,
                    observations=stats.observations,
                    changed=stats.changed,
                    unchanged=stats.unchanged,
                    increased=stats.increased,
                    decreased=stats.decreased,
                    distinct_values=max(1, len(stats.values)),
                    first_value=stats.first_value,
                    current_value=stats.current_value,
                )
                for address, stats in items
            ]

    def discard(self, scan_id: str) -> None:
        with self._lock:
            if scan_id in self._scans:
                del self._scans[scan_id]
        self._remove_cache(scan_id)

    @staticmethod
    def _clone_record(record: ScanRecord, session_id: str) -> ScanRecord:
        clone = deepcopy(record)
        clone.id = uuid4().hex
        clone.session_id = session_id
        if not clone.segments:
            clone.cache_backed = False
            clone.cached_bytes = 0
        return clone

    def remove_session(self, session_id: str) -> None:
        with self._lock:
            stale = [
                scan_id for scan_id, scan in self._scans.items() if scan.session_id == session_id
            ]
            for scan_id in stale:
                del self._scans[scan_id]
                self._remove_cache(scan_id)

    def _get(self, scan_id: str) -> ScanRecord:
        try:
            return self._scans[scan_id]
        except KeyError as exc:
            raise NotFoundError(f"scan {scan_id} was not found") from exc

    def _scan_scope(
        self,
        session: ProcessSession,
        width: int,
        *,
        max_bytes: int | None = None,
    ) -> ScanScope:
        return select_scan_regions(
            self.backend.regions(session.backend_handle),
            max_bytes=max_bytes or self.settings.max_scan_bytes,
            max_region_bytes=self.settings.max_scan_region_bytes,
            width=width,
        )

    def _chunk_ranges(self, region: MemoryRegion, width: int):
        offset = 0
        while offset + width <= region.size:
            chunk_size = min(self.settings.scan_chunk_bytes, region.size - offset)
            chunk_size -= chunk_size % width
            if chunk_size < width:
                return
            yield region.base_address + offset, chunk_size
            offset += chunk_size

    def _rescan_candidates(
        self,
        record: ScanRecord,
        session: ProcessSession,
        comparison: Comparison,
        value: int | float | None,
        progress: ScanProgress | None,
    ) -> None:
        next_candidates: dict[int, int | float] = {}
        width = value_size(record.value_type)
        total_bytes = len(record.candidates) * width
        processed_bytes = 0
        self._report_progress(progress, 0, total_bytes, 0, 1, 0)
        for address, previous in record.candidates.items():
            try:
                current = decode_value(
                    record.value_type,
                    self.backend.read(session.backend_handle, address, width),
                )
            except BackendError:
                continue
            if not self._value_allowed(record.value_type, current, record.normalized):
                continue
            if self._matches(record.value_type, comparison, previous, current, value):
                next_candidates[address] = current
                self._observe_candidate(record, address, previous, current)
            processed_bytes += width
            self._report_progress(
                progress, processed_bytes, total_bytes, 0, 1, len(next_candidates)
            )
        record.candidates = next_candidates
        record.result_count = len(next_candidates)
        self._report_progress(progress, processed_bytes, total_bytes, 1, 1, record.result_count)

    def _rescan_segments(
        self,
        record: ScanRecord,
        session: ProcessSession,
        comparison: Comparison,
        value: int | float | None,
        progress: ScanProgress | None,
    ) -> None:
        width = value_size(record.value_type)
        result_count = 0
        retained: list[ScanSegment] = []
        total_bytes = sum(segment.size for segment in record.segments)
        processed_bytes = 0
        self._report_progress(progress, 0, total_bytes, 0, len(record.segments), 0)
        writer = self._cache_writer(record.id)
        pending: deque[tuple[ScanSegment, _CacheWriteJob]] = deque()
        try:
            for segment_index, segment in enumerate(record.segments):
                if len(pending) >= 2:
                    self._finish_cache_write(*pending.popleft())
                previous_data = self._segment_data(segment)
                try:
                    current_data = self.backend.read(
                        session.backend_handle, segment.base_address, segment.size
                    )
                except BackendError:
                    continue
                slots = segment.size // width
                next_active = bytearray((slots + 7) // 8)
                if segment.active is None:
                    pairs = zip(
                        iter_values(record.value_type, previous_data),
                        iter_values(record.value_type, current_data),
                        strict=True,
                    )
                    indexes_and_values = (
                        (index, previous, current)
                        for index, (previous, current) in enumerate(pairs)
                    )
                else:
                    indexes_and_values = (
                        (
                            index,
                            decode_value(
                                record.value_type,
                                previous_data[index * width : (index + 1) * width],
                            ),
                            decode_value(
                                record.value_type,
                                current_data[index * width : (index + 1) * width],
                            ),
                        )
                        for index in _active_indexes(segment.active, slots)
                    )
                for index, previous, current in indexes_and_values:
                    if not self._value_allowed(record.value_type, current, record.normalized):
                        continue
                    if self._matches(record.value_type, comparison, previous, current, value):
                        _set_bit(next_active, index)
                        result_count += 1
                        self._observe_candidate(
                            record,
                            segment.base_address + index * width,
                            previous,
                            current,
                        )
                next_segment = ScanSegment(
                    base_address=segment.base_address,
                    size=len(current_data),
                    previous=current_data,
                    active=next_active,
                )
                retained.append(next_segment)
                if writer is not None and segment.cache_path is not None:
                    pending.append(
                        (
                            next_segment,
                            writer.submit(segment.cache_path, current_data),
                        )
                    )
                processed_bytes += len(current_data)
                self._report_progress(
                    progress,
                    processed_bytes,
                    total_bytes,
                    segment_index + 1,
                    len(record.segments),
                    result_count,
                )
            while pending:
                self._finish_cache_write(*pending.popleft())
        finally:
            if writer is not None:
                writer.close()
        record.segments = retained
        record.result_count = result_count
        record.cached_bytes = sum(
            segment.size for segment in retained if segment.cache_path is not None
        )
        if result_count <= self.settings.max_scan_results:
            self._compact_segment_candidates(record)

    def _initial_active_mask(
        self,
        value_type: ValueType,
        data: bytes,
        *,
        normalized: bool,
    ) -> tuple[bytearray | None, int]:
        width = value_size(value_type)
        slots = len(data) // width
        if value_type not in {ValueType.F32, ValueType.F64} and not normalized:
            return None, slots
        active = bytearray((slots + 7) // 8)
        count = 0
        for index, value in enumerate(iter_values(value_type, data)):
            if self._value_allowed(value_type, value, normalized):
                _set_bit(active, index)
                count += 1
        return active, count

    def _segment_sample(self, record: ScanRecord, limit: int) -> list[ScanCandidate]:
        if limit <= 0:
            return []
        width = value_size(record.value_type)
        sample: list[ScanCandidate] = []
        for segment in record.segments:
            previous_data = self._segment_data(segment)
            slots = segment.size // width
            indexes = (
                range(slots) if segment.active is None else _active_indexes(segment.active, slots)
            )
            for index in indexes:
                value = decode_value(
                    record.value_type,
                    previous_data[index * width : (index + 1) * width],
                )
                if not self._value_allowed(record.value_type, value, record.normalized):
                    continue
                sample.append(
                    ScanCandidate(
                        address=segment.base_address + index * width,
                        value=value,
                    )
                )
                if len(sample) >= limit:
                    return sample
        return sample

    def _cache_writer(self, scan_id: str) -> _ScanCacheWriter | None:
        try:
            directory = self.settings.scan_cache_directory / scan_id
            return _ScanCacheWriter(directory)
        except OSError:
            return None

    @staticmethod
    def _finish_cache_write(segment: ScanSegment, job: _CacheWriteJob) -> int:
        job.completed.wait()
        if job.error is not None:
            segment.cache_path = None
            return 0
        segment.cache_path = job.path
        segment.previous = None
        return segment.size

    @staticmethod
    def _segment_data(segment: ScanSegment) -> bytes:
        if segment.previous is not None:
            return segment.previous
        if segment.cache_path is None:
            raise ScanLimitError("cached scan segment is unavailable")
        try:
            data = segment.cache_path.read_bytes()
        except OSError as exc:
            raise ScanLimitError("cached scan segment could not be read") from exc
        if len(data) != segment.size:
            raise ScanLimitError("cached scan segment size does not match")
        return data

    def _compact_segment_candidates(self, record: ScanRecord) -> None:
        candidates: dict[int, int | float] = {}
        width = value_size(record.value_type)
        for segment in record.segments:
            data = self._segment_data(segment)
            slots = segment.size // width
            indexes = (
                range(slots) if segment.active is None else _active_indexes(segment.active, slots)
            )
            for index in indexes:
                value = decode_value(
                    record.value_type,
                    data[index * width : (index + 1) * width],
                )
                if self._value_allowed(record.value_type, value, record.normalized):
                    candidates[segment.base_address + index * width] = value
        if len(candidates) != record.result_count:
            return
        record.candidates = candidates
        for segment in record.segments:
            if segment.cache_path is not None:
                try:
                    segment.cache_path.unlink(missing_ok=True)
                except OSError:
                    pass
        record.segments = []
        record.cached_bytes = 0

    def _cache_record_metadata(self, record: ScanRecord) -> None:
        try:
            directory = self.settings.scan_cache_directory / record.id
            directory.mkdir(parents=True, exist_ok=True)
            payload = {
                "scan_id": record.id,
                "session_id": record.session_id,
                "scan_kind": record.scan_kind.value,
                "value_type": record.value_type.value,
                "comparison": record.comparison.value,
                "normalized": record.normalized,
                "target_value": record.target_value,
                "generation": record.generation,
                "result_count": record.result_count,
                "scanned_bytes": record.scanned_bytes,
                "eligible_bytes": record.eligible_bytes,
                "selected_region_count": record.selected_region_count,
                "cached_bytes": record.cached_bytes,
                "process_pid": record.process_pid,
                "process_started_at": record.process_started_at,
                "process_name": record.process_name,
                "executable": record.executable,
                "scope_fingerprint": record.scope_fingerprint,
                "cache_reused": record.cache_reused,
                "reused_from_scan_id": record.reused_from_scan_id,
                "segments": [
                    {
                        "base_address": segment.base_address,
                        "size": segment.size,
                        "file": segment.cache_path.name if segment.cache_path else None,
                    }
                    for segment in record.segments
                ],
                "candidates": [[address, value] for address, value in record.candidates.items()],
                "stability": {
                    str(address): {
                        "first_value": stats.first_value,
                        "current_value": stats.current_value,
                        "observations": stats.observations,
                        "changed": stats.changed,
                        "unchanged": stats.unchanged,
                        "increased": stats.increased,
                        "decreased": stats.decreased,
                        "values": sorted(stats.values),
                    }
                    for address, stats in record.stability.items()
                },
            }
            temporary = directory / "scan.tmp"
            manifest = directory / "scan.json"
            temporary.write_text(json.dumps(payload), encoding="utf-8")
            temporary.replace(manifest)
            record.cache_backed = record.cache_backed or bool(record.candidates)
            if record.scan_kind is ScanKind.EXACT:
                record.cached_bytes = manifest.stat().st_size
        except OSError:
            return

    def _remove_cache(self, scan_id: str) -> None:
        directory = self.settings.scan_cache_directory / scan_id
        try:
            if directory.parent.resolve() == self.settings.scan_cache_directory.resolve():
                shutil.rmtree(directory, ignore_errors=True)
        except OSError:
            return

    @staticmethod
    def _observe_candidate(
        record: ScanRecord,
        address: int,
        previous: int | float,
        current: int | float,
    ) -> None:
        stats = record.stability.get(address)
        if stats is None:
            stats = _CandidateStats(
                first_value=previous,
                current_value=current,
                values={previous},
            )
            record.stability[address] = stats
        stats.observations += 1
        stats.current_value = current
        stats.values.add(current)
        if current > previous:
            stats.changed += 1
            stats.increased += 1
        elif current < previous:
            stats.changed += 1
            stats.decreased += 1
        else:
            stats.unchanged += 1

    @staticmethod
    def _report_progress(
        progress: ScanProgress | None,
        processed_bytes: int,
        total_bytes: int,
        processed_regions: int,
        total_regions: int,
        result_count: int,
    ) -> None:
        if progress is not None:
            progress(
                processed_bytes,
                total_bytes,
                processed_regions,
                total_regions,
                result_count,
            )

    @staticmethod
    def _value_allowed(value_type: ValueType, value: int | float, normalized: bool) -> bool:
        if value_type not in {ValueType.F32, ValueType.F64}:
            return True
        numeric = float(value)
        return math.isfinite(numeric) and (not normalized or 0.0 <= numeric <= 1.0)

    @staticmethod
    def _matches(
        value_type: ValueType,
        comparison: Comparison,
        previous: int | float,
        current: int | float,
        target: int | float | None,
    ) -> bool:
        if comparison is Comparison.EXACT:
            assert target is not None
            encoded_target = decode_value(value_type, encode_value(value_type, target))
            return values_equal(value_type, current, encoded_target)
        if comparison is Comparison.CHANGED:
            return not values_equal(value_type, current, previous)
        if comparison is Comparison.UNCHANGED:
            return values_equal(value_type, current, previous)
        if comparison is Comparison.INCREASED:
            return current > previous
        if comparison is Comparison.DECREASED:
            return current < previous
        return False


def _set_bit(mask: bytearray, index: int) -> None:
    mask[index >> 3] |= 1 << (index & 7)


def _bit_is_set(mask: bytearray, index: int) -> bool:
    return bool(mask[index >> 3] & (1 << (index & 7)))


def _active_indexes(mask: bytearray, slots: int):
    return (index for index in range(slots) if _bit_is_set(mask, index))


def _scope_fingerprint(regions: list[MemoryRegion]) -> str:
    payload = "|".join(
        f"{region.base_address:X}:{region.size:X}:{region.kind.value}:{int(region.main_module)}"
        for region in regions
    )
    return hashlib.sha256(payload.encode()).hexdigest()
