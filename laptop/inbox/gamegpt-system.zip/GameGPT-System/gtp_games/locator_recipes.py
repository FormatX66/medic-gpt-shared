from __future__ import annotations

import os

from gtp_games.models import LocatorKind, MemoryLocator, ProcessSession

_NMS_CURRENCY_PATTERN = " ".join(
    [
        "48 8B 41 10 48 83 C1 10 FF 50 38",
        "44 88 B7 40 B1 01 00",
        "48 8B 05 ?? ?? ?? ??",
        "8B 88 8C BD 00 00",
    ]
)
_NMS_CURRENCY_OFFSETS = {
    "units": 0xBD8C,
    "nanites": 0xBD90,
    "quicksilver": 0xBD94,
}


def builtin_signature_pointer_locators(
    session: ProcessSession,
    label: str,
) -> list[MemoryLocator]:
    """Return data-only locator recipes translated from reviewed reference tables."""

    process_name = os.path.basename(session.executable or session.process_name).casefold()
    if process_name != "nms.exe":
        process_name = os.path.basename(session.process_name).casefold()
    field_offset = _NMS_CURRENCY_OFFSETS.get(label.strip().casefold())
    if process_name != "nms.exe" or field_offset is None:
        return []
    return [
        MemoryLocator(
            kind=LocatorKind.AOB_POINTER,
            module="NMS.exe",
            aob_pattern=_NMS_CURRENCY_PATTERN,
            # At +0x12: 48 8B 05 <disp32> loads the currency root slot.
            aob_offset=0x12,
            aob_displacement_offset=3,
            aob_instruction_size=7,
            pointer_offsets=[field_offset],
            match_count=1,
        )
    ]
