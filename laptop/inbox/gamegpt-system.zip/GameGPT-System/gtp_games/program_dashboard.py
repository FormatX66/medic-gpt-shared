"""Small GameGPT Workbench shell for Quick Action and Research Builder."""

from __future__ import annotations

import json
import subprocess
import sys
import tkinter as tk
from pathlib import Path
from tkinter import ttk

from .programs import MicrophoneGate


class ProgramDashboard:
    def __init__(self, root_path: Path) -> None:
        self.root_path = root_path
        self.gate = MicrophoneGate(start_muted=True)
        self.overlay_process: subprocess.Popen | None = None
        self.root = tk.Tk()
        self.root.title("GameGPT Workbench")
        self.root.geometry("900x600")
        self.tabs = ttk.Notebook(self.root)
        self.tabs.pack(fill="both", expand=True, padx=10, pady=10)
        self.quick = ttk.Frame(self.tabs)
        self.research = ttk.Frame(self.tabs)
        self.tabs.add(self.quick, text="Quick Action")
        self.tabs.add(self.research, text="Research Builder")
        self._build_quick()
        self._build_research()
        self.root.protocol("WM_DELETE_WINDOW", self.close)

    def _build_quick(self) -> None:
        self.mic_state = ttk.Label(self.quick, text="Microphone: Muted")
        self.mic_state.pack(anchor="w", pady=8)
        controls = ttk.Frame(self.quick)
        controls.pack(anchor="w")
        ttk.Button(controls, text="Mute / Unmute", command=self.toggle_mute).pack(side="left")
        ttk.Button(controls, text="Wait / Resume", command=self.toggle_wait).pack(side="left")
        ttk.Button(controls, text="Show Glenn", command=self.show_glenn).pack(side="left")
        ttk.Button(controls, text="Kill Glenn", command=self.kill_glenn).pack(side="left")
        ttk.Label(
            self.quick,
            text=(
                "Fast commands require current promoted actions. Unknown, ambiguous, stale, or "
                "quarantined commands fall through to Research Builder."
            ),
            wraplength=800,
        ).pack(anchor="w", pady=14)
        validated = json.loads(
            (self.root_path / "catalogs" / "validated-actions.json").read_text(encoding="utf-8")
        )
        self.action_list = tk.Listbox(self.quick, height=14)
        self.action_list.pack(fill="both", expand=True)
        if not validated["actions"]:
            self.action_list.insert("end", "No promoted actions — fast activation is fail-closed.")
        for action in validated["actions"]:
            self.action_list.insert("end", f"{action['game_id']}: {action['id']}")

    def _build_research(self) -> None:
        profiles = json.loads(
            (self.root_path / "research" / "game-profiles.json").read_text(encoding="utf-8")
        )
        ttk.Label(
            self.research,
            text="GPT-led research is submitted through the relay with no execution authority.",
        ).pack(anchor="w", pady=8)
        tree = ttk.Treeview(
            self.research,
            columns=("installed", "build", "next"),
            show="tree headings",
        )
        tree.heading("#0", text="Game")
        tree.heading("installed", text="Installed")
        tree.heading("build", text="Build")
        tree.heading("next", text="Next safe step")
        tree.column("#0", width=140)
        tree.column("installed", width=70)
        tree.column("build", width=240)
        tree.column("next", width=400)
        tree.pack(fill="both", expand=True)
        for profile in profiles["profiles"]:
            parent = tree.insert(
                "",
                "end",
                text=profile["game_id"],
                values=(profile["installed"], profile["build"], profile["next"]),
            )
            for capability, state in profile["states"].items():
                tree.insert(parent, "end", text=capability, values=(state, "", ""))

    def toggle_mute(self) -> None:
        if self.gate.snapshot.tape_visible:
            snapshot = self.gate.unmute()
        else:
            snapshot = self.gate.mute()
        self.mic_state.configure(text=f"Microphone: {snapshot.state_label}")

    def toggle_wait(self) -> None:
        if self.gate.snapshot.state.value == "waiting":
            snapshot = self.gate.resume()
        else:
            snapshot = self.gate.wait()
        self.mic_state.configure(text=f"Microphone: {snapshot.state_label}")

    def show_glenn(self) -> None:
        if self.overlay_process is None or self.overlay_process.poll() is not None:
            self.overlay_process = subprocess.Popen(
                [sys.executable, "-m", "gtp_games.glenn_overlay"],
                cwd=self.root_path,
                creationflags=0x08000000 if sys.platform == "win32" else 0,
            )

    def kill_glenn(self) -> None:
        if self.overlay_process is not None and self.overlay_process.poll() is None:
            self.overlay_process.terminate()
            self.overlay_process.wait(timeout=5)
        self.overlay_process = None

    def close(self) -> None:
        self.kill_glenn()
        self.root.destroy()

    def run(self) -> None:
        self.root.mainloop()


def main() -> None:
    root_path = Path(__file__).resolve().parents[2]
    ProgramDashboard(root_path).run()


if __name__ == "__main__":
    main()
