from __future__ import annotations

import ctypes
import queue
import sys
import threading
from ctypes import wintypes
from dataclasses import dataclass

WM_HOTKEY = 0x0312
WM_QUIT = 0x0012
MOD_ALT = 0x0001
MOD_CONTROL = 0x0002
MOD_SHIFT = 0x0004
MOD_NOREPEAT = 0x4000
GWL_EXSTYLE = -20
WS_EX_TRANSPARENT = 0x00000020
WS_EX_TOOLWINDOW = 0x00000080
WS_EX_TOPMOST = 0x00000008
WS_EX_NOACTIVATE = 0x08000000
HWND_TOPMOST = -1
SWP_NOSIZE = 0x0001
SWP_NOMOVE = 0x0002
SWP_NOACTIVATE = 0x0010
SWP_SHOWWINDOW = 0x0040
GA_ROOT = 2


@dataclass(frozen=True)
class WindowBounds:
    left: int
    top: int
    right: int
    bottom: int

    @property
    def width(self) -> int:
        return max(0, self.right - self.left)

    @property
    def height(self) -> int:
        return max(0, self.bottom - self.top)

    @property
    def area(self) -> int:
        return self.width * self.height

    def overlay_origin(self, width: int, height: int, *, margin: int = 16) -> tuple[int, int]:
        available_width = max(0, self.width - (2 * margin))
        available_height = max(0, self.height - (2 * margin))
        fitted_width = min(max(1, width), max(1, available_width))
        fitted_height = min(max(1, height), max(1, available_height))
        x = max(self.left + margin, self.right - fitted_width - margin)
        y = max(self.top + margin, self.bottom - fitted_height - margin)
        return x, y


@dataclass(frozen=True)
class WindowsHotkeySpec:
    modifiers: int
    virtual_key: int


def choose_game_window(candidates: list[WindowBounds]) -> WindowBounds | None:
    usable = [item for item in candidates if item.width >= 320 and item.height >= 240]
    return max(usable, key=lambda item: item.area, default=None)


def parse_windows_hotkey(sequence: str) -> WindowsHotkeySpec:
    parts = sequence.strip().strip("<>").split("-")
    if not parts or not parts[-1]:
        raise ValueError("the overlay shortcut is empty")
    modifiers = 0
    for modifier in parts[:-1]:
        normalized = modifier.casefold()
        if normalized == "control":
            modifiers |= MOD_CONTROL
        elif normalized == "alt":
            modifiers |= MOD_ALT
        elif normalized == "shift":
            modifiers |= MOD_SHIFT
        else:
            raise ValueError(f"unsupported overlay shortcut modifier: {modifier}")
    key = parts[-1].upper()
    if len(key) == 1 and key.isalnum():
        virtual_key = ord(key)
    elif key.startswith("F") and key[1:].isdigit() and 1 <= int(key[1:]) <= 12:
        virtual_key = 0x70 + int(key[1:]) - 1
    else:
        raise ValueError(f"unsupported overlay shortcut key: {parts[-1]}")
    return WindowsHotkeySpec(modifiers=modifiers | MOD_NOREPEAT, virtual_key=virtual_key)


def sparkline_points(
    values: list[float],
    *,
    width: int = 112,
    height: int = 26,
    padding: int = 2,
) -> list[float]:
    if not values:
        return []
    usable_width = max(1, width - (2 * padding))
    usable_height = max(1, height - (2 * padding))
    low = min(values)
    high = max(values)
    span = high - low
    points: list[float] = []
    for index, value in enumerate(values):
        x = padding + (usable_width * index / max(1, len(values) - 1))
        y = (
            padding + (usable_height / 2)
            if span == 0
            else padding + ((high - value) / span * usable_height)
        )
        points.extend((round(x, 3), round(y, 3)))
    return points


def process_is_running(pid: int) -> bool:
    if pid <= 0:
        return False
    try:
        import psutil

        process = psutil.Process(pid)
        return process.is_running() and process.status() != psutil.STATUS_ZOMBIE
    except (psutil.Error, OSError):
        return False


def find_game_window(pid: int) -> WindowBounds | None:
    if sys.platform != "win32" or pid <= 0:
        return None
    user32 = ctypes.WinDLL("user32", use_last_error=True)
    candidates: list[WindowBounds] = []
    callback_type = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)

    def visit(window, _lparam) -> bool:
        if not user32.IsWindowVisible(window) or user32.IsIconic(window):
            return True
        process_id = wintypes.DWORD()
        user32.GetWindowThreadProcessId(window, ctypes.byref(process_id))
        if int(process_id.value) != pid:
            return True
        rectangle = wintypes.RECT()
        if not user32.GetWindowRect(window, ctypes.byref(rectangle)):
            return True
        candidates.append(
            WindowBounds(
                left=int(rectangle.left),
                top=int(rectangle.top),
                right=int(rectangle.right),
                bottom=int(rectangle.bottom),
            )
        )
        return True

    callback = callback_type(visit)
    user32.EnumWindows(callback, 0)
    return choose_game_window(candidates)


def make_overlay_click_through(window_handle: int) -> bool:
    if sys.platform != "win32" or window_handle <= 0:
        return False
    user32 = ctypes.WinDLL("user32", use_last_error=True)
    window_handle = _top_level_window_handle(user32, window_handle)
    get_window_long = getattr(user32, "GetWindowLongPtrW", user32.GetWindowLongW)
    set_window_long = getattr(user32, "SetWindowLongPtrW", user32.SetWindowLongW)
    get_window_long.argtypes = [wintypes.HWND, ctypes.c_int]
    get_window_long.restype = ctypes.c_ssize_t
    set_window_long.argtypes = [wintypes.HWND, ctypes.c_int, ctypes.c_ssize_t]
    set_window_long.restype = ctypes.c_ssize_t
    current = int(get_window_long(window_handle, GWL_EXSTYLE))
    updated = current | WS_EX_TRANSPARENT | WS_EX_TOOLWINDOW | WS_EX_NOACTIVATE
    ctypes.set_last_error(0)
    result = int(set_window_long(window_handle, GWL_EXSTYLE, updated))
    return result != 0 or ctypes.get_last_error() == 0


def keep_overlay_topmost(window_handle: int) -> bool:
    """Reassert topmost without activating or moving the game-aligned overlay."""

    if sys.platform != "win32" or window_handle <= 0:
        return False
    user32 = ctypes.WinDLL("user32", use_last_error=True)
    window_handle = _top_level_window_handle(user32, window_handle)
    set_window_pos = user32.SetWindowPos
    set_window_pos.argtypes = [
        wintypes.HWND,
        wintypes.HWND,
        ctypes.c_int,
        ctypes.c_int,
        ctypes.c_int,
        ctypes.c_int,
        wintypes.UINT,
    ]
    set_window_pos.restype = wintypes.BOOL
    flags = SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE | SWP_SHOWWINDOW
    promoted = bool(
        set_window_pos(window_handle, HWND_TOPMOST, 0, 0, 0, 0, flags)
    )
    if promoted and _window_is_topmost(user32, window_handle):
        return True
    get_window_long = getattr(user32, "GetWindowLongPtrW", user32.GetWindowLongW)
    get_window_long.argtypes = [wintypes.HWND, ctypes.c_int]
    get_window_long.restype = ctypes.c_ssize_t
    if not int(get_window_long(window_handle, GWL_EXSTYLE)) & WS_EX_NOACTIVATE:
        return promoted
    # Windows can acknowledge the first call without changing bands for a newly
    # created no-activate window. The style still prevents focus activation.
    return bool(
        set_window_pos(
            window_handle,
            HWND_TOPMOST,
            0,
            0,
            0,
            0,
            flags & ~SWP_NOACTIVATE,
        )
    )


def overlay_is_topmost(window_handle: int) -> bool:
    """Return whether Windows currently keeps the overlay in the topmost band."""

    if sys.platform != "win32" or window_handle <= 0:
        return False
    user32 = ctypes.WinDLL("user32", use_last_error=True)
    window_handle = _top_level_window_handle(user32, window_handle)
    return _window_is_topmost(user32, window_handle)


def _window_is_topmost(user32, window_handle: int) -> bool:
    get_window_long = getattr(user32, "GetWindowLongPtrW", user32.GetWindowLongW)
    get_window_long.argtypes = [wintypes.HWND, ctypes.c_int]
    get_window_long.restype = ctypes.c_ssize_t
    return bool(int(get_window_long(window_handle, GWL_EXSTYLE)) & WS_EX_TOPMOST)


def _top_level_window_handle(user32, window_handle: int) -> int:
    """Resolve Tk's client HWND to the actual top-level Windows window."""

    get_ancestor = user32.GetAncestor
    get_ancestor.argtypes = [wintypes.HWND, wintypes.UINT]
    get_ancestor.restype = wintypes.HWND
    top_level = get_ancestor(wintypes.HWND(window_handle), GA_ROOT)
    return int(top_level or window_handle)


class WindowsGlobalHotkey:
    """Register one read-only shortcut and expose presses through a polled queue."""

    def __init__(self, sequence: str) -> None:
        self.sequence = sequence
        self.events: queue.SimpleQueue[bool] = queue.SimpleQueue()
        self.registered = False
        self.error: str | None = None
        self._ready = threading.Event()
        self._thread: threading.Thread | None = None
        self._thread_id: int | None = None

    def start(self, *, timeout: float = 1.0) -> bool:
        if sys.platform != "win32":
            self.error = "global overlay shortcuts are available only on Windows"
            return False
        if self._thread is not None and self._thread.is_alive():
            return self.registered
        try:
            spec = parse_windows_hotkey(self.sequence)
        except ValueError as exc:
            self.error = str(exc)
            return False
        self._thread = threading.Thread(
            target=self._message_loop,
            args=(spec,),
            name="gtp-overlay-hotkey",
            daemon=True,
        )
        self._thread.start()
        self._ready.wait(timeout)
        if not self._ready.is_set():
            self.error = "the overlay shortcut registration timed out"
        return self.registered

    def _message_loop(self, spec: WindowsHotkeySpec) -> None:
        user32 = ctypes.WinDLL("user32", use_last_error=True)
        kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
        self._thread_id = int(kernel32.GetCurrentThreadId())
        hotkey_id = 0x4754
        if not user32.RegisterHotKey(None, hotkey_id, spec.modifiers, spec.virtual_key):
            error_code = ctypes.get_last_error()
            self.error = f"shortcut is already in use (Windows error {error_code})"
            self._ready.set()
            return
        self.registered = True
        self._ready.set()
        message = wintypes.MSG()
        try:
            while user32.GetMessageW(ctypes.byref(message), None, 0, 0) > 0:
                if message.message == WM_HOTKEY and int(message.wParam) == hotkey_id:
                    self.events.put(True)
        finally:
            user32.UnregisterHotKey(None, hotkey_id)
            self.registered = False

    def pending_presses(self) -> int:
        count = 0
        while True:
            try:
                self.events.get_nowait()
            except queue.Empty:
                return count
            count += 1

    def close(self) -> None:
        thread_id = self._thread_id
        if sys.platform == "win32" and thread_id is not None:
            user32 = ctypes.WinDLL("user32", use_last_error=True)
            user32.PostThreadMessageW(thread_id, WM_QUIT, 0, 0)
        thread = self._thread
        if thread is not None and thread.is_alive():
            thread.join(timeout=0.5)
